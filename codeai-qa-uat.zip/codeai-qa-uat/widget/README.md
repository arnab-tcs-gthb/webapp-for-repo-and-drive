# Argo UAT Chrome Extension

A comprehensive Chrome extension for UAT (User Acceptance Testing) workflows with advanced element selection, issue tracking, and click blocking capabilities.

## 🌟 Key Features

### **Element Selection & Issue Tracking System**
- **Smart Element Selection**: Click any page element to capture detailed information
- **Issue Tracking Form**: Structured form with name, issue type, priority, and comments
- **Right Column Panel**: Dedicated issues list with real-time updates
- **Priority Color Coding**: Critical (red), High (orange), Medium (blue), Low (green)
- **Issue Management**: Add, view, and remove issues with confirmation dialogs
- **🆕 Search Functionality**: Real-time search across all issue fields with highlighting
- **🆕 URL Tracking**: Automatically captures and displays the page URL where each issue was reported
- **🆕 Collapsible Panel**: Independent collapse/expand button for issues list to save screen space
- **🆕 Element Selection Protection**: Collapse button excluded from element selection for seamless interaction
- **Smart Margins**: Automatic page margin adjustment for panel visibility

### **Advanced UAT Controls**
- **Click Blocking**: Prevents accidental interactions during testing
- **Page Margin Management**: Automatic 90px top margin for widget space
- **Smart Header Detection**: Identifies and handles fixed navigation elements
- **Persistent Settings**: All preferences saved across browser sessions
- **🆕 Panel State Memory**: Panel remembers its collapsed state
- **🆕 Smart Filtering**: Multi-field search with filtered/total counters and URL search capability
- **🆕 URL Parameter Activation**: Auto-activate widget via URL parameter `?openArgoWidget` for direct links and bookmarks

### **Professional UI/UX**
- **Floating Widget Bar**: Clean, professional header with Argo UAT branding
- **Form Validation**: Required fields with clear error messaging
- **Visual Feedback**: Cursor changes, element highlighting, smooth animations
- **Responsive Design**: Adapts to different screen sizes and layouts
- **🆕 Search Interface**: Modern search box with clear button and instant results
- **🆕 Collapsible Interface**: Space-saving panel design with smooth transitions

## 🚀 Quick Start Guide

### Installation
1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" in the top right corner
3. Click "Load unpacked" and select the `c:\POC\widget-page-uat` folder
4. The Argo UAT extension should appear in your Chrome toolbar

### Basic Usage
1. **Toggle Widget**: Click the extension icon or use `Shift + W` to show/hide
2. **Start Testing**: Click "Select Element" to enter selection mode
3. **Report Issues**: Click on page elements, fill out the form, and add to issues list
4. **Manage Issues**: View and manage all reported issues in the right panel
5. **Exit Mode**: Click "Stop Selecting" to return to normal browsing

### URL Parameter Activation
For quick access and team collaboration, you can activate the widget directly via URL:

```
https://yoursite.com?openArgoWidget
https://example.com/page?other=value&openArgoWidget
```

**Benefits:**
- **Direct Links**: Share URLs that automatically activate the widget
- **Bookmarks**: Create testing bookmarks for quick UAT sessions
- **Team Workflow**: Send links to team members with widget pre-activated
- **Documentation**: Include in testing procedures and bug reports
- **Clean URLs**: Parameter is automatically removed after activation

### Testing Workflow
1. **Navigate** to the page you want to test
2. **Enable** the Argo UAT extension (floating bar appears)
3. **Enter Selection Mode** (button turns red, cursor becomes crosshair)
4. **Click Elements** to report issues or enhancement requests
5. **Fill Form** with element name, issue type, priority, and comments
6. **Track Issues** in the right column panel with full details
7. **Export Results** (future feature) for team collaboration

## 📝 Issue Types Available

- **🐛 Bug**: Functional errors or unexpected behavior
- **✨ Enhancement**: Improvement suggestions or new features
- **👤 Usability**: User experience issues or confusing interfaces
- **⚡ Performance**: Slow loading, lag, or optimization needs
- **♿ Accessibility**: Screen reader, keyboard navigation, or contrast issues
- **👁️ Visual**: Layout problems, design inconsistencies, or styling issues
- **⚙️ Functional**: Missing features or broken workflows

## 🛠️ Technical Architecture

### Files Structure
- `manifest.json` - Extension configuration with Argo UAT branding and permissions
- `popup.html/css/js` - Extension popup with toggle controls and settings
- `background.js` - Service worker for extension lifecycle management
- `content.js` - Main functionality with element selection and issue tracking
- `content.css` - Styling for floating widget, forms, and animations
- `test-page.html` - Comprehensive testing page with various element types
- `TESTING-GUIDE.md` - Complete installation and testing documentation
- `icons/` - PNG and SVG icons for the extension

### Core Technologies
- **Chrome Extensions API**: For browser integration and permissions
- **Event Interception**: Clean click blocking without DOM manipulation
- **CSS Grid/Flexbox**: Responsive layouts for forms and issue cards
- **Local Storage**: Persistent settings and preferences
- **ES6+ JavaScript**: Modern syntax with arrow functions and destructuring
- **URL Parameter Detection**: Automatic widget activation via URL queries with SPA support
- **History API Monitoring**: Real-time URL change detection for modern web applications

### Security & Privacy
- **Local Storage Only**: No data sent to external servers
- **Minimal Permissions**: Only requires `activeTab`, `storage`, and `tabs`
- **No Tracking**: Extension operates entirely offline
- **Clean Uninstall**: Removes all data when extension is uninstalled

## 🔧 Development & Customization

### Adding New Issue Types
Edit the `issue-type-select` options in `content.js`:
```javascript
<option value="security">Security Issue</option>
<option value="compatibility">Browser Compatibility</option>
```

### Modifying Priority Colors
Update the `priorityColors` object in the `updateIssuesDisplay` function:
```javascript
const priorityColors = {
    critical: '#f44336',
    urgent: '#e91e63',  // New priority level
    high: '#ff9800',
    // ... etc
};
```

### Customizing UI Styling
Modify the inline styles in `content.js` or add to `content.css` for external styling.

### URL Parameter Configuration
The widget automatically detects the `openArgoWidget` parameter. To customize this behavior:

```javascript
// In content.js - modify the checkUrlParameters function
function checkUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Add custom parameters
    if (urlParams.has('openArgoWidget') || urlParams.has('customParam')) {
        // Activation logic
    }
}
```

**Supported URL Patterns:**
- `?openArgoWidget` - Basic activation
- `?openArgoWidget=true` - Explicit activation
- `?other=value&openArgoWidget` - Mixed with other parameters
- `#section?openArgoWidget` - Works with hash routing

## 📊 Future Enhancement Ideas

- **Export Functionality**: Export issues to CSV, JSON, or integrate with issue tracking systems
- **Team Collaboration**: Share issue lists between team members
- **Screenshot Capture**: Automatically capture screenshots of selected elements
- **Integration APIs**: Connect with Jira, GitHub Issues, or other project management tools
- **Analytics Dashboard**: Track testing progress and issue patterns
- **Mobile Testing**: Extend support for mobile device testing

## 📄 License

This project is open source and available under the MIT License.

---

**Ready for professional UAT testing workflows! 🌱**
