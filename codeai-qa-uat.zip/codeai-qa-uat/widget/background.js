// Background script for Chrome extension
chrome.runtime.onInstalled.addListener(function(details) {
    if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        console.log('Chrome Widget extension installed');
          // Set default settings
        chrome.storage.local.set({
            darkTheme: false,
            userNotes: '',
            savedPages: [],
            floatingWidgetEnabled: true
        });
    }
});

// Handle extension icon click
chrome.action.onClicked.addListener(function(tab) {
    // This will open the popup, but we can add additional functionality here
    console.log('Extension icon clicked on tab:', tab.title);
});

// Listen for tab updates to potentially update widget data
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete') {
        // Tab finished loading, we can perform actions here if needed
        console.log('Tab updated:', tab.title);
    }
});

// Handle messages from content scripts or popup
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'savePageData') {
        // Handle saving page data
        chrome.storage.local.get(['savedPages'], function(result) {
            const savedPages = result.savedPages || [];
            savedPages.push(request.data);
            chrome.storage.local.set({savedPages: savedPages});
        });
    }
    
    if (request.action === 'getTabInfo') {
        // Return current tab information
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            sendResponse({
                url: tabs[0].url,
                title: tabs[0].title
            });
        });
        return true; // Keep the messaging channel open for async response
    }
});
