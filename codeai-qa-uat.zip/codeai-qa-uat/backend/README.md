# ARGO Backend

This is the backend service for the ARGO platform, built with FastAPI and designed for modular, scalable AI-powered document and project management. The backend provides RESTful APIs for project, page, image, template, and AI-driven analysis operations.

## Features
- **Project & Page Management:** CRUD APIs for projects and pages, with support for metadata, templates, and status tracking.
- **Image Handling:** Upload, process, and analyze images using AI (Google Gemini integration), with support for captions and matched images.
- **Document Generation:** Automated document generation and publishing, including integration with Google Drive and AEM templates.
- **AI Integration:** Endpoints for AI-powered text and image analysis, mapping UI components, and generating knowledge base content.
- **Template Management:** Manage and use AEM templates for document and page generation.
- **User Acceptance Testing (UAT):** Track UAT feedback and status for pages and projects.
- **Knowledge Base:** Generate and serve YAML-based knowledge base files for block/component mapping.
- **Logging & Error Handling:** Centralized logging and robust error handling throughout the API.

## Project Structure
```
backend/
  app/
    api/           # FastAPI routers (v1, etc.)
    core/          # Core config, logging
    crud/          # CRUD operations for models
    db/            # Database session and base
    helper/        # Utility scripts (e.g., docx to yaml)
    models/        # SQLAlchemy models (Project, Page, Image, etc.)
    repositories/  # Repository pattern for DB access
    schemas/       # Pydantic schemas for validation
    services/      # Business logic, AI, file upload, etc.
  static/          # Uploaded and processed files
  output/          # Generated documents and exports
  aem_block_kb/    # Knowledge base YAMLs and related files
  logs/            # Application and error logs
  database.db      # SQLite database (default)
  requirements.txt # Python dependencies
  README.md        # This file
```

## Setup & Installation

1. **Clone the repository:**
   ```zsh
   git clone <repo-url>
   cd codeai/backend
   ```
2. **Create and activate a virtual environment:**
   ```zsh
   python3 -m venv venv
   source venv/bin/activate
   ```
3. **Install dependencies:**
   ```zsh
   pip install -r requirements.txt
   ```
4. **Configure environment variables:**
   - Copy `.env.example` to `.env` and set required values (e.g., database URL, API keys).
   - Set `GEMINI_API_KEY` for Google Gemini integration.
5. **Run database migrations (if using Alembic):**
   ```zsh
   alembic upgrade head
   ```
6. **Start the FastAPI server:**
   ```zsh
   uvicorn app.main:app --reload
   ```

## Usage
- Access the API docs at: `http://localhost:8000/docs`
- Use the provided endpoints for project, page, image, template, and AI operations.
- Upload files to `/static/` and generated documents will appear in `/output/`.

## Key Endpoints
- `/projects/` - Project CRUD
- `/projects/{project_id}/pages/` - Page CRUD
- `/projects/{project_id}/images/` - Image upload and analysis
- `/analyze` - AI-driven image analysis
- `/generate-doc` - Document generation
- `/aem-templates/` - Template management
- `/kb-metadata` - Knowledge base info

## Development & Contribution
- Follow PEP8 and use type hints where possible.
- Organize new logic into the appropriate `services/`, `repositories/`, or `schemas/` modules.
- Add/modify tests as needed (pytest recommended).
- Log issues and feature requests in the repository.

## License
This project is licensed under the MIT License.

## Contact
For support or contributions, please open an issue or contact the maintainers.
