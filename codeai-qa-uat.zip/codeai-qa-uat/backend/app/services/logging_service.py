from app.repositories.log_entry_repo import create_log_entry
from app.schemas.log_entry import LogEntryCreate
from sqlalchemy.orm import Session

def log_event(
    db: Session,
    project_id: int,
    page_id: str,
    log_output: str,
    llm_input_tokens: int = None,
    llm_output_tokens: int = None,
    llm_total_tokens: int = None,
    llm_input: str = None,
    llm_output: str = None,
    extra: dict = None
):
    log = LogEntryCreate(
        project_id=project_id,
        page_id=page_id,
        log_output=log_output,
        llm_input_tokens=llm_input_tokens,
        llm_output_tokens=llm_output_tokens,
        llm_total_tokens=llm_total_tokens,
        llm_input=llm_input,
        llm_output=llm_output,
        extra=extra
    )
    return create_log_entry(db, log)
