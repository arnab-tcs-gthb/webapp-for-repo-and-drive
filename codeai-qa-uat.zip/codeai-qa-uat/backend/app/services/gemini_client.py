import logging
from google.genai import types

def call_gemini_api(client, model, img_bytes, prompt):
    """
    Calls the Gemini API with the given image bytes and prompt, returns the raw response text.
    Args:
        client: Gemini API client
        model: Model name
        img_bytes: Image bytes
        prompt: Prompt string
    Returns:
        str: Raw response text from Gemini API
    Raises:
        Exception: If the API call fails
    """
    logger = logging.getLogger(__name__)
    try:
        contents = [
            types.Content(
                role="user",
                parts=[
                    types.Part.from_bytes(mime_type="image/png", data=img_bytes),
                    types.Part.from_text(text=prompt),
                ],
            )
        ]
        config = types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_budget=0),
            response_mime_type="text/plain",
        )
        logger.debug(f"Calling Gemini API with model: {model}")
        chunks = client.models.generate_content_stream(
            model=model, contents=contents, config=config
        )
        raw = ""
        for chunk in chunks:
            if hasattr(chunk, 'text'):
                raw += chunk.text
        logger.debug(f"Received response from Gemini API (first 200 chars): {raw[:200]}...")
        return raw
    except Exception as e:
        logger.error(f"Error calling Gemini API: {str(e)}")
        raise
