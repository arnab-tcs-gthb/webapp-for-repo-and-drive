from app.repositories.images_repo import ImagesRepository
from app.repositories.projects_repo import ProjectsRepo
from app.services.image_processing import ImageProcessingService
from app.helper.gemini_openai_helper import call_gemini_openai
import json
import logging
import re
import os
from app.helper.doc_format import Document, process_docx_tables
from app.helper.google_docs import upload_docx_as_gdoc
from app.helper.md_to_docx import html_to_docx
from app.services.generate_docs_service import GenerateDocsService
from app.services.mapping_service import MappingService
from google.genai import types
from app.repositories.pages_repo import PagesRepo
from app.services.logging_service import log_event

image_dir = "images"
output_dir = "output"

logger = logging.getLogger(__name__)


try:
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    model = "gemini-2.5-pro-preview-05-06"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None


logger = logging.getLogger(__name__)
class AnalyzeService:
    def __init__(self, db=None):
        self.db = db

    async def analyze_image_service(self, project_id, page_id=None, analyze_flag=False):
        try:
            if page_id == 0:
                page_id = None
            image_repo = ImagesRepository(db=self.db)
            if page_id is None:
                projectImages = image_repo.get_images_by_project(project_id=project_id)
            else:
                projectImages = image_repo.get_images_by_page(page_id=page_id)
            if not projectImages:
                logger.warning(f"No images found for id {project_id}")
                return {"error": "No images found for this project", "results": []}
            try:
                page_repo = PagesRepo(self.db)
                logger.info(f"Starting parallel processing of {len(projectImages)} images...")
                image_results = []
                for i, indivProject in enumerate(projectImages):
                    try:
                        page_repo.update_status(page_id=indivProject.page_id, status="in-progress")
                        page_repo.update_status(page_id=indivProject.page_id, status="in-progress", action="analysis")
                        logger.info(f"Processing image {i+1}/{len(projectImages)}: {indivProject.filepath}")
                        result = await self.process_image(indivProject, project_id, analyze_flag)
                        # --- LOGGING ---
                        try:
                            # Ensure UUID string for project_id and page_id
                            project_uuid = str(getattr(indivProject, 'project_id', project_id))
                            page_uuid = str(getattr(indivProject, 'page_id', None))
                            llm_input = None
                            llm_output = None
                            llm_input_tokens = None
                            llm_output_tokens = None
                            llm_total_tokens = None
                            if isinstance(result, dict):
                                llm_input = result.get('llm_input')
                                llm_output = result.get('llm_output')
                                llm_input_tokens = result.get('llm_input_tokens')
                                llm_output_tokens = result.get('llm_output_tokens')
                                llm_total_tokens = result.get('llm_total_tokens')
                            log_result = log_event(
                                db=self.db,
                                project_id=project_uuid,
                                page_id=page_uuid,
                                log_output=str(result),
                                llm_input=llm_input,
                                llm_output=llm_output,
                                llm_input_tokens=llm_input_tokens,
                                llm_output_tokens=llm_output_tokens,
                                llm_total_tokens=llm_total_tokens
                            )
                            logger.debug(f"Log entry created: {log_result}")
                        except Exception as log_err:
                            logger.error(f"Error logging analyze_image_service: {log_err}")
                        # --- END LOGGING ---
                        if not isinstance(result, dict):
                            logger.warning(f"Image {indivProject.filepath} returned non-dict result: {type(result)}")
                        elif "components" not in result:
                            logger.warning(f"Image {indivProject.filepath} missing 'components' key in result. Result keys: {list(result.keys())}")
                        page_repo.update_analysis_data(indivProject.page_id, result)
                        page_repo.update_status(page_id=indivProject.page_id, status="completed", action="analysis")
                        image_results.append(result)
                        logger.info(f"Successfully processed image {i+1}: {indivProject.filepath}")
                    except Exception as individual_err:
                        logger.error(f"Error processing individual image {indivProject.filepath}: {str(individual_err)}")
                        image_results.append({
                            "page_title": f"Error Processing Image {i+1}",
                            "components": [
                                {
                                    "type": "error",
                                    "properties": {
                                        "title": "Image Processing Error",
                                        "description": f"Failed to process image: {str(individual_err)}"
                                    },
                                    "layout": "full-width",
                                    "element_type": "page-building"
                                }
                            ]
                        })
                logger.info(f"Completed processing {len(image_results)} images")
                return self.analyze_image_resp(image_results, no_of_images=len(projectImages))
            except Exception as gather_err:
                logger.error(f"Error during parallel image processing: {str(gather_err)}")
                return {
                    "error": f"Error during image analysis: {str(gather_err)}",
                    "results": [],
                    "no_of_images": len(projectImages),
                    "success": False
                }
        except Exception as e:
            logger.error(f"Unhandled exception in analyze endpoint: {str(e)}")
            try:
                page_repo.update_status(page_id=getattr(indivProject, 'page_id', None), status="error", action="analysis")
            except Exception as status_err:
                logger.error(f"Error updating page status: {str(status_err)}")
            return {
                "error": f"Unhandled exception: {str(e)}",
                "results": [],
                "success": False
            }
        finally:
            try:
                self.db.close()
            except Exception as close_err:
                logger.error(f"Error closing DB session: {str(close_err)}")

    def _extract_json(self, raw: str) -> str:
        try:
            if not raw:
                logger.warning("Empty raw text provided to _extract_json")
                return '{}'
            raw = re.sub(r"```(?:json)?\s*", "", raw).replace("```", "").strip()
            start, end = raw.find("{"), raw.rfind("}")
            if start != -1 and end != -1 and end > start:
                json_str = raw[start: end + 1]
                try:
                    json.loads(json_str)
                    return json_str
                except json.JSONDecodeError:
                    logger.debug("First JSON extraction attempt failed, trying alternatives")
            json_matches = re.findall(r'\{(?:[^{}]|"(?:\\.|[^"\\])*")*\}', raw)
            for match in json_matches:
                try:
                    json.loads(match)
                    return match
                except json.JSONDecodeError:
                    continue
            cleaned = raw.strip()
            if not (cleaned.startswith('{') and cleaned.endswith('}')):
                cleaned = '{' + cleaned + '}'
            cleaned = re.sub(r"(?<!\\)'([^']*?)(?<!\\)'", r'"\1"', cleaned)
            try:
                json.loads(cleaned)
                return cleaned
            except json.JSONDecodeError:
                logger.warning("All JSON extraction methods failed, returning empty object")
                return '{}'
        except Exception as e:
            logger.error(f"Error in _extract_json: {str(e)}")
            return '{}'

    def analyze_image(self, image_path: str, captions: dict = None) -> dict:
        try:
            page_name_from_image_path = image_path.split("/")[-1]
            try:
                with open(image_path, "rb") as f:
                    img_bytes = f.read()
                logger.debug(f"Successfully read image: {image_path}")
            except Exception as e:
                logger.error(f"Error reading image file {image_path}: {str(e)}")
                raise RuntimeError(f"Could not read image file: {str(e)}")
            try:
                mapping_service = MappingService(self.db)
                block_info = mapping_service.get_block_info()
                if hasattr(captions, '__dict__'):
                    captions_dict = {}
                    if hasattr(captions, 'captions'):
                        if isinstance(captions.captions, dict):
                            captions_dict = {'captions': captions.captions}
                        else:
                            captions_dict = {'captions': {}}
                    elif hasattr(captions, 'dict') and callable(getattr(captions, 'dict')):
                        captions_dict = captions.dict()
                    elif hasattr(captions, 'model_dump') and callable(getattr(captions, 'model_dump')):
                        captions_dict = captions.model_dump()
                elif isinstance(captions, dict):
                    captions_dict = captions
                else:
                    logger.warning(f"Could not convert captions to dict, using empty dict. Type: {type(captions)}")
                    captions_dict = {'captions': {}}
                try:
                    captions_str = json.dumps(captions_dict, indent=2, default=str)
                except Exception as json_err:
                    logger.error(f"Error serializing captions to JSON: {str(json_err)}")
                    captions_str = "{}"
            except Exception as e:
                logger.error(f"Error preparing prompt data: {str(e)}")
                raise RuntimeError(f"Error preparing prompt data: {str(e)}")
            prompt = f"""
    You have perfect vision and pay great attention to detail, making you an expert at analyzing user interfaces.
    Identify the UI components in this image and map them to AEM block types.
    **Instructions:**
    - Identify and classify **all UI sections** in the image, including both:
    - **Global elements** (such as header, footer, navigation bars, etc.)
    - **Page-building elements** (such as hero, cards, carousels, columns, etc.)
    - For each section/component, do the following:
    1. Assign the most appropriate AEM block type (choose from both global and page-building elements).
    2. Specify required properties (title, description, image references, etc.).
    3. Note any special styling or layout requirements.
    4. Indicate the markdown template to use (from the block list below).
    5. Using your own internal reasoning and understanding of the image content, estimate and include a confidence_score field (ranging from 0 to 1) that reflects how certain you are about the classification of this component.
    **Available AEM block types and descriptions:**
    {block_info}
    **Image Captioning Context:**
    You are provided with the following Asset image along with its captions for reference:
    {captions_str}
    Return your response as clean, parseable JSON with this structure:
    {{
    "page_title": "Title for the page",
    "original_file_name": {page_name_from_image_path},
    "components": [
        {{
        "type": "component_type",
        "properties": {{
            "title": "Component title",
            "description": "Description text",
            "imageRef": "image reference path from provided captions",
        }},
        "layout": "layout information",
        "markdown_template": "block_type",
        "element_type": "page-building or global"
        "confidence_score": "confidence score"
        }}
    ]
    }}
    Think step by step before providing the final JSON output.
    """.strip()
            try:
                contents = [
                    types.Content(
                        role="user",
                        parts=[
                            types.Part.from_bytes(mime_type="image/png", data=img_bytes),
                            types.Part.from_text(text=prompt),
                        ],
                    )
                ]

                config = types.GenerateContentConfig(
                    thinking_config=types.ThinkingConfig(thinking_budget=0),
                    response_mime_type="text/plain",
                )
                chunks = client.models.generate_content_stream(
                    model=model, contents=contents, config=config
                )
                # Process chunks
                raw = ""
                chunk_count = 0
                token_data = {}
                for chunk in chunks:
                    logger.debug(f"Gemini chunk: {chunk}")
                    logger.debug(f"Gemini chunk dir: {dir(chunk)}")
                    if hasattr(chunk, 'text'):
                        raw += chunk.text
                        chunk_count += 1
                    # Try to extract token usage if present in chunk
                    if hasattr(chunk, 'usage') and chunk.usage:
                        logger.debug(f"Gemini chunk.usage: {chunk.usage}")
                        token_data = {
                            'llm_input_tokens': getattr(chunk.usage, 'prompt_tokens', None),
                            'llm_output_tokens': getattr(chunk.usage, 'completion_tokens', None),
                            'llm_total_tokens': getattr(chunk.usage, 'total_tokens', None)
                        }
                # raw = call_gemini_openai(image_bytes=img_bytes, prompt=prompt)
            except Exception as e:
                logger.error(f"Error calling Gemini API: {str(e)}")
                raise RuntimeError(f"Error calling Gemini API: {str(e)}")
            try:
                payload = self._extract_json(raw)
                result = json.loads(payload)
                logger.debug(f"Successfully parsed JSON to dictionary with {len(result)} keys")
                # Attach token data if available
                if token_data:
                    result['llm_input_tokens'] = token_data.get('llm_input_tokens')
                    result['llm_output_tokens'] = token_data.get('llm_output_tokens')
                    result['llm_total_tokens'] = token_data.get('llm_total_tokens')
                # Attach token data to result for logging
                logger.info(f"Token usage - Input: {result.get('llm_input_tokens', 0)}, Output: {result.get('llm_output_tokens', 0)}, Total: {result.get('llm_total_tokens', 0)}")
                if not isinstance(result, dict):
                    logger.error(f"Invalid response format: Expected dict, got {type(result)}")
                    raise ValueError(f"Invalid response format: Expected dict, got {type(result)}")
                if "components" not in result:
                    logger.error(f"Missing 'components' in response. Keys: {list(result.keys())}")
                    result["components"] = []
                    logger.warning(f"Auto-fixed missing 'components' key in response")
                if "page_title" not in result:
                    logger.warning(f"Missing 'page_title' in response")
                    result["page_title"] = "Untitled Page"
                if "components" in result and not isinstance(result["components"], list):
                    logger.error(f"'components' is not a list: {type(result['components'])}")
                    result["components"] = []
                logger.info(f"Successfully analyzed image: {image_path}")
                return result
            except json.decoder.JSONDecodeError as e:
                logger.error(f"JSON decode error in analyze_image: {str(e)}")
                logger.debug(f"Raw response received: {raw[:500]}...")
                raise RuntimeError(f"Error processing image JSON: {str(e)}")
            except Exception as e:
                logger.error(f"Unexpected error in analyze_image: {str(e)}")
                raise RuntimeError(f"Error processing image: {str(e)}")
        except Exception as e:
            logger.error(f"Error in analyze_image: {str(e)}")
            raise RuntimeError(f"Error in analyze_image: {str(e)}")

    def analyze_image_resp(self, process_data, no_of_images):
        try:
            image_count = 0
            link_count = 0
            block_count = 0
            form_count = 0
            video_count = 0
            processingData = {}
            processingData['llm_response'] = process_data
            processingData['pages'] = len(process_data)
            for page in process_data:
                if not isinstance(page, dict):
                    logger.warning(f"Skipping non-dict page: {type(page)}")
                    continue
                if "components" not in page:
                    logger.warning(f"Skipping page without 'components' key. Keys: {list(page.keys())}")
                    continue
                if not isinstance(page["components"], list):
                    logger.warning(f"'components' is not a list: {type(page['components'])}")
                    continue
                for component in page["components"]:
                    if not isinstance(component, dict):
                        logger.warning(f"Skipping non-dict component: {type(component)}")
                        continue
                    if component.get("type"):
                        block_count += 1
                    if "properties" in component:
                        if "imageRef" in component["properties"] and component["properties"]["imageRef"]:
                            image_count += 1
                        if "items" in component["properties"]:
                            for item in component["properties"]["items"]:
                                if "imageRef" in item and item["imageRef"]:
                                    image_count += 1
                    if "properties" in component:
                        if "navigation_links" in component["properties"]:
                            link_count += len(component["properties"]["navigation_links"])
                        if "utility_icons" in component["properties"]:
                            link_count += len(component["properties"]["utility_icons"])
                        if "items" in component["properties"]:
                            for item in component["properties"]["items"]:
                                if "link_url" in item or "link" in item:
                                    link_count += 1
                        if "cta_button" in component["properties"] and "url" in component["properties"]["cta_button"]:
                            link_count += 1
                    if "properties" in component:
                        if "forms" in component["properties"]:
                            form_count += len(component["properties"]["forms"])
                    if "properties" in component:
                        if "videos" in component["properties"]:
                            video_count += len(component["properties"]["videos"])
            processingData['blocks'] = block_count
            processingData['images'] = image_count
            processingData['links'] = link_count
            processingData['forms'] = form_count
            processingData['videos'] = video_count
            progress_percentage = (processingData['pages'] / no_of_images) * 100 if no_of_images > 0 else 0
            processingData['progress'] = f"{processingData['pages']}/{no_of_images} ({progress_percentage:.2f}%)"
            return processingData
        except Exception as e:
            logger.error(f"Error in analyze_image_resp: {str(e)}")
            return {"error": str(e)}

    def create_page_from_components(self, page_title: str, components: list, output_folder: str) -> str:
        try:
            os.makedirs(output_folder, exist_ok=True)
            os.makedirs(f"{output_folder}/global", exist_ok=True)
            doc = Document(title=page_title)
            for comp in components:
                comp_type = comp.get("type")
                properties = comp.get("properties", {})
                element_type = comp.get("element_type", "page-building")
                if element_type == "global":
                    doc.add_global_component(
                        comp_type=comp_type,
                        title=properties.get("title", ""),
                        text=properties.get("description", ""),
                        image=properties.get("imageRef", ""),
                    )
                else:
                    doc.add_component(
                        comp_type=comp_type,
                        title=properties.get("title", ""),
                        text=properties.get("description", ""),
                        image=properties.get("imageRef", ""),
                    )
            generate_docs_service = GenerateDocsService(self.db)
            slug = generate_docs_service._slug(page_title)
            html_path = f"{output_folder}/boilerplate.html"
            docx_path = f"{output_folder}/boilerplate.docx"
            with open(html_path, "w") as f:
                f.write(doc.generate_html())
            html_to_docx(html_path, docx_path)
            process_docx_tables(docx_path)
            return html_path
        except Exception as e:
            logger.error(f"Error creating page from components: {str(e)}")
            return ""

    def generate_doc_from_json_components(self, data, project_name):
        try:
            output_folder = f"{output_dir}/{project_name}"
            page_title = data.get("page_title", "Untitled Page")
            components = data.get("components", [])
            html_path = self.create_page_from_components(page_title, components, output_folder)
            if html_path:
                try:
                    docx_path = html_path.replace(".html", ".docx")
                    gdoc_url = upload_docx_as_gdoc(docx_path)
                    return {
                        "html_path": html_path,
                        "docx_path": docx_path,
                        "gdoc_url": gdoc_url
                    }
                except Exception as e:
                    logger.error(f"Error uploading to Google Docs: {str(e)}")
                    return {
                        "html_path": html_path,
                        "docx_path": html_path.replace(".html", ".docx"),
                        "error": str(e)
                    }
            return {"error": "Failed to create document"}
        except Exception as e:
            logger.error(f"Error generating doc from components: {str(e)}")
            return {"error": str(e)}

    async def process_image(self, indivProject, project_id, analyze_flag):
        try:
            print(indivProject.llm_response)
            print(indivProject.llm_processed)
            print(analyze_flag)
            if (indivProject.llm_response is not None) and (indivProject.llm_processed is True) and (analyze_flag is False):
                try:
                    image_data = indivProject.llm_response
                    image_data = json.loads(image_data)
                except json.decoder.JSONDecodeError as json_err:
                    logger.error(f"Error parsing stored JSON for image {indivProject.filepath}: {str(json_err)}")
            else:
                projects_repo = ProjectsRepo(self.db)
                project_details = projects_repo.get_project_by_id(project_id=project_id)
                analyze_args = {"image_path": indivProject.filepath}
                if indivProject.matched_images is not None:
                    analyze_args["matched_images"] = indivProject.matched_images
                if project_details.captions is not None:
                    analyze_args["captions"] = project_details.captions
                logger.info(f"Analyzing image: {indivProject.filepath}")
                image_data = self.analyze_image(**analyze_args)
            image_id = indivProject.id
            service = ImageProcessingService(self.db)
            try:
                await service.mark_as_processed(
                    image_id=image_id,
                    llm_response=image_data,
                    success=True
                )
            except Exception as db_err:
                logger.error(f"Error saving analysis results to database: {str(db_err)}")
            return image_data
        except Exception as e:
            logger.error(f"Error processing image {indivProject.filepath}: {str(e)}")
            return {
                "page_title": "Error Processing Image",
                "components": [
                    {
                        "type": "error",
                        "properties": {
                            "title": "Image Processing Error",
                            "description": f"Failed to process image: {str(e)}"
                        },
                        "layout": "full-width",
                        "element_type": "page-building"
                    }
                ]
            }

