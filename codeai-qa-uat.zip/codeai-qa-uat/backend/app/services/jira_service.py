import logging
from typing import Optional, Dict, Any
from jira import JIRA, JIRAError
from app.core.config import settings
from app.schemas.jira_schemas import EpicCreate, StoryCreate, TaskCreate, SubtaskCreate

logger = logging.getLogger(__name__)

_jira_client_instance: Optional[JIRA] = None


def validate_project_access(jira: JIRA, project_key: str) -> bool:
    """Validate that the project exists and the user has create permissions."""
    try:
        project = jira.project(project_key)
        logger.info(f"Jira project validation successful for: {project.name} ({project.key})")

        # Check for create permissions
        create_meta = jira.createmeta(projectKeys=project_key, expand='projects.issuetypes.fields')
        if not create_meta['projects']:
            logger.error(
                f"User '{settings.JIRA_USER_EMAIL}' does not have create permissions for project '{project_key}'.")
            raise PermissionError(f"User '{settings.JIRA_USER_EMAIL}' does not have create permissions for project '{project_key}'.")
        logger.info(f"User '{settings.JIRA_USER_EMAIL}' has create permissions for project '{project_key}'.")
        return True
    except JIRAError as e:
        if e.status_code == 404:
            logger.error(f"Jira project '{project_key}' not found or not accessible.")
            raise FileNotFoundError(f"Jira project '{project_key}' not found or not accessible.")
        elif e.status_code == 403:
            logger.error(f"User '{settings.JIRA_USER_EMAIL}' forbidden from accessing Jira project '{project_key}'.")
            raise PermissionError(f"User '{settings.JIRA_USER_EMAIL}' forbidden from accessing Jira project '{project_key}'.")
        else:
            logger.error(f"Error validating Jira project '{project_key}': {e.text}", exc_info=True)
            raise RuntimeError(f"Error validating Jira project '{project_key}': {e.text}")
    except Exception as e:  # Catch any other unexpected errors
        logger.error(f"Unexpected error during Jira project validation for '{project_key}': {e}", exc_info=True)
        raise RuntimeError(f"Unexpected error during Jira project validation for '{project_key}': {e}")


def get_jira_client_instance() -> Optional[JIRA]:
    """Initializes and returns a JIRA client instance, caching it."""
    global _jira_client_instance
    if _jira_client_instance:
        return _jira_client_instance

    if not all([settings.JIRA_BASE_URL, settings.JIRA_USER_EMAIL, settings.JIRA_API_TOKEN, settings.JIRA_PROJECT_KEY]):
        logger.error("Jira configuration (URL, Username, API Token, or Project Key) is incomplete in settings.")
        raise RuntimeError("Jira configuration (URL, Username, API Token, or Project Key) is incomplete in settings.")

    try:
        jira_options = {'server': str(settings.JIRA_BASE_URL)}
        client = JIRA(
            options=jira_options,
            basic_auth=(settings.JIRA_USER_EMAIL, settings.JIRA_API_TOKEN),
            timeout=20  # seconds
        )
        # Test connection by fetching current user
        user_info = client.myself()
        display_name = user_info.get('displayName', user_info.get('name', 'Unknown User'))
        logger.info(f"Jira client initialized successfully for server: {settings.JIRA_BASE_URL}, user: {display_name}")

        # Validate project access after successful client initialization
        validate_project_access(client, settings.JIRA_PROJECT_KEY)
        _jira_client_instance = client
        return client
    except JIRAError as e:
        logger.error(
            f"Jira authentication or connection error during client initialization: {e.text}. "
            f"Status: {e.status_code}. URL: {e.url}",
            exc_info=True
        )
        raise RuntimeError(f"Jira authentication or connection error during client initialization: {e.text}. Status: {e.status_code}. URL: {e.url}")
    except Exception as e:
        logger.error(f"Unexpected error initializing Jira client: {e}", exc_info=True)
        raise RuntimeError(f"Unexpected error initializing Jira client: {e}")


def create_jira_epic(jira: JIRA, epic_data: EpicCreate) -> Dict[str, Any]:
    issue_dict = {
        'project': {'key': settings.JIRA_PROJECT_KEY},
        'summary': epic_data.summary,
        'issuetype': {'name': settings.JIRA_EPIC_ISSUE_TYPE_NAME},
    }
    description_parts = []
    if epic_data.description:
        description_parts.append(epic_data.description)

    # Use epic_name for summary if summary is not detailed, or for custom field
    effective_epic_name = epic_data.epic_name or epic_data.summary

    if settings.JIRA_EPIC_NAME_CUSTOM_FIELD_ID:
        issue_dict[settings.JIRA_EPIC_NAME_CUSTOM_FIELD_ID] = effective_epic_name
        logger.info(
            f"Using Epic Name custom field '{settings.JIRA_EPIC_NAME_CUSTOM_FIELD_ID}' with value: {effective_epic_name}")
    elif epic_data.epic_name:  # If no custom field, append to description
        description_parts.append(f"Epic Name (from input): {epic_data.epic_name}")

    issue_dict['description'] = "\n\n".join(description_parts).strip() or effective_epic_name  # Fallback description

    logger.info(f"Creating Epic with payload: {issue_dict}")
    new_issue = jira.create_issue(fields=issue_dict)
    return {"key": new_issue.key, "id": new_issue.id, "self_url": new_issue.self}


def create_jira_story(jira: JIRA, story_data: StoryCreate) -> Dict[str, Any]:
    issue_dict = {
        'project': {'key': settings.JIRA_PROJECT_KEY},
        'summary': story_data.summary,
        'description': story_data.description or "",  # Ensure description is at least an empty string
        'issuetype': {'name': settings.JIRA_STORY_ISSUE_TYPE_NAME},
    }
    if story_data.epic_link_key:
        if settings.JIRA_EPIC_LINK_CUSTOM_FIELD_ID:
            issue_dict[settings.JIRA_EPIC_LINK_CUSTOM_FIELD_ID] = story_data.epic_link_key
            logger.info(
                f"Linking Story to Epic '{story_data.epic_link_key}' using custom field '{settings.JIRA_EPIC_LINK_CUSTOM_FIELD_ID}'.")
        else:
            logger.warning(
                f"Attempted to link Story to Epic '{story_data.epic_link_key}', but JIRA_EPIC_LINK_CUSTOM_FIELD_ID is not configured. Story will not be linked."
            )

    logger.info(f"Creating Story with payload: {issue_dict}")
    new_issue = jira.create_issue(fields=issue_dict)
    return {"key": new_issue.key, "id": new_issue.id, "self_url": new_issue.self}


def create_jira_task(jira: JIRA, task_data: TaskCreate) -> Dict[str, Any]:
    issue_dict = {
        'project': {'key': settings.JIRA_PROJECT_KEY},
        'summary': task_data.summary,
        'description': task_data.description or "",
        'issuetype': {'name': settings.JIRA_TASK_ISSUE_TYPE_NAME},
    }
    logger.info(f"Creating Task with payload: {issue_dict}")
    new_issue = jira.create_issue(fields=issue_dict)
    return {"key": new_issue.key, "id": new_issue.id, "self_url": new_issue.self}


def create_jira_subtask(jira: JIRA, subtask_data: SubtaskCreate) -> Dict[str, Any]:
    if not subtask_data.parent_key:  # Should be caught by Pydantic, but good to double check
        raise ValueError("Parent key is absolutely required for creating a sub-task.")
    issue_dict = {
        'project': {'key': settings.JIRA_PROJECT_KEY},  # Subtasks inherit project from parent but good to be explicit
        'summary': subtask_data.summary,
        'description': subtask_data.description or "",
        'issuetype': {'name': settings.JIRA_SUBTASK_ISSUE_TYPE_NAME},
        'parent': {'key': subtask_data.parent_key},
    }
    logger.info(f"Creating Subtask for parent '{subtask_data.parent_key}' with payload: {issue_dict}")
    new_issue = jira.create_issue(fields=issue_dict)
    return {"key": new_issue.key, "id": new_issue.id, "self_url": new_issue.self}