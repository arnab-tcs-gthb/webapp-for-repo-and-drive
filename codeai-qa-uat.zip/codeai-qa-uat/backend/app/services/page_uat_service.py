from app.repositories.page_uat_repo import PageUATRepository
from fastapi import HTTPException
from app.services.page_service import PageService
class PageUATService:
    def __init__(self, db=None):
        self.db = db


    async def get_uat_data_service(self, **kwargs):
        try:
            all_page_data = {}
            all_page_data["ticket_detail"] = []
            uat_repo = PageUATRepository(self.db)
            print(type(kwargs))
            print(kwargs)
            page_service =  PageService(self.db)
            pages_data = await page_service.get_pages_by_project_id(project_id=kwargs["project_id"])

            for data in pages_data:
                kwargs['page_id'] = data.id
                print(kwargs)
                page_uat_data=  uat_repo.get_data_by_id(**kwargs)
                print(page_uat_data)
                all_page_data["ticket_detail"].append({
                    "jira_url":page_uat_data.jira if page_uat_data else None,
                    "jira_id":page_uat_data.jira.split("/")[-1] if page_uat_data else None,
                    "page_name":data.page_name,
                    "preview_url":data.preview_url,
                    "page_id": data.id
                })

            return all_page_data
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))