from sqlalchemy.orm import Session
from typing import Optional
from app.models.image import Image
from app.schemas.image import ImageCreate, ImageUpdate, ImageLLMUpdate

def get_image(db: Session, image_id: int):
    return db.query(Image).filter(Image.id == image_id).first()

def get_images_by_project(db: Session, project_id: int, skip: int = 0, limit: int = 100):
    return db.query(Image).filter(Image.project_id == project_id).offset(skip).limit(limit).all()

def create_image(db: Session, image: ImageCreate):
    db_image = Image(**image.dict())
    db.add(db_image)
    db.commit()
    db.refresh(db_image)
    return db_image

def update_image(db: Session, image_id: int, image: ImageUpdate):
    db_image = get_image(db, image_id)
    if not db_image:
        return None
    update_data = image.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_image, field, value)
    db.commit()
    db.refresh(db_image)
    return db_image

async def update_image_llm_data(db: Session, image_id: int, llm_data: ImageLLMUpdate) -> Optional[Image]:
    db_image = await get_image(db, image_id)
    if not db_image:
        return None
    db_image.llm_processed = llm_data.llm_processed
    db_image.llm_response = llm_data.llm_response
    db.commit()
    db.refresh(db_image)
    return db_image

def delete_image(db: Session, image_id: int):
    db_image = get_image(db, image_id)
    if not db_image:
        return False
    db.delete(db_image)
    db.commit()
    return True

async def update_llm_processing(
    db: Session,
    image_id: int,
    processed: bool,
    response: str
) -> Optional[Image]:
    """Direct database update without Pydantic overhead"""
    image = db.query(Image).filter(Image.id == image_id).first()
    if not image:
        return None
    image.llm_processed = processed
    image.llm_response = response
    db.commit()
    db.refresh(image)
    return image