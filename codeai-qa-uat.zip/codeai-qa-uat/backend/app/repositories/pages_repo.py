
from app.models.page import Page
from fastapi import HTTPException,status


class PagesRepo:
    def __init__(self,db = None):
        self.db = db


    def get_page_by_url(self, page_url):
        try:
            existing_page = self.db.query(Page).filter(Page.page_url == page_url).first()
            return existing_page
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    def get_page_by_name(self, page_name):
        try:
            existing_page = self.db.query(Page).filter(Page.page_name == page_name).first()
            return existing_page
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    def get_page_by_id(self, page_id):
        try:
            existing_page = self.db.query(Page).filter(Page.id == page_id).all()
            return existing_page
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    def get_page_by_project_id(self, project_id):
        try:
            get_pages = self.db.query(Page).filter(Page.project_id == project_id).all()
            return get_pages
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    
    def create_page(self, page):
        try:
            db_page = Page(**page.dict())
            self.db.add(db_page)
            self.db.commit()
            self.db.refresh(db_page)
            return db_page
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))
    
    def update_status(self,page_id:int, status:str, action = None):
        if action is not None:
            update_body = {
                action:status,

            }
        else:
            update_body = {
                "page_status":status,

            }
            
        try:
            self.db.query(Page).filter(Page.id==page_id).update(update_body)
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))
        
    def update_analysis_data(self, page_id, data):
        update_body = {
            "page_components":data
        }
        try:
            self.db.query(Page).filter(Page.id==page_id).update(update_body)
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))
    
    def update_mapping_data(self, page_id, data):
        update_body = {
            "mapping_data":data
        }
        try:
            self.db.query(Page).filter(Page.id==page_id).update(update_body)
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))
    
    def update_preview_url(self, page_id, preview_url):
        update_body = {
            "preview_url":preview_url
        }
        try:
            self.db.query(Page).filter(Page.id==page_id).update(update_body)
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))

    
        

