from sqlalchemy import Column, String, Text, DateTime, Integer, JSON, ForeignKey
import datetime
import uuid
from app.db.base import Base


class LogEntry(Base):
    __tablename__ = "tbl_logs"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True)
    project_id = Column(String(36), ForeignKey('tbl_projects.id'), index=True)
    page_id = Column(String(36), ForeignKey('tbl_pages.id'), index=True)
    log_output = Column(Text)
    llm_input_tokens = Column(Integer, nullable=True)
    llm_output_tokens = Column(Integer, nullable=True)
    llm_total_tokens = Column(Integer, nullable=True)
    llm_input = Column(Text, nullable=True)
    llm_output = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    extra = Column(JSON, nullable=True)
