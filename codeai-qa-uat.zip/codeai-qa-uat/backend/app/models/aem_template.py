from sqlalchemy import Column, String, Text, Boolean, DateTime
import uuid
from app.db.base import Base
from datetime import datetime

class AEMTemplate(Base):
    __tablename__ = "aem_template"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    aem_template_name = Column(String(100), nullable=False, unique=True)
    aem_template_description = Column(Text)
    aem_template_url = Column(Text) #base url for tempalte
    aem_template_type = Column(String(50), nullable=False) # value needs to be decide, for now default is aem
    active = Column(Boolean, default=True, nullable=False)
    template_processed = Column(Boolean, default=False, nullable=False)  # Indicates if template is processed name needs to be changed to status
    template_body = Column(Text, nullable=True)  # Store template body as JSON or text
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    version = Column(String(50), nullable=True)  # Optional: versioning for templates
    author = Column(String(100), nullable=True)  # Optional: who created/owns the template


    #template name from ae template