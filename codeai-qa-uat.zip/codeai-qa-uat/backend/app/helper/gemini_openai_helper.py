import logging
from openai import OpenAI
import os
import base64
import vertexai
from vertexai.preview.generative_models import GenerativeModel, Part

api_key_gemini = os.environ.get("GEMINI_API_KEY", "dummy_key")

def call_gemini_openai(prompt, model="gemini-2.5-pro", api_key=None, image_bytes=None, mime_type=None):
    """
    Calls the Gemini model via the OpenAI-compatible API and returns the response text.
    Args:
        prompt (str): The prompt or instruction for the model.
        model (str): The Gemini model name.
        api_key (str): API key for authentication.
        image_bytes (bytes, optional): Image data if needed for vision tasks.
        mime_type (str, optional): MIME type of the image (e.g., 'image/png').
    Returns:
        str: The generated response from the Gemini model.
    Raises:
        Exception: If the API call fails.
    """
    logger = logging.getLogger(__name__)
    try:
        client = OpenAI(api_key=api_key_gemini, base_url="https://generativelanguage.googleapis.com/v1beta/openai/")
        if image_bytes and mime_type:
            # Encode image to base64 string
            image_b64 = base64.b64encode(image_bytes).decode("utf-8")
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{image_b64}"}}
                    ]
                }
            ]
        else:
            messages = [
                {"role": "user", "content": prompt}
            ]
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            stream=False
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error calling Gemini via OpenAI API: {str(e)}")
        raise RuntimeError(f"Error calling Gemini via OpenAI API: {str(e)}")

def call_gemini_vertexai(prompt, model_name="gemini-2.5-pro", project=None, location="us-central1", image_bytes=None, mime_type=None):
    """
    Calls the Gemini model via Google Vertex AI and returns the response text.
    Args:
        prompt (str): The prompt or instruction for the model.
        model_name (str): The Gemini model name.
        project (str, optional): GCP project ID.
        location (str): GCP region for Vertex AI.
        image_bytes (bytes, optional): Image data if needed for vision tasks.
        mime_type (str, optional): MIME type of the image (e.g., 'image/png').
    Returns:
        str: The generated response from the Gemini model.
    Raises:
        Exception: If the API call fails.
    """
    logger = logging.getLogger(__name__)
    try:
        vertexai.init(project="woven-icon-461203-g9", location=location)
        model = GenerativeModel(model_name)
        parts = [Part.from_text(prompt)]
        if image_bytes and mime_type:
            parts.append(Part.from_data(mime_type=mime_type, data=image_bytes))
        response = model.generate_content(parts)
        if hasattr(response, 'text'):
            return response.text
        elif hasattr(response, 'candidates') and response.candidates:
            return response.candidates[0].text
        else:
            return str(response)
    except Exception as e:
        logger.error(f"Error calling Gemini via Vertex AI: {str(e)}")
        raise RuntimeError(f"Error calling Gemini via Vertex AI: {str(e)}")
