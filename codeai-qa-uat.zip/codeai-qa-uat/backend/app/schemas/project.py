from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, Dict, Any
from fastapi import Form

class ProjectBase(BaseModel):
    project_name: str = Field(..., max_length=255)
    project_type: str = Field(..., max_length=100)
    project_description: Optional[str] = None
    title: Optional[str] = Field(None, max_length=255)
    project_metadata: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = True
    github_repo_url: Optional[str] = Field(None, max_length=512)
    captions: Optional[Dict[str, Any]] = None

class ProjectCreate(ProjectBase):
    @classmethod
    def as_form(
        cls,
        project_name: str = Form(...),
        project_type: str = Form(...),
        project_description: Optional[str] = Form(None),
        title: Optional[str] = Form(None),
        project_metadata: Optional[str] = Form(None),
        github_repo_url: Optional[str] = Form(None),
        captions: Optional[str] = Form(None),
    ):
        import json
        return cls(
            project_name=project_name,
            project_type=project_type,
            project_description=project_description,
            title=title,
            project_metadata=json.loads(project_metadata) if project_metadata else None,
            github_repo_url=github_repo_url,
            captions=json.loads(captions) if captions else None,
        )

class ProjectUpdate(BaseModel):
    project_name: Optional[str] = Field(None, max_length=255)
    project_type: Optional[str] = Field(None, max_length=100)
    project_description: Optional[str] = None
    title: Optional[str] = Field(None, max_length=255)
    project_metadata: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None
    github_repo_name: Optional[str] = Field(None, max_length=255)
    github_repo_url: Optional[str] = Field(None, max_length=512)
    github_repo_id: Optional[str] = Field(None, max_length=100)
    github_config: Optional[Dict[str, Any]] = None
    captions: Optional[Dict[str, Any]] = None

class ProjectInDB(ProjectBase):
    id: str
    created_date: datetime
    updated_at: Optional[datetime] = None
    github_last_sync: Optional[datetime] = None

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "b3b7e2e2-8c2e-4e2a-9b2e-2e2e2e2e2e2e",
                "project_name": "ecommerce-platform",
                "project_type": "web",
                "created_date": "2023-08-01T12:00:00",
                "title": "E-Commerce Platform",
                "is_active": True,
                "github_repo_name": "ecommerce-platform",
                "github_repo_url": "https://github.com/username/ecommerce-platform"
            }
        }