from typing import List, Optional
from pydantic import BaseModel

class ComponentProperties(BaseModel):
    title: str
    description: str
    imageRef: Optional[str] = None
    caption: Optional[str] = None

class PageComponent(BaseModel):
    type: str
    properties: ComponentProperties
    layout: Optional[str] = None
    markdown_template: Optional[str] = None
    element_type: Optional[str] = None

class PageModel(BaseModel):
    page_title: str
    components: List[PageComponent]