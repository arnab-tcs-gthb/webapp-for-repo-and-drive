from pydantic import BaseModel
from typing import Optional, Any
import datetime

class LogEntryBase(BaseModel):
    project_id: str
    page_id: str
    log_output: str
    llm_input_tokens: Optional[int] = None
    llm_output_tokens: Optional[int] = None
    llm_total_tokens: Optional[int] = None
    llm_input: Optional[str] = None
    llm_output: Optional[str] = None
    extra: Optional[Any] = None

class LogEntryCreate(LogEntryBase):
    pass

class LogEntryInDB(LogEntryBase):
    id: str
    created_at: datetime.datetime

    class Config:
        orm_mode = True

class LogEntryResponse(LogEntryInDB):
    pass
