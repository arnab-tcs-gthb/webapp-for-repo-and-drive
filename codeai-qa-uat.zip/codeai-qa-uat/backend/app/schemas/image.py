from pydantic import BaseModel, Field, validator
import json
from datetime import datetime
from typing import Optional, Dict, List, Any

class Message(BaseModel):
    detail: str

class ImageBase(BaseModel):
    filename: str = Field(..., max_length=255)
    filepath: str = Field(..., max_length=512)
    content_type: str = Field(..., max_length=100)
    project_id: str
    page_id:str

class ImageCreate(ImageBase):
    file_size: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    alt_text: Optional[str] = Field(None, max_length=255)

class ImageUpdate(BaseModel):
    alt_text: Optional[str] = Field(None, max_length=255)
    llm_processed: Optional[bool] = None
    llm_response: Optional[str] = None
    matched_images: Optional[List[str]] = None

class ImageInDB(ImageBase):
    id: str
    upload_date: datetime
    file_size: Optional[int]
    width: Optional[int]
    height: Optional[int]
    alt_text: Optional[str]
    llm_processed: bool
    llm_response: Optional[str]
    matched_images: Optional[List[str]]
    class Config:
        orm_mode = True
class ImageLLMUpdate(BaseModel):
    llm_processed: bool
    llm_response: str
    
class LLMResponseAnalysis(BaseModel):
    total_components: int
    reusable_components: int
    
 
class ImageWithAnalysis(ImageInDB):
    llm_analysis: Optional[LLMResponseAnalysis] = None
 
    @validator('llm_analysis', pre=True, always=True)
    def parse_llm_response(cls, v, values):
        if 'llm_response' not in values or not values['llm_response']:
            return None
        try:
            response_data = json.loads(values['llm_response'])
            components = response_data.get('components', [])
            
            global_count = 0
            component_details = []
            
            for comp in components:
                if not isinstance(comp, dict):
                    continue
                element_type = comp.get('element_type', '').lower()
                if element_type == "global":
                    global_count += 1
            analysis = {
                'total_components': len(response_data.get('components', [])),
                'reusable_components': global_count
            }
            return LLMResponseAnalysis(**analysis)
        except (json.JSONDecodeError, AttributeError):
            return None