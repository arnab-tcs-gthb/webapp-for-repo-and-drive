from pydantic import BaseModel
from typing import Optional, Dict, Any

class AnalysisMetadata(BaseModel):
    project_id: str

class ImageProcessingPaths(BaseModel):
    screenshot_path: str
    images_folder_path: str
    filtered_destination_path: str

class ImageFilter(BaseModel):
    project_id:str