# --- Google Docs get_doc tool for fetching document structure ---
def _get_doc_sync(document_id: str) -> dict:
    try:
        doc = docs_service.documents().get(documentId=document_id).execute()
        return {"success": True, "result": doc}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_doc(document_id: str) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _get_doc_sync, document_id)
# --- Google Docs batchUpdate tool for advanced editing/formatting ---
from typing import List, Dict
def _batch_update_doc_sync(document_id: str, requests: List[Dict]) -> dict:
    try:
        result = docs_service.documents().batchUpdate(
            documentId=document_id, body={"requests": requests}
        ).execute()
        return {"success": True, "result": result}
    except Exception as e:
        return {"success": False, "error": str(e)}

import asyncio
async def batch_update_doc(document_id: str, requests: List[Dict]) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _batch_update_doc_sync, document_id, requests)
import re

async def llm_fill_path_parameters(endpoint_template: str, user_params: dict) -> str:
    """
    Fill in path parameters in the endpoint template using user_params.
    E.g., /project/{project_id}/run/{run_id} with {"project_id": 123, "run_id": 456} -> /project/123/run/456
    Falls back to leaving placeholders if not found in user_params.
    """
    def replacer(match):
        key = match.group(1)
        value = str(user_params.get(key, match.group(0)))
        #print(f"[DEBUG] Filling path parameter: {{{key}}} -> {value}")
        return value
    filled = re.sub(r"{(\w+)}", replacer, endpoint_template)
    #print(f"[DEBUG] Filled endpoint: {filled}")
    return filled
# utils.py
import httpx
from typing import Dict, Any, Optional, List, Tuple
import json
from agno.tools import tool
import re
import os
import mimetypes
import logging
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv()

OPENAPI_URL = "http://localhost:8003/api/v1/openapi.json"
API_BASE_URL = "http://localhost:8003"


# Configure logging
logger = logging.getLogger(__name__)
# Initialize Gemini client with robust error handling
try:
    import google.generativeai as genai
    GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "dummy_key")
    #print(f"[DEBUG] GEMINI_API_KEY: {GEMINI_API_KEY}")  # Debugging line
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model_name = "gemini-2.5-flash-preview-05-20"
    gemini = genai.GenerativeModel(gemini_model_name)
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    gemini = None
    gemini_model_name = None


async def call_fastapi_endpoint(
    endpoint: str,
    method: str = "GET",
    params: Optional[Dict[str, Any]] = None,
    json: Optional[Dict[str, Any]] = None,
    files: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    url = API_BASE_URL + endpoint
    #print(f"[DEBUG] call_fastapi_endpoint: method={method}, url={url}")
    #print(f"[DEBUG] params={params}")
    #print(f"[DEBUG] json={json}")
    #print(f"[DEBUG] files={files}")
    #print(f"[DEBUG] headers={headers}")
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.request(
                method=method,
                url=url,
                params=params,
                json=json,
                files=files,
                headers=headers,
            )
            #print(f"[DEBUG] Response status: {response.status_code}")
            #print(f"[DEBUG] Response text: {response.text}")
            response.raise_for_status()
            return response.json()
    except Exception as e:
        #print(f"[DEBUG] Exception in call_fastapi_endpoint: {e}")
        raise

async def fetch_openapi_schema() -> Dict[str, Any]:
    async with httpx.AsyncClient() as client:
        resp = await client.get(OPENAPI_URL)
        resp.raise_for_status()
        return resp.json()

def summarize_endpoints(openapi_schema: Dict[str, Any]) -> str:
    summary = []
    for path, methods in openapi_schema.get("paths", {}).items():
        for method, details in methods.items():
            desc = details.get("summary") or details.get("description") or ""
            # Get parameters (query/path)
            params = details.get("parameters", [])
            param_list = []
            for param in params:
                pname = param.get("name")
                ptype = param.get("schema", {}).get("type", "string")
                preq = param.get("required", False)
                ploc = param.get("in", "query")
                param_list.append(f"  - {pname} ({ptype}, {ploc}, {'required' if preq else 'optional'})")

            # Get request body schema (if any)
            req_body = details.get("requestBody", {})
            req_schema = None
            sample_body = None
            if req_body:
                content = req_body.get("content", {})
                json_schema = content.get("application/json", {}).get("schema")
                if json_schema:
                    req_schema = json_schema
                    # Resolve $ref if present
                    if "$ref" in req_schema:
                        ref = req_schema["$ref"]
                        ref_path = ref.lstrip("#/" ).split("/")
                        schema = openapi_schema
                        for part in ref_path:
                            schema = schema.get(part, {})
                        req_schema = schema
                    # Generate a sample request body
                    if req_schema and "properties" in req_schema:
                        sample_body = {}
                        for k, v in req_schema["properties"].items():
                            vtype = v.get("type", "string")
                            if vtype == "array":
                                sample_body[k] = []
                            elif vtype == "object":
                                sample_body[k] = {}
                            else:
                                sample_body[k] = f"<{vtype}>"

            summary.append(f"{method.upper()} {path}\n  Description: {desc}")
            if param_list:
                summary.append("  Parameters:\n" + "\n".join(param_list))
            if sample_body is not None:
                summary.append(f"  Sample Request Body (application/json):\n    {json.dumps(sample_body, indent=4)}")
    return "\n".join(summary)

@tool(name="get_api_context", description="List all available API endpoints and their summaries")
async def get_api_context() -> str:
    schema = await fetch_openapi_schema()
    return summarize_endpoints(schema)

def find_endpoint_for_task(openapi_schema: Dict[str, Any], task_keywords: List[str]) -> List[Tuple[str, str, str]]:
    matches = []
    for path, methods in openapi_schema.get("paths", {}).items():
        for method, details in methods.items():
            desc = (details.get("summary", "") + " " + details.get("description", "")).lower()
            if all(kw.lower() in (desc + path).lower() for kw in task_keywords):
                matches.append((method.upper(), path, desc.strip()))
    return matches

def get_request_schema(openapi_schema: Dict[str, Any], path: str, method: str) -> Optional[Dict[str, Any]]:
    method = method.lower()
    path_item = openapi_schema.get("paths", {}).get(path, {})
    method_item = path_item.get(method, {})
    request_body = method_item.get("requestBody", {})
    content = request_body.get("content", {})
    json_schema = content.get("application/json", {}).get("schema")
    if json_schema:
        if "$ref" in json_schema:
            ref = json_schema["$ref"]
            ref_path = ref.lstrip("#/" ).split("/")
            schema = openapi_schema
            for part in ref_path:
                schema = schema.get(part, {})
            return schema
        else:
            return json_schema
    return None

@tool(name="smart_api_call", description="Call the best API endpoint for a given user intent and parameters")
async def smart_api_call(
    user_intent: str,
    user_params: Dict[str, Any]
) -> Dict[str, Any]:
    #print(f"[DEBUG] user_intent: {user_intent}")
    #print(f"[DEBUG] user_params (raw): {user_params}")

    openapi_schema = await fetch_openapi_schema()
    #print(f"[DEBUG] OpenAPI schema fetched (keys): {list(openapi_schema.keys())}")

    # --- LLM-driven endpoint selection ---
    result = await llm_select_endpoint(user_intent, openapi_schema)
    if not result:
        #print("[DEBUG] No matching endpoint found by LLM.")
        return {"error": "No matching endpoint found for your request."}
    method, path = result
    #print(f"[DEBUG] LLM selected endpoint: {method} {path}")

    req_schema = get_request_schema(openapi_schema, path, method)
    #print(f"[DEBUG] Request schema: {req_schema}")

    required_fields = req_schema.get("required", []) if req_schema else []
    schema_props = req_schema.get("properties", {}) if req_schema else {}

    #print(f"[DEBUG] Required fields: {required_fields}")
    #print(f"[DEBUG] Schema properties: {list(schema_props.keys())}")

    # --- FLATTEN user_params if nested under a single key (e.g., 'example_key') ---
    if (
        isinstance(user_params, dict)
        and len(user_params) == 1
        and isinstance(next(iter(user_params.values())), dict)
    ):
        #print("[DEBUG] Flattening nested user_params")
        user_params = next(iter(user_params.values()))
    #print(f"[DEBUG] user_params (flattened): {user_params}")

    # Validate required fields
    missing = [field for field in required_fields if field not in user_params or user_params[field] in [None, ""]]
    #print(f"[DEBUG] Missing required fields: {missing}")
    if missing:
        prompts = []
        for field in missing:
            field_info = schema_props.get(field, {})
            field_type = field_info.get("type", "string")
            desc = field_info.get("title", "") or field_info.get("description", "")
            prompts.append(f"- {field} ({field_type}): {desc}")
        prompt_text = (
            f"To {user_intent}, I need the following information:\n" +
            "\n".join(prompts) +
            "\nPlease provide these details."
        )
        #print(f"[DEBUG] Prompt for missing fields: {prompt_text}")
        return {"need_more_info": True, "prompt": prompt_text, "missing_fields": missing}

    # Only send parameters that are in the schema
    allowed_fields = set(schema_props.keys())
    payload = {k: v for k, v in user_params.items() if k in allowed_fields}
    #print(f"[DEBUG] Payload to send: {payload}")

    # --- Fill endpoint path parameters dynamically ---
    filled_path = await llm_fill_path_parameters(path, user_params)
    #print(f"[DEBUG] Filled endpoint path: {filled_path}")

    # --- Check if this endpoint expects a file upload ---
    api_params = await get_api_parameters(path, method)
    file_param = next((p for p in api_params.get("parameters", []) if p["type"] == "file"), None)

    files = None
    if file_param:
        file_key = file_param["name"]
        file_path = user_params.get(file_key) or user_params.get("file") or user_params.get("image_path")
        if not file_path or not os.path.exists(file_path):
            #print(f"[DEBUG] File path for '{file_key}' not provided or does not exist.")
            return {"error": f"File path for '{file_key}' not provided or does not exist."}
        filename = os.path.basename(file_path)
        mime_type, _ = mimetypes.guess_type(file_path)
        if not mime_type:
            mime_type = "application/octet-stream"
        files = {"file": (filename, open(file_path, "rb"), mime_type)}
        payload = {k: v for k, v in user_params.items() if k != file_key and k in allowed_fields}

    try:
        result = await call_fastapi_endpoint(
            endpoint=filled_path,
            method=method,
            json=None if files else payload,
            files=files
        )
        #print(f"[DEBUG] API call result: {result}")
        # Close file handle if opened
        if files:
            for _, file_tuple in files.items():
                file_tuple[1].close()
        return {"success": True, "result": result}
    except Exception as e:
        #print(f"[DEBUG] API call failed: {e}")
        return {"error": f"API call failed: {e}"}

def normalize_key(key: str) -> str:
    # Lowercase, remove extra spaces, convert to snake_case
    key = key.lower().strip()
    key = re.sub(r'[\s\-]+', '_', key)
    # Fix common typos
    key = key.replace('descriptrion', 'description')
    return key

def extract_intent_and_params(user_input: str, schema_keys: list[str]) -> dict:
    params = {}
    for key in schema_keys:
        pattern = rf"{key.replace('_', '[ _-]?')}[ :]*['\"]?([^,'\"\n]+)['\"]?"
        match = re.search(pattern, user_input, re.IGNORECASE)
        if match:
            params[key] = match.group(1).strip()
    return params


async def get_api_parameters(
    endpoint: str,
    method: str = "POST"
) -> Dict[str, Any]:
    """
    Returns required and optional parameters for the given endpoint and method,
    including type and description from the OpenAPI schema.
    Handles both application/json and multipart/form-data request bodies.
    """
    openapi_schema = await fetch_openapi_schema()
    req_schema = get_request_schema(openapi_schema, endpoint, method)
    if not req_schema:
        # --- Try multipart/form-data ---
        method = method.lower()
        path_item = openapi_schema.get("paths", {}).get(endpoint, {})
        method_item = path_item.get(method, {})
        request_body = method_item.get("requestBody", {})
        content = request_body.get("content", {})
        multipart_schema = content.get("multipart/form-data", {}).get("schema")
        if multipart_schema:
            # --- Resolve $ref if present ---
            if "$ref" in multipart_schema:
                ref = multipart_schema["$ref"]
                ref_path = ref.lstrip("#/").split("/")
                schema = openapi_schema
                for part in ref_path:
                    schema = schema.get(part, {})
                multipart_schema = schema
            required_fields = multipart_schema.get("required", [])
            properties = multipart_schema.get("properties", {})
            params_info = []
            for name, prop in properties.items():
                param_type = prop.get("type", "string")
                if param_type == "string" and prop.get("format") == "binary":
                    param_type = "file"
                params_info.append({
                    "name": name,
                    "type": param_type,
                    "required": name in required_fields,
                    "description": prop.get("description", "") or prop.get("title", "")
                })
            return {
                "endpoint": endpoint,
                "method": method.upper(),
                "parameters": params_info
            }
        return {"error": "No request schema found for this endpoint/method."}

    required_fields = req_schema.get("required", [])
    properties = req_schema.get("properties", {})

    params_info = []
    for name, prop in properties.items():
        params_info.append({
            "name": name,
            "type": prop.get("type", "string"),
            "required": name in required_fields,
            "description": prop.get("description", "") or prop.get("title", "")
        })

    return {
        "endpoint": endpoint,
        "method": method.upper(),
        "parameters": params_info
    }

import re
import json
from typing import List, Dict, Any

# Example Gemini client import (replace with your actual Gemini client)
# from agno.models.google import Gemini

# You may want to initialize your Gemini client globally or pass it as an argument
# gemini_client = Gemini("gemini-2.5-flash-preview-05-20")

@tool(
    name="llm_map_user_input_to_schema",
    description="Use Gemini LLM to extract and map user-supplied values to schema keys. "
                "Takes user_message (str) and schema_params (list of parameter dicts) and returns a dict mapping parameter names to values."
)
async def llm_map_user_input_to_schema(user_message: str, schema_params: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Use Gemini LLM to extract and map user-supplied values to schema keys.
    """
    schema_desc = "\n".join(
        [f"- {p['name']} ({p['type']}): {p.get('description','')}" for p in schema_params]
    )
    prompt = (
        "You are an expert API assistant.\n"
        "Given the following user message and API parameter schema, extract the values for each parameter.\n"
        "Return a JSON object mapping parameter names (as shown in the schema) to values. Only include parameters present in the user message.\n"
        "If the user uses a different format (e.g., 'project name'), map it to the schema key (e.g., 'project_name').\n"
        f"User message: {user_message}\n"
        f"Schema:\n{schema_desc}\n"
        "JSON:"
    )

    # --- Gemini LLM call (replace with your actual Gemini client code) ---
    try:
        if gemini is None:
            raise RuntimeError("Gemini client is not initialized.")
        response =  gemini.generate_content(prompt)
        if hasattr(response, "text"):
            response_text = response.text
        elif hasattr(response, "candidates") and response.candidates:
            response_text = response.candidates[0].content.parts[0].text
        else:
            response_text = str(response)
        #print("[DEBUG] Gemini response for llm_map_user_input_to_schema:", response_text)
        try:
            return json.loads(response_text)
        except Exception:
            return {"raw_response": response_text}
    except Exception as e:
        #print(f"[DEBUG] LLM map_user_input_to_schema failed: {e}")
        return {"error": str(e)}

async def llm_select_endpoint(user_intent: str, openapi_schema: Dict[str, Any]) -> Optional[Tuple[str, str]]:
    """
    Use Gemini LLM to select the best endpoint (method, path) for the user's intent.
    """
    endpoint_summaries = []
    for path, methods in openapi_schema.get("paths", {}).items():
        for method, details in methods.items():
            summary = details.get("summary", "")
            description = details.get("description", "")
            # Extract allowed file types from description if present
            file_types = ""
            if "file type" in description.lower() or "supported" in description.lower():
                matches = re.findall(r"(image/\w+|application/\w+|text/\w+|audio/\w+|video/\w+|application/x-\w+)", description, re.IGNORECASE)
                if matches:
                    file_types = f" [Allowed types: {', '.join(sorted(set(matches)))}]"
            endpoint_summaries.append(f"{method.upper()} {path} - {summary} {description}{file_types}")
    endpoints_text = "\n".join(endpoint_summaries)

    prompt = (
        "You are an expert API assistant. "
        "Given the following list of API endpoints and a user request, "
        "select the single best endpoint (method and path) to fulfill the request. "
        "Pay special attention to the allowed file types in the endpoint descriptions. "
        "Return your answer as a JSON object with 'method' and 'path'.\n\n"
        f"API Endpoints:\n{endpoints_text}\n\n"
        f"User request: {user_intent}\n\n"
        "JSON:"
    )

    try:
        response = gemini.generate_content(prompt)
        # Extract text from the Gemini response object
        if hasattr(response, "text"):
            response_text = response.text
        elif hasattr(response, "candidates") and response.candidates:
            response_text = response.candidates[0].content.parts[0].text
        else:
            response_text = str(response)
        #print("[DEBUG] Gemini response for endpoint selection:", response_text)
        # Remove code block markers if present
        response_text = response_text.strip()
        if response_text.startswith("```json"):
            response_text = response_text[len("```json"):].strip()
        if response_text.endswith("```"):
            response_text = response_text[:-3].strip()
        # Parse JSON
        result = json.loads(response_text)
        return result.get("method"), result.get("path")
    except Exception as e:
        #print(f"[DEBUG] LLM endpoint selection failed: {e}")
        return None


#===================================================================
#google doc editing tools   
#===================================================================
from typing import Optional
from pydantic import BaseModel
import google.auth
from google.oauth2 import service_account
from googleapiclient.discovery import build

# Load credentials from service account key JSON
SCOPES = ['https://www.googleapis.com/auth/documents', 'https://www.googleapis.com/auth/drive']
SERVICE_ACCOUNT_FILE = '/Users/ajayhazra/Desktop/My Space/ARGO/codeai/backend/credentials.json'  # Replace with actual path

credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

docs_service = build('docs', 'v1', credentials=credentials)
drive_service = build('drive', 'v3', credentials=credentials)


class CreateDocInput(BaseModel):
    title: str


class EditDocInput(BaseModel):
    document_id: str
    content: str


class ShareDocInput(BaseModel):
    document_id: str
    email: str
    role: str = "writer"  # 'reader', 'writer', etc.


import asyncio
def _create_doc_sync(input: CreateDocInput) -> dict:
    try:
        body = {"title": input.title}
        doc = docs_service.documents().create(body=body).execute()
        url = f"https://docs.google.com/document/d/{doc.get('documentId')}/edit"
        return {"success": True, "result": {"title": doc.get('title'), "document_id": doc.get('documentId'), "url": url}}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def create_doc(input: CreateDocInput) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _create_doc_sync, input)


def _edit_doc_sync(input: EditDocInput) -> dict:
    try:
        requests = [
            {
                "insertText": {
                    "location": {
                        "index": 1
                    },
                    "text": input.content
                }
            }
        ]
        result = docs_service.documents().batchUpdate(
            documentId=input.document_id, body={"requests": requests}
        ).execute()
        return {"success": True, "result": "Document updated with new content."}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def edit_doc(input: EditDocInput) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _edit_doc_sync, input)


def _share_doc_sync(input: ShareDocInput) -> dict:
    try:
        permission = {
            "type": "user",
            "role": input.role,
            "emailAddress": input.email
        }
        drive_service.permissions().create(
            fileId=input.document_id,
            body=permission,
            sendNotificationEmail=False
        ).execute()
        return {"success": True, "result": f"Document shared with {input.email}."}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def share_doc(input: ShareDocInput) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _share_doc_sync, input)


tool_specs = [
    {
        "name": "get_doc",
        "description": "Fetch the full structure/content of a Google Doc by document_id.",
        "function": get_doc,
        "input_model": None,  # Accepts document_id directly
    },
    {
        "name": "create_google_doc",
        "description": "Create a new Google Doc with a given title.",
        "function": create_doc,
        "input_model": CreateDocInput,
    },
    {
        "name": "edit_google_doc",
        "description": "Insert or append content into an existing Google Doc.",
        "function": edit_doc,
        "input_model": EditDocInput,
    },
    {
        "name": "share_google_doc",
        "description": "Share a Google Doc with a specific email.",
        "function": share_doc,
        "input_model": ShareDocInput,
    },
    {
        "name": "batch_update_doc",
        "description": "Send advanced batchUpdate requests to Google Docs API for formatting, headings, and more. Input: document_id (str), requests (list of dicts) as per Google Docs API.",
        "function": batch_update_doc,
        "input_model": None,  # Accepts document_id and requests directly
    }
]
