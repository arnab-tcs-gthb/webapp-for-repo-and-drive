"""
Google Docs API Discovery schema fetcher and related tools.
"""
import requests
from agno.tools import tool

DOCS_DISCOVERY_URL = "https://docs.googleapis.com/$discovery/rest?version=v1"
_docs_discovery_schema_cache = None

def fetch_docs_discovery_schema(force_refresh: bool = False):
    global _docs_discovery_schema_cache
    if _docs_discovery_schema_cache is None or force_refresh:
        resp = requests.get(DOCS_DISCOVERY_URL)
        resp.raise_for_status()
        _docs_discovery_schema_cache = resp.json()
    return _docs_discovery_schema_cache

@tool(name="get_docs_api_schema", description="Fetch the Google Docs API Discovery schema")
async def get_docs_api_schema() -> dict:
    return fetch_docs_discovery_schema()
