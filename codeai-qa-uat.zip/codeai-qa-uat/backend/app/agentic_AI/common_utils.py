"""
General-purpose utility functions.
"""
import re

def normalize_key(key: str) -> str:
    key = key.lower().strip()
    key = re.sub(r'[\s\-]+', '_', key)
    key = key.replace('descriptrion', 'description')
    return key

def extract_intent_and_params(user_input: str, schema_keys: list[str]) -> dict:
    params = {}
    for key in schema_keys:
        pattern = rf"{key.replace('_', '[ _-]?')}[ :]*['\"]?([^,'\"\n]+)['\"]?"
        match = re.search(pattern, user_input, re.IGNORECASE)
        if match:
            params[key] = match.group(1).strip()
    return params
