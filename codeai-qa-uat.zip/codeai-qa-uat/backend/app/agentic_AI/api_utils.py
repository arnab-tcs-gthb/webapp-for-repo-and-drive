from agno.tools import tool
from typing import Dict, Any, Optional
from app.agentic_AI.llm_utils import llm_fill_path_parameters, llm_select_endpoint

@tool(name="smart_api_call", description="Call the best API endpoint for a given user intent and parameters")
async def smart_api_call(
    user_intent: str,
    user_params: Dict[str, Any]
) -> Dict[str, Any]:
    # Recursively flatten single-key dicts whose value is a dict
    def flatten_single_key_dict(d):
        while (
            isinstance(d, dict)
            and len(d) == 1
            and isinstance(next(iter(d.values())), dict)
        ):
            d = next(iter(d.values()))
        return d
    user_params = flatten_single_key_dict(user_params)
    print("[DEBUG] user_params after flattening:", user_params)
    openapi_schema = await fetch_openapi_schema()
    result = await llm_select_endpoint(user_intent, openapi_schema)
    if not result:
        return {"error": "No matching endpoint found for your request."}
    method, path = result
    req_schema = get_request_schema(openapi_schema, path, method)
    required_fields = req_schema.get("required", []) if req_schema else []
    schema_props = req_schema.get("properties", {}) if req_schema else {}
    # Recursively flatten single-key dicts whose value is a dict
    def flatten_single_key_dict(d):
        while (
            isinstance(d, dict)
            and len(d) == 1
            and isinstance(next(iter(d.values())), dict)
        ):
            d = next(iter(d.values()))
        return d
    user_params = flatten_single_key_dict(user_params)
    missing = [field for field in required_fields if field not in user_params or user_params[field] in [None, ""]]
    if missing:
        prompts = []
        for field in missing:
            field_info = schema_props.get(field, {})
            field_type = field_info.get("type", "string")
            desc = field_info.get("title", "") or field_info.get("description", "")
            prompts.append(f"- {field} ({field_type}): {desc}")
        prompt_text = (
            f"To {user_intent}, I need the following information:\n" +
            "\n".join(prompts) +
            "\nPlease provide these details."
        )
        return {"need_more_info": True, "prompt": prompt_text, "missing_fields": missing}
    allowed_fields = set(schema_props.keys())
    payload = {k: v for k, v in user_params.items() if k in allowed_fields}
    filled_path = await llm_fill_path_parameters(path, user_params)
    api_params = await get_api_parameters(path, method)
    # If no schema, treat all as query params (for endpoints like /generate-doc)
    if isinstance(api_params, dict) and api_params.get("error"):
        try:
            # For endpoints with no schema, send all user_params as query params
            result = await call_fastapi_endpoint(
                endpoint=filled_path,
                method=method,
                params=user_params,
                json=None,
                files=None
            )
            return {"success": True, "result": result}
        except Exception as e:
            return {"error": f"API call failed: {e}"}
    file_param = next((p for p in api_params.get("parameters", []) if p["type"] == "file"), None)
    # --- Separate query and body parameters ---
    query_params = {}
    body_params = {}
    for param in api_params.get("parameters", []):
        pname = param["name"]
        if pname in payload:
            if param.get("in") == "query":
                query_params[pname] = payload[pname]
            else:
                body_params[pname] = payload[pname]
    files = None
    import os
    import mimetypes
    if file_param:
        file_key = file_param["name"]
        file_path = user_params.get(file_key) or user_params.get("file") or user_params.get("image_path")
        if not file_path or not os.path.exists(file_path):
            return {"error": f"File path for '{file_key}' not provided or does not exist."}
        filename = os.path.basename(file_path)
        mime_type, _ = mimetypes.guess_type(file_path)
        if not mime_type:
            mime_type = "application/octet-stream"
        files = {"file": (filename, open(file_path, "rb"), mime_type)}
        # Remove file param from body/query
        if file_key in body_params:
            del body_params[file_key]
        if file_key in query_params:
            del query_params[file_key]
    try:
        result = await call_fastapi_endpoint(
            endpoint=filled_path,
            method=method,
            params=query_params if query_params else None,
            json=None if files else (body_params if body_params else None),
            files=files
        )
        if files:
            for _, file_tuple in files.items():
                file_tuple[1].close()
        return {"success": True, "result": result}
    except Exception as e:
        return {"error": f"API call failed: {e}"}
"""
API interaction and OpenAPI schema utilities.
"""
import httpx
import os
import mimetypes
import logging
from typing import Dict, Any, Optional, List, Tuple
from agno.tools import tool
import json
import re
from dotenv import load_dotenv

load_dotenv()

#OPENAPI_URL = "http://localhost:8003/api/v1/openapi.json"
#API_BASE_URL = "http://localhost:8003"
OPENAPI_URL = os.getenv("OPENAPI_URL")
API_BASE_URL = os.getenv("API_BASE_URL")

logger = logging.getLogger(__name__)

async def call_fastapi_endpoint(
    endpoint: str,
    method: str = "GET",
    params: Optional[Dict[str, Any]] = None,
    json: Optional[Dict[str, Any]] = None,
    files: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    url = API_BASE_URL + endpoint
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            request_args = dict(
                method=method,
                url=url,
                params=params,
                files=files,
                headers=headers,
            )
            if json is not None:
                request_args['json'] = json
            print("[DEBUG] HTTPX request_args:", request_args)
            response = await client.request(**request_args)
            print("[DEBUG] HTTPX response status:", response.status_code)
            print("[DEBUG] HTTPX response text:", response.text)
            response.raise_for_status()
            return response.json()
    except Exception as e:
        raise

async def fetch_openapi_schema() -> Dict[str, Any]:
    async with httpx.AsyncClient() as client:
        resp = await client.get(OPENAPI_URL)
        resp.raise_for_status()
        return resp.json()

def summarize_endpoints(openapi_schema: Dict[str, Any]) -> str:
    summary = []
    for path, methods in openapi_schema.get("paths", {}).items():
        for method, details in methods.items():
            desc = details.get("summary") or details.get("description") or ""
            params = details.get("parameters", [])
            param_list = []
            for param in params:
                pname = param.get("name")
                ptype = param.get("schema", {}).get("type", "string")
                preq = param.get("required", False)
                ploc = param.get("in", "query")
                param_list.append(f"  - {pname} ({ptype}, {ploc}, {'required' if preq else 'optional'})")
            req_body = details.get("requestBody", {})
            req_schema = None
            sample_body = None
            if req_body:
                content = req_body.get("content", {})
                json_schema = content.get("application/json", {}).get("schema")
                if json_schema:
                    req_schema = json_schema
                    if "$ref" in req_schema:
                        ref = req_schema["$ref"]
                        ref_path = ref.lstrip("#/" ).split("/")
                        schema = openapi_schema
                        for part in ref_path:
                            schema = schema.get(part, {})
                        req_schema = schema
                    if req_schema and "properties" in req_schema:
                        sample_body = {}
                        for k, v in req_schema["properties"].items():
                            vtype = v.get("type", "string")
                            if vtype == "array":
                                sample_body[k] = []
                            elif vtype == "object":
                                sample_body[k] = {}
                            else:
                                sample_body[k] = f"<{vtype}>"
            summary.append(f"{method.upper()} {path}\n  Description: {desc}")
            if param_list:
                summary.append("  Parameters:\n" + "\n".join(param_list))
            if sample_body is not None:
                summary.append(f"  Sample Request Body (application/json):\n    {json.dumps(sample_body, indent=4)}")
    return "\n".join(summary)

@tool(name="get_api_context", description="List all available API endpoints and their summaries")
async def get_api_context() -> str:
    schema = await fetch_openapi_schema()
    return summarize_endpoints(schema)

def get_request_schema(openapi_schema: Dict[str, Any], path: str, method: str) -> Optional[Dict[str, Any]]:
    method = method.lower()
    path_item = openapi_schema.get("paths", {}).get(path, {})
    method_item = path_item.get(method, {})
    request_body = method_item.get("requestBody", {})
    content = request_body.get("content", {})
    json_schema = content.get("application/json", {}).get("schema")
    if json_schema:
        if "$ref" in json_schema:
            ref = json_schema["$ref"]
            ref_path = ref.lstrip("#/" ).split("/")
            schema = openapi_schema
            for part in ref_path:
                schema = schema.get(part, {})
            return schema
        else:
            return json_schema
    return None

async def get_api_parameters(
    endpoint: str,
    method: str = "POST"
) -> Dict[str, Any]:
    openapi_schema = await fetch_openapi_schema()
    req_schema = get_request_schema(openapi_schema, endpoint, method)
    if not req_schema:
        method = method.lower()
        path_item = openapi_schema.get("paths", {}).get(endpoint, {})
        method_item = path_item.get(method, {})
        request_body = method_item.get("requestBody", {})
        content = request_body.get("content", {})
        multipart_schema = content.get("multipart/form-data", {}).get("schema")
        if multipart_schema:
            if "$ref" in multipart_schema:
                ref = multipart_schema["$ref"]
                ref_path = ref.lstrip("#/").split("/")
                schema = openapi_schema
                for part in ref_path:
                    schema = schema.get(part, {})
                multipart_schema = schema
            required_fields = multipart_schema.get("required", [])
            properties = multipart_schema.get("properties", {})
            params_info = []
            for name, prop in properties.items():
                param_type = prop.get("type", "string")
                if param_type == "string" and prop.get("format") == "binary":
                    param_type = "file"
                params_info.append({
                    "name": name,
                    "type": param_type,
                    "required": name in required_fields,
                    "description": prop.get("description", "") or prop.get("title", "")
                })
            return {
                "endpoint": endpoint,
                "method": method.upper(),
                "parameters": params_info
            }
        return {"error": "No request schema found for this endpoint/method."}
    required_fields = req_schema.get("required", [])
    properties = req_schema.get("properties", {})
    params_info = []
    for name, prop in properties.items():
        params_info.append({
            "name": name,
            "type": prop.get("type", "string"),
            "required": name in required_fields,
            "description": prop.get("description", "") or prop.get("title", "")
        })
    return {
        "endpoint": endpoint,
        "method": method.upper(),
        "parameters": params_info
    }
