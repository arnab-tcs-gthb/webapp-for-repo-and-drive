import React, { useState } from 'react';
import { Button, Card, Input, Modal, Dropdown } from '../components/ui';
import { useTheme } from '../context/ThemeContext';
import '../styles/responsive.css';

const ComponentDemo = () => {
  const { theme, toggleTheme, isEnhancedTheme, toggleEnhancedTheme } = useTheme();
  const [loadingStates, setLoadingStates] = useState({});
  const [modalOpen, setModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleLoadingDemo = (buttonId) => {
    setLoadingStates(prev => ({ ...prev, [buttonId]: true }));
    setTimeout(() => {
      setLoadingStates(prev => ({ ...prev, [buttonId]: false }));
    }, 2000);
  };

  const codeExample = `
import { Button, Card } from '../components/ui';

<Button variant="primary" size="md" onClick={handleClick}>
  Primary Button
</Button>

<Card>
  <Card.Header>
    <Card.Title>Card Title</Card.Title>
    <Card.Subtitle>Card subtitle</Card.Subtitle>
  </Card.Header>
  <Card.Content>
    <p>This is the card content area.</p>
  </Card.Content>
  <Card.Footer>
    <Button variant="outline" size="sm">Action</Button>
  </Card.Footer>
</Card>
  `.trim();

  return (
    <div className="container-lg" style={{ 
      padding: 'var(--spacing-lg)', 
      backgroundColor: theme.colors.background,
      color: theme.colors.text,
      minHeight: '100vh'
    }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4" style={{ color: theme.colors.primary }}>
          Component Library Demo
        </h1>
        <p className="text-lg mb-6" style={{ color: theme.colors.textSecondary }}>
          Showcase of the new reusable UI components with accessibility and responsive design features.
        </p>
        
        {/* Theme Controls */}
        <div className="flex flex-wrap gap-4 mb-6">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={toggleTheme}
            aria-label={`Switch to ${theme.mode === 'light' ? 'dark' : 'light'} mode`}
          >
            {theme.mode === 'light' ? '🌙' : '☀️'} {theme.mode === 'light' ? 'Dark' : 'Light'} Mode
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={toggleEnhancedTheme}
            aria-label={`Switch to ${isEnhancedTheme ? 'legacy' : 'enhanced'} theme`}
          >
            {isEnhancedTheme ? '🎨' : '⚡'} {isEnhancedTheme ? 'Enhanced' : 'Legacy'} Theme
          </Button>
        </div>
      </div>

      {/* Button Variants Section */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Button Variants</Card.Title>
          <Card.Subtitle>Different button styles and states</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <div className="grid-system">
            <div className="grid-col-12 grid-col-md-6 grid-col-lg-4 mb-6">
              <h3 className="text-lg font-semibold mb-4">Primary Variants</h3>
              <div className="flex flex-col gap-3">
                <Button variant="primary" size="md">Primary Button</Button>
                <Button variant="secondary" size="md">Secondary Button</Button>
                <Button variant="outline" size="md">Outline Button</Button>
                <Button variant="ghost" size="md">Ghost Button</Button>
              </div>
            </div>
            
            <div className="grid-col-12 grid-col-md-6 grid-col-lg-4 mb-6">
              <h3 className="text-lg font-semibold mb-4">Status Variants</h3>
              <div className="flex flex-col gap-3">
                <Button variant="success" size="md">Success Button</Button>
                <Button variant="danger" size="md">Danger Button</Button>
                <Button variant="primary" size="md" disabled>Disabled Button</Button>
                <Button 
                  variant="primary" 
                  size="md" 
                  loading={loadingStates.loading1}
                  onClick={() => handleLoadingDemo('loading1')}
                >
                  Loading Demo
                </Button>
              </div>
            </div>
            
            <div className="grid-col-12 grid-col-md-6 grid-col-lg-4 mb-6">
              <h3 className="text-lg font-semibold mb-4">Sizes</h3>
              <div className="flex flex-col gap-3">
                <Button variant="primary" size="xs">Extra Small</Button>
                <Button variant="primary" size="sm">Small</Button>
                <Button variant="primary" size="md">Medium</Button>
                <Button variant="primary" size="lg">Large</Button>
                <Button variant="primary" size="xl">Extra Large</Button>
              </div>
            </div>
          </div>
        </Card.Content>
      </Card>

      {/* Card Variants Section */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Card Components</Card.Title>
          <Card.Subtitle>Flexible card layouts with compound pattern</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <div className="grid-system">
            <div className="grid-col-12 grid-col-md-6 grid-col-lg-4 mb-6">
              <Card elevation={1}>
                <Card.Header>
                  <Card.Title>Basic Card</Card.Title>
                  <Card.Subtitle>Elevation level 1</Card.Subtitle>
                </Card.Header>
                <Card.Content>
                  <p>This is a basic card with minimal elevation and clean styling.</p>
                </Card.Content>
                <Card.Footer>
                  <Button variant="outline" size="sm">Learn More</Button>
                </Card.Footer>
              </Card>
            </div>
            
            <div className="grid-col-12 grid-col-md-6 grid-col-lg-4 mb-6">
              <Card elevation={2} hoverable>
                <Card.Header>
                  <Card.Title>Hoverable Card</Card.Title>
                  <Card.Subtitle>Elevation level 2 with hover effect</Card.Subtitle>
                </Card.Header>
                <Card.Content>
                  <p>This card has hover effects and medium elevation for better visual hierarchy.</p>
                </Card.Content>
                <Card.Footer>
                  <Button variant="primary" size="sm">Get Started</Button>
                </Card.Footer>
              </Card>
            </div>
            
            <div className="grid-col-12 grid-col-md-6 grid-col-lg-4 mb-6">
              <Card elevation={3}>
                <Card.Header>
                  <Card.Title>High Elevation</Card.Title>
                  <Card.Subtitle>Elevation level 3</Card.Subtitle>
                </Card.Header>
                <Card.Content>
                  <p>This card uses higher elevation for important content that needs to stand out.</p>
                </Card.Content>
                <Card.Footer>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm">Cancel</Button>
                    <Button variant="success" size="sm">Confirm</Button>
                  </div>
                </Card.Footer>
              </Card>
            </div>
          </div>
        </Card.Content>
      </Card>

      {/* Input Components Section */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Input Components</Card.Title>
          <Card.Subtitle>Form inputs with validation and accessibility</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <div className="grid-system">
            <div className="grid-col-12 grid-col-md-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Input Variants</h3>
              <div className="flex flex-col gap-4">
                <Input
                  label="Default Input"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
                <Input
                  label="Email Input"
                  type="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  leftIcon="📧"
                />
                <Input
                  label="Password Input"
                  type="password"
                  placeholder="Enter password"
                  rightIcon="👁️"
                />
                <Input
                  label="Search Input"
                  placeholder="Search..."
                  leftIcon="🔍"
                  variant="filled"
                />
              </div>
            </div>
            
            <div className="grid-col-12 grid-col-md-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Input States</h3>
              <div className="flex flex-col gap-4">
                <Input
                  label="Error State"
                  placeholder="Invalid input"
                  error
                  helperText="This field is required"
                />
                <Input
                  label="Disabled Input"
                  placeholder="Disabled"
                  disabled
                  value="Cannot edit this"
                />
                <Input
                  label="Success State"
                  placeholder="Valid input"
                  helperText="Looks good!"
                  rightIcon="✅"
                />
                <Input
                  label="Large Textarea"
                  placeholder="Enter your message"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  size="lg"
                  fullWidth
                />
              </div>
            </div>
          </div>
        </Card.Content>
      </Card>

      {/* Modal & Dropdown Section */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Modal & Dropdown Components</Card.Title>
          <Card.Subtitle>Interactive overlays and selection components</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <div className="grid-system">
            <div className="grid-col-12 grid-col-md-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Modal Examples</h3>
              <div className="flex flex-col gap-3">
                <Button 
                  variant="primary" 
                  onClick={() => setModalOpen(true)}
                >
                  Open Modal
                </Button>
                <Button variant="outline" size="sm">Small Modal</Button>
                <Button variant="secondary" size="sm">Large Modal</Button>
              </div>
            </div>
            
            <div className="grid-col-12 grid-col-md-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Dropdown Examples</h3>
              <div className="flex flex-col gap-3">
                <Dropdown
                  trigger={<Button variant="outline">Actions Menu</Button>}
                  placement="bottom-start"
                >
                  <Dropdown.Label>Account</Dropdown.Label>
                  <Dropdown.Item onClick={() => console.log('Profile clicked')}>
                    👤 View Profile
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => console.log('Settings clicked')}>
                    ⚙️ Settings
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Label>Actions</Dropdown.Label>
                  <Dropdown.Item onClick={() => console.log('Export clicked')}>
                    📄 Export Data
                  </Dropdown.Item>
                  <Dropdown.Item 
                    variant="danger" 
                    onClick={() => console.log('Delete clicked')}
                  >
                    🗑️ Delete Account
                  </Dropdown.Item>
                </Dropdown>
                
                <Dropdown
                  trigger={<Button variant="ghost" size="sm">User Menu</Button>}
                  placement="bottom-end"
                >
                  <Dropdown.Item>John Doe</Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item>Dashboard</Dropdown.Item>
                  <Dropdown.Item>Projects</Dropdown.Item>
                  <Dropdown.Item>Sign Out</Dropdown.Item>
                </Dropdown>
              </div>
            </div>
          </div>
        </Card.Content>
      </Card>

      {/* Modal Component */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Example Modal"
        size="md"
      >
        <div className="mb-4">
          <p className="mb-4">This is an example modal with form inputs and actions.</p>
          
          <div className="space-y-4">
            <Input
              label="Full Name"
              placeholder="Enter your full name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              fullWidth
            />
            <Input
              label="Email Address"
              type="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              fullWidth
              leftIcon="📧"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-3 mt-6">
          <Button 
            variant="outline" 
            onClick={() => setModalOpen(false)}
          >
            Cancel
          </Button>
          <Button 
            variant="primary" 
            onClick={() => {
              console.log('Form submitted:', formData);
              setModalOpen(false);
            }}
          >
            Save Changes
          </Button>
        </div>
      </Modal>

      {/* Interactive Examples */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Interactive Examples</Card.Title>
          <Card.Subtitle>Real-world usage scenarios</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <div className="grid-system">
            <div className="grid-col-12 grid-col-lg-6 mb-6">
              <Card elevation={1} hoverable>
                <Card.Header>
                  <Card.Title>User Profile</Card.Title>
                  <Card.Subtitle>Manage your account settings</Card.Subtitle>
                </Card.Header>
                <Card.Content>
                  <div className="mb-4">
                    <p><strong>Name:</strong> John Doe</p>
                    <p><strong>Email:</strong> john.doe@example.com</p>
                    <p><strong>Role:</strong> Developer</p>
                  </div>
                </Card.Content>
                <Card.Footer>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">Edit Profile</Button>
                    <Button variant="primary" size="sm">Save Changes</Button>
                  </div>
                </Card.Footer>
              </Card>
            </div>
            
            <div className="grid-col-12 grid-col-lg-6 mb-6">
              <Card elevation={2}>
                <Card.Header>
                  <Card.Title>Project Status</Card.Title>
                  <Card.Subtitle>Current deployment status</Card.Subtitle>
                </Card.Header>
                <Card.Content>
                  <div className="mb-4">
                    <p><strong>Status:</strong> <span style={{ color: theme.colors.success }}>✅ Active</span></p>
                    <p><strong>Last Updated:</strong> 2 minutes ago</p>
                    <p><strong>Version:</strong> v1.2.3</p>
                  </div>
                </Card.Content>
                <Card.Footer>
                  <div className="flex gap-2">
                    <Button 
                      variant="danger" 
                      size="sm"
                      loading={loadingStates.stop}
                      onClick={() => handleLoadingDemo('stop')}
                    >
                      Stop
                    </Button>
                    <Button 
                      variant="success" 
                      size="sm"
                      loading={loadingStates.deploy}
                      onClick={() => handleLoadingDemo('deploy')}
                    >
                      Deploy
                    </Button>
                  </div>
                </Card.Footer>
              </Card>
            </div>
          </div>
        </Card.Content>
      </Card>

      {/* Code Example */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Usage Example</Card.Title>
          <Card.Subtitle>How to use these components in your code</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <pre style={{ 
            backgroundColor: theme.colors.surfaceVariant || theme.colors.surface,
            padding: 'var(--spacing-md)',
            borderRadius: 'var(--border-radius-md)',
            overflow: 'auto',
            fontSize: '0.875rem',
            lineHeight: '1.5'
          }}>
            <code>{codeExample}</code>
          </pre>
        </Card.Content>
      </Card>

      {/* Accessibility Features */}
      <Card className="mb-8">
        <Card.Header>
          <Card.Title>Accessibility Features</Card.Title>
          <Card.Subtitle>WCAG 2.1 AA compliance built-in</Card.Subtitle>
        </Card.Header>
        <Card.Content>
          <div className="grid-system">
            <div className="grid-col-12 grid-col-md-6">
              <h3 className="text-lg font-semibold mb-3">✅ Features Included</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Keyboard navigation support</li>
                <li>Screen reader friendly ARIA labels</li>
                <li>Proper focus indicators</li>
                <li>Touch targets minimum 44px</li>
                <li>Color contrast compliance</li>
                <li>Reduced motion support</li>
              </ul>
            </div>
            <div className="grid-col-12 grid-col-md-6">
              <h3 className="text-lg font-semibold mb-3">🎯 Test Instructions</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Use Tab key to navigate between elements</li>
                <li>Press Enter/Space on focused buttons</li>
                <li>Test with screen reader software</li>
                <li>Verify in high contrast mode</li>
                <li>Check responsiveness on mobile devices</li>
              </ul>
            </div>
          </div>
        </Card.Content>
      </Card>

      {/* Footer */}
      <div className="text-center py-8">
        <p style={{ color: theme.colors.textSecondary }}>
          Component library built with React, accessibility, and responsive design in mind.
        </p>
      </div>
    </div>
  );
};

export default ComponentDemo;
