import axios from 'axios';
import config from '../config/config';

// Create a direct axios instance without retry logic
const api = axios.create({
  baseURL: 'http://localhost:8000/api/v1',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Track active requests with progress
const activeRequests = new Map();
const metadataRequests = new Map();

// Helper to validate and sanitize file type
const validateAndSanitizeFile = (file) => {
  if (!(file instanceof File)) {
    throw new Error('Invalid file object provided');
  }

  console.debug(`Validating file: ${file.name} (${file.type})`);

  // Define allowed MIME types - these match the backend requirements exactly
  const ALLOWED_MIME_TYPES = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
    'application/zip',
    'application/x-zip-compressed'
  ];

  // File type mapping for common extensions to ensure correct MIME types
  const FILE_TYPE_MAP = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.zip': 'application/x-zip-compressed'
  };

  // Special handling for zip files - always normalize to application/x-zip-compressed
  if (file.name.toLowerCase().endsWith('.zip')) {
    console.debug(`Normalizing zip file ${file.name} to application/x-zip-compressed`);
    return new File([file], file.name, { type: 'application/x-zip-compressed' });
  }

  // For non-zip files, check if the type is directly allowed
  if (ALLOWED_MIME_TYPES.includes(file.type)) {
    console.debug(`Using original allowed type for ${file.name}: ${file.type}`);
    return file;
  }

  // Try to determine type from extension
  const extension = '.' + file.name.split('.').pop().toLowerCase();
  const detectedType = FILE_TYPE_MAP[extension];
  
  if (!detectedType) {
    throw new Error(
      `Unsupported file type for ${file.name}. Allowed types:\n` +
      '- Images: .jpg, .jpeg, .png, .gif, .webp, .svg\n' +
      '- Archives: .zip'
    );
  }

  if (!ALLOWED_MIME_TYPES.includes(detectedType)) {
    throw new Error(
      `File ${file.name} has an invalid type (${detectedType}). Only these MIME types are allowed: ${ALLOWED_MIME_TYPES.join(', ')}`
    );
  }

  console.debug(`Corrected file type for ${file.name}: ${file.type || 'none'} -> ${detectedType}`);
  return new File([file], file.name, { type: detectedType });
};

/**
 * Enhanced ApiService without global loading overlay
 */
const ApiService = {
  /**
   * Get all projects
   * 
   * @returns {Promise} Promise with projects data
   */
  async getAllProjects() {
    try {
      const response = await api.get('projects');
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load projects');
    }
  },

  /**
   * Create a new project
   * 
   * @param {Object} projectData - Project data to create
   * @returns {Promise} Promise with created project
   */  
  async createProject(projectData) {
    try {      const formData = new FormData();

      // Debug start of project creation
      console.debug('Starting project creation...', projectData.project_name);

      // Add required fields
      formData.append('project_name', projectData.project_name);
      formData.append('project_type', projectData.project_type);

      // Add optional fields if present
      if (projectData.project_metadata) {
        formData.append('project_metadata', JSON.stringify(projectData.project_metadata));
      }
      if (projectData.project_description) {
        formData.append('project_description', projectData.project_description);
      }
      if (projectData.github_repo_url) {
        formData.append('github_repo_url', projectData.github_repo_url);
      }
      if (projectData.is_active !== undefined) {
        formData.append('is_active', projectData.is_active);
      }
      if (projectData.captions) {
        formData.append('captions', JSON.stringify(projectData.captions));
      }      // Process files with strict validation
      const files = projectData.files || [];
      
      if (files.length === 0) {
        // Backend requires files field to be present, even if empty
        console.debug('No files provided, adding empty blob');
        formData.append('files', new Blob([], { type: 'application/octet-stream' }), 'empty');
      } else {
        console.debug(`Processing ${files.length} files...`);
        
        // Define allowed MIME types - must match backend exactly
        const ALLOWED_MIME_TYPES = [
          'image/jpeg', 'image/png', 'image/gif', 
          'image/webp', 'image/svg+xml', 
          'application/zip', 'application/x-zip-compressed'
        ];
        
        // First validate all files before appending to form data
        const validatedFiles = [];
        for (let i = 0; i < files.length; i++) {
          try {
            const file = files[i];
            console.debug(`Pre-validation check for file[${i}]: ${file.name} (${file.type})`);
            
            // Special handling for zip files to ensure correct MIME type
            let validatedFile;
            if (file.name.toLowerCase().endsWith('.zip')) {
              validatedFile = new File([file], file.name, { type: 'application/x-zip-compressed' });
              console.debug(`Normalized zip file: ${file.name} -> ${validatedFile.type}`);
            } else {
              // For non-zip files, validate against allowed MIME types
              if (!ALLOWED_MIME_TYPES.includes(file.type)) {
                throw new Error(`Unsupported file type: ${file.type}. Allowed types: ${ALLOWED_MIME_TYPES.join(', ')}`);
              }
              validatedFile = file;
            }
            
            // Double-check final file type
            if (!ALLOWED_MIME_TYPES.includes(validatedFile.type)) {
              throw new Error(`File validation failed: ${validatedFile.name} has type ${validatedFile.type} which is not allowed`);
            }
            
            validatedFiles.push(validatedFile);
            console.debug(`Successfully validated file[${i}]: ${validatedFile.name} (${validatedFile.type})`);
          } catch (error) {
            console.error('File validation failed:', error);
            throw new Error(`File validation failed for file ${i + 1} (${files[i].name}): ${error.message}`);
          }
        }
        
        // Now append all validated files with the field name 'files' (plural)
        for (let i = 0; i < validatedFiles.length; i++) {
          const validatedFile = validatedFiles[i];
          formData.append('files', validatedFile, validatedFile.name);
          console.debug(`Appended file[${i}] to FormData: ${validatedFile.name} (${validatedFile.type})`);
        }
      }

      // Debug log payload
      console.debug('Project creation payload:', {
        name: projectData.project_name,
        type: projectData.project_type,
        filesCount: files.length,
        metadata: projectData.project_metadata
      });      // Log FormData contents for debugging before sending
      console.debug('===== FormData Contents =====');
      for (const [key, value] of formData.entries()) {
        if (value instanceof File) {
          console.debug(`FormData ${key}: File(name=${value.name}, type=${value.type}, size=${value.size})`);
          
          // Additional debug for files - check if the browser sees the file type as we expect
          const fileReader = new FileReader();
          fileReader.onload = () => {
            const arr = new Uint8Array(fileReader.result);
            let header = '';
            for (let i = 0; i < 4; i++) {
              header += arr[i].toString(16).padStart(2, '0');
            }
            console.debug(`File ${value.name} binary header: 0x${header}`);
          };
          fileReader.readAsArrayBuffer(value.slice(0, 4));
          
        } else if (value instanceof Blob) {
          console.debug(`FormData ${key}: Blob(type=${value.type}, size=${value.size})`);
        } else {
          console.debug(`FormData ${key}: ${value}`);
        }
      }
      console.debug('===== End FormData Contents =====');// Log FormData contents for debugging before sending
      console.debug('FormData contents:');
      for (const [key, value] of formData.entries()) {
        if (value instanceof File) {
          console.debug(`- ${key}: File(name=${value.name}, type=${value.type}, size=${value.size})`);
        } else if (value instanceof Blob) {
          console.debug(`- ${key}: Blob(type=${value.type}, size=${value.size})`);
        } else {
          console.debug(`- ${key}: ${value}`);
        }
      }
      
      // Important: Do NOT set Content-Type header manually for FormData
      // Let the browser set the correct boundary parameter
      const response = await api.post('projects-create-v2/', formData, {
        headers: {
          'Accept': 'application/json'
        },
        timeout: 60000, // Increased timeout for larger uploads
        maxRedirects: 5,
        transformRequest: [], // Prevent axios from trying to transform the FormData
        responseType: 'json'
      });

      return response.data;
    } catch (error) {      // Enhanced error handling with better diagnostics
      if (error.response) {
        const { status, data } = error.response;
        
        // Log the full error details for debugging
        console.error(`Project creation failed with status ${status}:`, data);
        
        if (status === 422) {
          const detail = data.detail || 'Invalid request format';
          throw new Error(`Validation error (422): ${detail}`);
        }
        
        if (status === 400) {
          const detail = data.detail || 'Bad request';
          // For file type issues, provide more specific guidance
          if (detail.includes('Unsupported file type')) {
            throw new Error(`File type error (400): ${detail}. Please only use: .jpg, .jpeg, .png, .gif, .webp, .svg, or .zip files.`);
          }
          throw new Error(`Bad request (400): ${detail}`);
        }
        
        throw new Error(`Server error (${status}): ${data.detail || 'Unknown error'}`);
      }
      
      if (error.request) {
        console.error('No response received:', error.request);
        throw new Error('No response received from server. Please check your network connection.');
      }
      
      console.error('Project creation failed:', error);
      throw error;
    }
  },

  /**
   * Upload a file for a project
   * 
   * @param {string} projectId - Project ID
   * @param {File} file - File to upload
   * @returns {Promise} Promise with upload result
   */
  async uploadProjectFile(projectId, file) {
    if (file.size > config.MAX_UPLOAD_SIZE) {
      throw new Error(`File size exceeds maximum allowed size of ${config.MAX_UPLOAD_SIZE / (1024 * 1024)}MB`);
    }
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await api.post(
        `projects/${projectId}/images`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          },
          onUploadProgress: progressEvent => {
            const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            console.log(`Upload progress: ${percentCompleted}%`);
            this._updateRequestProgress(projectId, percentCompleted);
          }
        }
      );
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to upload file');
    }
  },

  /**
   * Get project details
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with project details
   */
  async getProjectDetails(projectId) {
    try {
      const response = await api.get(`projects/${projectId}`);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load project details');
    }
  },

  /**
   * Get project images
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with project images
   */
  async getProjectImages(projectId) {
    try {
      const response = await api.get(`projects/${projectId}/images`);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load project images');
    }
  },

  /**
   * Get project analysis
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with project analysis
   */
  async getProjectAnalysis(projectId) {
    try {
      const response = await api.get(`projects/${projectId}/analysis`);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load project analysis');
    }
  },

  /**
   * Get metadata
   * 
   * @param {string} projectId - Project name
   * @returns {Promise} Promise with metadata
   */  async getMetadata(projectId, pageId = 0) {
    if (metadataRequests.has(projectId)) {
      return metadataRequests.get(projectId);
    }
    const promise = (async () => {
      try {        // Create the request payload - always convert projectId to string
        // Always send page_id (as null when it's 0 or undefined) to match backend expectations
        const payload = {
          project_id: String(projectId),
          page_id: (pageId && pageId !== 0) ? String(pageId) : null,
          analyze_trigger_flag: true,  // Always trigger analysis when explicitly calling this API
          captions_trigger_flag: true  // Set to true to force caption regeneration when explicitly requested
        };
        
        console.log('📤 Sending analyze request with payload:', payload);
        const response = await api.post('/analyze', payload);
        return response.data;
      } finally {
        metadataRequests.delete(projectId);
      }
    })();
    metadataRequests.set(projectId, promise);
    return promise;
  },

  /**
   * Get KB metadata
   * 
   * @returns {Promise} Promise with KB metadata
   */
  async getKBMetadata() {
    try {
      const response = await api.get('/kb-metadata');
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load knowledge base metadata');
    }
  },
  
  /**
   * Prepare captioning for project's images
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with caption preparation result
   */  async prepareCaptioning(projectId) {
    try {
      // Always convert projectId to string
      const payload = {
        project_id: String(projectId),
        captions_trigger_flag: true  // Explicitly set the flag to trigger caption generation
      };
      console.log('📤 Sending caption-images request with payload:', payload);
      const response = await api.post('/caption-images', payload);
      return response;
    } catch (error) {
      this._handleError(error, 'Failed to prepare image captions');
      throw error; // Make sure to propagate the error for proper handling
    }
  },

  /**
   * Get templates
   * 
   * @param {string} templateType - Optional template type filter
   * @returns {Promise} Promise with templates data
   */
  async getTemplates(templateType = null) {
    try {
      const params = templateType ? { template_type: templateType } : {};
      const response = await api.get('/aem-templates/', { params });
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load templates');
    }
  },

  /**
   * Post llmResponse to mapping API
   * 
   * @param {string} projectId - Project ID
   * @param {Object} llmData - LLM response data to send to mapping API
   * @returns {Promise} Promise with mapping result
   */  async postMappingData(projectId, llmData) {
    try {
      // Always convert projectId to string
      const payload = {
        project_id: String(projectId),
        components_data: llmData
      };
      console.log('📤 Sending mapping request with payload:', payload);
      const response = await api.post('/mapping', payload);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to post mapping data');
    }
  },

  /**
   * Generate documentation for a project
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with generated documentation data
   */  async generateDocumentation(projectId, pageId = 0) {
    try {
      // Create the request payload - always convert projectId to string
      const payload = {
        project_id: String(projectId)
      };
      
      // Only include page_id if it has a valid value and not 0
      if (pageId && pageId !== 0) {
        payload.page_id = String(pageId);
      }
      
      console.log('📤 Sending generate-doc request with payload:', payload);
      const response = await api.post('/generate-doc', payload);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to generate documentation');
    }
  },

  /**
   * Stream chat with AEM Agent (text only, streaming)
   * @param {string} userInput - User's message
   * @param {string} projectId - The current project ID
   * @param {function} onChunk - Callback for each streamed chunk
   * @returns {Promise<void>} Resolves when stream ends
   */
  async streamAemAgentChat(userInput, projectId, onChunk) {
    const response = await fetch('http://127.0.0.1:8001/agentic-chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_input: userInput,
        project_id: projectId != null ? String(projectId) : null,
        user_id: "web_user",
        session_id: "web_session",
        debug_mode: false
      })
    });

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        if (line.trim()) {
          try {
            const json = JSON.parse(line);
            onChunk(json);
          } catch (e) {
            console.warn('Failed to parse chat response:', e);
          }
        }
      }
    }
  },

  /**
   * Check if a request is in progress
   * 
   * @param {string} requestId - Unique request identifier
   * @returns {boolean} Whether request is in progress
   */
  isRequestInProgress(requestId) {
    return activeRequests.has(requestId);
  },

  /**
   * Get request progress
   * 
   * @param {string} requestId - Unique request identifier
   * @returns {number} Progress percentage
   */
  getRequestProgress(requestId) {
    return activeRequests.get(requestId)?.progress || 0;
  },

  /**
   * Cancel a request
   * 
   * @param {string} requestId - Unique request identifier
   */
  cancelRequest(requestId) {
    const requestInfo = activeRequests.get(requestId);
    if (requestInfo && requestInfo.cancelToken) {
      requestInfo.cancelToken.cancel('Request canceled by user');
    }
    activeRequests.delete(requestId);
  },

  /**
   * Update request progress
   * 
   * @param {string} requestId - Unique request identifier
   * @param {number} progress - Progress percentage
   * @private
   */
  _updateRequestProgress(requestId, progress) {
    const requestInfo = activeRequests.get(requestId) || {};
    activeRequests.set(requestId, { 
      ...requestInfo, 
      progress 
    });
  },

  /**
   * Handle API error
   * 
   * @param {Error} error - Error object
   * @param {string} defaultMessage - Default error message
   * @private
   */    _handleError(error, errorContext = 'API Error') {
    const status = error.response?.status;
    const responseData = error.response?.data;
    const requestConfig = error.config;
    
    // Create a detailed error log
    console.error(`🚨 ${errorContext}:`, {
      status,
      responseData,
      errorMessage: error.message,
      url: requestConfig?.url,
      method: requestConfig?.method,
      data: requestConfig?.data ? JSON.parse(requestConfig.data) : null,
      headers: requestConfig?.headers
    });
    
    // Handle specific validation errors from FastAPI
    if (status === 422 && responseData?.detail) {
      console.error('🔍 FastAPI Validation errors:', responseData.detail);
      
      let errorMessage = 'Validation failed:';
      if (Array.isArray(responseData.detail)) {
        responseData.detail.forEach(err => {
          const field = err.loc?.slice(1).join('.') || 'unknown';
          errorMessage += `\n- ${field}: ${err.msg}`;
          
          // Special handling for known validation issues
          if (field === 'project_id' && err.msg.includes('str type expected')) {
            console.error('⚠️ project_id needs to be a string but was sent as:', 
              requestConfig?.data ? JSON.parse(requestConfig.data).project_id : 'unknown');
          }
          if (field === 'page_id' && err.msg.includes('str type expected')) {
            console.error('⚠️ page_id needs to be a string but was sent as:', 
              requestConfig?.data ? JSON.parse(requestConfig.data).page_id : 'unknown');
          }
        });
      } else {
        errorMessage += '\n' + responseData.detail;
      }
      
      console.error(errorMessage);
      error.validationErrors = responseData.detail;
      throw error; // Preserve the original error object for better debugging
    }    
    // No need to look for status-specific messages since we use a simpler approach now
    // Just add the error context to the error object
    error.customMessage = errorContext;
    
    // Default error handling
    const message = error.response?.data?.message 
      || error.response?.data?.detail 
      || error.message 
      || 'An unexpected error occurred';
      
    error.formattedMessage = message;
    console.error(message);
    throw error; // Preserve the original error object for better debugging
  }
};

export default ApiService;
