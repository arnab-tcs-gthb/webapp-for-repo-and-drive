// Mock for monaco-editor to prevent Jest issues
export const editor = {
  create: jest.fn(() => ({
    dispose: jest.fn(),
    getValue: jest.fn(() => ''),
    setValue: jest.fn(),
    layout: jest.fn(),
    onDidChangeModelContent: jest.fn(),
  })),
  getModels: jest.fn(() => []),
  setTheme: jest.fn(),
};

export const languages = {
  register: jest.fn(),
  setTokensProvider: jest.fn(),
  setLanguageConfiguration: jest.fn(),
  registerCompletionItemProvider: jest.fn(),
};

export const Range = jest.fn();
export const Selection = jest.fn();

export default {
  editor,
  languages,
  Range,
  Selection,
};
