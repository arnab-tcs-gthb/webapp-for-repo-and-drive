import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
  MetadataSection,
  MetadataHeader,
  MetadataGrid,
  MetadataCard,
  SectionTitle,
  CompleteBadge,
  CompleteIcon,
  MetadataLabel,
  MetadataValue,
  StatsGrid,
  StatCard,
  StatValue,
  StatLabel,
  UploadedFilesSection,
  FilesHeader,
  FilesTitle,
  FilesGrid,
  FileCard,
  FileImagePreview,
  FileIconPreview,
  FileInfo,
  FileName,
  FileSize,
  CheckIcon
} from '../../ui/adobe-franklin/SharedComponents';
import { PrimaryButton, LoadingSpinner } from '../../ui/adobe-franklin';

/**
 * StepProjectSetup Component
 * 
 * Displays project template metadata, design analysis results, and uploaded files
 * for the first step of the Adobe Franklin project wizard.
 */
const StepProjectSetup = ({
  projectDetails = null,
  kbMetadata = {},
  analysisMetadata = {},
  uploadedFiles = [],
  getFileIcon,
  getFileColor,
  formatFileSize,
  onAnalyze = () => {}
}) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      await onAnalyze();
    } finally {
      setIsAnalyzing(false);
    }
  };

  const StatBlockWithLoading = ({ value, label }) => (
    <StatCard>
      {isAnalyzing ? (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
          padding: '1rem'
        }}>
          <LoadingSpinner />
        </div>
      ) : (
        <>
          <StatValue>{value}</StatValue>
          <StatLabel>{label}</StatLabel>
        </>
      )}
    </StatCard>
  );

  return (
    <>      {/* Template Metadata Section */}
      <MetadataSection isComplete={true}>
        <MetadataHeader>
          <SectionTitle>Template Metadata</SectionTitle>
          <CompleteBadge>
            <CompleteIcon>
              <CheckIcon />
            </CompleteIcon>
            Complete
          </CompleteBadge>
        </MetadataHeader>

        <MetadataGrid>
          <MetadataCard>
            <MetadataLabel>Project Template</MetadataLabel>
            <MetadataValue>{projectDetails?.project_metadata?.selected_template}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Brand</MetadataLabel>
            <MetadataValue>{kbMetadata?.brand}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Total Blocks</MetadataLabel>
            <MetadataValue>{kbMetadata?.total_count}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Global Blocks</MetadataLabel>
            <MetadataValue>{kbMetadata?.global_count}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Site Building Blocks</MetadataLabel>
            <MetadataValue>{kbMetadata?.page_building_count}</MetadataValue>
          </MetadataCard>
        </MetadataGrid>
      </MetadataSection>      {/* Design Metadata Section */}
      <MetadataSection isComplete={Object.keys(analysisMetadata || {}).length > 0}>        <MetadataHeader>
          <SectionTitle>Design Metadata</SectionTitle>
          {Object.keys(analysisMetadata || {}).length > 0 ? (
            <CompleteBadge>
              <CompleteIcon>
                <CheckIcon />
              </CompleteIcon>
              Complete
            </CompleteBadge>
          ) : (
            <CompleteBadge style={{ backgroundColor: '#fdf6b2', color: '#92400e' }}>
              <CompleteIcon style={{ backgroundColor: '#92400e' }}>
                <span style={{ fontSize: '12px' }}>⏳</span>
              </CompleteIcon>
              Pending
            </CompleteBadge>
          )}
        </MetadataHeader><div>{analysisMetadata?.progress}</div>

        {Object.keys(analysisMetadata || {}).length > 0 ? (
          <StatsGrid>
            <StatBlockWithLoading 
              value={analysisMetadata?.pages} 
              label="Pages" 
            />
            <StatBlockWithLoading 
              value={analysisMetadata?.links} 
              label="Links" 
            />
            <StatBlockWithLoading 
              value={analysisMetadata?.images} 
              label="Images" 
            />
            <StatBlockWithLoading 
              value={analysisMetadata?.blocks} 
              label="Blocks" 
            />
            <StatBlockWithLoading 
              value={analysisMetadata?.forms} 
              label="Forms" 
            />
            <StatBlockWithLoading 
              value={1} 
              label="Videos" 
            />
          </StatsGrid>
        ) : (
          <div style={{
            padding: '24px',
            textAlign: 'center',
            color: '#666',
            backgroundColor: '#f8f9fa',
            borderRadius: '8px',
            margin: '16px 0'
          }}>
            Run the image analysis by clicking the Analyze Image(s) button below to fetch the data.
          </div>
        )}
      </MetadataSection>

      {/* Uploaded Files Section */}
      {uploadedFiles && uploadedFiles.length > 0 && (
        <UploadedFilesSection>
          <FilesHeader>
            <FilesTitle>Uploaded Files</FilesTitle>
          </FilesHeader>
          <FilesGrid>
            {uploadedFiles.map((file, index) => {
              // Check if file is an image by extension
              const imageExtensions = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'];
              const ext = file.extension || (file.name ? file.name.split('.').pop().toLowerCase() : '');
              const isImage = imageExtensions.includes(ext);
              
              return (
                <FileCard key={`file-${index}`}>
                  {isImage && file.previewUrl ? (
                    <FileImagePreview>
                      <img src={file.previewUrl} alt={file.name} />
                    </FileImagePreview>
                  ) : (
                    <FileIconPreview backgroundColor={getFileColor(ext)}>
                      {getFileIcon(ext)}
                    </FileIconPreview>
                  )}
                  <FileInfo>
                    <FileName title={file.name}>
                      {file.name.length > 20 ? file.name.substring(0, 17) + '...' : file.name}
                    </FileName>
                    <FileSize>{formatFileSize(file.size)}</FileSize>
                  </FileInfo>
                </FileCard>
              );
            })}
          </FilesGrid>
        </UploadedFilesSection>
      )}      {/* Project Actions Section */}
      <MetadataSection style={{ marginTop: '2rem' }}>
        <MetadataHeader>
          <SectionTitle>Project Actions</SectionTitle>
        </MetadataHeader>
        <div style={{
          padding: '24px',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#f8f9fa',
          borderRadius: '8px',
          margin: '16px 0'
        }}>
          <PrimaryButton
            onClick={handleAnalyze}
            style={{
              minWidth: '200px',
              position: 'relative'
            }}
            disabled={isAnalyzing}
          >
            {isAnalyzing ? (
              <>
                <LoadingSpinner style={{ marginRight: '8px' }} />
                Analyzing...
              </>
            ) : (
              'Analyze Image(s)'
            )}
          </PrimaryButton>
          
          {/* Analysis status indicator */}
          <div style={{ 
            marginTop: '8px', 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px',
            color: analysisMetadata && analysisMetadata.images ? '#2e7d32' : '#f57c00',
            fontSize: '14px',
            fontWeight: '500'
          }}>
            <span style={{ 
              width: '12px', 
              height: '12px', 
              borderRadius: '50%', 
              backgroundColor: analysisMetadata && analysisMetadata.images ? '#2e7d32' : '#f57c00',
              display: 'inline-block'
            }}></span>            {analysisMetadata && analysisMetadata.images 
              ? 'Images analyzed successfully' 
              : 'Images need to be analyzed to continue'}
          </div>
          
          {/* Next step status indicator */}
          <div style={{ 
            marginTop: '16px', 
            textAlign: 'center',
            padding: '8px 12px',
            backgroundColor: analysisMetadata && analysisMetadata.images ? '#e8f5e9' : '#fff3e0',
            border: `1px solid ${analysisMetadata && analysisMetadata.images ? '#a5d6a7' : '#ffe0b2'}`,
            borderRadius: '4px',
            fontSize: '14px'
          }}>
            <span style={{ fontWeight: '600' }}>Next Step:</span> Continue to Mapping 
            <span style={{ 
              marginLeft: '8px',
              fontSize: '20px',
              verticalAlign: 'middle'
            }}>
              {analysisMetadata && analysisMetadata.images ? '✅' : '🔒'}
            </span>
            <p style={{ 
              margin: '4px 0 0 0', 
              fontSize: '12px',
              color: '#666',
              fontStyle: 'italic'
            }}>
              {analysisMetadata && analysisMetadata.images 
                ? 'Ready to proceed to the next step' 
                : 'Analyze images to unlock this step'}
            </p>
          </div>
        </div>
      </MetadataSection>
    </>
  );
};

StepProjectSetup.propTypes = {
  /** Project details object containing metadata */
  projectDetails: PropTypes.shape({
    project_metadata: PropTypes.shape({
      selected_template: PropTypes.string
    })
  }),
  /** Knowledge base metadata */
  kbMetadata: PropTypes.shape({
    brand: PropTypes.string,
    total_count: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    global_count: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    page_building_count: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
  }),
  /** Analysis metadata containing statistics */
  analysisMetadata: PropTypes.shape({
    progress: PropTypes.string,
    pages: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    links: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    images: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    blocks: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    forms: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
  }),
  /** Array of uploaded files */
  uploadedFiles: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      extension: PropTypes.string,
      size: PropTypes.number,
      previewUrl: PropTypes.string
    })
  ),
  /** Function to get file icon based on extension */
  getFileIcon: PropTypes.func.isRequired,
  /** Function to get file color based on extension */
  getFileColor: PropTypes.func.isRequired,
  /** Function to format file size */  formatFileSize: PropTypes.func.isRequired,
  /** Function called when analyze button is clicked */
  onAnalyze: PropTypes.func
};

export default StepProjectSetup;
