import React from 'react';
import styled, { keyframes } from 'styled-components';

// Animations
const spin = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;

const pulse = keyframes`
  0% { opacity: 0.6; }
  50% { opacity: 1; }
  100% { opacity: 0.6; }
`;

const shimmer = keyframes`
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;

// Spinner - for buttons, inline loading states
export const Spinner = styled.div`
  width: ${props => props.size || '20px'};
  height: ${props => props.size || '20px'};
  border: 2px solid rgba(0, 0, 0, 0.1);
  border-top-color: ${props => props.theme.colors?.primary || '#4a7dfc'};
  border-radius: 50%;
  animation: ${spin} 0.8s linear infinite;
  display: inline-block;
  vertical-align: middle;
  margin: ${props => props.margin || '0'};
`;

// Section Loader - for loading specific sections
export const SectionLoader = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: ${props => props.padding || '2rem'};
  flex-direction: column;
`;

export const SectionLoaderText = styled.p`
  margin: 0.5rem 0 0;
  color: ${props => props.theme.colors?.textSecondary || '#666'};
  font-size: 0.9rem;
`;

// Skeleton loaders - for content placeholders
const SkeletonBase = styled.div`
  background: linear-gradient(90deg, 
    ${props => props.theme.colors?.skeletonStart || '#f0f0f0'} 25%, 
    ${props => props.theme.colors?.skeletonEnd || '#e0e0e0'} 50%, 
    ${props => props.theme.colors?.skeletonStart || '#f0f0f0'} 75%);
  background-size: 200% 100%;
  border-radius: 4px;
  animation: ${shimmer} 2s infinite;
  height: ${props => props.height || '1rem'};
  width: ${props => props.width || '100%'};
  margin: ${props => props.margin || '0.5rem 0'};
`;

export const SkeletonText = styled(SkeletonBase)`
  height: ${props => props.height || '1rem'};
`;

export const SkeletonCircle = styled(SkeletonBase)`
  height: ${props => props.size || '2rem'};
  width: ${props => props.size || '2rem'};
  border-radius: 50%;
`;

export const SkeletonRect = styled(SkeletonBase)`
  height: ${props => props.height || '100px'};
`;

// Card loading skeleton
export const SkeletonCard = styled.div`
  padding: 1rem;
  border-radius: 8px;
  background-color: ${props => props.theme.colors?.cardBackground || '#fff'};
  border: 1px solid ${props => props.theme.colors?.border || '#eaeaea'};
`;

// Button with loading state
export const ButtonWithLoading = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: ${props => props.padding || '0.5rem 1rem'};
  background-color: ${props => props.isLoading ? 
    props.theme.colors?.primaryLight || '#e6effd' : 
    props.theme.colors?.primary || '#4a7dfc'};
  color: ${props => props.isLoading ? 
    props.theme.colors?.primary || '#4a7dfc' : 'white'};
  border-radius: 4px;
  font-size: 0.875rem;
  font-weight: 500;
  border: none;
  cursor: ${props => props.isLoading ? 'not-allowed' : 'pointer'};
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.isLoading ? 
      props.theme.colors?.primaryLight || '#e6effd' : 
      props.theme.colors?.primaryDark || '#3a6edf'};
  }
  
  > ${Spinner} {
    margin-right: ${props => props.children ? '0.5rem' : '0'};
  }
`;

// Skeleton for project list items
export const ProjectRowSkeleton = () => (
  <SkeletonCard style={{ display: 'flex', alignItems: 'center', height: '72px' }}>
    <div style={{ flexGrow: 1 }}>
      <SkeletonText width="60%" height="1.2rem" margin="0 0 0.5rem 0" />
      <SkeletonText width="80%" height="0.8rem" margin="0" />
    </div>
    <SkeletonText width="60px" height="1.5rem" margin="0 1rem" />
    <div style={{ display: 'flex', gap: '0.5rem' }}>
      <SkeletonCircle size="2rem" />
      <SkeletonCircle size="2rem" />
      <SkeletonCircle size="2rem" />
    </div>
  </SkeletonCard>
);

// Skeleton for project cards
export const ProjectCardSkeleton = () => (
  <SkeletonCard style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
    <div style={{ padding: '1rem' }}>
      <SkeletonText width="70%" height="1.2rem" margin="0 0 0.5rem 0" />
      <SkeletonText width="40%" height="0.8rem" margin="0 0 1rem 0" />
      <SkeletonText width="90%" height="0.8rem" margin="0 0 0.8rem 0" />
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
        <div style={{ display: 'flex', gap: '0.25rem' }}>
          <SkeletonCircle size="1.5rem" />
          <SkeletonCircle size="1.5rem" />
        </div>
        <SkeletonText width="30%" height="0.8rem" />
      </div>
    </div>
    <SkeletonText margin="1rem 0 0 0" height="2.5rem" style={{ borderRadius: '0 0 8px 8px' }} />
  </SkeletonCard>
);

// Loading state for grid of items
export const LoadingGrid = ({ count = 6, type = 'card' }) => (
  <div style={{ 
    display: 'grid', 
    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
    gap: '1.5rem'
  }}>
    {Array(count).fill(0).map((_, index) => (
      type === 'card' ? 
        <ProjectCardSkeleton key={index} /> : 
        <ProjectRowSkeleton key={index} />
    ))}
  </div>
);

// Loading state for list of items
export const LoadingList = ({ count = 5 }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
    {Array(count).fill(0).map((_, index) => (
      <ProjectRowSkeleton key={index} />
    ))}
  </div>
);

const LoadingStates = {
  Spinner,
  SectionLoader,
  SectionLoaderText,
  SkeletonText,
  SkeletonCircle,
  SkeletonRect,
  SkeletonCard,
  ButtonWithLoading,
  ProjectRowSkeleton,
  ProjectCardSkeleton,
  LoadingGrid,
  LoadingList
};

export default LoadingStates;
