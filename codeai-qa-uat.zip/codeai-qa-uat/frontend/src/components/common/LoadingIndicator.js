import React from 'react';
import styled, { keyframes } from 'styled-components';

const Overlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.6);
  display: ${props => props.isLoading ? 'flex' : 'none'};
  justify-content: center;
  align-items: center;
  z-index: 9999;
`;

const loadingAnimation = keyframes`
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
`;

const LoadingContainer = styled.div`
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
  padding: 20px;
  width: 300px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
`;

const ProgressBarOuter = styled.div`
  background-color: #f0f0f0;
  border-radius: 4px;
  height: 8px;
  overflow: hidden;
`;

const ProgressBarInner = styled.div`
  height: 100%;
  background-color: ${props => props.theme.colors?.primary || '#4a7dfc'};
  border-radius: 4px;
  animation: ${loadingAnimation} 1.5s infinite ease-in-out;
`;

const LoadingText = styled.p`
  margin: 8px 0 0 0;
  text-align: center;
  font-size: 14px;
  color: ${props => props.theme.colors?.text || '#333'};
`;

const LoadingIndicator = ({ isLoading, message = 'Loading...' }) => {
  return (
    <Overlay isLoading={isLoading}>
      <LoadingContainer>
        <ProgressBarOuter>
          <ProgressBarInner />
        </ProgressBarOuter>
        <LoadingText>{message}</LoadingText>
      </LoadingContainer>
    </Overlay>
  );
};

export default LoadingIndicator;