import React, { useState, useEffect, useRef } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import PropTypes from 'prop-types';
import { useTheme } from '../../context/ThemeContext';
import ReactMarkdown from 'react-markdown';

// Global style for spinner keyframes
const GlobalSpinnerStyle = createGlobalStyle`
  @keyframes spin {
    0% { transform: rotate(0deg);}
    100% { transform: rotate(360deg);}
  }
`;

// Chat container
const ChatContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: ${props => props.theme.colors.background};
`;

// Chat header
const ChatHeader = styled.div`
  height: 60px;
  padding: 0 1rem;
  border-bottom: 1px solid ${props => props.theme.colors.border};
  font-weight: 600;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: ${props => props.theme.colors.cardBackground};
  color: ${props => props.theme.colors.text};
`;

// Chat messages area
const ChatMessages = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  background-color: ${props => props.theme.colors.background};

  /* Custom scrollbar */
  &::-webkit-scrollbar {
    width: 8px;
  }
  
  &::-webkit-scrollbar-track {
    background: transparent;
  }
  
  &::-webkit-scrollbar-thumb {
    background-color: ${props => props.theme.colors.border};
    border-radius: 4px;
  }
`;

// Individual message
const Message = styled.div`
  display: flex;
  flex-direction: column;
  max-width: 85%;
  animation: fadeIn 0.3s ease;
  
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  &.user-message {
    align-self: flex-end;
    
    .message-content {
      background-color: ${props => props.theme.colors.primary};
      color: white;
      border-radius: 16px 16px 4px 16px;
    }

    .message-meta {
      text-align: right;
    }
  }
  
  &.ai-message {
    align-self: flex-start;
    
    .message-content {
      background-color: ${props => props.theme.colors.cardBackground};
      color: ${props => props.theme.colors.text};
      border-radius: 16px 16px 16px 4px;
      border: 0.5px solid ${props => props.theme.colors.border};
    }

    &.streaming .message-content {
      border-color: ${props => props.theme.colors.primary};
    }
  }
  
  .message-content {
    padding: 1.5rem;
    font-size: 14px;
    line-height: 1.5;
    word-wrap: break-word;
    /* Fix for horizontal scrollbar in code blocks */
    pre {
      background-color: ${props => props.theme.colors.inputBackground};
      padding: 1rem;
      border-radius: 4px;
      overflow-x: auto;
      max-width: 100%;
      word-break: break-word;
      white-space: pre-wrap;
      box-sizing: border-box;
    }
    code {
      background-color: ${props => props.theme.colors.inputBackground};
      padding: 0.2em 0.4em;
      border-radius: 3px;
      font-size: 0.9em;
      font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
      word-break: break-word;
      white-space: pre-wrap;
      box-sizing: border-box;
    }
  }
  
  .message-meta {
    font-size: 12px;
    color: ${props => props.theme.colors.textSecondary};
    margin-top: 0.3rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
`;

// Chat input area
const ChatInput = styled.div`
  padding: 1rem;
  border-top: 1px solid ${props => props.theme.colors.border};
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  background-color: ${props => props.theme.colors.cardBackground};
`;

const InputArea = styled.div`
  display: flex;
  align-items: flex-end;
  gap: 0.5rem;
`;

const TextInput = styled.textarea`
  flex: 1;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: 8px;
  padding: 0.75rem 1rem;
  resize: none;
  font-family: inherit;
  font-size: 14px;
  min-height: 40px;
  max-height: 120px;
  background-color: ${props => props.theme.colors.inputBackground};
  color: ${props => props.theme.colors.text};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
    box-shadow: 0 0 0 2px ${props => props.theme.colors.primarySoft};
  }
  
  &::placeholder {
    color: ${props => props.theme.colors.textSecondary};
  }

  &:disabled {
    background-color: ${props => props.theme.colors.disabledBackground};
    cursor: not-allowed;
  }
`;

const Button = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.5rem;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  border: none;
  height: 40px;
  min-width: 40px;
  
  &.primary {
    background-color: ${props => props.theme.colors.primary};
    color: white;
    
    &:hover:not(:disabled) {
      background-color: ${props => props.theme.colors.primaryHover};
    }
    
    &:disabled {
      background-color: ${props => props.theme.colors.textMuted};
      cursor: not-allowed;
    }
  }
  
  &.secondary {
    background-color: transparent;
    color: ${props => props.theme.colors.text};
    border: 1px solid ${props => props.theme.colors.border};
    
    &:hover {
      background-color: ${props => props.theme.colors.inputBackground};
    }
  }
`;

const TypingIndicator = styled.div`
  padding: 0.5rem 1rem;
  color: ${props => props.theme.colors.textSecondary};
  font-style: italic;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const Spinner = () => {
  const { theme } = useTheme();
  return (
    <span
      style={{
        display: 'inline-block',
        border: `3px solid ${theme.colors.textSecondary}`,
        borderTop: `3px solid ${theme.colors.primary}`,
        borderRadius: '50%',
        width: 20,
        height: 20,
        animation: 'spin 0.7s linear infinite',
        marginRight: 8,
        verticalAlign: 'middle'
      }}
    />
  );
};

// Icons
const SendIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="22" y1="2" x2="11" y2="13"></line>
    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
  </svg>
);

const AttachmentIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
  </svg>
);

/**
 * ChatView Component - A reusable chat interface
 */
const ChatView = ({
  title = "Chat Assistant",
  messages = [],
  onSendMessage,
  placeholder = "Type your message here...",
  isLoading = false,
  showAttachment = true,
  maxMessageLength = 2000,
  className,
  style
}) => {
  const { theme } = useTheme();
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef(null);
  const chatMessagesRef = useRef(null);
  const aiMessageRefs = useRef([]);

  // Auto-scroll to bottom when messages change or when streaming
  useEffect(() => {
    // Find the last AI message
    const lastAiIndex = [...messages].reverse().findIndex(m => m.type === 'ai');
    if (lastAiIndex !== -1) {
      const aiIndex = messages.length - 1 - lastAiIndex;
      const aiMessageEl = aiMessageRefs.current[aiIndex];
      if (aiMessageEl) {
        aiMessageEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
    }
    // Fallback: scroll to bottom
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Sync aiMessageRefs with messages length
  useEffect(() => {
    aiMessageRefs.current = aiMessageRefs.current.slice(0, messages.length);
  }, [messages]);

  // Handle sending a message
  const handleSendMessage = () => {
    const trimmedMessage = message.trim();
    if (!trimmedMessage || isLoading) return;
    
    if (onSendMessage) {
      onSendMessage(trimmedMessage);
    }
    
    setMessage('');
  };

  // Handle Enter key to send message
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Format timestamp
  const formatTimestamp = (isoString) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
    } catch (e) {
      return '';
    }
  };

  // Auto-resize textarea
  const handleInputChange = (e) => {
    const value = e.target.value;
    if (value.length <= maxMessageLength) {
      setMessage(value);
      
      // Auto-resize textarea
      e.target.style.height = 'auto';
      e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
    }
  };

  return (
    <>
      <GlobalSpinnerStyle />
      <ChatContainer className={className} style={style}>
        <ChatHeader>
          <span>{title}</span>
        </ChatHeader>

        <ChatMessages ref={chatMessagesRef}>
          {messages.map((msg, index) => (
            <Message
              key={index}
              className={`${msg.type}-message ${msg.streaming ? 'streaming' : ''}`}
              ref={el => {
                if (msg.type === 'ai') aiMessageRefs.current[index] = el;
              }}
            >
              <div className="message-meta">
                {msg.type === 'ai' && (
                  <img
                    src="/logos/ai_agent.png"
                    alt="ARGO Agent"
                    style={{
                      width: 60,
                      height: 60,
                      marginRight: 2,
                      verticalAlign: 'middle',
                      borderRadius: '50%',
                      borderColor: theme.colors.border, 
                      borderWidth: 1, 
                      borderStyle: 'solid',
                      objectFit: 'cover'
                    }}
                  />
                )}
                <span>{msg.type === 'user' ? 'You' : 'ARGO Agent'}</span>
                {msg.timestamp && (
                  <>
                    <span>•</span>
                    <span>{formatTimestamp(msg.timestamp)}</span>
                  </>
                )}
              </div>
              <div className="message-content">
                {msg.type === 'ai' ? (
                  <ReactMarkdown 
                    children={msg.content} 
                    components={{
                      code: ({ node, inline, className, children, ...props }) => {
                        return inline ? (
                          <code {...props}>{children}</code>
                        ) : (
                          <pre style={{ 
                            backgroundColor: theme.colors.inputBackground,
                            padding: '1rem',
                            borderRadius: '4px',
                            overflowX: 'auto'
                          }}>
                            <code {...props}>{children}</code>
                          </pre>
                        );
                      }
                    }}
                  />
                ) : (
                  msg.content.split('\n').map((line, i) => (
                    <React.Fragment key={i}>
                      {line}
                      {i < msg.content.split('\n').length - 1 && <br />}
                    </React.Fragment>
                  ))
                )}
              </div>
            </Message>
          ))}
          <div ref={messagesEndRef} />
          {isLoading && (
            <TypingIndicator>
              <Spinner /> ARGO is thinking...
            </TypingIndicator>
          )}
        </ChatMessages>

        <ChatInput>
          <InputArea>
            {showAttachment && (
              <Button 
                className="secondary" 
                type="button" 
                title="Attach file"
                disabled={isLoading}
              >
                <AttachmentIcon />
              </Button>
            )}
            <TextInput 
              placeholder={placeholder}
              value={message}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              maxLength={maxMessageLength}
              rows={1}
              aria-label="Chat message input"
            />
            <Button 
              className="primary" 
              onClick={handleSendMessage}
              disabled={!message.trim() || isLoading}
              type="button"
              title="Send message"
            >
              <SendIcon />
            </Button>
          </InputArea>
          {maxMessageLength && (
            <div style={{ 
              fontSize: '12px', 
              color: theme.colors.textSecondary,
              textAlign: 'right',
              opacity: message.length > maxMessageLength * 0.8 ? 1 : 0.7
            }}>
              {message.length}/{maxMessageLength}
            </div>
          )}
        </ChatInput>
      </ChatContainer>
    </>
  );
};

ChatView.propTypes = {
  /** Title displayed in the chat header */
  title: PropTypes.string,
  /** Array of message objects with type, content, and timestamp */
  messages: PropTypes.arrayOf(PropTypes.shape({
    type: PropTypes.oneOf(['user', 'ai']).isRequired,
    content: PropTypes.string.isRequired,
    timestamp: PropTypes.string.isRequired
  })),
  /** Callback function when a message is sent */
  onSendMessage: PropTypes.func,
  /** Placeholder text for the input */
  placeholder: PropTypes.string,
  /** Loading state indicator */
  isLoading: PropTypes.bool,
  /** Whether to show attachment button */
  showAttachment: PropTypes.bool,
  /** Maximum message length */
  maxMessageLength: PropTypes.number,
  /** Additional CSS class */
  className: PropTypes.string,
  /** Additional inline styles */
  style: PropTypes.object
};

export default ChatView;