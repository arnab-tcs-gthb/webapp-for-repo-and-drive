// Central export point for all reusable UI components
// This creates a clean import path: import { Button, Card } from '../components/ui';

// Base UI Components
export * from './base';

// Adobe Franklin UI Components  
export * from './adobe-franklin';

// Re-export for backward compatibility
export { default as Button } from './base/Button';
export { default as Card } from './base/Card';
export { default as Input } from './base/Input';
export { default as Modal } from './base/Modal';
export { default as Dropdown } from './base/Dropdown';

// TODO: Add more components as they are created
// export { default as Table } from './Table';
// export { default as Form } from './Form';
// export { default as Badge } from './Badge';
// export { default as Tooltip } from './Tooltip';
// export { default as Spinner } from './Spinner';
// export { default as Alert } from './Alert';
// export { default as Tabs } from './Tabs';
// export { default as Accordion } from './Accordion';
// export { default as Breadcrumb } from './Breadcrumb';
// export { default as Pagination } from './Pagination';
