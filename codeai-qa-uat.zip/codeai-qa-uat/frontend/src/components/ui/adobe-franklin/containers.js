import styled from 'styled-components';
import { adobeFranklinTheme } from './theme';

// Layout container components
export const PageContainer = styled.div`
  display: flex;
  height: 100vh;
  background-color: ${props => props.theme.colors.background};
`;

export const MainContent = styled.main.withConfig({
  shouldForwardProp: (prop) => prop !== 'sidebarCollapsed',
})`
  flex: 1;
  display: flex;
  flex-direction: column;
  margin-left: ${props => props.sidebarCollapsed ? '70px' : '240px'};
  transition: margin-left 0.3s ease;
  overflow: hidden;
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    margin-left: 0;
  }
`;

export const Header = styled.header`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem 2rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  flex-shrink: 0;
`;

export const PageTitle = styled.h1`
  font-size: 1.75rem;
  font-weight: 600;
  margin: 0;
  color: ${props => props.theme.colors.text};
`;

export const StepTitle = styled.h2.withConfig({
  shouldForwardProp: (prop) => !['active', 'completed'].includes(prop),
})`
  font-size: 1.5rem;
  font-weight: 600;
  margin: 0 0 1.5rem 0;
  color: ${props => props.theme.colors.text};
`;

// Content containers
export const ContentCard = styled.div`
  flex: 1;
  margin: 2rem;
  padding: 2rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: 12px;
  border: 1px solid ${props => props.theme.colors.border};
  overflow-y: auto;
  box-shadow: 0 2px 4px ${props => props.theme.colors.shadow};
`;

export const CardTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
  margin: 0 0 1.5rem 0;
  color: ${props => props.theme.colors.text};
`;

// Section containers
export const MetadataSection = styled.div`
  margin-bottom: 2rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

export const MetadataHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

export const SectionTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 500;
  margin: 0;
  color: ${props => props.theme.colors.text};
`;

// Action containers
export const ActionContainer = styled.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  padding-top: 1.5rem;
  border-top: 1px solid ${props => props.theme.colors.border};
  margin-top: 2rem;
`;

// Grid layouts
export const MetadataGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  margin-bottom: 1rem;
  
  @media (max-width: ${props => props.theme.breakpoints?.md || '768px'}) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (max-width: ${props => props.theme.breakpoints?.sm || '576px'}) {
    grid-template-columns: 1fr;
  }
`;

export const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 1rem;
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    grid-template-columns: repeat(3, 1fr);
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (max-width: ${props => props.theme.breakpoints.sm}) {
    grid-template-columns: 1fr;
  }
`;

// File explorer containers
export const FileExplorerContainer = styled.div`
  display: grid;
  grid-template-columns: 300px 1fr;
  height: 600px;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: 8px;
  overflow: hidden;
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    grid-template-columns: 250px 1fr;
  }
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    grid-template-columns: 1fr;
    height: auto;
  }
`;

export const FileTreeContainer = styled.div`
  background-color: ${props => props.theme.colors.inputBackground};
  border-right: 1px solid ${props => props.theme.colors.border};
  overflow-y: auto;
  
  @media (max-width: ${props => props.theme.breakpoints.md}) {
    max-height: 300px;
  }
`;

export const FileTreeHeader = styled.div`
  padding: 0.75rem 1rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  font-weight: 500;
  font-size: 0.9rem;
  color: ${props => props.theme.colors.text};
`;

export const FileTreeContent = styled.div`
  padding: 0.5rem;
`;

export const PreviewContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  background-color: ${props => props.theme.colors.cardBackground};
`;

// Testing containers
export const TestingContainer = styled.div`
  margin-bottom: 2rem;
`;

export const TestingGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
  margin: 1.5rem 0;
`;

// Deployment containers
export const DeploymentContainer = styled.div`
  margin-bottom: 2rem;
`;

export const DeploymentSteps = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  margin-bottom: 2rem;
  padding: 1rem 0;
`;

export const DeploymentStep = styled.div`
  display: flex;
  gap: 1rem;
`;

export const EnvironmentContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  
  @media (max-width: ${props => props.theme.breakpoints.lg}) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (max-width: ${props => props.theme.breakpoints.sm}) {
    grid-template-columns: 1fr;
  }
`;

// Files section containers
export const UploadedFilesSection = styled.div`
  margin-top: 2rem;
`;

export const FilesHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

export const FilesTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 500;
  margin: 0;
`;

export const FilesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 1rem;
`;

export const PageCardsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.5rem;
  margin-top: 1rem;
`;

export const LoadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 200px;
  padding: 2rem;
  background-color: ${props => props.theme.colors.surface};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  text-align: center;
`;

export const WizardContainer = styled.div`
  width: 100%;
  margin: 0;
  padding: 1.5rem;
  background-color: ${props => props.theme.colors.background};
  min-height: 100vh;
`;

export const ProgressContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  background-color: ${props => props.theme.colors.surface};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  margin-bottom: 1rem;
`;

export const WizardContent = styled.div`
  padding: 1rem;
  background-color: ${props => props.theme.colors.surface};
  border-radius: ${props => props.theme.borderRadius?.medium || '8px'};
  box-shadow: ${props => props.theme.shadows?.card || '0 2px 4px rgba(0,0,0,0.1)'};
`;

export const StepContent = styled.div`
  min-height: calc(100vh - 200px);
  padding: 1.5rem;
`;

export const ButtonGroup = styled.div`
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: flex-end;
  padding: 1rem 0;
  border-top: 1px solid ${props => props.theme.colors.border};
  margin-top: 1.5rem;
`;
