import styled from 'styled-components';
import { adobeFranklinTheme } from './theme';

// Base card component
export const Card = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1.5rem;
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
`;

// Metadata cards
export const MetadataCard = styled(Card)`
  text-align: center;
  padding: 1rem;
  
  &:hover {
    transform: translateY(-2px);
  }
`;

export const MetadataLabel = styled.div`
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textSecondary};
  margin-bottom: 0.5rem;
  font-weight: ${props => props.theme.fontWeight.normal};
`;

export const MetadataValue = styled.div`
  font-size: ${props => props.theme.fontSize.lg};
  font-weight: ${props => props.theme.fontWeight.semibold};
  color: ${props => props.theme.colors.text};
  line-height: 1.2;
`;

// Statistics cards
export const StatCard = styled(Card)`
  text-align: center;
  padding: 1rem;
  min-height: 80px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  
  &:hover {
    transform: translateY(-2px);
  }
`;

export const StatValue = styled.div`
  font-size: ${props => props.theme.fontSize.xl};
  font-weight: ${props => props.theme.fontWeight.bold};
  color: ${props => props.theme.colors.primary};
  margin-bottom: 0.25rem;
  line-height: 1;
`;

export const StatLabel = styled.div`
  font-size: ${props => props.theme.fontSize.xs};
  color: ${props => props.theme.colors.textSecondary};
  text-transform: uppercase;
  font-weight: ${props => props.theme.fontWeight.medium};
  letter-spacing: 0.5px;
`;

// Page cards (for content mapping)
export const PageCard = styled(Card)`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  overflow: hidden;
  border: 1px solid ${props => props.theme.colors.border};
  transition: all ${props => props.theme.transitions.normal};
  display: flex;
  flex-direction: column;
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
`;

export const PageCardImagePreview = styled.div`
  width: 100%;
  height: 160px;
  background-color: ${props => props.theme.colors.inputBackground};
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

export const PageCardStatusBadge = styled.div`
  position: absolute;
  top: 10px;
  right: 10px;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.success};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.theme.colors.textInverse};
  z-index: 1;
`;

export const PageCardInfo = styled.div`
  padding: 1rem;
  display: flex;
  flex-direction: column;
  flex: 1;
`;

export const PageCardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.75rem;
`;

export const PageCardTitle = styled.div`
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize.md};
  color: ${props => props.theme.colors.text};
`;

export const PageCardPath = styled.div`
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textSecondary};
  margin-top: 0.25rem;
`;

export const PageCardConfidence = styled.div`
  background-color: ${props => props.theme.colors.successLight};
  color: ${props => props.theme.colors.success};
  padding: 0.25rem 0.5rem;
  border-radius: ${adobeFranklinTheme.borderRadius.small};
  display: inline-block;
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize.xs};
  white-space: nowrap;
`;

export const PageCardStats = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 0.75rem 0;
  padding-top: 0.75rem;
  border-top: 1px solid ${props => props.theme.colors.border};
`;

export const PageCardStat = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const PageCardStatValue = styled.div`
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize.md};
  color: ${props => props.theme.colors.text};
`;

export const PageCardStatLabel = styled.div`
  font-size: ${props => props.theme.fontSize.xs};
  color: ${props => props.theme.colors.textSecondary};
`;

export const PageCardFooter = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-top: auto;
  padding-top: 0.75rem;
  justify-content: flex-end;
`;

// Testing cards
export const TestingCard = styled(Card)`
  display: flex;
  flex-direction: column;
  height: 100%;
`;

export const TestingCardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
`;

export const TestingTitle = styled.h4`
  font-size: ${props => props.theme.fontSize.lg};
  font-weight: ${props => props.theme.fontWeight.medium};
  margin: 0;
  color: ${props => props.theme.colors.text};
`;

export const TestingStatus = styled.span`
  padding: 0.25rem 0.5rem;
  border-radius: ${adobeFranklinTheme.borderRadius.small};
  font-size: ${props => props.theme.fontSize.xs};
  font-weight: ${props => props.theme.fontWeight.medium};
  text-transform: uppercase;
  background-color: ${props => {
    switch (props.status) {
      case 'Passed': return props.theme.colors.successLight;
      case 'Failed': return props.theme.colors.errorLight;
      case 'In Progress': return props.theme.colors.warningLight;
      default: return props.theme.colors.borderLight;
    }
  }};
  color: ${props => {
    switch (props.status) {
      case 'Passed': return props.theme.colors.success;
      case 'Failed': return props.theme.colors.error;
      case 'In Progress': return props.theme.colors.warning;
      default: return props.theme.colors.textSecondary;
    }
  }};
`;

export const TestingDescription = styled.p`
  font-size: ${props => props.theme.fontSize.md};
  color: ${props => props.theme.colors.text};
  margin-bottom: 1rem;
  line-height: 1.4;
`;

export const TestingDetails = styled.div`
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textSecondary};
  margin-top: auto;
  
  p {
    margin: 0.25rem 0;
  }
  
  strong {
    color: ${props => props.theme.colors.text};
  }
`;

// Environment cards
export const EnvironmentCard = styled(Card)`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1.5rem;
  
  h5 {
    font-size: ${props => props.theme.fontSize.lg};
    font-weight: ${props => props.theme.fontWeight.medium};
    margin: 0 0 1rem 0;
    color: ${props => props.theme.colors.text};
    display: flex;
    align-items: center;
  }
`;

// Step content cards
export const StepContent = styled.div`
  flex: 1;
`;

export const StepContentHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
`;

export const StepName = styled.div`
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize.md};
  color: ${props => props.theme.colors.text};
`;

export const StepTime = styled.div`
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textSecondary};
`;

export const StepIcon = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  background-color: ${props =>
    props.status === 'completed' ? props.theme.colors.success :
      props.status === 'in-progress' ? props.theme.colors.warning :
        props.theme.colors.borderLight
  };
  color: ${props =>
    props.status === 'completed' || props.status === 'in-progress' ? props.theme.colors.textInverse :
      props.theme.colors.textSecondary
  };
  font-weight: ${props => props.theme.fontWeight.semibold};
  font-size: ${props => props.theme.fontSize.sm};
`;

// Content card (main container for step content)
export const ContentCard = styled(Card)`
  flex: 1;
  margin: 2rem;
  padding: 2rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.large};
  border: 1px solid ${props => props.theme.colors.border};
  overflow-y: auto;
  box-shadow: 0 2px 4px ${props => props.theme.colors.shadow};
  
  &:hover {
    transform: none; // Override hover transform for main content card
  }
`;
