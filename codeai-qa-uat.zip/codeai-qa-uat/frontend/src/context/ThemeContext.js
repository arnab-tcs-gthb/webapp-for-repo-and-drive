import React, { createContext, useState, useContext, useEffect } from 'react';

// Legacy theme definitions for backward compatibility
export const lightTheme = {
  name: 'light',
  colors: {
    background: '#f5f7fa',
    surface: '#ffffff',
    surfaceHover: '#f0f2f5',
    border: '#e1e4e8',
    borderLight: '#f0f2f5',
    borderDark: '#d1d9e0',
    primary: '#4285f4',
    primaryLight: '#e8f0fe',
    primaryDark: '#1a73e8',
    primarySoft: 'rgba(66, 133, 244, 0.15)',
    primaryHover: '#1a73e8',
    primaryShadow: 'rgba(66, 133, 244, 0.3)',
    success: '#34a853',
    successLight: '#e6f4ea',
    info: '#4285f4',
    infoLight: '#e8f0fe',
    warning: '#fbbc05',
    warningLight: '#fef7e0',
    error: '#ea4335',
    errorLight: '#fce8e6',
    text: '#2c303a',
    textSecondary: '#6c757d',
    textMuted: '#999999',
    textInverse: '#ffffff',
    sidebarBackground: '#ffffff',
    sidebarBorder: '#e1e4e8',
    cardBackground: '#ffffff',
    cardBorder: '#e1e4e8',
    cardShadow: '0 4px 8px rgba(0, 0, 0, 0.05)',
    inputBackground: '#ffffff',
    inputBorder: '#e1e4e8',
    inputText: '#2c303a',
    inputPlaceholder: '#6c757d',
    inputHoverBackground: '#f0f2f5',
    iconColor: '#6c757d',
    shadow: 'rgba(0, 0, 0, 0.1)',
    shadowLight: 'rgba(0, 0, 0, 0.05)',
    shadowDark: 'rgba(0, 0, 0, 0.15)'
  },
  fontSize: {
    xs: '0.75rem',    // 12px
    sm: '0.875rem',   // 14px
    md: '1rem',       // 16px
    lg: '1.125rem',   // 18px
    xl: '1.25rem',    // 20px
    xxl: '1.5rem',    // 24px
    xxxl: '2rem',     // 32px
  },
  fontWeight: {
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
  },
  transitions: {
    fast: '0.15s ease',
    normal: '0.2s ease',
    slow: '0.3s ease',
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    card: '0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24)',
  },
  borderRadius: {
    small: '4px',
    medium: '8px',
    large: '12px',
    xl: '16px',
  },
  breakpoints: {
    sm: '576px',
    md: '768px',
    lg: '992px',
    xl: '1200px',
    xxl: '1400px',
  }
};

export const darkTheme = {
  name: 'dark',
  colors: {
    background: '#1c1f26',
    surface: '#2c303a',
    surfaceHover: '#373c48',
    border: '#2c303a',
    borderLight: '#373c48',
    borderDark: '#454c5b',
    primary: '#4285f4',
    primaryLight: '#1c2a43',
    primaryDark: '#5a95f5',
    primarySoft: 'rgba(66, 133, 244, 0.15)',
    primaryHover: '#5a95f5',
    primaryShadow: 'rgba(66, 133, 244, 0.3)',
    success: '#34a853',
    successLight: '#0f2a1b',
    info: '#4285f4',
    infoLight: '#1c2a43',
    warning: '#fbbc05',
    warningLight: '#2e2a15',
    error: '#ea4335',
    errorLight: '#2d1a1a',
    text: '#ffffff',
    textSecondary: '#a0a0a0',
    textMuted: '#666666',
    textInverse: '#000000',
    sidebarBackground: '#12151C',
    sidebarBorder: '#2c303a',
    cardBackground: '#2c303a',
    cardBorder: '#2c303a',
    cardShadow: '0 4px 8px rgba(0, 0, 0, 0.15)',
    inputBackground: '#2c303a',
    inputBorder: '#454c5b',
    inputText: '#ffffff',
    inputPlaceholder: '#a0a0a0',
    inputHoverBackground: '#373c48',
    iconColor: '#a0a0a0',
    shadow: 'rgba(0, 0, 0, 0.3)',
    shadowLight: 'rgba(0, 0, 0, 0.2)',
    shadowDark: 'rgba(0, 0, 0, 0.4)'
  },
  fontSize: {
    xs: '0.75rem',    // 12px
    sm: '0.875rem',   // 14px
    md: '1rem',       // 16px
    lg: '1.125rem',   // 18px
    xl: '1.25rem',    // 20px
    xxl: '1.5rem',    // 24px
    xxxl: '2rem',     // 32px
  },
  fontWeight: {
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
  },
  transitions: {
    fast: '0.15s ease',
    normal: '0.2s ease',
    slow: '0.3s ease',
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.1)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.2), 0 2px 4px -1px rgba(0, 0, 0, 0.12)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.2), 0 4px 6px -2px rgba(0, 0, 0, 0.1)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.2), 0 10px 10px -5px rgba(0, 0, 0, 0.08)',
    card: '0 1px 3px rgba(0, 0, 0, 0.24), 0 1px 2px rgba(0, 0, 0, 0.36)',
  },
  borderRadius: {
    small: '4px',
    medium: '8px',
    large: '12px',
    xl: '16px',
  },
  breakpoints: {
    sm: '576px',
    md: '768px',
    lg: '992px',
    xl: '1200px',
    xxl: '1400px',
  }
};

// Create the theme context
export const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  // Initialize from localStorage or default to dark theme
  const [currentTheme, setCurrentTheme] = useState(darkTheme);
  const [useEnhanced, setUseEnhanced] = useState(false); // Default to false to avoid circular dependency

  // Load theme preference from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const savedEnhanced = localStorage.getItem('useEnhancedTheme');
    
    const shouldUseEnhanced = savedEnhanced === 'true'; // Default to false to avoid dependency issues
    setUseEnhanced(shouldUseEnhanced);
    
    if (savedTheme) {
      if (shouldUseEnhanced) {
        // Dynamically import enhanced themes to avoid circular dependency
        import('./enhancedTheme').then(({ enhancedLightTheme, enhancedDarkTheme }) => {
          setCurrentTheme(savedTheme === 'light' ? enhancedLightTheme : enhancedDarkTheme);
        });
      } else {
        setCurrentTheme(savedTheme === 'light' ? lightTheme : darkTheme);
      }
    }
  }, []);

  // Toggle between light and dark themes
  const toggleTheme = () => {
    const isLight = currentTheme.name === 'light';
    
    if (useEnhanced) {
      // Dynamically import enhanced themes
      import('./enhancedTheme').then(({ enhancedLightTheme, enhancedDarkTheme }) => {
        const newTheme = isLight ? enhancedDarkTheme : enhancedLightTheme;
        setCurrentTheme(newTheme);
        localStorage.setItem('theme', newTheme.name);
      });
    } else {
      const newTheme = isLight ? darkTheme : lightTheme;
      setCurrentTheme(newTheme);
      localStorage.setItem('theme', newTheme.name);
    }
  };

  // Set a specific theme
  const setTheme = (themeName) => {
    if (useEnhanced) {
      // Dynamically import enhanced themes
      import('./enhancedTheme').then(({ enhancedLightTheme, enhancedDarkTheme }) => {
        const newTheme = themeName === 'light' ? enhancedLightTheme : enhancedDarkTheme;
        setCurrentTheme(newTheme);
        localStorage.setItem('theme', themeName);
      });
    } else {
      const newTheme = themeName === 'light' ? lightTheme : darkTheme;
      setCurrentTheme(newTheme);
      localStorage.setItem('theme', themeName);
    }
  };

  // Toggle between enhanced and legacy theme systems
  const toggleEnhancedTheme = () => {
    const newUseEnhanced = !useEnhanced;
    setUseEnhanced(newUseEnhanced);
    localStorage.setItem('useEnhancedTheme', newUseEnhanced.toString());
    
    // Update current theme to match new system
    const isLight = currentTheme.name === 'light';
    
    if (newUseEnhanced) {
      // Dynamically import enhanced themes
      import('./enhancedTheme').then(({ enhancedLightTheme, enhancedDarkTheme }) => {
        const newTheme = isLight ? enhancedLightTheme : enhancedDarkTheme;
        setCurrentTheme(newTheme);
      });
    } else {
      const newTheme = isLight ? lightTheme : darkTheme;
      setCurrentTheme(newTheme);
    }
  };

  const themeValue = {
    theme: currentTheme,
    toggleTheme,
    setTheme,
    toggleEnhancedTheme,
    useEnhanced,
    isDarkMode: currentTheme.name === 'dark',
    // Provide access to legacy theme variants (enhanced themes loaded dynamically)
    themes: {
      light: lightTheme,
      dark: darkTheme
    }
  };

  return (
    <ThemeContext.Provider value={themeValue}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom hook to use the theme context
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export default ThemeContext;