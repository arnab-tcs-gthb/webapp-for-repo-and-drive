import React, { createContext, useContext, useReducer } from 'react';
import PropTypes from 'prop-types';

// Initial state for file management
const initialState = {
  files: [],
  fileTree: {},
  selectedFile: null,
  expandedFolders: new Set(['src', 'components', 'documents']),
  searchQuery: '',
  uploadProgress: {},
  isUploading: false,
  previewCache: new Map(),
  fileValidation: {},
  documentHierarchy: []
};

// Action types
const FILE_ACTIONS = {
  SET_FILES: 'SET_FILES',
  ADD_FILES: 'ADD_FILES',
  REMOVE_FILE: 'REMOVE_FILE',
  SET_FILE_TREE: 'SET_FILE_TREE',
  SET_SELECTED_FILE: 'SET_SELECTED_FILE',
  TOGGLE_FOLDER: 'TOGGLE_FOLDER',
  SET_EXPANDED_FOLDERS: 'SET_EXPANDED_FOLDERS',
  SET_SEARCH_QUERY: 'SET_SEARCH_QUERY',
  SET_UPLOAD_PROGRESS: 'SET_UPLOAD_PROGRESS',
  SET_IS_UPLOADING: 'SET_IS_UPLOADING',
  SET_PREVIEW_CACHE: 'SET_PREVIEW_CACHE',
  ADD_TO_PREVIEW_CACHE: 'ADD_TO_PREVIEW_CACHE',
  REMOVE_FROM_PREVIEW_CACHE: 'REMOVE_FROM_PREVIEW_CACHE',
  SET_FILE_VALIDATION: 'SET_FILE_VALIDATION',
  SET_DOCUMENT_HIERARCHY: 'SET_DOCUMENT_HIERARCHY',
  RESET_FILES: 'RESET_FILES'
};

// Reducer function
const fileReducer = (state, action) => {
  switch (action.type) {
    case FILE_ACTIONS.SET_FILES:
      return {
        ...state,
        files: action.payload
      };

    case FILE_ACTIONS.ADD_FILES:
      return {
        ...state,
        files: [...state.files, ...action.payload]
      };

    case FILE_ACTIONS.REMOVE_FILE:
      const filteredFiles = state.files.filter(file => file.id !== action.payload);
      return {
        ...state,
        files: filteredFiles,
        selectedFile: state.selectedFile?.id === action.payload ? null : state.selectedFile
      };

    case FILE_ACTIONS.SET_FILE_TREE:
      return {
        ...state,
        fileTree: action.payload
      };

    case FILE_ACTIONS.SET_SELECTED_FILE:
      return {
        ...state,
        selectedFile: action.payload
      };

    case FILE_ACTIONS.TOGGLE_FOLDER:
      const newExpandedFolders = new Set(state.expandedFolders);
      if (newExpandedFolders.has(action.payload)) {
        newExpandedFolders.delete(action.payload);
      } else {
        newExpandedFolders.add(action.payload);
      }
      return {
        ...state,
        expandedFolders: newExpandedFolders
      };

    case FILE_ACTIONS.SET_EXPANDED_FOLDERS:
      return {
        ...state,
        expandedFolders: new Set(action.payload)
      };

    case FILE_ACTIONS.SET_SEARCH_QUERY:
      return {
        ...state,
        searchQuery: action.payload
      };

    case FILE_ACTIONS.SET_UPLOAD_PROGRESS:
      return {
        ...state,
        uploadProgress: action.payload
      };

    case FILE_ACTIONS.SET_IS_UPLOADING:
      return {
        ...state,
        isUploading: action.payload
      };

    case FILE_ACTIONS.SET_PREVIEW_CACHE:
      return {
        ...state,
        previewCache: action.payload
      };

    case FILE_ACTIONS.ADD_TO_PREVIEW_CACHE:
      const newCache = new Map(state.previewCache);
      newCache.set(action.payload.fileId, action.payload.preview);
      return {
        ...state,
        previewCache: newCache
      };

    case FILE_ACTIONS.REMOVE_FROM_PREVIEW_CACHE:
      const updatedCache = new Map(state.previewCache);
      updatedCache.delete(action.payload);
      return {
        ...state,
        previewCache: updatedCache
      };

    case FILE_ACTIONS.SET_FILE_VALIDATION:
      return {
        ...state,
        fileValidation: {
          ...state.fileValidation,
          [action.payload.fileId]: action.payload.validation
        }
      };

    case FILE_ACTIONS.SET_DOCUMENT_HIERARCHY:
      return {
        ...state,
        documentHierarchy: action.payload
      };

    case FILE_ACTIONS.RESET_FILES:
      return initialState;

    default:
      return state;
  }
};

// Create context
const FileContext = createContext();

// Context provider component
const FileProvider = ({ children }) => {
  const [state, dispatch] = useReducer(fileReducer, initialState);

  // Action creators
  const actions = {
    setFiles: (files) => {
      dispatch({ type: FILE_ACTIONS.SET_FILES, payload: files });
    },

    addFiles: (files) => {
      dispatch({ type: FILE_ACTIONS.ADD_FILES, payload: files });
    },

    removeFile: (fileId) => {
      dispatch({ type: FILE_ACTIONS.REMOVE_FILE, payload: fileId });
    },

    setFileTree: (tree) => {
      dispatch({ type: FILE_ACTIONS.SET_FILE_TREE, payload: tree });
    },

    setSelectedFile: (file) => {
      dispatch({ type: FILE_ACTIONS.SET_SELECTED_FILE, payload: file });
    },

    toggleFolder: (folderPath) => {
      dispatch({ type: FILE_ACTIONS.TOGGLE_FOLDER, payload: folderPath });
    },

    setExpandedFolders: (folders) => {
      dispatch({ type: FILE_ACTIONS.SET_EXPANDED_FOLDERS, payload: folders });
    },

    setSearchQuery: (query) => {
      dispatch({ type: FILE_ACTIONS.SET_SEARCH_QUERY, payload: query });
    },

    setUploadProgress: (progress) => {
      dispatch({ type: FILE_ACTIONS.SET_UPLOAD_PROGRESS, payload: progress });
    },

    setIsUploading: (isUploading) => {
      dispatch({ type: FILE_ACTIONS.SET_IS_UPLOADING, payload: isUploading });
    },

    setPreviewCache: (cache) => {
      dispatch({ type: FILE_ACTIONS.SET_PREVIEW_CACHE, payload: cache });
    },

    addToPreviewCache: (fileId, preview) => {
      dispatch({ 
        type: FILE_ACTIONS.ADD_TO_PREVIEW_CACHE, 
        payload: { fileId, preview } 
      });
    },

    removeFromPreviewCache: (fileId) => {
      dispatch({ type: FILE_ACTIONS.REMOVE_FROM_PREVIEW_CACHE, payload: fileId });
    },

    setFileValidation: (fileId, validation) => {
      dispatch({ 
        type: FILE_ACTIONS.SET_FILE_VALIDATION, 
        payload: { fileId, validation } 
      });
    },

    setDocumentHierarchy: (hierarchy) => {
      dispatch({ type: FILE_ACTIONS.SET_DOCUMENT_HIERARCHY, payload: hierarchy });
    },

    resetFiles: () => {
      dispatch({ type: FILE_ACTIONS.RESET_FILES });
    }
  };

  const value = {
    ...state,
    ...actions
  };

  return (
    <FileContext.Provider value={value}>
      {children}
    </FileContext.Provider>
  );
};

FileProvider.propTypes = {
  children: PropTypes.node.isRequired
};

// Custom hook to use the file context
const useFileContext = () => {
  const context = useContext(FileContext);
  if (!context) {
    throw new Error('useFileContext must be used within a FileProvider');
  }
  return context;
};

export { FileProvider, useFileContext, FILE_ACTIONS };
export default FileContext;
