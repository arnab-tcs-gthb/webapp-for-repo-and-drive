import React, { createContext, useContext, useReducer, useEffect } from 'react';
import PropTypes from 'prop-types';

// Initial state for project data
const initialState = {
  projectId: '',  // Changed from null to empty string
  currentStep: 1,
  projectData: {},
  loading: {
    project: false,
    metadata: false,
    analysis: false
  },
  errors: {
    project: null,
    metadata: null,
    analysis: null
  }
};

// Action types
const PROJECT_ACTIONS = {
  SET_PROJECT_ID: 'SET_PROJECT_ID',
  SET_CURRENT_STEP: 'SET_CURRENT_STEP',
  UPDATE_PROJECT_DATA: 'UPDATE_PROJECT_DATA',
  SET_LOADING: 'SET_LOADING',
  SET_ERROR: 'SET_ERROR',
  RESET_ERROR: 'RESET_ERROR',
  RESET_PROJECT: 'RESET_PROJECT'
};

// Helper to ensure projectId is always a string
const ensureString = (value) => value != null ? String(value) : '';

// Reducer function
const projectReducer = (state, action) => {
  switch (action.type) {
    case PROJECT_ACTIONS.SET_PROJECT_ID:
      return {
        ...state,
        projectId: ensureString(action.payload)
      };

    case PROJECT_ACTIONS.SET_CURRENT_STEP:
      console.log('📋 Reducer: Current step changing from', state.currentStep, 'to', action.payload);
      const newState = {
        ...state,
        currentStep: action.payload,
        projectData: {
          ...state.projectData,
          currentStep: action.payload
        }
      };
      console.log('📋 Reducer: New state after step change:', newState);
      return newState;

    case PROJECT_ACTIONS.UPDATE_PROJECT_DATA:
      return {
        ...state,
        projectData: {
          ...state.projectData,
          ...action.payload
        }
      };

    case PROJECT_ACTIONS.SET_LOADING:
      return {
        ...state,
        loading: {
          ...state.loading,
          [action.payload.key]: action.payload.value
        }
      };

    case PROJECT_ACTIONS.SET_ERROR:
      return {
        ...state,
        errors: {
          ...state.errors,
          [action.payload.key]: action.payload.error
        }
      };

    case PROJECT_ACTIONS.RESET_ERROR:
      return {
        ...state,
        errors: {
          ...state.errors,
          [action.payload]: null
        }
      };

    case PROJECT_ACTIONS.RESET_PROJECT:
      return initialState;

    default:
      return state;
  }
};

// Create context
const ProjectContext = createContext();

// Context provider component
const ProjectProvider = ({ children, projectId, projectData, initialStep = 1 }) => {
  const [state, dispatch] = useReducer(projectReducer, {
    ...initialState,
    projectId: ensureString(projectId),
    currentStep: initialStep,
    projectData: projectData || {}
  });

  // Initialize project data when projectId changes
  useEffect(() => {
    if (projectId != null) {
      dispatch({ type: PROJECT_ACTIONS.SET_PROJECT_ID, payload: projectId });
    }
  }, [projectId]);

  // Initialize project data when projectData prop changes
  useEffect(() => {
    if (projectData) {
      dispatch({ type: PROJECT_ACTIONS.UPDATE_PROJECT_DATA, payload: projectData });
    }
  }, [projectData]);

  // Action creators
  const actions = {
    setCurrentStep: (step) => {
      console.log('🔄 Context: Setting current step from', state.currentStep, 'to', step);
      dispatch({ type: PROJECT_ACTIONS.SET_CURRENT_STEP, payload: step });
    },

    updateProjectData: (data) => {
      dispatch({ type: PROJECT_ACTIONS.UPDATE_PROJECT_DATA, payload: data });
    },

    setLoading: (key, value) => {
      dispatch({ 
        type: PROJECT_ACTIONS.SET_LOADING, 
        payload: { key, value } 
      });
    },

    setError: (key, error) => {
      dispatch({ 
        type: PROJECT_ACTIONS.SET_ERROR, 
        payload: { key, error } 
      });
    },

    resetError: (key) => {
      dispatch({ type: PROJECT_ACTIONS.RESET_ERROR, payload: key });
    },

    resetProject: () => {
      dispatch({ type: PROJECT_ACTIONS.RESET_PROJECT });
    }
  };

  const value = {
    ...state,
    ...actions
  };

  return (
    <ProjectContext.Provider value={value}>
      {children}
    </ProjectContext.Provider>
  );
};

ProjectProvider.propTypes = {
  children: PropTypes.node.isRequired,
  projectId: PropTypes.string,
  projectData: PropTypes.object,
  initialStep: PropTypes.number
};

// Custom hook to use the project context
const useProjectContext = () => {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProjectContext must be used within a ProjectProvider');
  }
  return context;
};

export { ProjectProvider, useProjectContext, PROJECT_ACTIONS };
export default ProjectContext;
