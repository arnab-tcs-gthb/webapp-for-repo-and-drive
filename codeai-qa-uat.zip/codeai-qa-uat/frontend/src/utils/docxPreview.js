/**
 * Utility functions for rendering DOCX file previews
 */

/**
 * Creates a safe embedding HTML for Google Drive documents
 * @param {Object} file - The file object containing path and metadata
 * @param {boolean} isLoading - Whether the document is still loading
 * @returns {string} - HTML string for embedding the Google Drive document
 */
export const createGoogleDriveEmbed = (file, isLoading = false) => {
  if (!file || !file.path) {
    return `<div style="padding: 1rem; text-align: center;">No file path provided</div>`;
  }
  
  if (isLoading) {
    return `
      <div style="padding: 2rem; text-align: center; color: #555;">
        <div style="font-size: 48px; margin-bottom: 20px;">🔄</div>
        <div style="margin-bottom: 1rem; font-size: 16px;">
          Loading document from Google Drive
        </div>
        <div style="color: #777; font-size: 14px;">
          Retrieving ${file.name} from cloud storage...
        </div>
      </div>
    `;
  }
  
  // Process the Google Drive URL to ensure proper embedding
  let embeddingUrl = file.path;
  
  // If the URL contains /view, transform it to an embedding URL
  if (embeddingUrl.includes('/view')) {
    // Replace /view with /preview for better embedding
    embeddingUrl = embeddingUrl.replace(/\/view.*$/, '/preview');
  }
  
  // If the URL contains /folders/, handle folder link
  if (embeddingUrl.includes('/folders/')) {
    // For folder links, provide a view that shows the folder contents
    embeddingUrl = `https://drive.google.com/embeddedfolderview?id=${
      embeddingUrl.match(/\/folders\/([^/?]+)/)?.[1] || ''
    }#list`;
  }
  
  // Create embedded iframe for Google Docs with error handling
  return `
    <div style="width: 100%; height: 100%; min-height: 500px; padding: 1rem;">
      <iframe 
        src="${embeddingUrl}" 
        style="width: 100%; height: 100%; min-height: 600px; border: 1px solid #e0e0e0;"
        frameborder="0"
        allowfullscreen="true"
        mozallowfullscreen="true"
        webkitallowfullscreen="true"
        onerror="this.style.display='none'; this.parentNode.innerHTML += '<div>Failed to load document. <a href=\\'${file.path}\\' target=\\'_blank\\'>Open in browser</a></div>';"
      ></iframe>
      <div style="margin-top: 10px; text-align: right;">
        <a href="${file.path}" target="_blank" style="text-decoration: none; color: #1a73e8; font-size: 14px;">
          Open in Google Drive ↗
        </a>
      </div>
    </div>
  `;
};

/**
 * Simple in-memory cache for document previews to improve performance 
 * particularly for cloud documents which may take longer to retrieve
 */
export const documentPreviewCache = {
  cache: {},
  
  /**
   * Store document preview HTML in cache
   * @param {string} documentId - Unique ID for the document
   * @param {string} html - Generated HTML preview content
   */
  set(documentId, html) {
    if (documentId && html) {
      this.cache[documentId] = {
        html,
        timestamp: Date.now()
      };
      console.log(`Cached preview for document: ${documentId}`);
    }
  },
  
  /**
   * Retrieve cached document preview if available
   * @param {string} documentId - Unique ID for the document
   * @returns {string|null} - HTML content or null if not cached/expired
   */
  get(documentId) {
    const entry = this.cache[documentId];
    if (entry) {
      // Cache entries expire after 1 hour
      const cacheValidTimeMs = 60 * 60 * 1000;
      if (Date.now() - entry.timestamp < cacheValidTimeMs) {
        console.log(`Using cached preview for document: ${documentId}`);
        return entry.html;
      } else {
        // Remove expired entry
        delete this.cache[documentId];
        console.log(`Cache expired for document: ${documentId}`);
      }
    }
    return null;
  },
  
  /**
   * Check if a document preview exists in the cache
   * @param {string} documentId - Unique ID for the document
   * @returns {boolean} - Whether a valid cache entry exists
   */
  has(documentId) {
    return !!this.get(documentId);
  },
  
  /**
   * Clear all cached previews
   */
  clear() {
    this.cache = {};
    console.log('Document preview cache cleared');
  }
};

/**
 * Determine the document source (local or cloud service) based on path or URL
 * @param {Object} file - The file object containing path or URL
 * @returns {Object} - Contains source type and specific service if applicable
 */
export const getDocumentSource = (file) => {
  if (!file) return { type: 'unknown' };
  
  const path = file.path || '';
  
  // Check for cloud service URLs
  if (path.includes('drive.google.com')) {
    return { 
      type: 'cloud', 
      service: 'google-drive',
      icon: '🔄',
      label: 'Google Drive'
    };
  } else if (path.includes('sharepoint.com') || path.includes('office365.com')) {
    return { 
      type: 'cloud', 
      service: 'sharepoint',
      icon: '🔄',
      label: 'SharePoint'
    };
  } else if (path.includes('onedrive.live.com') || path.includes('1drv.ms')) {
    return { 
      type: 'cloud', 
      service: 'onedrive',
      icon: '🔄',
      label: 'OneDrive'
    };
  } else if (path.startsWith('http://') || path.startsWith('https://')) {
    return { 
      type: 'cloud', 
      service: 'web',
      icon: '🔗',
      label: 'Web Link'
    };
  }
  
  // Default to local file
  return { 
    type: 'local', 
    service: null,
    icon: '📄',
    label: 'Local File'
  };
};

/**
 * Extract useful display information for a document
 * @param {Object} file - The file object
 * @returns {Object} - Metadata about the file
 */
export const getDocumentMetadata = (file) => {
  if (!file || !file.name) return {};
  
  const docTitle = file.name.replace('.docx', '');
  const source = getDocumentSource(file);
  
  let locationInfo = {};
  
  if (source.type === 'local') {
    const filePathParts = (file.path || "").split(/[/\\]/); // Split by forward or backslash
    locationInfo = {
      folder: filePathParts.length > 1 ? filePathParts[filePathParts.length - 2] : 'documents',
      relativePath: file.relativePath || file.path,
      fullPath: file.path
    };
  } else if (source.type === 'cloud') {
    locationInfo = {
      folder: source.label,
      relativePath: file.name,
      fullPath: file.path
    };
  }
  
  return {
    title: docTitle,
    source,
    ...locationInfo
  };
};

/**
 * Generate a fallback HTML preview for a DOCX file
 * since we can't access the actual file contents in the browser environment
 */
export const generateDocxFallbackPreview = (file, components = []) => {
  if (!file || !file.name) {
    return `
      <div style="padding: 2rem; text-align: center;">
        <p>Unable to generate preview: File data is missing</p>
      </div>
    `;
  }

  // Get document metadata
  const metadata = getDocumentMetadata(file);
  const docTitle = metadata.title;
  const fileLocation = metadata.folder;

  // Create different content based on file location/folder
  let specificContent = '';
  
  if (fileLocation === 'technical') {
    // Technical documentation content
    specificContent = `
      <h2 style="color: #2B579A; font-size: 20px; margin-top: 32px;">Technical Specifications</h2>
      <p style="line-height: 1.6;">
        The following technical specifications outline the requirements and configurations 
        for deploying and maintaining the AEM Franklin project components.
      </p>
      
      <h3 style="color: #2B579A; font-size: 18px; margin-top: 24px;">Component Architecture</h3>
      <p style="line-height: 1.6;">
        All components follow a standard structure with the following files:
      </p>
      <ul style="line-height: 1.6;">
        <li><strong>index.js</strong> - Main component definition</li>
        <li><strong>component.css</strong> - Component styling</li>
        <li><strong>README.md</strong> - Component documentation</li>
      </ul>
      
      <h3 style="color: #2B579A; font-size: 18px; margin-top: 24px;">API Endpoints</h3>
      <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
        <thead>
          <tr style="background-color: #f3f3f3;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Endpoint</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Method</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Purpose</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">/api/components</td>
            <td style="border: 1px solid #ddd; padding: 8px;">GET</td>
            <td style="border: 1px solid #ddd; padding: 8px;">Retrieve all components</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">/api/components/{id}</td>
            <td style="border: 1px solid #ddd; padding: 8px;">GET</td>
            <td style="border: 1px solid #ddd; padding: 8px;">Get specific component</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">/api/templates</td>
            <td style="border: 1px solid #ddd; padding: 8px;">GET</td>
            <td style="border: 1px solid #ddd; padding: 8px;">Retrieve all templates</td>
          </tr>
        </tbody>
      </table>
    `;
  } else if (fileLocation === 'guides') {
    // User guides content
    specificContent = `
      <h2 style="color: #2B579A; font-size: 20px; margin-top: 32px;">User Guide</h2>
      <p style="line-height: 1.6;">
        This guide will help you get started with implementing AEM Franklin components 
        within your project.
      </p>
      
      <h3 style="color: #2B579A; font-size: 18px; margin-top: 24px;">Getting Started</h3>
      <p style="line-height: 1.6;">
        Follow these steps to integrate the components into your project:
      </p>
      <ol style="line-height: 1.6;">
        <li>Clone the repository</li>
        <li>Install dependencies using <code>npm install</code></li>
        <li>Configure your environment variables</li>
        <li>Run the application with <code>npm start</code></li>
      </ol>
      
      <h3 style="color: #2B579A; font-size: 18px; margin-top: 24px;">Component Usage</h3>
      <p style="line-height: 1.6;">
        Each component can be imported and used as follows:
      </p>
      <div style="background-color: #f5f5f5; border-radius: 4px; padding: 16px; font-family: monospace; margin: 16px 0; overflow-x: auto;">
        import { Header, Footer } from '@aem-franklin/components';<br><br>
        
        function App() {<br>
        &nbsp;&nbsp;return (<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&lt;div&gt;<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;Header /&gt;<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;main&gt;Your content here&lt;/main&gt;<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;Footer /&gt;<br>
        &nbsp;&nbsp;&nbsp;&nbsp;&lt;/div&gt;<br>
        &nbsp;&nbsp;);<br>
        }
      </div>
    `;
  } else {
    // General overview content
    specificContent = `
      <h2 style="color: #2B579A; font-size: 20px; margin-top: 32px;">Project Overview</h2>
      <p style="line-height: 1.6;">
        The AEM Franklin project provides a comprehensive collection of reusable components 
        for building modern, responsive websites using Adobe Experience Manager.
      </p>
      
      <h3 style="color: #2B579A; font-size: 18px; margin-top: 24px;">Key Components</h3>
      <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
        <thead>
          <tr style="background-color: #f3f3f3;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Component</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Description</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Status</th>
          </tr>
        </thead>
        <tbody>
          ${components.map(comp => `
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">${comp.name}</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${comp.description}</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${comp.progress}%</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <h3 style="color: #2B579A; font-size: 18px; margin-top: 24px;">Implementation Timeline</h3>
      <p style="line-height: 1.6;">
        The project is scheduled for completion by June 2025, with the following milestones:
      </p>
      <ul style="line-height: 1.6;">
        <li><strong>Phase 1 (Complete):</strong> Core component development</li>
        <li><strong>Phase 2 (In Progress):</strong> Integration with AEM</li>
        <li><strong>Phase 3 (Planned):</strong> Testing and optimization</li>
        <li><strong>Phase 4 (Planned):</strong> Documentation and handover</li>
      </ul>
    `;
  }
  
  // Final HTML to render
  return `
    <div class="docx-wrapper">
      <div class="docx-pages">
        <div class="docx-page" data-page-number="1" style="font-family: 'Segoe UI', Arial, sans-serif; padding: 2rem; max-width: 800px; margin: 0 auto; position: relative;">
          <div style="text-align: right; margin-bottom: 1rem;">
            <span style="font-size: 0.8rem; background-color: #e8f0fe; color: #1a73e8; padding: 0.25rem 0.5rem; border-radius: 4px;">
              Document Preview
            </span>
          </div>
            <h1 style="color: #2B579A; font-size: 24px; margin-top: 0;">${docTitle}</h1>
          <div style="display: flex; align-items: center; margin-bottom: 24px;">
            ${getDocumentSource(file).type === 'cloud' ? 
              `<span style="display: inline-flex; align-items: center; background-color: #e3f2fd; color: #0d47a1; padding: 4px 8px; border-radius: 4px; margin-right: 10px; font-size: 0.8rem;">
                <span style="margin-right: 4px;">${getDocumentSource(file).icon}</span>
                ${getDocumentSource(file).label}
              </span>` : ''}
            <p style="color: #666; font-style: italic; margin: 0;">
              ${getDocumentSource(file).type === 'cloud' ? 
                `Shared document • Source: ${file.path}` : 
                `Generated from ${file.relativePath || file.path}`} • Last modified: ${file.lastModified || 'Unknown'}
            </p>
          </div>
          
          <h2 style="color: #2B579A; font-size: 20px; margin-top: 32px;">Overview</h2>
          <p style="line-height: 1.6;">
            This document provides comprehensive details about the Adobe Franklin Project components, 
            structure, and implementation guidelines. The documentation is automatically generated 
            based on the project analysis and includes technical specifications and user implementation instructions.
          </p>
          
          ${specificContent}
        </div>
      </div>
      
      <div style="margin-top: 2rem; text-align: center; padding: 1rem; border-top: 1px solid #e0e0e0; color: #777; font-size: 0.9rem;">
        <p>AEM Franklin Project - Confidential Document</p>
      </div>
    </div>
  `;
};
