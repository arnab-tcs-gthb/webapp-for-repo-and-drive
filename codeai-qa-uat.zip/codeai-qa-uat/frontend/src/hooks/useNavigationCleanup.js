import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import apiClient from '../utils/apiClient';

/**
 * Hook to clean up loading states and cancel pending requests on navigation
 * or component unmount.
 * 
 * @param {Object} options - Configuration options
 * @param {boolean} options.onNavigate - Whether to clean up on navigation (default: true)
 * @param {boolean} options.onUnmount - Whether to clean up on unmount (default: true)
 * @param {boolean} options.cancelRequests - Whether to cancel in-flight requests (default: true)
 */
const useNavigationCleanup = (options = {}) => {
  const { onNavigate = true, onUnmount = true, cancelRequests = true } = options;
  const location = useLocation();
  const cancelTokenRef = useRef();
  
  // Function to create and manage cancel token using apiClient
  const setupCancelToken = () => {
    // Use our apiClient's cancel token system instead of managing it ourselves
    return apiClient.cancelToken.create();
  };
  
  // Clean up on navigation
  useEffect(() => {
    if (onNavigate) {
      // If canceling requests is enabled, setup cancel token
      if (cancelRequests) {
        setupCancelToken();
      }
      
      return () => {
        // Clear loading states
        apiClient.loading.clearAll();
        
        // Cancel any pending requests
        if (cancelRequests) {
          apiClient.cancelToken.cancelAll();
        }
      };
    }
  }, [location, onNavigate, cancelRequests]);
  
  // Clean up on unmount
  useEffect(() => {
    if (onUnmount) {
      return () => {
        // Clear loading states
        apiClient.loading.clearAll();
        
        // Cancel any pending requests
        if (cancelRequests) {
          apiClient.cancelToken.cancelAll();
        }
      };
    }
  }, [onUnmount]);
  
  // Return useful utilities
  return {
    /**
     * Returns an axios cancel token that will be automatically 
     * canceled on navigation or component unmount
     */
    getCancelToken: () => apiClient.cancelToken.getCurrentToken()?.token || setupCancelToken(),
    
    /**
     * Cancel all in-flight requests manually
     */
    cancelRequests: () => {
      apiClient.cancelToken.cancelAll();
    },
    
    /**
     * Clear all loading states manually
     */
    clearLoadingStates: () => {
      apiClient.loading.clearAll();
    }
  };
};

export default useNavigationCleanup;
