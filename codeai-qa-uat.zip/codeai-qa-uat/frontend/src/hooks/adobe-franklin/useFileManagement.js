import { useState, useCallback, useRef } from 'react';
import { useFileContext } from '../../context';
import ApiServiceEnhanced from '../../services/ApiServiceEnhanced';

export const useFileManagement = () => {
  const { files, setFiles, fileTree, setFileTree } = useFileContext();
  const [uploadProgress, setUploadProgress] = useState({});
  const [isUploading, setIsUploading] = useState(false);
  const [previewCache, setPreviewCache] = useState(new Map());
  const [validationResults, setValidationResults] = useState({});
  const abortControllerRef = useRef(null);

  const uploadFiles = useCallback(async (fileList) => {
    setIsUploading(true);
    abortControllerRef.current = new AbortController();
    
    try {
      const uploadPromises = Array.from(fileList).map(async (file, index) => {
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await ApiServiceEnhanced.uploadFile(formData, {
          signal: abortControllerRef.current.signal,
          onUploadProgress: (progressEvent) => {
            const progress = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setUploadProgress(prev => ({
              ...prev,
              [file.name]: progress
            }));
          }
        });
        
        return {
          ...response.data,
          originalFile: file,
          uploadedAt: new Date().toISOString()
        };
      });

      const uploadedFiles = await Promise.all(uploadPromises);
      setFiles(prev => [...prev, ...uploadedFiles]);
      
      // Generate file tree structure
      const newFileTree = generateFileTree([...files, ...uploadedFiles]);
      setFileTree(newFileTree);
      
      return uploadedFiles;
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('File upload failed:', error);
        throw new Error(`Upload failed: ${error.message}`);
      }
    } finally {
      setIsUploading(false);
      setUploadProgress({});
    }
  }, [files, setFiles, setFileTree]);

  const removeFile = useCallback((fileId) => {
    setFiles(prev => prev.filter(file => file.id !== fileId));
    setPreviewCache(prev => {
      const newCache = new Map(prev);
      newCache.delete(fileId);
      return newCache;
    });
    
    // Update file tree
    const remainingFiles = files.filter(file => file.id !== fileId);
    const newFileTree = generateFileTree(remainingFiles);
    setFileTree(newFileTree);
  }, [files, setFiles, setFileTree]);

  const getFilePreview = useCallback(async (fileId) => {
    if (previewCache.has(fileId)) {
      return previewCache.get(fileId);
    }

    try {
      const file = files.find(f => f.id === fileId);
      if (!file) throw new Error('File not found');

      const preview = await ApiServiceEnhanced.getFilePreview(fileId);
      setPreviewCache(prev => new Map(prev).set(fileId, preview));
      return preview;
    } catch (error) {
      console.error('Preview generation failed:', error);
      throw error;
    }
  }, [files, previewCache]);

  const validateFiles = useCallback(async () => {
    const validationResults = await Promise.all(
      files.map(async (file) => {
        try {
          const validation = await ApiServiceEnhanced.validateFile(file.id);
          return { fileId: file.id, isValid: validation.isValid, errors: validation.errors };
        } catch (error) {
          return { fileId: file.id, isValid: false, errors: [error.message] };
        }
      })
    );

    // Update validation results state
    const validationMap = {};
    validationResults.forEach(result => {
      validationMap[result.fileId] = result;
    });
    setValidationResults(validationMap);

    const invalidFiles = validationResults.filter(result => !result.isValid);
    return invalidFiles.length === 0;
  }, [files]);

  const cancelUpload = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  const getFileIcon = useCallback((extension) => {
    const ext = extension?.toLowerCase();
    switch (ext) {
      case 'pdf':
        return '📄';
      case 'docx':
      case 'doc':
        return '📝';
      case 'zip':
      case 'rar':
        return '📦';
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
        return '🖼️';
      case 'mp4':
      case 'avi':
      case 'mov':
        return '🎥';
      default:
        return '📎';
    }
  }, []);

  const getFileColor = useCallback((extension) => {
    const ext = extension?.toLowerCase();
    switch (ext) {
      case 'pdf':
        return '#FF5252';
      case 'docx':
      case 'doc':
        return '#2196F3';
      case 'zip':
      case 'rar':
        return '#FFA000';
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
        return '#4CAF50';
      case 'mp4':
      case 'avi':
      case 'mov':
        return '#9C27B0';
      default:
        return '#757575';
    }
  }, []);

  const formatFileSize = useCallback((bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }, []);

  return {
    files,
    fileTree,
    uploadProgress,
    isUploading,
    previewCache,
    validationResults,
    uploadFiles,
    removeFile,
    getFilePreview,
    validateFiles,
    cancelUpload,
    getFileIcon,
    getFileColor,
    formatFileSize,
  };
};

// Helper function to generate file tree structure
const generateFileTree = (files) => {
  const tree = {};
  
  files.forEach(file => {
    const pathParts = file.path ? file.path.split('/') : [file.name];
    let currentLevel = tree;
    
    pathParts.forEach((part, index) => {
      if (!currentLevel[part]) {
        currentLevel[part] = {
          name: part,
          type: index === pathParts.length - 1 ? 'file' : 'folder',
          children: {},
          file: index === pathParts.length - 1 ? file : null
        };
      }
      currentLevel = currentLevel[part].children;
    });
  });
  
  return tree;
};

export default useFileManagement;
