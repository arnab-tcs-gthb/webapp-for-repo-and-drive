from fastapi import FastAPI, APIRouter,UploadFile, HTTPException,File,Depends
import os
from typing import Optional

#import all service functions
from app.services.chat_service import analyze_image, load_block_kb, map_ui_to_blocks, generate_docs


#import all schemas
from app.schemas.analysis import AnalysisMetadata, ImageProcessingPaths, ImageFilter
from app.schemas.chat_schemas import AnalyzeImage,MappingData,GenerateDocs
from app.schemas.aem_template import AEMTemplateCreate

from app.models.project import Project
from app.services.image_processing import ImageProcessingService

from app.api.v1.routers import router, read_project_images, PageCreate

from app.db.session import SessionLocal, engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import Session
from app.db.deps import get_db
from pathlib import Path # Added for Path operations


# --- Image Captioning Module Imports ---
from app.services import captioning_service # Import the new service
from app.schemas.captioning_schemas import ImageCaptionRequest, CaptionSummaryResponse # Import schemas

# --- Image Filtering Module Imports ---
from app.services.image_filter_service import process_images_api
from app.schemas.project import ProjectUpdate
from app.schemas.image import ImageUpdate

from app.crud.aem_template import create_aem_template,get_active_aem_templates


from app.services.upload_service import *

import json
import shutil

static_dir = Path('static')


from app.db.session import SessionLocal, engine
from app.crud.image import create_image, get_images_by_project, update_image
from app.crud.project import get_project, update_project, get_project
from app.schemas.knowledge_base import ProcessRequest
from app.helper.docx_to_yaml import BlockDocxProcessor

Session_create = sessionmaker(bind=engine)
session_bind = Session()



chat_router = APIRouter()


@chat_router.get('/kb-metadata')
async def get_kb_data():
    try:
        # Load the block knowledge base
        block_kb = load_block_kb()
        global_count = 0
        page_building_count = 0

        # Iterate through the blocks and count based on the 'element' field
        for block in block_kb:
            if block_kb[block]['element'] == 'global':
                global_count += 1
            elif block_kb[block]['element'] == 'page building':
                page_building_count += 1
        return {'brand': 'AEM','total_count': global_count+page_building_count,'global_count': global_count, 'page_building_count': page_building_count}
    except Exception as e:
        raise e



@chat_router.post("/mapping")
async def mapping(data:MappingData):
    try:
        #pass response value of (llm_response) in 
        # components_data param 

        #response body
    #     {
    #     "page_title" :strt,
    #     "mapped_data" : list,
    #     "not_found_block":int,
    #     "global_block_number" :int,
    #     "block_used" : int

    # }
        #return list of dict
        all_pages_mapped_data =  []
        for page in data.components_data:
            block_data = await map_ui_to_blocks(page_json=page, block_kb=load_block_kb())
            all_pages_mapped_data.append(block_data)
        return all_pages_mapped_data
    except Exception as e:
        raise e


@chat_router.post("/create-folder")
async def create_folder(project_name: str = Form(...)):
    """Handles API request to create a Google Drive folder, 'Global' subfolder, and trigger GitHub workflow"""
    return await create_folder_api(project_name)

@chat_router.post("/upload-folder")
async def upload_folder(local_path: str = Form(...), folder_id:str = Form(...)):
    """Uploads all files from a local folder into the most recently created Google Drive folder."""
    return {"uploaded_files": await upload_folder_to_drive(local_path,folder_id)}

@chat_router.post("/upload-folder-with-dymamic-folder-id")
def upload_folder(local_path: str = Form(...), folder_id: str = Form(...)):
    """Uploads all files from a local folder into the specified Google Drive folder."""
    return {"uploaded_files": upload_folder_to_drive_with_dynamic_folder_id(local_path, folder_id)}

@chat_router.post("/upload-file-with-dymamic-folder-id")
async def upload_file(local_path: str = Form(...), folder_id: str = Form(...)):
    """Uploads a file from local system to the Google Drive folder and converts it"""
    return await upload_file_to_drive(local_path, folder_id)

@chat_router.get("/fetch-files")
def fetch_files():
    """Fetches all files and folders recursively from the latest created Google Drive folder."""    
    return {"files_in_folder": fetch_files_recursively()}

@chat_router.get("/fetch-github-files")
def fetch_github_files():
    """Fetches all files and folders from the latest created GitHub branch."""    
    return fetch_github_branch_files()

@chat_router.post('/api/analysis-metadata')
async def create_metadata(data:AnalysisMetadata):
    # return data
    try:
        meta = session_bind.query(Project).filter(Project.id == data).first()
        return meta
    except Exception as e:
        raise e


