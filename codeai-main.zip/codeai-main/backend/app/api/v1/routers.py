from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime
from typing import List, Optional
from typing import Union
import os


# Import your database and models
from app.db.deps import get_db
from app.models.project import  Project
from app.models.page import Page
from app.schemas.project import (
    ProjectCreate,
    ProjectUpdate,
    ProjectInDB
)

from app.schemas.page import (
    PageBase,
    PageUpdate,
    PageCreate,
    PageInDB
)
from app.core.config import settings
from app.schemas.image import ImageInDB, ImageCreate, ImageWithAnalysis,Message
from app.crud.image import create_image, get_images_by_project
from app.services.file_upload import file_upload_service
from app.schemas.chat_schemas import AnalyzeImage,MappingData,GenerateDocs
from app.db.session import SessionLocal, engine
from app.services.image_processing import ImageProcessingService
from app.services.chat_service import analyze_image, load_block_kb, map_ui_to_blocks, generate_docs
from app.crud.project import get_project
import json
from app.services.upload_service import *
from app.services.upload_service_v2 import upload_file_to_drive
from app.services import captioning_service # Import the new service
from app.schemas.captioning_schemas import ImageCaptionRequest, CaptionSummaryResponse # Import schemas
from app.schemas.knowledge_base import ProcessRequest
from app.helper.docx_to_yaml import BlockDocxProcessor
from app.schemas.analysis import AnalysisMetadata, ImageProcessingPaths, ImageFilter
from app.services.image_filter_service import process_images_api
from app.crud.image import create_image, get_images_by_project, update_image
from app.schemas.image import ImageUpdate
from app.crud.project import get_project, update_project, get_project
from app.services.upload_service_v2 import publish_for_file, preview_for_file, create_folder








from app.schemas.aem_template import AEMTemplateInDB, AEMTemplateCreate
from app.crud.aem_template import (
    get_active_aem_templates,
    create_aem_template,
    get_aem_template_by_name,
    get_aem_template
)


router = APIRouter()

# ===== Project Routes =====
@router.post("/projects/", response_model=ProjectInDB, status_code=status.HTTP_201_CREATED)
def create_project(
    project: ProjectCreate,
    db: Session = Depends(get_db)
):
    """Create a new project"""
    # Check for existing project with the same name
    existing_project = db.query(Project).filter(Project.project_name == project.project_name).first()
    if existing_project:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Project with name '{project.project_name}' already exists"
        )
    
    # Validate GitHub URL format if provided
    if project.github_repo_url:
        import re
        github_pattern = r'^https?:\/\/github\.com\/[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+\/?$'
        if not re.match(github_pattern, project.github_repo_url):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid GitHub repository URL format. Expected: https://github.com/owner/repository"
            )
        
        # Check if another project is already using this GitHub URL
        github_project = db.query(Project).filter(Project.github_repo_url == project.github_repo_url).first()
        if github_project:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"GitHub repository URL is already linked to project"
            )
 
    db_project = Project(**project.dict())
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project

@router.post("/mapping")
async def mapping(data:MappingData):
    try:
        #pass response value of (llm_response) in 
        # components_data param 

        #response body
    #     {
    #     "page_title" :strt,
    #     "mapped_data" : list,
    #     "not_found_block":int,
    #     "global_block_number" :int,
    #     "block_used" : int

    # }
        #return list of dict
        all_pages_mapped_data =  []
        for page in data.components_data:
            block_data = await map_ui_to_blocks(page_json=page, block_kb=load_block_kb())
            all_pages_mapped_data.append(block_data)
        return all_pages_mapped_data
    except Exception as e:
        raise e

@router.get("/projects/", response_model=List[ProjectInDB])
def read_projects(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Retrieve all projects with pagination"""
    projects = db.query(Project).offset(skip).limit(limit).all()
    return projects

@router.get("/projects/{project_id}", response_model=ProjectInDB)
def read_project(
    project_id: int,
    db: Session = Depends(get_db)
):
    """Get a specific project by ID"""
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found"
        )
    return project

# ===== Page Routes =====
@router.post("/projects/{project_id}/pages/", response_model=PageInDB, status_code=status.HTTP_201_CREATED)
def create_page(
    project_id: int,
    page: PageCreate,
    db: Session = Depends(get_db)
):
    """Create a page within a project"""
    # Verify project exists
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found"
        )
    
    # Check for duplicate page URL
    existing_page = db.query(Page).filter(Page.page_url == page.page_url).first()
    if existing_page:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Page with this URL already exists"
        )
    
    db_page = Page(**page.dict(), project_id=project_id)
    db.add(db_page)
    db.commit()
    db.refresh(db_page)
    return db_page

@router.post("/projects/{project_id}/images/", response_model=Union[ImageInDB, Message])
async def upload_project_image(
    project_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    try:
        file_metadata = await file_upload_service.save_uploaded_file(file, project_id)
        
        if file_metadata is None:
            # Zip file - no DB insert, just return success message or empty response
            return {"detail": "Zip file uploaded and extracted successfully."}
        else:
            image_data = ImageCreate(
                filename=file_metadata["filename"],
                filepath=file_metadata["filepath"],
                content_type=file.content_type,
                project_id=project_id,
                file_size=file_metadata["file_size"]
            
        )   
            return create_image(db=db, image=image_data)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/projects/{project_id}/images/", response_model=List[ImageInDB])
def read_project_images(
    project_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    return get_images_by_project(db, project_id=project_id, skip=skip, limit=limit)


@router.post("/pages/{page_id}/upload-image/")
async def upload_page_image(
    page_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload an image for a specific page"""
    # Verify page exists
    page = db.query(Page).filter(Page.id == page_id).first()
    if not page:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Page not found"
        )
    
    try:
        file_url = await upload_file_to_server(file, settings.UPLOAD_DIR)
        # Here you would typically save the file metadata to your database
        return JSONResponse(
            status_code=status.HTTP_201_CREATED,
            content={"message": "File uploaded successfully", "file_url": file_url}
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

# ===== AI Integration Routes =====
@router.post("/ai/generate-text")
def generate_text_with_ai(
    prompt: str,
    provider: str = "openai",
    db: Session = Depends(get_db)
):
    """Generate text using configured AI provider"""
    try:
        # In a real implementation, you would call your AI service here
        # For example:
        # ai_response = ai_service.generate_text(prompt, provider)
        return {"result": f"Generated text for: {prompt} using {provider}"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"AI generation failed: {str(e)}"
        )

# ===== GitHub Integration Routes =====
@router.post("/projects/{project_id}/deploy-to-github")
def deploy_to_github(
    project_id: int,
    repo_name: str,
    db: Session = Depends(get_db)
):
    """Deploy project to GitHub"""
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found"
        )
    
    try:
        # In a real implementation, you would call GitHub API here
        return {"message": f"Project {project.project_name} deployed to GitHub as {repo_name}"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"GitHub deployment failed: {str(e)}"
        )

# ===== AEM tamplates list =====
@router.post("/aem-templates/", response_model=AEMTemplateInDB)
def create_new_aem_template(
    template: AEMTemplateCreate,
    db: Session = Depends(get_db)
):
    if get_aem_template_by_name(db, template_name=template.aem_template_name):
        raise HTTPException(
            status_code=400,
            detail="AEM Template with this name already exists"
        )
    return create_aem_template(db=db, template=template)

@router.get("/aem-templates/", response_model=List[AEMTemplateInDB])
def read_active_aem_templates(
    template_type: str = None,
    db: Session = Depends(get_db)
):
    """Get all active AEM templates, optionally filtered by type"""
    return get_active_aem_templates(db, template_type=template_type)

@router.get("/aem-templates/{template_id}", response_model=AEMTemplateInDB)
def read_aem_template(
    template_id: int,
    db: Session = Depends(get_db)
):
    template = get_aem_template(db, template_id=template_id)
    if not template:
        raise HTTPException(status_code=404, detail="AEM Template not found")
    return template
#api_router = APIRouter()

# Include your routes here
# Example: api_router.include_router(project_router, prefix="/projects", tags=["projects"])

# Add the router to the main application
# Example: app.include_router(api_router)

@router.get("/projects/{project_id}/analysis", response_model=List[ImageWithAnalysis])
def get_project_images_with_analysis(
    project_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Get all images for a project with analyzed LLM response data.
    Returns:
        - List of image details with:
            - Image metadata
            - Analysis of LLM response including:
                - total_components
                - reusable_components
                - components_details
            - raw_llm_response
    """
    images = get_images_by_project(db, project_id=project_id, skip=skip, limit=limit)
    if not images:
        raise HTTPException(
            status_code=404,
            detail=f"No images found for project {project_id}"
        )
    return images



@router.post("/upload-image")
async def upload_image(file:UploadFile = File(...)):
    try:
        img_content = await file.read()
        img_path = os.path.join('static','images',file.filename)
        with open(img_path,"wb") as f:
            while contents := await file.read(1024):
                f.write(contents)
    except Exception as e:
        raise e
    return {"filename":file.filename, "detail":"Image Uploaded"}

# Analyse image response from LLM and return metadata
def analyze_image_resp(process_data, no_of_images):
    image_count = 0
    link_count = 0
    block_count = 0
    form_count = 0
    video_count = 0
    processingData = {}
    processingData['llm_response'] = process_data
    processingData['pages'] = len(process_data)
    
    # Iterate through pages and components
    for page in process_data:
        # Check if page has components key
        if not isinstance(page, dict):
            print(f"WARNING: Skipping non-dict page: {type(page)}")
            continue
            
        if "components" not in page:
            print(f"WARNING: Skipping page without 'components' key. Keys: {list(page.keys())}")
            continue
            
        if not isinstance(page["components"], list):
            print(f"WARNING: 'components' is not a list: {type(page['components'])}")
            continue
            
        for component in page["components"]:
            if not isinstance(component, dict):
                print(f"WARNING: Skipping non-dict component: {type(component)}")
                continue
                
            # Count component types
            if component.get("type"):
                block_count += 1
                
            # Count images
            if "properties" in component:
                if "imageRef" in component["properties"] and component["properties"]["imageRef"]:
                    image_count += 1
                if "items" in component["properties"]:
                    for item in component["properties"]["items"]:
                        if "imageRef" in item and item["imageRef"]:
                            image_count += 1

            # Count links
            if "properties" in component:
                if "navigation_links" in component["properties"]:
                    link_count += len(component["properties"]["navigation_links"])
                if "utility_icons" in component["properties"]:
                    link_count += len(component["properties"]["utility_icons"])
                if "items" in component["properties"]:
                    for item in component["properties"]["items"]:
                        if "link_url" in item or "link" in item:
                            link_count += 1
                if "cta_button" in component["properties"] and "url" in component["properties"]["cta_button"]:
                    link_count += 1
            
            # Count forms
            if "properties" in component:
                if "forms" in component["properties"]:
                    form_count += len(component["properties"]["forms"])

            # Count videos
            if "properties" in component:
                if "videos" in component["properties"]:
                    video_count += len(component["properties"]["videos"])

    processingData['blocks'] = block_count
    processingData['images'] = image_count
    processingData['links'] = link_count
    processingData['forms'] = form_count
    processingData['videos'] = video_count
    progress_percentage = (processingData['pages'] / no_of_images) * 100 if no_of_images > 0 else 0
    processingData['progress'] = f"{processingData['pages']}/{no_of_images} ({progress_percentage:.2f}%)"
    
    return processingData

@router.post("/analyze")
async def analyze(data:AnalyzeImage):
    db = SessionLocal()
    service = ImageProcessingService(db)
    try:
        # Use the local db session consistently
        try:
            projectImages = read_project_images(project_id=data.project_id, db=db)
            
            # If no images found, return early
            if not projectImages:
                print(f"No images found for project {data.project_id}")
                return {"error": "No images found for this project", "results": []}
                
        except Exception as project_err:
            print(f"Error retrieving project images: {str(project_err)}")
            return {"error": f"Error retrieving project images: {str(project_err)}", "results": []}

        # Define a coroutine to process each image
        async def process_image(indivProject):
            try:
                # First check if we already have processed results
                if (indivProject.llm_response is not None) and (indivProject.llm_processed is True):
                    try:
                        return json.loads(indivProject.llm_response)
                    except json.decoder.JSONDecodeError as json_err:
                        print(f"Error parsing stored JSON for image {indivProject.filepath}: {str(json_err)}")
                        # Continue with reprocessing the image if stored JSON is invalid

                project_details = get_project(db,data.project_id)
                analyze_args = {"image_path": indivProject.filepath}
                if indivProject.matched_images is not None:
                    analyze_args["matched_images"] = indivProject.matched_images
                if project_details.captions is not None:
                    analyze_args["captions"] = project_details.captions
                # Analyze the image with Gemini AI
                print(f"Analyzing image: {indivProject.filepath}")
                image_data = analyze_image(**analyze_args)
                
                # Store the results in database
                image_id = indivProject.id
                try:
                    await service.mark_as_processed(
                        image_id=image_id,
                        llm_response=image_data,
                        success=True
                    )
                except Exception as db_err:
                    print(f"Error saving analysis results to database: {str(db_err)}")
                    # Continue even if saving to DB fails
                    
                return image_data
            except Exception as e:
                print(f"Error processing image {indivProject.filepath}: {str(e)}")
                # Return a fallback response instead of failing the whole batch
                return {
                    "page_title": "Error Processing Image",
                    "components": [
                        {
                            "type": "error", 
                            "properties": {
                                "title": "Image Processing Error",
                                "description": f"Failed to process image: {str(e)}"
                            },
                            "layout": "full-width",
                            "element_type": "page-building"
                        }
                    ]
                }

        # Run all image processing tasks in parallel
        try:
            print(f"Starting parallel processing of {len(projectImages)} images...")
            # Process each image individually and collect results
            image_results = []
            for i, indivProject in enumerate(projectImages):
                try:
                    print(f"Processing image {i+1}/{len(projectImages)}: {indivProject.filepath}")
                    result = await process_image(indivProject)
                    
                    # Validate that the result has the expected structure
                    if not isinstance(result, dict):
                        print(f"WARNING: Image {indivProject.filepath} returned non-dict result: {type(result)}")
                    elif "components" not in result:
                        print(f"WARNING: Image {indivProject.filepath} missing 'components' key in result")
                        print(f"Result keys: {list(result.keys())}")
                    
                    image_results.append(result)
                    print(f"Successfully processed image {i+1}: {indivProject.filepath}")
                except Exception as individual_err:
                    print(f"Error processing individual image {indivProject.filepath}: {str(individual_err)}")
                    # Add a fallback response for this specific image
                    image_results.append({
                        "page_title": f"Error Processing Image {i+1}",
                        "components": [
                            {
                                "type": "error",
                                "properties": {
                                    "title": "Image Processing Error",
                                    "description": f"Failed to process image: {str(individual_err)}"
                                },
                                "layout": "full-width",
                                "element_type": "page-building"
                            }
                        ]
                    })
            
            print(f"Completed processing {len(image_results)} images")
            return analyze_image_resp(image_results, no_of_images=len(projectImages))
        except Exception as gather_err:
            print(f"Error during parallel image processing: {str(gather_err)}")
            # Return a fallback response with error information
            return {
                "error": f"Error during image analysis: {str(gather_err)}",
                "results": [],
                "no_of_images": len(projectImages),
                "success": False
            }
    except Exception as e:
        print(f"Unhandled exception in analyze endpoint: {str(e)}")
        # Return a structured error response rather than re-raising
        return {
            "error": f"Unhandled exception: {str(e)}",
            "results": [],
            "success": False
        }
    finally:
        # Always close your db session
        db.close()


@router.post("/generate-doc")
async def generate(project_id:int, db: Session = Depends(get_db)):
    #return google docs link
    try:
        #pass mapping api response in this mapped_data list to mapped_data
        #get data from database by project_id
        mapped_data = []
        get_project_name = get_project(db,project_id)
        project_name = get_project_name.project_name
        images = get_images_by_project(db, project_id=project_id)
        for image in images:
            analyze_data = json.loads(image.llm_response)
            block_data = await map_ui_to_blocks(page_json=analyze_data, block_kb=load_block_kb())
            mapped_data.append(block_data)  

        page_output_data={}
        google_docs_folder_created = False
        folder_id = ""
        page_data_return = {}
        global_header_list= []
        preview_url = ""
        for map_data in mapped_data:
            try:
                data_final_page_wise,global_header_list = await generate_docs(mapped=map_data["mapped_data"], project_name=project_name,global_header_list=global_header_list)
                
                if not google_docs_folder_created:
                    print(f"Creating folder for project: {project_name}")
                    upload_folder_links = await create_folder(username=project_name)
                    print(upload_folder_links,"upload folder datat")
                    preview_url = upload_folder_links["preview_url"]
                    print(f"Folder creation response: {upload_folder_links}")
                    
                    if "error" in upload_folder_links:
                        print(f"Warning: Error in folder creation: {upload_folder_links['error']}")
                    
                    # Safely get folder IDs with fallbacks
                    
                    google_docs_folder_created = True
                folder_id = upload_folder_links.get("folder_id", "default_folder_id")
                folder_url = upload_folder_links.get("folder_url", "#")
                global_folder_id = upload_folder_links.get("global_folder_id", "default_global_folder_id")
                print(folder_id)
                
                # print(f"Processing output data: {data_final_page_wise}")
            except Exception as map_err:
                print(f"Error processing mapped data: {str(map_err)}")
                
        # Upload everything to google drive
        project_path = os.path.join("output",project_name)
        global_path = os.path.join(project_path,"global")
        
        # Verify directories exist
        if not os.path.exists(project_path):
            print(f"Warning: Project path does not exist: {project_path}")
            os.makedirs(project_path, exist_ok=True)
            
        if not os.path.exists(global_path):
            print(f"Warning: Global path does not exist: {global_path}")
            os.makedirs(global_path, exist_ok=True)
 
        page_data_return = {}
        global_pages=[]
        
        # Process main project files
        try:
            print(f"Processing files in directory: {project_path}")
            for file_name in os.listdir(project_path):   
                full_path = os.path.join(project_path,file_name)
                if not os.path.isdir(full_path):
                    # Skip HTML files - only process DOCX files
                    if file_name.endswith('.html'):
                        print(f"Skipping HTML file: {file_name}")
                        continue
                        
                    try:
                        print(f"Uploading file: {full_path}")
                        file_upload_url = await upload_file_to_drive(full_path, folder_id)
                        print(f"Upload response: {file_upload_url}")
                        

                        #do publish and preview for url and pass to frontend
                        #introducing wait time because it took some time for adobe yaml to run around 1 minutes
                        import time 
                        time.sleep(60)
                        do_preview_url = await preview_for_file("team-argo",site=project_name,path=file_name.split(".")[0])

                        do_publish_url = await publish_for_file("team-argo",site=project_name,path=file_name.split(".")[0])



                        page_data_return[file_name] = {
                            "name": file_name,
                            "type": file_name.split(".")[1],
                            "nodeType": 'file',
                            "url": file_upload_url.get("file_url", "#"),
                            "preview_url" : do_preview_url["message"],
                            "publish_url" : do_publish_url["message"]
                        }
                    except Exception as file_err:
                        print(f"Error uploading file {full_path}: {str(file_err)}")
                        page_data_return[file_name] = {
                            "name": file_name,
                            "type": file_name.split(".")[1],
                            "nodeType": 'file',
                            "url": "#",
                            "error": str(file_err)
                        }
        except Exception as dir_err:
            print(f"Error processing project directory: {str(dir_err)}")
                
        # Process global files
        try:
            print(f"Processing files in global directory: {global_path}")
            for file_name in os.listdir(global_path):  
                full_path = os.path.join(global_path, file_name)
                if not os.path.isdir(full_path):
                    try:  
                        path = await upload_file_to_drive(full_path, global_folder_id)
                        global_pages.append({
                            "name": file_name,
                            "type": file_name.split(".")[1],
                            "nodeType": 'file',
                            "url": "#",
                            "url": path.get("file_url", "#"),
                            "preview_url" : f"{preview_url.replace(".page",".live")}/{project_name}/{file_name.split(".")[0]}"
                        })
                    except Exception as global_file_err:
                        print(f"Error uploading global file {full_path}: {str(global_file_err)}")
                        global_pages.append(f"Error with {file_name}: {str(global_file_err)}")
        except Exception as global_dir_err:
            print(f"Error processing global directory: {str(global_dir_err)}")
            global_pages.append("Error loading global files")

        page_data_return["global"]={
                    "name": "global",
                    "type": 'folder',
                    "nodeType": 'folder',
                    "children": global_pages
                }

        return_json = {
            "documents": {
                "name": "documents",
                "type": "folder",
                "nodeType": "folder",
            }
            }
        return_json["documents"]["children"] = page_data_return
        return return_json
    except Exception as e:
        print(f"Error in generate-doc endpoint: {str(e)}")
        # Return a minimal valid response that the frontend can handle
        return {
            "documents": {
                "name": "documents",
                "type": "folder",
                "nodeType": "folder",
                "children": {
                    "error": {
                        "name": "Error",
                        "type": "file",
                        "nodeType": "file",
                        "url": "#",
                        "error_details": str(e)
                    }
                },
                "error": str(e)
            }
        }
    


# --- Image Process and Filtering Endpoint ---
@router.post("/process-and-filter-images")
async def image_filter(ImageFilter: ImageFilter, db: Session = Depends(get_db)):
    """
    FastAPI endpoint to process a screenshot and filter images from a given folder.
    Returns a custom JSON response with a message and list of matched image names.
    """
    
    # Filter the images based on the uploaded image
    try:
        projectImages = read_project_images(project_id=ImageFilter.project_id, db=db)
            
        # If no images found, return early
        if not projectImages:
            print(f"No images found for project {ImageFilter.project_id}")
            return {"error": "No images found for this project", "results": []}
                
    except Exception as project_err:
        print(f"Error retrieving project images: {str(project_err)}")
        return {"error": f"Error retrieving project images: {str(project_err)}", "results": []}

    # Define a coroutine to process each image
    for i, indivProject in enumerate(projectImages):
        if indivProject.matched_images is None:
            try:
                image_process = await process_images_api(
                    ImageProcessingPaths(
                        screenshot_path=indivProject.filepath,
                        images_folder_path='static/assets',
                        filtered_destination_path='static/output',
                    )
                )
            except Exception as image_filter_err:
                print(f"Error processing images for {indivProject.filepath}: {str(image_filter_err)}")
                image_process = []  # Provide empty list if processing fails

            try:
                updated_image = await update_image(
                    db=db,
                    image_id=indivProject.id,
                    image=ImageUpdate(
                        matched_images=image_process,
                    )
                )
            except Exception as update_err:
                print(f"Error updating image {indivProject.id}: {str(update_err)}")
    
    # Generate captions for the images in the folder
    # and update the project with the generated captions
    try:
        try:
            project_obj = get_project(db, ImageFilter.project_id)
        except Exception as get_project_err:
            print(f"Error retrieving project: {str(get_project_err)}")
            project_obj = None

        if project_obj is not None and getattr(project_obj, "captions", None) is None:
            try:
                caption_data = await captioning_service.create_captions_for_images_in_folder_endpoint(
                    ImageCaptionRequest(folder_location='assets')
                )
                try:
                    updated_details = update_project(
                        db=db,
                        project_id=ImageFilter.project_id,
                        project=ProjectUpdate(captions=caption_data['captions']),
                    )
                except Exception as update_project_err:
                    print(f"Error updating project with captions: {str(update_project_err)}")

                
                # Validate caption data structure
                if not isinstance(caption_data, dict) and hasattr(caption_data, '__dict__'):
                    # It's an object with attributes, convert to dict
                    print(f"Converting caption_data object to dictionary")
                    if hasattr(caption_data, 'captions') and caption_data.captions:
                        caption_data = {"captions": caption_data.captions}
                    else:
                        caption_data = {"captions": {}}
                elif not isinstance(caption_data, dict):
                    print(f"Caption data is not a dict, got {type(caption_data)}")
                    caption_data = {"captions": {}}

            except Exception as caption_err:
                print(f"Error generating captions: {str(caption_err)}")
                caption_data = {"captions": {}}  # Provide empty captions if generation fails
    except Exception as outer_err:
        print(f"Unexpected error in caption generation block: {str(outer_err)}")

# --- Image Captioning Endpoint ---
@router.post("/caption-images")
async def image_caption(ImageFilter: ImageFilter, db: Session = Depends(get_db)):
    """
    FastAPI endpoint to create captions for images from a given folder.
    Returns a custom JSON response with a message and list of caption names.
    """
    # Generate captions for the images in the folder
    # and update the project with the generated captions
    try:
        try:
            project_obj = get_project(db, ImageFilter.project_id)
        except Exception as get_project_err:
            print(f"Error retrieving project: {str(get_project_err)}")
            project_obj = None

        if project_obj is not None and getattr(project_obj, "captions", None) is None:
            try:
                caption_data = await captioning_service.create_captions_for_images_in_folder_endpoint(
                    ImageCaptionRequest(folder_location='static/assets')
                )
                try:
                    updated_details = update_project(
                        db=db,
                        project_id=ImageFilter.project_id,
                        project=ProjectUpdate(captions=caption_data['captions']),
                    )
                except Exception as update_project_err:
                    print(f"Error updating project with captions: {str(update_project_err)}")

                
                # Validate caption data structure
                if not isinstance(caption_data, dict) and hasattr(caption_data, '__dict__'):
                    # It's an object with attributes, convert to dict
                    print("Converting caption_data object to dictionary")
                    if hasattr(caption_data, 'captions') and caption_data.captions:
                        caption_data = {"captions": caption_data.captions}
                    else:
                        caption_data = {"captions": {}}
                elif not isinstance(caption_data, dict):
                    print(f"Caption data is not a dict, got {type(caption_data)}")
                    caption_data = {"captions": {}}

            except Exception as caption_err:
                print(f"Error generating captions: {str(caption_err)}")
                caption_data = {"captions": {}}  # Provide empty captions if generation fails
    except Exception as outer_err:
        print(f"Unexpected error in caption generation block: {str(outer_err)}")



@router.post("/get_all_templates")
def get_all_tempalates(db: Session = Depends(get_db),template_type:Optional[str]=None):
    return get_active_aem_templates(db,template_type)


@router.post("/genrate-knowledge-base")
def generate_block_yaml(data:AEMTemplateCreate, db: Session = Depends(get_db)):
    process_block = ProcessRequest()
    complete_url = data.aem_template_url+process_block.json_list_url
    formatted_path = "aem_block_kb/" + data.aem_template_name + ".yaml"


    create_template = create_aem_template(db,data)

    
    processor = BlockDocxProcessor(
        full_url = complete_url,
        docx_root=process_block.docx_root,
        output_yaml=process_block.output_yaml,
        formatted_yaml=formatted_path
    )
    processor.process()
    return {
        "message": "YAML generation and formatting complete."
    }    


@router.get('/kb-metadata')
async def get_kb_data():
    try:
        # Load the block knowledge base
        block_kb = load_block_kb()
        global_count = 0
        page_building_count = 0

        # Iterate through the blocks and count based on the 'element' field
        for block in block_kb:
            if block_kb[block]['element'] == 'global':
                global_count += 1
            elif block_kb[block]['element'] == 'page building':
                page_building_count += 1
        return {'brand': 'AEM','total_count': global_count+page_building_count,'global_count': global_count, 'page_building_count': page_building_count}
    except Exception as e:
        raise e
    


@router.post("/mapping")
async def mapping(data:MappingData):
    try:
        #pass response value of (llm_response) in 
        # components_data param 

        #response body
    #     {
    #     "page_title" :strt,
    #     "mapped_data" : list,
    #     "not_found_block":int,
    #     "global_block_number" :int,
    #     "block_used" : int

    # }
        #return list of dict
        all_pages_mapped_data =  []
        for page in data.components_data:
            block_data = await map_ui_to_blocks(page_json=page, block_kb=load_block_kb())
            all_pages_mapped_data.append(block_data)
        return all_pages_mapped_data
    except Exception as e:
        raise e
