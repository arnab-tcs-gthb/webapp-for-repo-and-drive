from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, BackgroundTasks, Form
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime
from typing import List, Optional
from typing import Union
import os
import asyncio
from pydantic import BaseModel


# Import your database and models
from app.db.deps import get_db
from app.models.page import Page
from app.schemas.project import (
    ProjectCreate,
    ProjectUpdate,
    ProjectInDB
)

from app.schemas.page import (
    PageCreate,
    PageInDB
)
from app.core.config import settings
from app.schemas.image import ImageInDB, ImageCreate, ImageWithAnalysis,Message
from app.crud.image import create_image, get_images_by_project
from app.services.file_upload import file_upload_service
from app.schemas.chat_schemas import AnalyzeImage,MappingData,GenerateDocs, AnalyzeResponse
from app.db.session import SessionLocal, engine
from app.services.image_processing import ImageProcessingService
from app.schemas.knowledge_base import ProcessRequest
from app.helper.docx_to_yaml import BlockDocxProcessor
from app.schemas.analysis import  ImageFilter

#services handler
from app.services.captioning_service_v2 import CaptioningService
from app.services.image_processing import ImageProcessingService
from app.services.analyze_image_service import AnalyzeService
from app.services.mapping_service import MappingService
from app.services.generate_docs_service import GenerateDocsService

from app.schemas.aem_template import AEMTemplateInDB, AEMTemplateCreate
from app.crud.aem_template import (
    get_active_aem_templates,
    create_aem_template,
    get_aem_template_by_name,
    get_aem_template
)
from app.services.project_services import ProjectsService
from app.services.page_service import PageService
from app.services.image_service import ImageService
from functools import partial
from app.services.page_uat_service import PageUATService



from app.api.v1.routers.jira_router import jira_router  # <-- ADDED THIS IMPORT

router = APIRouter()

# Include Jira router
router.include_router(jira_router, prefix="/jira", tags=["Jira Integration"])  # <-- ADDED THIS LINE

# ===== Project Routes =====
@router.post(
    "/projects/",
    response_model=ProjectInDB,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new project",
    description="""
    Create a new project in the system.
    
    **Input:**
    - `project`: ProjectCreate schema (JSON body) with project details (name, description, etc.)
    
    **Output:**
    - Returns the created project as a ProjectInDB schema.
    """
)

async def create_project(
    project: ProjectCreate,
    background_tasks: BackgroundTasks,
    # files: Optional[List[UploadFile]] = File(None),
    db: Session = Depends(get_db),
):
    try:
        project_service = ProjectsService(db)
        pages_service = PageService(db)
        add_new_project = await project_service.create_project(project)
        generate_doc_service = GenerateDocsService(db)
        if add_new_project.project_name:
            background_tasks.add_task(generate_doc_service.create_folder_and_sub_folder, project.project_name)
        # if files:
        #     for file in files:
        #         upload_image = await pages_service.upload_project_image(add_new_project.id, file)
            
        #     #start captioning
        #     caption_service = CaptioningService(db)
        #     caption_data = await caption_service.captioning_service_main(add_new_project.project_id)

        return add_new_project
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

@router.get(
    "/projects/",
    response_model=List[ProjectInDB],
    summary="List all projects",
    description="""
    Retrieve all projects with optional pagination.
    
    **Input:**
    - `skip`: Number of records to skip (query param, default 0)
    - `limit`: Max number of records to return (query param, default 100)
    
    **Output:**
    - List of ProjectInDB schemas.
    """
)
async def read_projects(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Retrieve all projects with pagination"""
    try:
        project_service = ProjectsService(db)
        projects = await project_service.read_projects(limit, skip)
        return projects
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

@router.get(
    "/projects/{project_id}",
    response_model=ProjectInDB,
    summary="Get a project by ID",
    description="""
    Retrieve a specific project by its unique ID.
    
    **Input:**
    - `project_id`: UUID parameter (project's unique identifier)
    
    **Output:**
    - ProjectInDB schema for the requested project.
    """
)
async def read_project(
    project_id: str,
    db: Session = Depends(get_db)
):
    """Get a specific project by ID"""
    try:
        project_service = ProjectsService(db)
        project = await project_service.read_project(project_id)
        return project
    except Exception as e:
        if e.response.status_code:
            return {'status': e.response.status_code, "message":f"Api is failing, please check : {e}"}
        else:
            return {'status': 500, "message":f"Api is failing, please check : {e}"}

# ===== Page Routes =====
@router.post(
    "/projects/{project_id}/pages/",
    response_model=PageInDB,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new page for a project",
    description="""
    Create a new page under a specific project.
    
    **Input:**
    - `project_id`: UUID parameter (project's unique identifier)
    - `page`: PageCreate schema (JSON body) with page details
    
    **Output:**
    - The created page as a PageInDB schema.
    """
)
async def create_page(
    project_id: str,
    page: PageCreate,
    db: Session = Depends(get_db)
):
    try:
        page_service = PageService(db)
        create_page_data =  await page_service.create_page(project_id,page)
        return create_page_data
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

@router.post(
    "/projects/{project_id}/images/",
    response_model=Union[ImageInDB, Message],
    summary="Upload an image to a project",
    description="""
    Upload an image file to a specific project. The image is associated with the project and stored on the server.
    
    **Input:**
    - `project_id`: UUID parameter (project's unique identifier)
    - `file`: Image file (multipart/form-data)
    
    **Output:**
    - ImageInDB schema for the uploaded image, or a Message schema if an error occurs.
    """
)
async def upload_project_image_by_page(
    project_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    try:
        pages_service = PageService(db)
        upload_image = await pages_service.upload_project_image(project_id, file)
        return upload_image  
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get(
    "/projects/{project_id}/images/",
    response_model=List[ImageInDB],
    summary="List all images for a project",
    description="""
    Retrieve all images associated with a specific project, with optional pagination.
    
    **Input:**
    - `project_id`: UUID parameter (project's unique identifier)
    - `skip`: Number of records to skip (query param, default 0)
    - `limit`: Max number of records to return (query param, default 100)
    
    **Output:**
    - List of ImageInDB schemas for the project.
    """
)
async def read_project_images(
    project_id: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    try:
        project_service =  ProjectsService(db)
        all_images =  await project_service.read_project_images(project_id, limit=limit, skip=skip)
        return all_images
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

@router.post(
    "/upload-image",
    summary="Upload a standalone image",
    description="""
    Upload an image file to the server (not associated with a project). The image is saved in the static/images directory.
    
    **Input:**
    - `file`: Image file (multipart/form-data)
    
    **Output:**
    - JSON with filename and upload status.
    """
)
async def upload_image(file:UploadFile = File(...)):
    try:
        img_content = await file.read()
        img_path = os.path.join('static','images',file.filename)
        with open(img_path,"wb") as f:
            while contents := await file.read(1024):
                f.write(contents)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"filename":file.filename, "detail":"Image Uploaded"}



@router.get("/projects/{project_id}/analysis", response_model=List[ImageWithAnalysis])
async def get_project_images_with_analysis(
    project_id: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Get all images for a project with analyzed LLM response data.
    Returns:
        - List of image details with:
            - Image metadata
            - Analysis of LLM response including:
                - total_components
                - reusable_components
                - components_details
            - raw_llm_response
    """
    image_service = ImageService(db)
    images = image_service.get_images_by_project(project_id=project_id, skip=skip, limit=limit)
    if not images:
        raise HTTPException(
            status_code=404,
            detail=f"No images found for project {project_id}"
        )
    return images


@router.post(
    "/analyze",
    # response_model=AnalyzeResponse,
    summary="Analyze project images",
    description="""
    Analyze all images associated with a given project. Performs image analysis and returns the results.
    
    **Input:**
    - `data`: AnalyzeImage schema (JSON body) with project_id and analysis options
    
    **Output:**
    - Analysis results (format depends on implementation)
    """
)
async def analyze(data:AnalyzeImage, db: Session = Depends(get_db)):
    # try:
    #     caption_service = CaptioningService(db)
    #     await caption_service.captioning_service_main(data.project_id, data.captions_trigger_flag)
    # except Exception as e:
    #     raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))
    
    try:
        analyze_service = AnalyzeService(db)
        analyze_data = await analyze_service.analyze_image_service(data.project_id, data.page_id, data.analyze_trigger_flag)
        return analyze_data
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

@router.post(
    "/generate-doc",
    summary="Generate documentation for a project",
    description="""
    Generate documentation for a given project based on its images and pages.
    
    **Input:**
    - `project_id`: UUID parameter (project's unique identifier)
    
    **Output:**
    - Generated documentation (format depends on implementation)
    """
)
async def generate(data:AnalyzeImage, db: Session = Depends(get_db)):
    try:
        gen_doc_service = GenerateDocsService(db)
        gen_doc_data = await gen_doc_service.generate_docs_service(data.project_id, data.page_id)
        return gen_doc_data
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))


# --- Image Process and Filtering Endpoint ---
@router.post(
    "/process-and-filter-images",
    summary="Process and filter images for a project",
    description="""
    Process and filter images for a given project based on provided filter criteria.
    
    **Input:**
    - `ImageFilter`: ImageFilter schema (JSON body) with project_id and filter options
    
    **Output:**
    - Filtered/processed image data (format depends on implementation)
    """
)
async def image_filter(ImageFilter: ImageFilter, db: Session = Depends(get_db)):
    try:
        image_service = ImageProcessingService(db)
        image_output_data = image_service.image_handling_service(ImageFilter.project_id)
        return image_output_data
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

# --- Image Captioning Endpoint ---
@router.post(
    "/caption-images",
    summary="Generate captions for project images",
    description="""
    Generate captions for all images in a given project.
    
    **Input:**
    - `ImageFilter`: ImageFilter schema (JSON body) with project_id
    
    **Output:**
    - Captioning results (format depends on implementation)
    """
)
async def image_caption(ImageFilter: ImageFilter, db: Session = Depends(get_db)):
    try:
        caption_service = CaptioningService(db)
        caption_data = await caption_service.captioning_service_main(ImageFilter.project_id)
        return caption_data
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))
   


@router.post(
    "/get_all_templates",
    summary="Get all active AEM templates",
    description="""
    Retrieve all active AEM templates, optionally filtered by template type.
    
    **Input:**
    - `template_type`: Optional string query parameter to filter templates
    
    **Output:**
    - List of active AEM templates
    """
)
def get_all_tempalates(db: Session = Depends(get_db),template_type:Optional[str]=None):
    return get_active_aem_templates(db,template_type)


@router.post(
    "/genrate-knowledge-base",
    summary="Generate YAML knowledge base from AEM template",
    description="""
    Generate a YAML knowledge base file from a given AEM template URL and name.
    
    **Input:**
    - `data`: AEMTemplateCreate schema (JSON body) with template URL and name
    
    **Output:**
    - Message indicating YAML generation and formatting completion
    """
)
def generate_block_yaml(data:AEMTemplateCreate, db: Session = Depends(get_db)):
    process_block = ProcessRequest()
    complete_url = data.aem_template_url+process_block.json_list_url
    formatted_path = "aem_block_kb/" + data.aem_template_name + ".yaml"


    create_template = create_aem_template(db,data)

    
    processor = BlockDocxProcessor(
        full_url = complete_url,
        docx_root=process_block.docx_root,
        output_yaml=process_block.output_yaml,
        formatted_yaml=formatted_path
    )
    processor.process()
    return {
        "message": "YAML generation and formatting complete."
    }    


@router.get(
    '/kb-metadata',
    summary="Get knowledge base metadata",
    description="""
    Retrieve metadata about the block knowledge base, including counts of global and page building blocks.
    
    **Input:**
    - None
    
    **Output:**
    - JSON with brand, total_count, global_count, and page_building_count
    """
)
async def get_kb_data():
    try:
        mapping_service = MappingService()
        # Load the block knowledge base
        block_kb = mapping_service.load_block_kb()
        global_count = 0
        page_building_count = 0

        # Iterate through the blocks and count based on the 'element' field
        for block in block_kb:
            if block_kb[block]['element'] == 'global':
                global_count += 1
            elif block_kb[block]['element'] == 'page building':
                page_building_count += 1
        return {'brand': 'AEM','total_count': global_count+page_building_count,'global_count': global_count, 'page_building_count': page_building_count}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@router.post(
    "/mapping",
    summary="Map UI components to knowledge base blocks",
    description="""
    Map UI components (from LLM or other sources) to blocks in the knowledge base.
    
    **Input:**
    - `data`: MappingData schema (JSON body) with components_data (list of page/component dicts)
    
    **Output:**
    - List of mapping results for each page/component
    """
)
async def mapping(data:MappingData):
    try:
        all_pages_mapped_data =  []
        mapping_service = MappingService()
        for page in data.components_data:
            block_data = await mapping_service.map_ui_to_blocks(page_json=page, block_kb=mapping_service.load_block_kb())
            all_pages_mapped_data.append(block_data)
        return all_pages_mapped_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@router.post("/get_uat_data")
async def uat_data(data:AnalyzeImage, db: Session = Depends(get_db)):
    try:
        page_uat_service =  PageUATService(db)
        kw_data =  data.model_dump()
        uat_data = await page_uat_service.get_uat_data_service(**kw_data)
        return uat_data
    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))

@router.post(
    "/projects-create-v2/",
    response_model=ProjectInDB,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new project with file upload(s)",
    description="""
    Create a new project in the system and upload one or more files.
    
    **Input:**
    - ProjectCreate schema fields (multipart/form-data)
    - `files`: One or more files to upload (multipart/form-data)
    
    **Output:**
    - Returns the created project as a ProjectInDB schema, plus file info.
    """
)
async def create_project_with_file(
    background_tasks: BackgroundTasks,
    project: ProjectCreate = Depends(ProjectCreate.as_form),
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
    
):
    try:
        project_service = ProjectsService(db)
        generate_doc_service = GenerateDocsService(db)
        add_new_project = await project_service.create_project(project)
        pages_service = PageService(db)
        if files:
            for file in files:
                upload_image = await pages_service.upload_project_image(add_new_project.id, file)
            
            #start captioning
            caption_service = CaptioningService(db)
            caption_data = await caption_service.captioning_service_main(add_new_project.id)
        
        if add_new_project.project_name:
            background_tasks.add_task(generate_doc_service.create_folder_and_sub_folder, project.project_name)
        
        return add_new_project

    except Exception as e:
        raise HTTPException(status_code=getattr(e, 'status_code', 500), detail=str(e))
