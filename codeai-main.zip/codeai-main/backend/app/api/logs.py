from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.schemas.log_entry import LogEntryCreate, LogEntryResponse
from app.repositories.log_entry_repo import create_log_entry, get_logs_by_project, get_logs_by_page, get_log
from app.db.session import get_db
from typing import List

router = APIRouter()

@router.post("/logs/", response_model=LogEntryResponse)
def log_entry_create(log: LogEntryCreate, db: Session = Depends(get_db)):
    return create_log_entry(db, log)

@router.get("/logs/{log_id}", response_model=LogEntryResponse)
def log_entry_get(log_id: int, db: Session = Depends(get_db)):
    log = get_log(db, log_id)
    if not log:
        raise HTTPException(status_code=404, detail="Log not found")
    return log

@router.get("/logs/project/{project_id}", response_model=List[LogEntryResponse])
def logs_by_project(project_id: int, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return get_logs_by_project(db, project_id, skip, limit)

@router.get("/logs/page/{page_id}", response_model=List[LogEntryResponse])
def logs_by_page(page_id: str, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return get_logs_by_page(db, page_id, skip, limit)

# In your main FastAPI app setup (e.g., main.py or app/__init__.py), include:
# from app.api import logs
# app.include_router(logs.router)
