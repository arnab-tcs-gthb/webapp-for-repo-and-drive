from sqlalchemy import Column, String, Text, Boolean, TIMESTAMP, JSON, Integer
import uuid
from sqlalchemy.sql import func
from app.db.base import Base

class JiraApiLog(Base):
    __tablename__ = "jira_api_log"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    created_in_db_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    api_endpoint_called = Column(String(255))
    request_project_key = Column(String(255))
    request_issue_type = Column(String(100))

    request_summary = Column(Text)
    request_description = Column(Text)
    request_assignee_id = Column(String(255))
    request_reporter_id = Column(String(255))
    request_labels = Column(JSON)
    request_parent_key = Column(String(255))
    request_epic_link_key = Column(String(255))
    request_custom_fields = Column(JSON)

    response_jira_issue_id = Column(String(255))
    response_jira_issue_key = Column(String(255))
    response_jira_url = Column(String(512))
    response_message = Column(Text)

    request_payload_raw = Column(JSON)
    response_payload_raw = Column(JSON)
    jira_api_success = Column(Boolean)
    error_message_if_failed = Column(Text)
    http_status_code_returned = Column(Integer)