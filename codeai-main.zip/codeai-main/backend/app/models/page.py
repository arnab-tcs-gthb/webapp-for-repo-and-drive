from sqlalchemy import Column, String, Text, DateTime, ForeignKey, JSON, ARRAY, Integer
import uuid
from datetime import datetime
from app.db.base import Base

class Page(Base):
    __tablename__ = "tbl_pages"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    project_id = Column(String(36), ForeignKey("tbl_projects.id"), nullable=False)
    page_name = Column(String(255), nullable=False)
    page_url = Column(String(255), nullable=False)
    page_body = Column(Text)
    page_metadata = Column(JSON,nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    sort_order = Column(Integer, default=0)
    
    # Analysis status of the page
    analysis = Column(String(50), default='new')  # e.g., new, inprogress, done
    # Components used in the page, stored as JSON
    page_components = Column(JSON, nullable=True)  # JSON for storing page components
    # Status of the document generation
    generate = Column(String(50), default='pending')  # e.g., pending, generated , only for  adobe franklin
    # URL for the preview document
    preview_url = Column(String(255), nullable=True)  # URL for preview doc
    publish_url = Column(String(255), nullable=True)  # URL for preview doc

    # Mapping data for the page, stored as JSON
    mapping_data = Column(JSON, nullable=True)  # JSON for mapping data only
    # Body of the generated document
    # Status of the page, can be new or in progress
    page_status = Column(String(50), default='new')  # enum: new, inprogress
    # User Acceptance Testing information, stored as JSON


