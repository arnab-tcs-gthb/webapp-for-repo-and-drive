from sqlalchemy import Column, String, Text, DateTime, Integer, JSON, ForeignKey
import datetime
import uuid
from app.db.base import Base



class LLMUsageLog(Base):
    __tablename__ = "llm_audit_log"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True)
    project_id = Column(String(36), ForeignKey('tbl_projects.id'), index=True)
    page_id = Column(String(36), ForeignKey('tbl_pages.id'), nullable=True)
    model_name = Column(String(100), nullable=True)
    provider = Column(String(50), nullable=True)
    endpoint = Column(String(255), nullable=True)
    llm_input_tokens = Column(Integer, nullable=True)
    llm_output_tokens = Column(Integer, nullable=True)
    llm_total_tokens = Column(Integer, nullable=True)
    llm_thinking_tokens = Column(Integer, nullable=True)
    latency_ms = Column(Integer, nullable=True)
    # status_code = Column(Integer, nullable=True)
    prompt_hash = Column(Text, nullable=True)
    temperature = Column(String(10), nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    extra = Column(JSON, nullable=True)