from sqlalchemy import Column, String, Text, JSON, DateTime, Boolean
import uuid
from datetime import datetime
from app.db.base import Base

class Project(Base):
    __tablename__ = "tbl_projects"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    project_name = Column(String(255),  nullable=False, unique=True)
    project_type = Column(String(100), nullable=False)
    created_date = Column(DateTime, default=datetime.utcnow, nullable=False)
    project_description = Column(Text)
    title = Column(String(255))
    project_metadata = Column(JSON, nullable=True)  # Renamed from 'metadata' to avoid conflict
    is_active = Column(Boolean, default=True)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    github_repo_url = Column(String(512))
    drive_info = Column(JSON, nullable=True)
    captions = Column(JSON, nullable=True)
    assets_exist  = Column(Boolean, default=False)
    template_id = Column(String(36), nullable=True)  # Consider ForeignKey to template table if needed
    project_status = Column(String(50), default='new') 
    is_deleted = Column(Boolean, default=False)
    technology = Column(String(100), nullable=True)

