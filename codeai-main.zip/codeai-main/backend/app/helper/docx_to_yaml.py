import os
import requests
import yaml
import tempfile
import re
from app.helper.md_to_docx import docx_to_html
from google import genai
from dotenv import load_dotenv

# --- Custom YAML Dumper with proper indentation ---
class BlockDumper(yaml.Dumper):
    def increase_indent(self, flow=False, indentless=False):
        return super(BlockDumper, self).increase_indent(flow, False)

def str_representer(dumper, data):
    if '\n' in data:
        if not data.endswith('\n'):
            data += '\n'
        return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
    return dumper.represent_scalar('tag:yaml.org,2002:str', data)

yaml.add_representer(str, str_representer, Dumper=BlockDumper)

class BlockDocxProcessor:
    def __init__(self, full_url, docx_root, output_yaml, formatted_yaml):
        self.full_url = full_url
        self.docx_root = docx_root
        self.output_yaml = output_yaml
        self.formatted_yaml = formatted_yaml

    def fetch_component_list(self):
        """Fetch the list of component endpoints from the remote JSON."""
        try:
            response = requests.get(self.full_url)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"Could not process url {self.full_url}: {e}")
            return None

    def get_component_folders(self):
        """Return a list of folder names in the docx_root directory."""
        return [name for name in os.listdir(self.docx_root) if os.path.isdir(os.path.join(self.docx_root, name))]

    def get_docx_files(self, folder_path):
        """Return a list of .docx files in the given folder."""
        return [f for f in os.listdir(folder_path) if f.lower().endswith('.docx')]

    def docx_file_to_html(self, docx_path):
        """Convert a docx file to HTML and return the HTML string."""
        with tempfile.TemporaryDirectory() as tmpdir:
            html_path = os.path.join(tmpdir, "temp.html")
            docx_to_html(docx_path, html_path)
            with open(html_path, "r", encoding="utf-8") as f:
                html = f.read()
        return html

    def get_llm_description(self, html, block_name=None):
        """
        Generate a structural description for the block using Gemini LLM from HTML, focusing only on the structure/layout,
        not the data/content. For known block types like 'cards' or 'carousel', use a canonical description.
        """
        canonical = {
            "cards": "List of cards with or without images and links. Each card can have a title, description, and an image. The cards are displayed in a grid format.",
            "carousel": "A dynamic display tool that smoothly transitions through a series of images with optional optional text content."
        }
        norm_name = (block_name or "").lower()
        if norm_name in canonical:
            return canonical[norm_name]

        load_dotenv()
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            print("GEMINI_API_KEY not found in environment. Returning fallback description.")
            return f"Structural description for block '{block_name}' based on HTML length {len(html)}. (No LLM key)"
        client = genai.Client(api_key=api_key)
        prompt = (
            f"You are given the HTML for a UI component block named '{block_name}'.\n"
            "Do NOT describe or mention any specific data, text, or content inside the elements.\n"
            "Make the description generic and suitable for another LLM to understand the block's structure and how it is organized, not what it contains.\n"
            "Use the following examples as a reference for the style and level of detail you should provide:\n"
            "cards: List of cards with or without images and links. Each card can have a title, description, and an image. The cards are displayed in a grid format.\n"
            "carousel: A dynamic display tool that smoothly transitions through a series of images with optional optional text content.\n"
            "a single, unique, one-line description of the block\n\n"
            f"Block Name: {block_name}\n"
            f"HTML:\n{html}"
        )
        contents = [genai.types.Content(role="user", parts=[genai.types.Part.from_text(text=prompt)])]
        config = genai.types.GenerateContentConfig(
            thinking_config=genai.types.ThinkingConfig(thinking_budget=0),
            response_mime_type="text/plain",
        )
        try:
            stream = client.models.generate_content_stream(
                model="gemini-1.5-pro-latest",
                contents=contents,
                config=config
            )
            raw = ""
            for chunk in stream:
                if hasattr(chunk, "text"):
                    raw += chunk.text
            description = raw.strip()
            if not description:
                return f"No LLM structural description generated for block '{block_name}'. (HTML length {len(html)})"
            return description
        except Exception as e:
            print(f"LLM error: {e}")
            return f"Structural description for block '{block_name}' based on HTML length {len(html)}. (LLM error)"

    def normalize_name(self, s):
        """Normalize component/folder names for matching."""
        return ''.join(e for e in s.lower() if e.isalnum())

    def process(self):
        endpoint_list = self.fetch_component_list()
        if not endpoint_list:
            print("No endpoints found.")
            return

        component_folders = self.get_component_folders()
        blocks = []
        for endpoint in endpoint_list["data"]:
            comp_name = endpoint.get("name") or endpoint.get("path", "").split("/")[-1]
            target = self.normalize_name(comp_name)
            folder_match = None
            for folder in component_folders:
                if self.normalize_name(folder) == target:
                    folder_match = folder
                    break
            if not folder_match:
                print(f"No folder found for component: {comp_name}")
                continue
            folder_path = os.path.join(self.docx_root, folder_match)
            docx_files = self.get_docx_files(folder_path)
            for docx_file in docx_files:
                docx_path = os.path.join(folder_path, docx_file)
                html = self.docx_file_to_html(docx_path)
                block_name = os.path.splitext(docx_file)[0]
                description = self.get_llm_description(html, block_name=block_name)
                blocks.append({
                    "type": block_name,
                    "html": html,
                    "element": "",
                    "markdown": "",
                    "description": description,
                })
                break
        self.save_yaml(blocks, self.output_yaml)
        print(f"Saved YAML to {self.output_yaml}")
        self.format_yaml(self.output_yaml, self.formatted_yaml)
        #delete the output file 
        if os.path.exists(self.output_yaml):
            os.remove(self.output_yaml)

    def save_yaml(self, blocks, path):
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump({"blocks": blocks}, f, allow_unicode=True, sort_keys=False, default_flow_style=False, indent=2, width=120)

    def format_yaml(self, input_yaml_path, output_yaml_path):
        """
        Formats the input YAML file to ensure proper structure and indentation.
        """
        try:
            with open(input_yaml_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if "blocks" not in data or not isinstance(data["blocks"], list):
                print("Invalid YAML structure: 'blocks' key is missing or not a list.")
                return

            formatted_blocks = []
            for block in data["blocks"]:
                block_type = block.get("type", "unknown").strip()
                if block_type.startswith('"') and block_type.endswith('"'):
                    block_type = block_type[1:-1]
                description = block.get("description", "").strip()
                html = block.get("html", "").strip()
                element = block.get("element", "").strip()

                html = re.sub(r"\s*\n\s*", "\n", html)
                description = re.sub(r"\s*\n\s*", " ", description)
                if description.startswith('"') and description.endswith('"'):
                    description = description[1:-1]

                formatted_blocks.append({
                    "type": block_type,
                    "description": description,
                    "html": html,
                    "element": element
                })

            with open(output_yaml_path, "w", encoding="utf-8") as f:
                yaml.dump({"blocks": formatted_blocks}, f,
                          Dumper=BlockDumper,
                          allow_unicode=True,
                          sort_keys=False,
                          default_flow_style=False,
                          indent=2,
                          width=120)

            print(f"Formatted YAML saved to {output_yaml_path}")

        except Exception as e:
            print(f"Error formatting YAML: {e}")

# if __name__ == "__main__":
#     BASE_URL = "https://sidekick-library--aem-block-collection--adobe.aem.page"
#     JSON_LIST_URL = "/tools/sidekick/library.json"
#     DOCX_ROOT = "all_docx"
#     OUTPUT_YAML = "block_kb_from_docx_aem.yaml"
#     FORMATTED_YAML = "block_kb_formatted.yaml"

#     processor = BlockDocxProcessor(
#         base_url=BASE_URL,
#         json_list_url=JSON_LIST_URL,
#         docx_root=DOCX_ROOT,
#         output_yaml=OUTPUT_YAML,
#         formatted_yaml=FORMATTED_YAML
#     )
#     processor.process()