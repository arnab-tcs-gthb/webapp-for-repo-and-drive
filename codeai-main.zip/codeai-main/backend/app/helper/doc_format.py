from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Inches
from docx.enum.table import WD_TABLE_ALIGNMENT


def set_cell_borders(cell):
    """Set borders for a table cell with direct XML manipulation"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()

    borders = {
        "top": {"val": "single", "sz": "4", "color": "000000"},
        "left": {"val": "single", "sz": "4", "color": "000000"},
        "bottom": {"val": "single", "sz": "4", "color": "000000"},
        "right": {"val": "single", "sz": "4", "color": "000000"},
    }

    for border, props in borders.items():
        element = OxmlElement(f"w:{border}")
        for attr, value in props.items():
            element.set(qn(f"w:{attr}"), value)
        tcPr.append(element)


def cell_has_image(cell):
    """Check if a cell contains an image by examining its XML"""
    for paragraph in cell.paragraphs:
        if paragraph._p.xpath(".//w:drawing") or paragraph._p.xpath(".//w:pict"):
            return True
    return False


def resize_images_in_cell(cell, max_width=None):
    """Resize images in the cell to fit properly"""
    if not max_width:
        # Calculate cell width (if available) or use a default
        try:
            max_width = cell.width
        except AttributeError:
            max_width = Inches(2.5)  # Default reasonable size

    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            # Access the underlying XML
            run_xml = run._r
            drawing_elements = run_xml.xpath(".//w:drawing")

            for drawing in drawing_elements:
                # Find extent element using local-name() instead of namespaces parameter
                extent = drawing.xpath('.//*[local-name()="extent"]')
                if extent:
                    # Set a reasonable max width and maintain aspect ratio
                    # Convert max_width to EMUs (English Metric Units)
                    if hasattr(max_width, "emu"):
                        emu_width = max_width.emu
                    else:
                        emu_width = int(max_width * 914400)  # Convert inches to EMUs

                    # Get current dimensions
                    cx = int(extent[0].get("cx", "0"))
                    cy = int(extent[0].get("cy", "0"))

                    if cx > emu_width:
                        # Scale height proportionally
                        aspect_ratio = cy / cx
                        new_cx = emu_width
                        new_cy = int(new_cx * aspect_ratio)

                        extent[0].set("cx", str(new_cx))
                        extent[0].set("cy", str(new_cy))


def merge_empty_cells(row):
    """Merge consecutive empty cells in a table row, handling both leading and trailing empty cells"""
    cells = row.cells
    if not cells:
        return

    # Don't merge cells with images
    cell_contents = [
        (i, cell.text.strip() != "", cell_has_image(cell))
        for i, cell in enumerate(cells)
    ]

    # Find cells that have content (text or images)
    content_indices = [
        i for i, has_text, has_image in cell_contents if has_text or has_image
    ]

    # Case 1: Empty cells before content
    if content_indices and content_indices[0] > 0:
        first_content_idx = content_indices[0]
        # Merge all empty cells before content into one
        cells[0].merge(cells[first_content_idx - 1])
        cells[0].text = ""  # Clear any accidental content
        # Refresh cells list after merge
        cells = row.cells

    # Case 2: Empty cells after content
    if cells and content_indices:  # Check if we still have cells after potential merge
        last_content_idx = content_indices[-1]
        if last_content_idx < len(cells) - 1:
            # Merge all empty cells after content
            cells[last_content_idx + 1].merge(cells[-1])


def process_docx_tables(doc):
    """Process all tables in document for borders and empty cells"""
    for table in doc.tables:
        table.alignment = WD_TABLE_ALIGNMENT.CENTER

        for row in table.rows:
            merge_empty_cells(row)

            # Apply borders to all cells (including merged ones) and resize images
            for cell in row.cells:
                set_cell_borders(cell)

                # Resize images if present
                if cell_has_image(cell):
                    # Get cell width (account for column span)
                    cell_width = Inches(
                        6.0 / len(row.cells)
                    )  # Approximate table width divided by cells
                    resize_images_in_cell(cell, cell_width)

                # Set consistent formatting
                for paragraph in cell.paragraphs:
                    paragraph.style = doc.styles["Normal"]
                    paragraph.paragraph_format.space_after = Pt(0)
