import json
import hashlib
from app.services.logging_service import log_event

async def entry_logs(db,input_data=None, output_data=None, token_data=None,project_id=None, page_id=None, endpoint=None):
    try:
        llm_input = json.dumps(input_data) if input_data else None
        print(llm_input)
        # Create a hash of the prompt (llm_input)
        # prompt_hash = hashlib.sha256(llm_input.encode('utf-8')).hexdigest() if llm_input else None
        llm_input_tokens = token_data.get('llm_input_tokens') if isinstance(token_data, dict) else None
        llm_output_tokens = token_data.get('llm_output_tokens') if isinstance(token_data, dict) else None
        llm_total_tokens = token_data.get('llm_total_tokens') if isinstance(token_data, dict) else None
        llm_thinking_tokens = token_data.get('llm_thinking_tokens') if isinstance(token_data, dict) else None
        log_event(
            db=db,
            project_id=project_id,
            # page_id=str(page_id) if page_id else None,
            llm_input=llm_input,
            llm_output=json.dumps(input_data) if input_data else None,
            llm_input_tokens=llm_input_tokens,
            llm_output_tokens=llm_output_tokens,
            llm_total_tokens=llm_total_tokens,
            llm_thinking_tokens = llm_thinking_tokens,
            endpoint=endpoint,
            # prompt_hash=llm_input,
        )
    except Exception as e:
        raise e