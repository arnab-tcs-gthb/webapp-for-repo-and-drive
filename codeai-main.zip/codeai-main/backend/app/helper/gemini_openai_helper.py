import logging
from openai import OpenAI
import os
import base64
import vertexai
from vertexai.preview.generative_models import GenerativeModel, Part
from google.genai import types

logger = logging.getLogger(__name__)


try:
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    model = "gemini-2.5-pro"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None



api_key_gemini = os.environ.get("GEMINI_API_KEY", "dummy_key")

def call_gemini_openai(prompt, model="gemini-2.5-pro", api_key=None, image_bytes=None, mime_type=None):
    """
    Calls the Gemini model via the OpenAI-compatible API and returns the response text.
    Args:
        prompt (str): The prompt or instruction for the model.
        model (str): The Gemini model name.
        api_key (str): API key for authentication.
        image_bytes (bytes, optional): Image data if needed for vision tasks.
        mime_type (str, optional): MIME type of the image (e.g., 'image/png').
    Returns:
        str: The generated response from the Gemini model.
    Raises:
        Exception: If the API call fails.
    """
    logger = logging.getLogger(__name__)
    try:
        client = OpenAI(api_key=api_key_gemini, base_url="https://generativelanguage.googleapis.com/v1beta/openai/")
        if image_bytes and mime_type:
            # Encode image to base64 string
            image_b64 = base64.b64encode(image_bytes).decode("utf-8")
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{image_b64}"}}
                    ]
                }
            ]
        else:
            messages = [
                {"role": "user", "content": prompt}
            ]
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            stream=False
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error calling Gemini via OpenAI API: {str(e)}")
        raise RuntimeError(f"Error calling Gemini via OpenAI API: {str(e)}")

def call_gemini_vertexai(prompt, model_name="gemini-2.5-pro", project=None, location="us-central1", image_bytes=None, mime_type=None):
    """
    Calls the Gemini model via Google Vertex AI and returns the response text.
    Args:
        prompt (str): The prompt or instruction for the model.
        model_name (str): The Gemini model name.
        project (str, optional): GCP project ID.
        location (str): GCP region for Vertex AI.
        image_bytes (bytes, optional): Image data if needed for vision tasks.
        mime_type (str, optional): MIME type of the image (e.g., 'image/png').
    Returns:
        str: The generated response from the Gemini model.
    Raises:
        Exception: If the API call fails.
    """
    logger = logging.getLogger(__name__)
    try:
        vertexai.init(project="woven-icon-461203-g9", location=location)
        model = GenerativeModel(model_name)
        parts = [Part.from_text(prompt)]
        if image_bytes and mime_type:
            parts.append(Part.from_data(mime_type=mime_type, data=image_bytes))
        response = model.generate_content(parts)
        if hasattr(response, 'text'):
            return response.text
        elif hasattr(response, 'candidates') and response.candidates:
            return response.candidates[0].text
        else:
            return str(response)
    except Exception as e:
        logger.error(f"Error calling Gemini via Vertex AI: {str(e)}")
        raise RuntimeError(f"Error calling Gemini via Vertex AI: {str(e)}")

def gemini_generate_content_stream(prompt, model="gemini-2.5-pro", img_bytes = None, mime_type=None):
    """
    Calls Gemini's generate_content_stream and returns (raw, token_data) for streaming responses.
    Handles token usage extraction and text aggregation.
    """
    logger = logging.getLogger(__name__)
    try:
        
        if img_bytes:
            contents = [
            types.Content(
                role="user",
                parts=[
                    types.Part.from_bytes(mime_type=mime_type, data=img_bytes),
                    types.Part.from_text(text=prompt),
                ],
            )
            ]
        else:
            contents = [
                types.Content(
                    role="user",
                    parts=[types.Part.from_text(text=prompt)]
                )
            ]
        config = types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_budget=5000),
            response_mime_type="text/plain",
        )
        chunks = client.models.generate_content_stream(
            model=model, contents=contents, config=config
        )
        raw = ""
        chunk_count = 0
        token_data = {}
        last_chunk = ""
        for chunk in chunks:
            if hasattr(chunk, 'candidates') and chunk.candidates:
                for candidate in chunk.candidates:
                    for part in candidate.content.parts:
                        if hasattr(part, "text"):
                            raw += part.text
            chunk_count += 1
            last_chunk = chunk
        if last_chunk and hasattr(last_chunk, 'usage_metadata'):
            usage = last_chunk.usage_metadata
            if usage:
                token_data = {
                    'llm_input_tokens': getattr(usage, 'prompt_token_count', None),
                    'llm_output_tokens': getattr(usage, 'candidates_token_count', None),
                    'llm_total_tokens': getattr(usage, 'total_token_count', None),
                    'llm_thinking_tokens': getattr(usage, 'thoughts_token_count', None)
                }
        return raw, token_data
    except Exception as e:
        logger.error(f"Error in gemini_generate_content_stream: {str(e)}")
        raise RuntimeError(f"Error in gemini_generate_content_stream: {str(e)}")
