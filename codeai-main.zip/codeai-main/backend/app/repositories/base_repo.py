

class BaseRepository:
    def __init__(self, db, model):
        self.db = db
        self.model = model

    
    def get_all(self):
        """Retrieves all items from the database."""
        try:
            all_rows = self.db.query(self.model).all()
            return all_rows
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

