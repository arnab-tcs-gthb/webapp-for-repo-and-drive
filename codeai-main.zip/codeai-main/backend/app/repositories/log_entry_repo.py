from sqlalchemy.orm import Session
from app.models.log_entry import LLMUsageLog
from app.schemas.log_entry import LogEntryCreate

def create_log_entry(db: Session, log: LogEntryCreate):
    db_log = LLMUsageLog(**log.dict())
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log

def get_logs_by_project(db: Session, project_id: int, skip: int = 0, limit: int = 100):
    return db.query(LLMUsageLog).filter(LLMUsageLog.project_id == project_id).offset(skip).limit(limit).all()

def get_logs_by_page(db: Session, page_id: str, skip: int = 0, limit: int = 100):
    return db.query(LLMUsageLog).filter(LLMUsageLog.page_id == page_id).offset(skip).limit(limit).all()

def get_log(db: Session, log_id: int):
    return db.query(LLMUsageLog).filter(LLMUsageLog.id == log_id).first()
