from app.models.image import Image
from app.schemas.image import ImageCreate
from fastapi import HTTPException
class ImagesRepository:
    def __init__(self, db=None):
        self.db = db



    def create_image(self, image:ImageCreate):
        try:
            db_image = Image(**image.dict())
            self.db.add(db_image)
            self.db.commit()
            self.db.refresh(db_image)
            return db_image
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))
        

    def get_images_by_project(self, project_id: int, skip: int = 0, limit: int = 100):
        try:
            return self.db.query(Image).filter(Image.project_id == project_id).offset(skip).limit(limit).all()
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))    
    
    def get_images_by_page(self, page_id: int, skip: int = 0, limit: int = 100):
        try:
            return self.db.query(Image).filter(Image.page_id == page_id).offset(skip).limit(limit).all()
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))  