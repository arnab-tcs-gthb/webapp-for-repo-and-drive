from app.models.project import Project
from app.schemas.project import ProjectCreate
from app.repositories.base_repo import BaseRepository
from fastapi import HTTPException,status



class ProjectsRepo(BaseRepository):
    def __init__(self, db):
        self.db = db
        super().__init__(db, Project)

    def get_project_by_project_name(self, project_name):
        try:
            existing_project = (
                self.db.query(Project)
                .filter(Project.project_name == project_name)
                .first()
            )
            return existing_project
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    def get_project_by_github_url(self, github_repo_url):
        # Check if another project is already using this GitHub URL
        try:
            github_project = (
                self.db.query(Project)
                .filter(Project.github_repo_url == github_repo_url)
                .first()
            )
            return github_project
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    def create_project(self, project: ProjectCreate):
        # project: should be object of ProjectCreate
        try:
            db_project = Project(**project.model_dump())
            self.db.add(db_project)
            self.db.commit()
            self.db.refresh(db_project)
            return db_project
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    def get_all_projects(self, limit: int = None, skip: int = None):
        try:
            projects = self.db.query(Project).offset(skip).limit(limit).all()
            return projects
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    def get_project_by_id(self, project_id):
        try:
            project = self.db.query(Project).filter(Project.id == project_id).first()
            return project
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    def update_project_upload_metadata(self, project_name, update_data):
        try:
            update_body = {
                "drive_info" :update_data
            }
            self.db.query(Project).filter(Project.project_name==project_name).update(update_body)
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))
    
    
        


        


