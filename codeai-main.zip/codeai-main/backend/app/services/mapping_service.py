import logging
import yaml
logger = logging.getLogger(__name__)
class MappingService:
    def __init__(self, db=None):
        self.db = db

    def load_block_kb(self,path="aem_block_kb/block_kb.yaml"):
        """
        Load the block knowledge base YAML and return a dict mapping block type to block info.
        
        Args:
            path (str): Path to the block knowledge base YAML file
            
        Returns:
            dict: Mapping of block types to their definitions
        """
        try:
            with open(path, encoding="utf-8") as f:
                kb = yaml.safe_load(f)
            return {b["type"]: b for b in kb["blocks"]}
        except Exception as e:
            logger.error(f"Error loading block knowledge base: {str(e)}")
            return {}

    async def map_ui_to_blocks(self,page_json, block_kb):
        """
        Deterministically map UI JSON to block definitions, including element_type and kb_html.
        
        Args:
            page_json (dict): Page JSON from image analysis
            block_kb (dict): Block knowledge base
            
        Returns:
            dict: Mapped components with block information
        """
        try:
            mapped = []
            not_found_block = 0
            global_block_number = 0
            block_used = 0
            
            for comp in page_json.get("components", []):
                blk = block_kb.get(comp["markdown_template"])
                if not blk:
                    not_found_block += 1
                    continue
                    
                if blk.get("element", "page-building") == "global":
                    global_block_number += 1
                else:
                    block_used += 1

                mapped.append({
                    "page_title": page_json.get("page_title", ""),
                    "original_file_name" : page_json.get("original_file_name", ""),
                    "type": comp["type"],
                    "element_type": comp.get("element_type", blk.get("element", "page-building")),
                    "properties": comp.get("properties", {}),
                    "layout": comp.get("layout", ""),
                    "kb_html": blk["html"],
                })

            return_json = {
                "page_title": page_json.get("page_title", ""),
                "mapped_data": mapped,
                "not_found_block": not_found_block,
                "global_block_number": global_block_number,
                "block_used": block_used
            }
            
            return return_json
        except Exception as e:
            logger.error(f"Error mapping UI to blocks: {str(e)}")
            return {
                "page_title": page_json.get("page_title", "Error Page"),
                "mapped_data": [],
                "not_found_block": 0,
                "global_block_number": 0, 
                "block_used": 0,
                "error": str(e)
            }
    
    def get_block_info(self,template_type=None):
        """
        Load block knowledge base and return a formatted string of block types and descriptions.
        Optionally filter by template_type.
        
        Args:
            template_type (str, optional): Filter blocks by this template type
            
        Returns:
            str: Formatted string with block types and descriptions
        """
        try:
            kb = self.load_block_kb()
            if template_type:
                block = kb.get(template_type, {})
                return f"{block.get('type', 'unknown')} - {block.get('description', 'No description')}"
            return "\n\n".join(f"### {b['type']} - {b['description']}" for b in kb.values())
        except Exception as e:
            logger.error(f"Error loading block info: {str(e)}")
            return "Error loading block information"