"""
Chat service module - handles image analysis with Google Gemini API
and converting the results to AEM blocks.

This module provides functions to analyze images with Google Gemini AI,
extract structured information, and generate HTML/DOCX documents.
"""

import os
import json
import yaml
import re
import unicodedata
import string
import logging
from typing import Dict, List, Any, Optional, Union

from google.genai import types
from dotenv import load_dotenv

from app.helper.md_to_docx import html_to_docx
from app.helper.doc_format import Document, process_docx_tables
from app.helper.google_docs import upload_docx_as_gdoc
from .upload_service import *

# Configure logging
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize Gemini client with robust error handling
try:
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    model = "gemini-2.5-pro-preview-05-06"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None

# Directory constants
image_dir = "images"
output_dir = "output"


def _extract_json(raw: str) -> str:
    """
    Extract valid JSON from a string that might contain markdown or other text.
    Handles various edge cases like code fences, extra text, and malformed JSON.
    
    Args:
        raw (str): The raw text containing JSON
        
    Returns:
        str: A valid JSON string or empty JSON object if extraction fails
    """
    if not raw:
        logger.warning("Empty raw text provided to _extract_json")
        return '{}'
        
    # Remove markdown code fences if present
    raw = re.sub(r"```(?:json)?\s*", "", raw).replace("```", "").strip()
    
    # First try: extract substring from first "{" to last "}"
    start, end = raw.find("{"), raw.rfind("}")
    if start != -1 and end != -1 and end > start:
        json_str = raw[start : end + 1]
        try:
            json.loads(json_str)  # Validate JSON
            return json_str
        except json.JSONDecodeError:
            logger.debug("First JSON extraction attempt failed, trying alternatives")
    
    # Second try: find any JSON-like structure
    json_matches = re.findall(r'\{(?:[^{}]|"(?:\\.|[^"\\])*")*\}', raw)
    for match in json_matches:
        try:
            json.loads(match)
            return match
        except json.JSONDecodeError:
            continue
    
    # Final attempt: try to fix common JSON issues
    cleaned = raw.strip()
    if not (cleaned.startswith('{') and cleaned.endswith('}')):
        cleaned = '{' + cleaned + '}'
    
    # Replace single quotes with double quotes
    cleaned = re.sub(r"(?<!\\)'([^']*?)(?<!\\)'", r'"\1"', cleaned)
    
    try:
        json.loads(cleaned)
        return cleaned
    except json.JSONDecodeError:
        logger.warning("All JSON extraction methods failed, returning empty object")
        return '{}'


def analyze_image(image_path: str, captions: dict) -> dict:
    """
    Analyze an image using Google's Gemini model and return structured JSON.
    Enhanced with robust error handling.
    
    Args:
        image_path (str): Path to the image file
        captions (dict): Captions for the image
        
    Returns:
        dict: Structured analysis of the image or fallback structure if analysis fails
    """
    # Check if Gemini API client is available
    if client is None:
        logger.warning("Gemini API client not initialized. Returning dummy data.")
        return {
            "page_title": "Example Page (API Client Unavailable)",
            "components": [
                {
                    "type": "text",
                    "properties": {
                        "title": "API Client Not Available",
                        "description": "The Gemini API client could not be initialized. This is dummy data."
                    },
                    "layout": "full-width",
                    "markdown_template": "text",
                    "element_type": "page-building"
                }
            ]
        }

    # Load and process image
    try:
        with open(image_path, "rb") as f:
            img_bytes = f.read()
        logger.debug(f"Successfully read image: {image_path}")
    except Exception as e:
        logger.error(f"Error reading image file {image_path}: {str(e)}")
        return {
            "page_title": "Error Reading Image",
            "components": [
                {
                    "type": "text",
                    "properties": {
                        "title": "Image Error",
                        "description": f"Could not read image file: {str(e)}"
                    },
                    "layout": "full-width",
                    "markdown_template": "text",
                    "element_type": "page-building"
                }
            ]
        }

    # Prepare prompt with block information
    try:
        block_info = get_block_info()
        
        # Make sure captions can be serialized to JSON by converting to a simple dict
        if hasattr(captions, '__dict__'):
            # Convert to dictionary if it's an object with __dict__
            captions_dict = {}
            # Extract the captions field if it exists
            if hasattr(captions, 'captions'):
                if isinstance(captions.captions, dict):
                    captions_dict = {'captions': captions.captions}
                else:
                    captions_dict = {'captions': {}}
            # Try using dict() or model_dump() methods if available
            elif hasattr(captions, 'dict') and callable(getattr(captions, 'dict')):
                captions_dict = captions.dict()
            elif hasattr(captions, 'model_dump') and callable(getattr(captions, 'model_dump')):
                captions_dict = captions.model_dump()
        elif isinstance(captions, dict):
            # If it's already a dict, use it as is
            captions_dict = captions
        else:
            # Fallback to empty dict if we can't convert
            logger.warning(f"Could not convert captions to dict, using empty dict. Type: {type(captions)}")
            captions_dict = {'captions': {}}
            
        # Use a safe JSON serialization approach
        try:
            captions_str = json.dumps(captions_dict, indent=2, default=str)
        except Exception as json_err:
            logger.error(f"Error serializing captions to JSON: {str(json_err)}")
            captions_str = "{}"
    except Exception as e:
        logger.error(f"Error preparing prompt data: {str(e)}")
        block_info = "Error loading block information"
        captions_str = "{}"

    prompt = f"""
You have perfect vision and pay great attention to detail, making you an expert at analyzing user interfaces.
Identify the UI components in this image and map them to AEM block types.

**Instructions:**
- Identify and classify **all UI sections** in the image, including both:
  - **Global elements** (such as header, footer, navigation bars, etc.)
  - **Page-building elements** (such as hero, cards, carousels, columns, etc.)

- For each section/component, do the following:
  1. Assign the most appropriate AEM block type (choose from both global and page-building elements).
  2. Specify required properties (title, description, image references, etc.).
  3. Note any special styling or layout requirements.
  4. Indicate the markdown template to use (from the block list below).

**Available AEM block types and descriptions:**
{block_info}

**Image Captioning Context:**
You are provided with the following Asset image along with its captions for reference:
{captions_str}

Return your response as clean, parseable JSON with this structure:
{{
  "page_title": "Title for the page",
  "components": [
    {{
      "type": "component_type",
      "properties": {{
        "title": "Component title",
        "description": "Description text",
        "imageRef": "image reference path from provided captions",
      }},
      "layout": "layout information",
      "markdown_template": "block_type",
      "element_type": "page-building or global"
    }}
  ]
}}
Think step by step before providing the final JSON output.
""".strip()
    # Set up Gemini API request
    try:
        contents = [
            types.Content(
                role="user",
                parts=[
                    types.Part.from_bytes(mime_type="image/png", data=img_bytes),
                    types.Part.from_text(text=prompt),
                ],
            )
        ]

        config = types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_budget=0),
            response_mime_type="text/plain",
        )

    except Exception as e:
        logger.error(f"Error setting up Gemini API request: {str(e)}")
        return {
            "page_title": "API Request Error",
            "components": [
                {
                    "type": "text",
                    "properties": {
                        "title": "Request Error",
                        "description": f"Error preparing API request: {str(e)}"
                    },
                    "layout": "full-width",
                    "markdown_template": "text",
                    "element_type": "page-building"
                }
            ]
        }

    # Call Gemini API and process response
    try:
        # Log parameters for debugging
        logger.debug(f"Calling Gemini API for image: {image_path}")
        logger.debug(f"Model: {model}")
        logger.debug(f"Caption data type: {type(captions)}")
        
        # Stream content from API
        chunks = client.models.generate_content_stream(
            model=model, contents=contents, config=config
        )
        
        # Process chunks
        raw = ""
        chunk_count = 0
        for chunk in chunks:
            if hasattr(chunk, 'text'):
                raw += chunk.text
                chunk_count += 1
                
        logger.debug(f"Received {chunk_count} chunks from Gemini API")
        logger.debug(f"Raw response (first 200 chars): {raw[:200]}...")
        
        # Extract JSON
        payload = _extract_json(raw)
        logger.debug(f"Extracted JSON payload (first 300 chars): {payload[:300]}...")
        
        # Parse JSON
        result = json.loads(payload)
        logger.debug(f"Successfully parsed JSON to dictionary with {len(result)} keys")
        
        # Validate expected structure
        if not isinstance(result, dict):
            logger.error(f"Invalid response format: Expected dict, got {type(result)}")
            raise ValueError(f"Invalid response format: Expected dict, got {type(result)}")
            
        if "components" not in result:
            logger.error(f"Missing 'components' in response. Keys: {list(result.keys())}")
            # Auto-fix the response structure if needed
            result["components"] = []
            logger.warning(f"Auto-fixed missing 'components' key in response")
            
        if "page_title" not in result:
            logger.warning(f"Missing 'page_title' in response")
            result["page_title"] = "Untitled Page"
            
        # Validate components structure if present
        if "components" in result and not isinstance(result["components"], list):
            logger.error(f"'components' is not a list: {type(result['components'])}")
            result["components"] = []
            
        logger.info(f"Successfully analyzed image: {image_path}")
        return result
    except json.decoder.JSONDecodeError as e:
        logger.error(f"JSON decode error in analyze_image: {str(e)}")
        logger.debug(f"Raw response received: {raw[:500]}...")
        # Return a basic valid fallback structure so the application doesn't crash
        return {
            "page_title": f"Image Analysis (Error Recovery)",
            "components": [
                {
                    "type": "text",
                    "properties": {
                        "title": "Analysis Error",
                        "description": f"Error processing image JSON: {str(e)}. Using fallback content."
                    },
                    "layout": "full-width",
                    "markdown_template": "text",
                    "element_type": "page-building"
                }
            ]
        }
    except Exception as e:
        logger.error(f"Unexpected error in analyze_image: {str(e)}")
        # Return a basic valid fallback structure so the application doesn't crash
        return {
            "page_title": f"Image Analysis (Error Recovery)",
            "components": [
                {
                    "type": "text",
                    "properties": {
                        "title": "Analysis Error",
                        "description": f"Error processing image: {str(e)}. Using fallback content."
                    },
                    "layout": "full-width",
                    "markdown_template": "text",
                    "element_type": "page-building"
                }
            ]
        }


def get_block_info(template_type=None):
    """
    Load block knowledge base and return a formatted string of block types and descriptions.
    Optionally filter by template_type.
    
    Args:
        template_type (str, optional): Filter blocks by this template type
        
    Returns:
        str: Formatted string with block types and descriptions
    """
    try:
        kb = load_block_kb()
        if template_type:
            block = kb.get(template_type, {})
            return f"{block.get('type', 'unknown')} - {block.get('description', 'No description')}"
        return "\n\n".join(f"### {b['type']} - {b['description']}" for b in kb.values())
    except Exception as e:
        logger.error(f"Error loading block info: {str(e)}")
        return "Error loading block information"


def load_block_kb(path="aem_block_kb/block_kb.yaml"):
    """
    Load the block knowledge base YAML and return a dict mapping block type to block info.
    
    Args:
        path (str): Path to the block knowledge base YAML file
        
    Returns:
        dict: Mapping of block types to their definitions
    """
    try:
        with open(path, encoding="utf-8") as f:
            kb = yaml.safe_load(f)
        return {b["type"]: b for b in kb["blocks"]}
    except Exception as e:
        logger.error(f"Error loading block knowledge base: {str(e)}")
        return {}


def _slug(txt: str, fallback: str = "page") -> str:
    """
    Convert a string to a safe filename slug (e.g., "Home Page!" -> "home_page").
    
    Args:
        txt (str): Text to convert to a slug
        fallback (str, optional): Default value if txt is empty
        
    Returns:
        str: Slugified string safe for filenames
    """
    if not txt:
        return fallback
        
    txt = unicodedata.normalize("NFKD", txt).encode("ascii", "ignore").decode()
    txt = txt.lower()
    allowed = string.ascii_lowercase + string.digits + "_"
    txt = "".join(c if c in allowed else "_" for c in txt)
    txt = re.sub(r"_+", "_", txt).strip("_")
    return txt or fallback


async def map_ui_to_blocks(page_json, block_kb):
    """
    Deterministically map UI JSON to block definitions, including element_type and kb_html.
    
    Args:
        page_json (dict): Page JSON from image analysis
        block_kb (dict): Block knowledge base
        
    Returns:
        dict: Mapped components with block information
    """
    try:
        mapped = []
        not_found_block = 0
        global_block_number = 0
        block_used = 0
        
        for comp in page_json.get("components", []):
            blk = block_kb.get(comp["markdown_template"])
            if not blk:
                not_found_block += 1
                continue
                
            if blk.get("element", "page-building") == "global":
                global_block_number += 1
            else:
                block_used += 1

            mapped.append({
                "page_title": page_json.get("page_title", ""),
                "type": comp["type"],
                "element_type": comp.get("element_type", blk.get("element", "page-building")),
                "properties": comp.get("properties", {}),
                "layout": comp.get("layout", ""),
                "kb_html": blk["html"],
            })

        return_json = {
            "page_title": page_json.get("page_title", ""),
            "mapped_data": mapped,
            "not_found_block": not_found_block,
            "global_block_number": global_block_number,
            "block_used": block_used
        }
        
        return return_json
    except Exception as e:
        logger.error(f"Error mapping UI to blocks: {str(e)}")
        return {
            "page_title": page_json.get("page_title", "Error Page"),
            "mapped_data": [],
            "not_found_block": 0,
            "global_block_number": 0, 
            "block_used": 0,
            "error": str(e)
        }


def render_markdown(client, model, page_payload):
    """
    Phase 2: Generate HTML content from the mapped JSON and block templates using Gemini.
    
    Args:
        client: Gemini API client
        model (str): Gemini model name
        page_payload (dict): Page payload with component data
        
    Returns:
        str: Generated HTML content
    """
    # Check if Gemini API client is available
    if client is None:
        logger.warning("Gemini API client not initialized. Returning dummy HTML.")
        return "<h1>Dummy HTML Content</h1><p>API key not available</p>"
    
    try:
        prompt = f"""
You are an expert AEM content author.

TASK
----
Create HTML content based on the JSON page payload and HTML templates provided.

STRICT RULES
1. Use ONLY the HTML structure from the templates in `kb_html`, preserving tags, elements, and structure.
2. Replace ALL content in the templates (titles, descriptions, text, image paths) with values from the JSON properties.
3. NEVER copy any placeholder text or content from the template examples.
4. All image src attributes should use the original image paths from the JSON properties.
5. Output ONLY the final HTML content—no explanations or code fences.
6. EXCEPTION: Preserve any metadata tables exactly as they appear in the original template.
7. All HTML id attributes must be unique. Prefix each id with the block type and a running index (e.g., id="columns-1", id="cards-2"), or use a page slug as a prefix. No duplicate ids.

For example, if kb_html contains:
<h2>Example Heading</h2>
<p>Lorem ipsum dolor sit amet</p>

And your component specifies title "Weather Forecast", your output should be:
<h2>Weather Forecast</h2>
<p>Check the latest weather updates for your area.</p>

CRITICAL: DO NOT KEEP ANY EXAMPLE TEXT FROM THE TEMPLATES EXCEPT FOR METADATA TABLES. Replace all other content while maintaining structure with json provided.

page_payload:
{json.dumps(page_payload, indent=2)}
"""
        contents = [
            types.Content(
                role="user",
                parts=[types.Part.from_text(text=prompt)]
            )
        ]
        config = types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_budget=0),
            response_mime_type="text/plain",
        )
        
        result = "".join(
            chunk.text 
            for chunk in client.models.generate_content_stream(
                model=model, contents=contents, config=config
            )
        )
        return result
    except Exception as e:
        logger.error(f"Error rendering markdown: {str(e)}")
        return f"<h1>Error Rendering Content</h1><p>{str(e)}</p>"


def save_html_and_docx(html, fname_base):
    """
    Save HTML to file, convert to DOCX, and enhance DOCX formatting.
    
    Args:
        html (str): HTML content to save
        fname_base (str): Base filename (without extension)
    """
    try:
        html_fname = f"{fname_base}.html"
        docx_fname = f"{fname_base}.docx"
        
        with open(html_fname, "w") as f:
            f.write(html)
        logger.info(f"✓ saved → {html_fname}")
        
        html_to_docx(html_fname, docx_fname)
        logger.info(f"✓ converted to DOCX → {docx_fname}")
        
        doc = Document(docx_fname)
        process_docx_tables(doc)
        doc.save(docx_fname)
        logger.info(f"✓ enhanced DOCX formatting → {docx_fname}")
        
        return True
    except Exception as e:
        logger.error(f"Error saving HTML and DOCX: {str(e)}")
        return False


async def generate_docs(mapped, project_name, global_header_list=[]):
    """
    Generate HTML and DOCX documents from mapped components.
    
    Args:
        mapped (list): List of mapped components
        project_name (str): Name of the project
        global_header_list (list): List of global header types
        
    Returns:
        tuple: (JSON output with stats, list of global items)
    """
    try:
        global_blocks = {}  
        pages = [] 
        page_building = []
        global_items = []
        new_project = False

        if len(global_header_list) > 0:
            global_items = global_header_list

        # Check if project directory exists
        project_path = os.path.join(output_dir, project_name)
        global_path = os.path.join(project_path, "global")
        
        if not os.path.exists(project_path):
            new_project = True
            os.makedirs(project_path, exist_ok=True)
            os.makedirs(global_path, exist_ok=True)
            logger.info(f"Created new project directory: {project_path}")

        # Separate global blocks from page components
        for comp in mapped:
            if comp["element_type"] == "global":
                global_blocks.setdefault(comp["type"], comp)
            else:
                page_building.append(comp)
                
        pages.append({
            "title": mapped[0].get("page_title", ""),
            "components": page_building
        })

        # Render and save global blocks
        for blk_type, comp in global_blocks.items():
            if blk_type not in global_items:
                html = render_markdown(client, model, {"components": [comp]}).strip()
                if html:
                    fname_base = os.path.join(global_path, _slug(blk_type)) 
                    save_html_and_docx(html, fname_base)
                    global_items.append(blk_type)

        # Render and save pages
        for page in pages:
            if not page["components"]:
                continue
                
            html = render_markdown(client, model, {"components": page["components"]}).strip()
            if html:
                fname_base = os.path.join(project_path, _slug(page['title']))
                save_html_and_docx(html, fname_base)

        json_output = {
            "no_of_global_blocks": len(global_blocks),
            "no_of_side_blocks": len(pages)
        }
        return json_output, global_items
    except Exception as e:
        logger.error(f"Error generating docs: {str(e)}")
        return {"error": str(e), "no_of_global_blocks": 0, "no_of_side_blocks": 0}, global_header_list


def create_page_from_components(page_title: str, components: list, output_folder: str) -> str:
    """
    Create HTML and DOCX files from page structure.
    
    Args:
        page_title (str): Title of the page
        components (list): List of components
        output_folder (str): Output folder path
        
    Returns:
        str: Path to the generated HTML file
    """
    try:
        os.makedirs(output_folder, exist_ok=True)
        os.makedirs(f"{output_folder}/global", exist_ok=True)

        # Initialize the document
        doc = Document(title=page_title)

        # Add each component to the document
        for comp in components:
            comp_type = comp.get("type")
            properties = comp.get("properties", {})
            element_type = comp.get("element_type", "page-building")

            if element_type == "global":
                # Handle global components
                doc.add_global_component(
                    comp_type=comp_type,
                    title=properties.get("title", ""),
                    text=properties.get("description", ""),
                    image=properties.get("imageRef", ""),
                )
            else:
                # Handle regular page components
                doc.add_component(
                    comp_type=comp_type,
                    title=properties.get("title", ""),
                    text=properties.get("description", ""),
                    image=properties.get("imageRef", ""),
                )

        # Generate files
        slug = _slug(page_title)
        html_path = f"{output_folder}/boilerplate.html"
        docx_path = f"{output_folder}/boilerplate.docx"

        with open(html_path, "w") as f:
            f.write(doc.generate_html())

        # Convert HTML to DOCX
        html_to_docx(html_path, docx_path)
        process_docx_tables(docx_path)

        return html_path
    except Exception as e:
        logger.error(f"Error creating page from components: {str(e)}")
        return ""


def generate_doc_from_json_components(data, project_name):
    """
    Generate document from analyzed JSON components.
    
    Args:
        data (dict): Analyzed JSON data
        project_name (str): Project name
        
    Returns:
        dict: Result with file paths or error
    """
    try:
        output_folder = f"{output_dir}/{project_name}"
        page_title = data.get("page_title", "Untitled Page")
        components = data.get("components", [])
        
        html_path = create_page_from_components(page_title, components, output_folder)
        
        if html_path:
            try:
                # Attempt to upload to Google Docs
                docx_path = html_path.replace(".html", ".docx")
                gdoc_url = upload_docx_as_gdoc(docx_path)
                return {
                    "html_path": html_path, 
                    "docx_path": docx_path, 
                    "gdoc_url": gdoc_url
                }
            except Exception as e:
                logger.error(f"Error uploading to Google Docs: {str(e)}")
                return {
                    "html_path": html_path, 
                    "docx_path": html_path.replace(".html", ".docx"), 
                    "error": str(e)
                }
        return {"error": "Failed to create document"}
    except Exception as e:
        logger.error(f"Error generating doc from components: {str(e)}")
        return {"error": str(e)}
