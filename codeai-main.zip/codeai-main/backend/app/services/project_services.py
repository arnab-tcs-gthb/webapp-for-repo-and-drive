from app.schemas.project import ProjectCreate
from app.repositories.projects_repo import ProjectsRepo
from fastapi import HTTPException, status
from app.repositories.images_repo import ImagesRepository
from fastapi import HTTPException,status



class ProjectsService:
    def __init__(self, db=None):
        self.db=db

    async def create_project(self, project:ProjectCreate):
        """Create a new project"""

        try:
            # Check for existing project with the same name

            #initialize project repo
            project_repo =  ProjectsRepo(self.db)
            existing_project = project_repo.get_project_by_project_name(project.project_name)
            if existing_project:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Project with name '{project.project_name}' already exists"
                )
            # Validate GitHub URL format if provided
            if project.github_repo_url:
                import re
                github_pattern = r'^https?:\/\/github\.com\/[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.-]+\/?$'
                if not re.match(github_pattern, project.github_repo_url):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid GitHub repository URL format. Expected: https://github.com/owner/repository"
                    )
                
                # Check if another project is already using this GitHub URL
                github_project = project_repo.get_project_by_github_url(project.github_repo_url)
                if github_project:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"GitHub repository URL is already linked to project"
                    )
        
            db_project = project_repo.create_project(project)
            return db_project
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    
    async def read_projects(self, limit:int = None, skip:int = None):
        try:
            project_repo =  ProjectsRepo(self.db)
            all_projects = project_repo.get_all_projects(limit, skip)
            return all_projects
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        

    async def read_project(self, id):
        try:
            project_repo =  ProjectsRepo(self.db)
            project = project_repo.get_project_by_id(id)
            if not project:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Project not found"
                )
            return project
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    async def read_project_images(self, project_id, limit, skip):
        try:
            image_repo = ImagesRepository(self.db)
            all_images = image_repo.get_images_by_project(project_id, limit=limit, skip=skip)
            return all_images
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    async def update_upload_data_project_name(self, project_name, folder_metadata):
        try:
            project_repo = ProjectsRepo(self.db)
            update_data = project_repo.update_project_upload_metadata(project_name, folder_metadata)
            return True
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

        
    


        
    