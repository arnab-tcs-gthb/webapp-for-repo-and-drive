import logging
import json
from sqlalchemy.orm import Session
from app.models.image import Image
from app.crud.image import (
    update_llm_processing
)
class ImageProcessingService:
    def __init__(self, db: Session):
        self.db = db
 
    async def mark_as_processed(
        self,
        image_id: int,
        llm_response: dict,  # This is a dictionary
        success: bool = True
    ) -> bool:
        """Service method for internal use only"""
        # Serialize the dictionary to a JSON string
        json_response = json.dumps(llm_response)
        
        updated = await update_llm_processing(
            db=self.db,
            image_id=image_id,
            processed=success,
            response=json_response  # Pass the serialized JSON string
        )
        return updated is not None