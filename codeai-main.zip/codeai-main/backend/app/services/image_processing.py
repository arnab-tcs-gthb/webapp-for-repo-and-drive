import logging
import json
from sqlalchemy.orm import Session
from app.models.image import Image
from app.repositories.projects_repo import ProjectsRepo
from app.repositories.images_repo import ImagesRepository
from app.services.image_filter_service import process_images_api
from app.schemas.analysis import AnalysisMetadata, ImageProcessingPaths, ImageFilter
from app.crud.image import create_image, get_images_by_project, update_image
from app.schemas.image import ImageUpdate
from app.services.captioning_service_v2 import CaptioningService
from app.schemas.captioning_schemas import ImageCaptionRequest, CaptionSummaryResponse # Import schemas
from app.crud.project import get_project, update_project, get_project
from app.schemas.project import (
    ProjectCreate,
    ProjectUpdate,
    ProjectInDB
)
from app.core.config import settings




from app.crud.image import (
    update_llm_processing
)
class ImageProcessingService:
    def __init__(self, db: Session):
        self.db = db
 
    async def mark_as_processed(
        self,
        image_id: int,
        llm_response: dict,  # This is a dictionary
        success: bool = True
    ) -> bool:
        """Service method for internal use only"""
        # Serialize the dictionary to a JSON string
        json_response = json.dumps(llm_response)
        
        updated = await update_llm_processing(
            db=self.db,
            image_id=image_id,
            processed=success,
            response=json_response  # Pass the serialized JSON string
        )
        return updated is not None
    

    async def image_handling_service(self, project_id):
        """
        FastAPI endpoint to process a screenshot and filter images from a given folder.
        Returns a custom JSON response with a message and list of matched image names.
        """
        
        # Filter the images based on the uploaded image
        try:
            images_repo = ImagesRepository(self.db)
            projectImages = images_repo.get_images_by_project(project_id=project_id)
                
            # If no images found, return early
            if not projectImages:
                print(f"No images found for project {project_id}")
                return {"error": "No images found for this project", "results": []}
                    
        except Exception as project_err:
            print(f"Error retrieving project images: {str(project_err)}")
            return {"error": f"Error retrieving project images: {str(project_err)}", "results": []}

        # Define a coroutine to process each image
        for i, indivProject in enumerate(projectImages):
            if indivProject.matched_images is None:
                try:
                    image_process = await process_images_api(
                        ImageProcessingPaths(
                            screenshot_path=indivProject.filepath,
                            images_folder_path=f"{settings.UPLOAD_DIR_ASSET.as_posix()}/project_{project_id}",
                            filtered_destination_path='static/output',
                        )
                    )
                except Exception as image_filter_err:
                    print(f"Error processing images for {indivProject.filepath}: {str(image_filter_err)}")
                    image_process = []  # Provide empty list if processing fails

                try:
                    updated_image = await update_image(
                        db=self.db,
                        image_id=indivProject.id,
                        image=ImageUpdate(
                            matched_images=image_process,
                        )
                    )
                except Exception as update_err:
                    print(f"Error updating image {indivProject.id}: {str(update_err)}")
        
        # Generate captions for the images in the folder
        # and update the project with the generated captions
        try:
            try:
                project_repo = ProjectsRepo(self.db)
                project_obj = project_repo.get_project_by_id(project_id)
            except Exception as get_project_err:
                print(f"Error retrieving project: {str(get_project_err)}")
                project_obj = None

            if project_obj is not None and getattr(project_obj, "captions", None) is None:
                try:
                    captioning_service =  CaptioningService(self.db)
                    folder_location = f"static/assets/project_{project_id}"
                    caption_data = await captioning_service.create_captions_for_images_in_folder_endpoint(
                        ImageCaptionRequest(folder_location=folder_location),
                        project_id=project_id
                    )
                    try:
                        updated_details = update_project(
                            db=self.db,
                            project_id=ImageFilter.project_id,
                            project=ProjectUpdate(captions=caption_data['captions']),
                        )
                    except Exception as update_project_err:
                        print(f"Error updating project with captions: {str(update_project_err)}")

                    
                    # Validate caption data structure
                    if not isinstance(caption_data, dict) and hasattr(caption_data, '__dict__'):
                        # It's an object with attributes, convert to dict
                        print(f"Converting caption_data object to dictionary")
                        if hasattr(caption_data, 'captions') and caption_data.captions:
                            caption_data = {"captions": caption_data.captions}
                        else:
                            caption_data = {"captions": {}}
                    elif not isinstance(caption_data, dict):
                        print(f"Caption data is not a dict, got {type(caption_data)}")
                        caption_data = {"captions": {}}

                except Exception as caption_err:
                    print(f"Error generating captions: {str(caption_err)}")
                    caption_data = {"captions": {}}  # Provide empty captions if generation fails
        except Exception as outer_err:
            print(f"Unexpected error in caption generation block: {str(outer_err)}")