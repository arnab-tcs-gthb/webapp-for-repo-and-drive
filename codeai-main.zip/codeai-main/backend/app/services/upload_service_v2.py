from fastapi import FastAPI, Form, HTTPException
import requests
import os
import glob
import json
from dotenv import load_dotenv
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

load_dotenv()

app = FastAPI()

# Configuration
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
WORKFLOW_REPO = os.getenv("WORKFLOW_REPO")
TARGET_REPO = os.getenv("TARGET_REPO")
WORKFLOW_FILENAME = os.getenv("WORKFLOW_FILENAME")
GITHUB_OWNER = os.getenv("GITHUB_OWNER")

SERVICE_ACCOUNT_FILE = "credentials.json"
SCOPES = ["https://www.googleapis.com/auth/drive.file"]

PARENT_ID = "1aIi85nOUBQKgATqOeUGkEUSsELh8KfAj"
SHARE_WITH_EMAIL = "helix@adobe.com"

# Define Helix Admin Base URL
HELIX_BASE_URL = "https://admin.hlx.page"

# Dictionary to store folder mappings
folder_storage = {}

# Dictionary to store branch mappings
branch_storage = {}


def create_drive_folder(username: str) -> dict:
    """Creates a Google Drive folder and a 'Global' subfolder, stores the folder_id."""
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    # Create the folder for the user
    folder_metadata = {"name": username, "mimeType": "application/vnd.google-apps.folder", "parents": [PARENT_ID]}
    user_folder = drive_service.files().create(body=folder_metadata, fields="id").execute()
    user_folder_id = user_folder.get("id")

    #create_global_folder
    global_folder_metadata = {"name": "Global", "mimeType": "application/vnd.google-apps.folder", "parents": [user_folder_id]}
    global_folder = drive_service.files().create(body=global_folder_metadata, fields="id").execute()
    global_folder_id = global_folder.get("id")
    print(f"Created Global subfolder with ID: {global_folder_id}")

    # Share both folders with AEM Helix
    share_with_helix(user_folder_id, SHARE_WITH_EMAIL, creds)
    share_with_helix(global_folder_id, SHARE_WITH_EMAIL, creds)

    # Store folder ID for later retrieval
    folder_storage["latest_folder_id"] = user_folder_id

    return {
            "folder_id": user_folder_id,
            "folder_url": f"https://drive.google.com/drive/folders/{user_folder_id}",
            "global_folder_id": global_folder_id,
            "global_folder_url": f"https://drive.google.com/drive/folders/{global_folder_id}",
        }


def share_with_helix(file_id: str, user_email: str, creds) -> None:
    """Shares the created Google Drive folder with AEM Helix"""
    drive_service = build("drive", "v3", credentials=creds)
    permission = {"type": "user", "role": "writer", "emailAddress": user_email}
    drive_service.permissions().create(fileId=file_id, body=permission, sendNotificationEmail=False).execute()
  

def create_drive_subfolder(parent_folder_id: str, folder_name: str, drive_service) -> str:
    """Creates a subfolder inside Google Drive and returns its ID."""
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    folder_metadata = {"name": folder_name, "mimeType": "application/vnd.google-apps.folder", "parents": [parent_folder_id]}
    folder = drive_service.files().create(body=folder_metadata, fields="id").execute()
    share_with_helix(folder.get("id"), SHARE_WITH_EMAIL, creds)
    return folder.get("id")

def process_folder_hierarchy(structure, parent_id, drive_service):
    """Recursively creates folders based on the given hierarchy."""
    folder_map = {}
    
    for folder_name, subfolders in structure.items():
        folder_id = create_drive_subfolder(parent_id, folder_name, drive_service)
        folder_map[folder_name] = {"id": folder_id, "subfolders": {}}
        
        if isinstance(subfolders, dict):  # Ensure it's a dictionary before recursion
            folder_map[folder_name]["subfolders"] = process_folder_hierarchy(subfolders, folder_id, drive_service)
    
    return folder_map

def upload_folder_with_hierarchy(local_path: str, folder_id: str) -> list:
    """Uploads files while maintaining folder hierarchy in Google Drive."""
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    uploaded_files = []
    folder_mapping = {local_path: folder_id}  # Maps local folders to Drive folder IDs

    for root, dirs, files in os.walk(local_path):
        parent_drive_folder_id = folder_mapping.get(root, folder_id)

        # Create subfolders in Drive
        for dir_name in dirs:
            subfolder_path = os.path.join(root, dir_name)
            subfolder_id = create_drive_subfolder(parent_drive_folder_id, dir_name, drive_service)
            folder_mapping[subfolder_path] = subfolder_id

        # Upload files to the correct Drive folder
        for file_name in files:
            file_path = os.path.join(root, file_name)
            media = MediaFileUpload(file_path)
            file_metadata = {"name": file_name, "parents": [parent_drive_folder_id]}

            uploaded_file = drive_service.files().create(body=file_metadata, media_body=media, fields="id, webViewLink").execute()
            
            uploaded_files.append({"file_name": file_name, "file_url": uploaded_file.get("webViewLink")})

    return uploaded_files



def fetch_files_recursively(folder_id: str, drive_service) -> dict:
    """Recursively fetches files and subfolders within a given Google Drive folder."""    
    
    results = drive_service.files().list(q=f"'{folder_id}' in parents", fields="files(id, name, mimeType, webViewLink)").execute()
    files = results.get("files", [])

    folder_contents = []

    for f in files:
        file_info = {"name": f["name"], "type": f["mimeType"], "file_url": f.get("webViewLink")}

        # If the file is a folder, fetch its contents recursively
        if f["mimeType"] == "application/vnd.google-apps.folder":
            file_info["contents"] = fetch_files_recursively(f["id"], drive_service)

        folder_contents.append(file_info)

    return folder_contents


def fetch_github_branch_files(branch_url) -> dict:
    """Fetches all files and folders from the given GitHub branch."""
    
    branch_name = branch_url.split("/")[-1]
    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{TARGET_REPO}/git/trees/{branch_name}?recursive=1"
    
    headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
    response = requests.get(api_url, headers=headers, verify=False)
    
    if response.status_code != 200:
        return {"error": f"Failed to fetch files from branch: {response.text}"}
    
    data = response.json()
    return {"branch_files": [{"path": f["path"], "type": f["type"]} for f in data.get("tree", [])]}



@app.post("/create-folder")
def create_folder(username: str = Form(...), target_repo_name: str = Form(...)):
    """Handles API request to create a Google Drive folder, 'Global' subfolder, and trigger GitHub workflow"""
    folder_info = create_drive_folder(username)

    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{WORKFLOW_REPO}/actions/workflows/{WORKFLOW_FILENAME}/dispatches"
    headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
    data = {"ref": "main", "inputs": {"username": username, "folder_url": folder_info["folder_url"], "target_repo_name": target_repo_name}}

    response = requests.post(api_url, json=data, headers=headers, verify=False)

    if response.status_code == 204:
        repo_url = f"https://github.com/{GITHUB_OWNER}/{username}/tree/main"
        branch_storage["latest_branch_url"] = repo_url
        preview_url = f"https://main--{username}--{GITHUB_OWNER}.aem.page"
        publish_url = f"https://main--{username}--{GITHUB_OWNER}.aem.live"
        return {
        "message": "Project Folder created successfully!",
        "folder_id": folder_info["folder_id"],
        "folder_url": folder_info["folder_url"],
        "repo_url": repo_url,
        "preview_url": preview_url,
        "publish_url": publish_url,
        "github_workflow_status": response.status_code,
    }
    else:
        return f"Error triggering workflow: {response.text}", 500


@app.post("/upload-folder")
def upload_folder(local_path: str = Form(...)):
    """Uploads all files from a local folder into the most recently created Google Drive folder."""
    # Retrieve the most recently created folder ID
    if not folder_storage:
        return {"error": "No folder found. Please create a folder first."}

    folder_id = folder_storage.get("latest_folder_id")
    return {"uploaded_files": upload_folder_with_hierarchy(local_path, folder_id)}


@app.post("/upload-folder-with-dynamic-folder-id")
def upload_folder_with_folder_id(local_path: str = Form(...), folder_id: str = Form(...)):
    """Uploads all files from a local folder into the specified Google Drive folder."""
    return {"uploaded_files": upload_folder_with_hierarchy(local_path, folder_id)}


@app.get("/fetch-files")
# def fetch_files(folder_id: str = Form(...)):
def fetch_files():
    """Fetches all files and folders recursively from the latest created Google Drive folder."""   

    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    folder_id = folder_storage.get("latest_folder_id")
    if not folder_id:
        return {"error": "No folder found. Please create a folder first."} 

    return {"files_in_folder": fetch_files_recursively(folder_id, drive_service)}


@app.get("/fetch-github-files")
# def fetch_github_files(branch_url: str = Form(...)):
def fetch_github_files():
    """Fetches all files and folders from the latest created GitHub branch."""   
    branch_url = branch_storage.get("latest_branch_url")
    if not branch_url:
        return {"error": "No branch found. Please create a folder first to generate a branch URL."} 
    return fetch_github_branch_files(branch_url)


@app.post("/create-folder-hierarchy")
def create_folders(data: dict):
    """Creates folders in Google Drive based on hierarchical JSON input."""

    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    if len(data) != 1:
        raise HTTPException(status_code=400, detail="JSON must start with one main folder name")

    main_folder_name = list(data.keys())[0]
    main_folder_structure = data[main_folder_name]

    main_folder_id = create_drive_subfolder(PARENT_ID, main_folder_name, drive_service)
    created_folders = {main_folder_name: {"id": main_folder_id, "subfolders": {}}}

    if isinstance(main_folder_structure, dict):
        created_folders[main_folder_name]["subfolders"] = process_folder_hierarchy(main_folder_structure, main_folder_id, drive_service)

    return {"status": "success", "folders": created_folders}

@app.post("/upload-file")
async def upload_file(folder_id: str = Form(...), file_path: str = Form(...)):
    """Receives folder ID and local file path, then uploads the file to Google Drive."""
    file_name = os.path.basename(file_path)
    file = await upload_file_to_drive(file_path, folder_id)

    return { "message": "File uploaded successfully!", "file": file, "file_name": file_name }

# GET Method - Fetch Status for Main Branch
# org = teamagro and site = repo_name
@app.get("/status")
def get_main_status(org: str = Form(...), site: str = Form(...)):
    url = f"{HELIX_BASE_URL}/status/{org}/{site}/main/"
    response = requests.get(url)
    return response.json()

# POST Method - Trigger Refresh for Main Branch for particular file path
# org = team-argo and site = repo_name
@app.post("/preview-for-file")
async def post_main_preview(org: str = Form(...), site: str = Form(...), path: str = Form(...)):
    url = f"{HELIX_BASE_URL}/preview/{org}/{site}/main/{path}"
    print("Request URL:", url)
    response = requests.post(url, verify=False)
    return {"status_code": response.status_code, "message": response.json()["preview"]["url"]}

# POST Method - Trigger Refresh for Main Branch
# org = teamagro and site = repo_name
@app.post("/preview-for-repo")
async def refresh_main_branch(org: str = Form(...), site: str = Form(...)):
    url = f"{HELIX_BASE_URL}/preview/{org}/{site}/main/*"
    response = requests.post(url, verify=False)
    return {"status_code": response.status_code, "message": response.text}

# POST Method - Trigger Refresh for Main Branch for particular file path
# org = teamagro and site = repo_name
@app.post("/publish-for-file")
async def publish_main_branch_for_file(org: str = Form(...), site: str = Form(...), path: str = Form(...)):
    url = f"{HELIX_BASE_URL}/live/{org}/{site}/main/{path}"
    response = requests.post(url, verify=False)
    return {"status_code": response.status_code, "message": response.json()["live"]["url"]}

# POST Method - Trigger Refresh for Main Branch
# org = teamagro and site = repo_name
@app.post("/publish-for-repo")
async def publish_main_branch(org: str = Form(...), site: str = Form(...)):
    url = f"{HELIX_BASE_URL}/live/{org}/{site}/main/*"
    response = requests.post(url, verify=False)
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=response.text)
    return {"status_code": response.status_code, "message": response.text}


async def preview_for_file(org, site, path):
    url = f"{HELIX_BASE_URL}/preview/{org}/{site}/main/{path}"
    print("Request URL:", url)
    response = requests.post(url, verify=False)
    try:
        response.raise_for_status()
        return {"status_code": response.status_code, "message": response.json()["preview"]["url"]}
    except Exception as e:
        raise HTTPException(status_code=response.status_code, detail=f"Preview error: {str(e)}")


async def publish_for_file(org, site, path):
    url = f"{HELIX_BASE_URL}/live/{org}/{site}/main/{path}"
    response = requests.post(url, verify=False)
    try:
        response.raise_for_status()
        return {"status_code": response.status_code, "message": response.json()["live"]["url"]}
    except Exception as e:
        raise HTTPException(status_code=response.status_code, detail=f"Publish error: {str(e)}")


async def create_folder(username:str, target_repo_name:str="aem-boilerplate"):
    """Handles API request to create a Google Drive folder, 'Global' subfolder, and trigger GitHub workflow"""
    try:
        folder_info = create_drive_folder(username)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating Google Drive folder: {str(e)}")
    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{WORKFLOW_REPO}/actions/workflows/{WORKFLOW_FILENAME}/dispatches"
    headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
    data = {"ref": "main", "inputs": {"project_name": username, "folder_url": folder_info["folder_url"], "target_repo_name": target_repo_name}}
    print("creating folder herrer")
    response = requests.post(api_url, json=data, headers=headers, verify=False)
    if response.status_code == 204:
        repo_url = f"https://github.com/{GITHUB_OWNER}/{username}/tree/main"
        branch_storage["latest_branch_url"] = repo_url
        preview_url = f"https://main--{username}--{GITHUB_OWNER}.aem.page"
        publish_url = f"https://main--{username}--{GITHUB_OWNER}.aem.live"
        output_json = {
        "message": "Project Folder created successfully!",
        "folder_id": folder_info["folder_id"],
        "folder_url": folder_info["folder_url"],
        "repo_url": repo_url,
        "preview_url": preview_url,
        "publish_url": publish_url,
        "github_workflow_status": response.status_code,
        "global_folder_id": folder_info["global_folder_id"],
        "global_folder_url": folder_info["global_folder_url"],
        }
        print("create_folder output",output_json)
        return output_json
    else:
        raise HTTPException(status_code=response.status_code, detail=f"GitHub workflow trigger failed: {response.text}")


def get_target_mime(local_path: str):
    if local_path.endswith('.docx'):
        return "application/vnd.google-apps.document"
    elif local_path.endswith('.xlsx'):
        return "application/vnd.google-apps.spreadsheet"
    elif local_path.endswith('.pptx'):
        return "application/vnd.google-apps.presentation"
    else: 
        return None

async def upload_file_to_drive(local_path: str, folder_id: str) -> dict:
    """Uploads a file from local system to Google Drive and converts if necessary"""
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    if not os.path.exists(local_path):
        return {"error": "File not found"}

    file_name = os.path.basename(local_path)
    target_mime = get_target_mime(local_path)
    media = MediaFileUpload(local_path)
    file_metadata = {"name": file_name, "mimeType": target_mime, "parents": [folder_id]}
    # Search for existing file with the same name in the folder
    query = f"'{folder_id}' in parents and name='{file_name}' and trashed=false"
    results = drive_service.files().list(q=query, fields="files(id)").execute()
    files = results.get('files', [])

    uploaded_file = drive_service.files().create(body=file_metadata, media_body=media, fields="id, webViewLink").execute()

    if files:
        # File exists, update it
        file_id = files[0]['id']
        updated_file = drive_service.files().update(
            fileId=file_id,
            media_body=media,
            fields="id, webViewLink"
        ).execute()
        print(f"Updated file ID: {updated_file['id']}")
    else:
        # File doesn't exist, create it
        uploaded_file = drive_service.files().create(body=file_metadata, media_body=media, fields="id, webViewLink").execute()

    # Make file editable by anyone
    drive_service.permissions().create(
        fileId = uploaded_file["id"],
        body = {
            "type": "anyone",
            "role": "reader"
        }
    ).execute()

    # Convert Microsoft files to Google-native formats
    # if file_name.endswith(".docx"):
    #     converted_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.document"}).execute()
    # elif file_name.endswith(".xlsx"):
    #     converted_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.spreadsheet"}).execute()
    # elif file_name.endswith(".pptx"):
    #     converted_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.presentation"}).execute()
    # else:
    #     converted_file = uploaded_file

    return {
        "file_id": uploaded_file["id"],
        "file_url": uploaded_file["webViewLink"],
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)