from app.repositories.page_uat_repo import PageUATRepository
from app.repositories.projects_repo import ProjectsRepo
from fastapi import HTTPException
from app.services.page_service import PageService
class PageUATService:
    def __init__(self, db=None):
        self.db = db


    async def get_uat_data_service(self, **kwargs):
        try:
            all_page_data = {}
            uat_repo = PageUATRepository(self.db)
            page_service =  PageService(self.db)
            project_repo = ProjectsRepo(self.db)
            project_data = project_repo.get_project_by_id(project_id=kwargs["project_id"])
            pages_data = await page_service.get_pages_by_project_id(project_id=kwargs["project_id"])
            print(project_data)
            all_page_data["project_name"] = project_data.project_name if project_data else None
            all_page_data["project_id"] = project_data.id if project_data else None
            all_page_data["preview_url"] = project_data.drive_info["preview_url"] if project_data else None
            all_page_data["pages"] = []

            for data in pages_data:
                kwargs['page_id'] = data.id
                page_uat_data=  uat_repo.get_data_by_id(**kwargs)
                tickets = []
                for uat_data in page_uat_data:
                    tickets.append({
                        "jira_url":uat_data.jira if uat_data else None,
                        "jira_id":uat_data.jira.split("/")[-1] if uat_data else None,
                    })
                all_page_data[data.id] = {
                    "page_name":data.page_name,
                    "preview_url":data.preview_url,
                    "tickets":tickets
                }
                page_uat_data = uat_repo.get_data_by_id(**kwargs)
                tickets = []
                for uat_data in page_uat_data:
                    tickets.append({
                        "jira_url":uat_data.jira if uat_data else None,
                        "jira_id":uat_data.jira.split("/")[-1] if uat_data else None,
                    })
                all_page_data["pages"].append({
                    "page_name":data.page_name if data else None,
                    "page_id": data.id if data else None,
                    "preview_url":data.preview_url if data else None,
                    "tickets":tickets
                }) 

            return all_page_data
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))