import logging
from sqlalchemy.orm import Session
from app.models.image import Image
from app.crud.image import (
    get_image,
    update_image_llm_data,
    get_images_by_project
)

# Setup logging
logger = logging.getLogger(__name__)

class ImageService:
    def __init__(self, db: Session):
        self.db = db

    async def update_llm_status(
        self,
        image_id: int,
        llm_response: dict,
        llm_processed: bool
    ) -> bool:
        """Update image with LLM processing status"""
        try:
            updated = await update_image_llm_data(
            db=self.db,         # Pass the database session
            image_id=image_id,  # image ID
            llm_response=llm_response,  # LLM response payload
            llm_processed=llm_processed  # processed flag
        )
            return updated
        except Exception as e:
            logger.error(f"Error updating LLM status for image {image_id}: {e}")
            return False
        

    async def get_unprocessed_images(self, project_id: int) -> list[Image]:
        """For LLM service to fetch images needing processing"""
        return get_images_by_project(
            db=self.db,
            project_id=project_id
        ).filter(Image.llm_processed == False).all()
        
        
# async def update_llm_status(
#     image_id: int,
#     llm_response: str,
#     is_success: bool = True
# ):
#     db = SessionLocal()
#     try:
#         image_service = ImageService(db)
#         success = await image_service.update_llm_status(
#             image_id=image_id,
#             llm_response=llm_response,
#             is_success=is_success
#         )
#         if not success:
#             raise HTTPException(status_code=404, detail="Image not found")
#         return {"status": "updated"}
#     finally:
#         db.close()