from app.repositories.images_repo import ImagesRepository
from app.repositories.projects_repo import ProjectsRepo
from app.services.image_processing import ImageProcessingService
from app.helper.gemini_openai_helper import call_gemini_openai
import json
import logging
import re
import os
from app.helper.doc_format import Document, process_docx_tables
from app.helper.google_docs import upload_docx_as_gdoc
from app.helper.md_to_docx import html_to_docx
from app.services.generate_docs_service import GenerateDocsService
from app.services.mapping_service import MappingService
from google.genai import types
from app.repositories.pages_repo import PagesRepo
from app.services.logging_service import log_event
from app.helper.gemini_openai_helper import gemini_generate_content_stream
from app.helper.log_data import entry_logs
import mimetypes



image_dir = "images"
output_dir = "output"

logger = logging.getLogger(__name__)


try:
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    model = "gemini-2.5-pro-preview-05-06"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None


logger = logging.getLogger(__name__)
class AnalyzeService:
    def __init__(self, db=None):
        self.db = db

    async def analyze_image_service(self, project_id, page_id=None, analyze_flag=False):
        try:
            if page_id == 0:
                page_id = None
            image_repo = ImagesRepository(db=self.db)
            if page_id is None:
                projectImages = image_repo.get_images_by_project(project_id=project_id)
            else:
                projectImages = image_repo.get_images_by_page(page_id=page_id)
            if not projectImages:
                logger.warning(f"No images found for id {project_id}")
                return {"error": "No images found for this project", "results": []}
            try:
                page_repo = PagesRepo(self.db)
                logger.info(f"Starting parallel processing of {len(projectImages)} images...")
                image_results = []
                for i, indivProject in enumerate(projectImages):
                    try:
                        page_repo.update_status(page_id=indivProject.page_id, status="in-progress")
                        page_repo.update_status(page_id=indivProject.page_id, status="in-progress", action="analysis")
                        logger.info(f"Processing image {i+1}/{len(projectImages)}: {indivProject.filepath}")
                        result, token_data = await self.process_image(indivProject, project_id, analyze_flag)
                        # --- LOGGING ---

                        await entry_logs(self.db, output_data=result, project_id=project_id, page_id=indivProject.page_id,token_data=token_data,endpoint="analyze")

                        if not isinstance(result, dict):
                            logger.warning(f"Image {indivProject.filepath} returned non-dict result: {type(result)}")
                        elif "components" not in result:
                            logger.warning(f"Image {indivProject.filepath} missing 'components' key in result. Result keys: {list(result.keys())}")
                        page_repo.update_analysis_data(indivProject.page_id, result)
                        page_repo.update_status(page_id=indivProject.page_id, status="completed", action="analysis")
                        image_results.append(result)
                        logger.info(f"Successfully processed image {i+1}: {indivProject.filepath}")
                    except Exception as individual_err:
                        logger.error(f"Error processing individual image {indivProject.filepath}: {str(individual_err)}")
                        raise RuntimeError(f"Error processing individual image {indivProject.filepath}: {str(individual_err)}")
                logger.info(f"Completed processing {len(image_results)} images")
                return self.analyze_image_resp(image_results, no_of_images=len(projectImages))
            except Exception as gather_err:
                logger.error(f"Error during parallel image processing: {str(gather_err)}")
                raise RuntimeError(f"Error during parallel image processing: {str(gather_err)}")
        except Exception as e:
            logger.error(f"Unhandled exception in analyze endpoint: {str(e)}")
            try:
                page_repo.update_status(page_id=getattr(indivProject, 'page_id', None), status="error", action="analysis")
            except Exception as status_err:
                logger.error(f"Error updating page status: {str(status_err)}")
                raise RuntimeError(f"Error updating page status: {str(status_err)}")
        finally:
            try:
                self.db.close()
            except Exception as close_err:
                logger.error(f"Error closing DB session: {str(close_err)}")

    def _extract_json(self, raw: str) -> str:
        try:
            if not raw:
                logger.warning("Empty raw text provided to _extract_json")
                return '{}'
            raw = re.sub(r"```(?:json)?\s*", "", raw).replace("```", "").strip()
            start, end = raw.find("{"), raw.rfind("}")
            if start != -1 and end != -1 and end > start:
                json_str = raw[start: end + 1]
                try:
                    json.loads(json_str)
                    return json_str
                except json.JSONDecodeError:
                    logger.debug("First JSON extraction attempt failed, trying alternatives")
            json_matches = re.findall(r'\{(?:[^{}]|"(?:\\.|[^"\\])*")*\}', raw)
            for match in json_matches:
                try:
                    json.loads(match)
                    return match
                except json.JSONDecodeError:
                    continue
            cleaned = raw.strip()
            if not (cleaned.startswith('{') and cleaned.endswith('}')):
                cleaned = '{' + cleaned + '}'
            cleaned = re.sub(r"(?<!\\)'([^']*?)(?<!\\)'", r'"\1"', cleaned)
            try:
                json.loads(cleaned)
                return cleaned
            except json.JSONDecodeError:
                logger.warning("All JSON extraction methods failed, returning empty object")
                return '{}'
        except Exception as e:
            logger.error(f"Error in _extract_json: {str(e)}")
            raise e

    def analyze_image(self, image_path: str, captions: dict = None) -> dict:
        try:
            page_name_from_image_path = image_path.split("/")[-1]
            try:
                with open(image_path, "rb") as f:
                    img_bytes = f.read()
                logger.debug(f"Successfully read image: {image_path}")
            except Exception as e:
                logger.error(f"Error reading image file {image_path}: {str(e)}")
                raise RuntimeError(f"Could not read image file: {str(e)}")
            try:
                mapping_service = MappingService(self.db)
                block_info = mapping_service.get_block_info()
                if hasattr(captions, '__dict__'):
                    captions_dict = {}
                    if hasattr(captions, 'captions'):
                        if isinstance(captions.captions, dict):
                            captions_dict = {'captions': captions.captions}
                        else:
                            captions_dict = {'captions': {}}
                    elif hasattr(captions, 'dict') and callable(getattr(captions, 'dict')):
                        captions_dict = captions.dict()
                    elif hasattr(captions, 'model_dump') and callable(getattr(captions, 'model_dump')):
                        captions_dict = captions.model_dump()
                elif isinstance(captions, dict):
                    captions_dict = captions
                else:
                    logger.warning(f"Could not convert captions to dict, using empty dict. Type: {type(captions)}")
                    captions_dict = {'captions': {}}
                try:
                    captions_str = json.dumps(captions_dict, indent=2, default=str)
                except Exception as json_err:
                    logger.error(f"Error serializing captions to JSON: {str(json_err)}")
                    captions_str = "{}"
            except Exception as e:
                logger.error(f"Error preparing prompt data: {str(e)}")
                raise RuntimeError(f"Error preparing prompt data: {str(e)}")
            

               
            prompt = a= f"""
            **You are a senior AEM (Adobe Experience Manager) content architect. Your expertise is in meticulously deconstructing webpage images into their fundamental UI components and mapping them to a predefined set of AEM block types with extreme precision.**

            **Primary Directive:** Your mission is to analyze the provided webpage image and produce a single, clean, parseable JSON object that details the page's structure and components. You must strictly adhere to the output format.

            **Step-by-Step Instructions:**

            1.  **Holistic Image Analysis:** Begin by performing a full-screen analysis of the image to identify every distinct UI component. For each component, classify its `element_type` as either **"global"** (e.g., header, footer, persistent navigation) or **"page-building"** (e.g., hero, carousel, card grid).

            2.  **Component-by-Component Processing:** For each component you identify, you MUST perform the following sequence of operations:
                * **A. AEM Block Classification:** Compare the component's visual characteristics against the descriptions in `{block_info}`. You must assign the AEM block type that is the most direct and accurate match.
                * **B. Property Extraction:** Scrutinize the component in the image and extract all text or image data that directly corresponds to the properties of the assigned AEM block (e.g., `title`, `description`). Use the `{captions_str}` to find the correct `imageRef`. If a property's value is not visually present, you MUST omit its key from the `properties` object.
                * **C. Layout Description:** Briefly and accurately describe the component's layout structure (e.g., "3-column grid", "Full-width banner with centered text").
                * **D. Confidence Score Assignment:** You MUST assign a `confidence_score` as an **integer percentage** (from 0 to 100). Calculate this score by strictly following the rubric below. Your internal reasoning must explicitly justify this score by referencing the rubric.

            **Confidence Score Rubric (Percentage-Based):**
            * **100 (Perfect Match):** The component is a textbook example of the AEM block, matching its structure, content, and purpose perfectly.
            * **85-95 (High Confidence):** A very strong match with only minor stylistic deviations or a missing non-critical property.
            * **70-80 (Medium Confidence):** The component is a reasonable match, but has notable differences in layout or is missing one or more key properties.
            * **50-65 (Low Confidence):** The component is ambiguous and could plausibly map to multiple block types. The classification is a best-effort attempt.
            * **< 50 (Very Low Confidence):** The component does not clearly map to any block type other than a generic container like `content-fragment`.

            ---
            **Available AEM Block Types:**
            `{block_info}`

            **Image Asset Captions:**
            `{captions_str}`
            ---

            **Final Output Requirements:**
            Your entire response MUST be a single, raw JSON object. Do NOT include any explanatory text, notes, or markdown formatting like ` ```json ` before or after the JSON.

            **JSON Structure:**
            ```json
            {{
            "page_title": "A concise and descriptive title for the page",
            "original_file_name": "{page_name_from_image_path}",
            "components": [ // <-- NESTED COMPONENTS
                {{
                "type": "component_type",
                "element_type": "page-building or global",
                "properties": {{
                    "title": "Component title, if present",
                    "description": "Descriptive text, if present",
                    "imageRef": "image reference path from provided captions, if present"
                }},
                "layout": "Specific layout information, e.g., '3-column grid'",
                "markdown_template": "block_type",
                "confidence_score": 95
                    "justification": "Component is highly custom and does not map well to any specific block other than a generic one." // <-- EXPLICIT JUSTIFICATION

                }}
            ],
            "confidence_score_full_page": "The simple numerical average of all component confidence scores, rounded to the nearest integer"
            }} """
            try:
                mime_type, _ = mimetypes.guess_type(image_path)
                raw, token_data = gemini_generate_content_stream(prompt,img_bytes=img_bytes, mime_type=mime_type)
            except Exception as e:
                logger.error(f"Error calling Gemini API: {str(e)}")
                raise RuntimeError(f"Error calling Gemini API: {str(e)}")
            try:
                payload = self._extract_json(raw)
                result = json.loads(payload)
                logger.debug(f"Successfully parsed JSON to dictionary with {len(result)} keys")
                # Attach token data if available
                # Attach token data to result for logging
                logger.info(f"Token usage - Input: {result.get('llm_input_tokens', 0)}, Output: {result.get('llm_output_tokens', 0)}, Total: {result.get('llm_total_tokens', 0)}")
                if not isinstance(result, dict):
                    logger.error(f"Invalid response format: Expected dict, got {type(result)}")
                    raise ValueError(f"Invalid response format: Expected dict, got {type(result)}")
                if "components" not in result:
                    logger.error(f"Missing 'components' in response. Keys: {list(result.keys())}")
                    result["components"] = []
                    logger.warning(f"Auto-fixed missing 'components' key in response")
                if "page_title" not in result:
                    logger.warning(f"Missing 'page_title' in response")
                    result["page_title"] = "Untitled Page"
                if "components" in result and not isinstance(result["components"], list):
                    logger.error(f"'components' is not a list: {type(result['components'])}")
                    result["components"] = []
                logger.info(f"Successfully analyzed image: {image_path}")
                return result, token_data
            except json.decoder.JSONDecodeError as e:
                logger.error(f"JSON decode error in analyze_image: {str(e)}")
                logger.debug(f"Raw response received: {raw[:500]}...")
                raise RuntimeError(f"Error processing image JSON: {str(e)}")
            except Exception as e:
                logger.error(f"Unexpected error in analyze_image: {str(e)}")
                raise RuntimeError(f"Error processing image: {str(e)}")
        except Exception as e:
            logger.error(f"Error in analyze_image: {str(e)}")
            raise RuntimeError(f"Error in analyze_image: {str(e)}")

    def analyze_image_resp(self, process_data, no_of_images):
        try:
            image_count = 0
            link_count = 0
            block_count = 0
            form_count = 0
            video_count = 0
            processingData = {}
            processingData['llm_response'] = process_data
            processingData['pages'] = len(process_data)
            for page in process_data:
                if not isinstance(page, dict):
                    logger.warning(f"Skipping non-dict page: {type(page)}")
                    continue
                if "components" not in page:
                    logger.warning(f"Skipping page without 'components' key. Keys: {list(page.keys())}")
                    continue
                if not isinstance(page["components"], list):
                    logger.warning(f"'components' is not a list: {type(page['components'])}")
                    continue
                for component in page["components"]:
                    if not isinstance(component, dict):
                        logger.warning(f"Skipping non-dict component: {type(component)}")
                        continue
                    if component.get("type"):
                        block_count += 1
                    if "properties" in component:
                        if "imageRef" in component["properties"] and component["properties"]["imageRef"]:
                            image_count += 1
                        if "items" in component["properties"]:
                            for item in component["properties"]["items"]:
                                if "imageRef" in item and item["imageRef"]:
                                    image_count += 1
                    if "properties" in component:
                        if "navigation_links" in component["properties"]:
                            link_count += len(component["properties"]["navigation_links"])
                        if "utility_icons" in component["properties"]:
                            link_count += len(component["properties"]["utility_icons"])
                        if "items" in component["properties"]:
                            for item in component["properties"]["items"]:
                                if "link_url" in item or "link" in item:
                                    link_count += 1
                        if "cta_button" in component["properties"] and "url" in component["properties"]["cta_button"]:
                            link_count += 1
                    if "properties" in component:
                        if "forms" in component["properties"]:
                            form_count += len(component["properties"]["forms"])
                    if "properties" in component:
                        if "videos" in component["properties"]:
                            video_count += len(component["properties"]["videos"])
            processingData['blocks'] = block_count
            processingData['images'] = image_count
            processingData['links'] = link_count
            processingData['forms'] = form_count
            processingData['videos'] = video_count
            progress_percentage = (processingData['pages'] / no_of_images) * 100 if no_of_images > 0 else 0
            processingData['progress'] = f"{processingData['pages']}/{no_of_images} ({progress_percentage:.2f}%)"
            return processingData
        except Exception as e:
            logger.error(f"Error in analyze_image_resp: {str(e)}")
            raise RuntimeError(f"Error Analyze Image response: {str(e)}")

    def create_page_from_components(self, page_title: str, components: list, output_folder: str) -> str:
        try:
            os.makedirs(output_folder, exist_ok=True)
            os.makedirs(f"{output_folder}/global", exist_ok=True)
            doc = Document(title=page_title)
            for comp in components:
                comp_type = comp.get("type")
                properties = comp.get("properties", {})
                element_type = comp.get("element_type", "page-building")
                if element_type == "global":
                    doc.add_global_component(
                        comp_type=comp_type,
                        title=properties.get("title", ""),
                        text=properties.get("description", ""),
                        image=properties.get("imageRef", ""),
                    )
                else:
                    doc.add_component(
                        comp_type=comp_type,
                        title=properties.get("title", ""),
                        text=properties.get("description", ""),
                        image=properties.get("imageRef", ""),
                    )
            generate_docs_service = GenerateDocsService(self.db)
            slug = generate_docs_service._slug(page_title)
            html_path = f"{output_folder}/boilerplate.html"
            docx_path = f"{output_folder}/boilerplate.docx"
            with open(html_path, "w") as f:
                f.write(doc.generate_html())
            html_to_docx(html_path, docx_path)
            process_docx_tables(docx_path)
            return html_path
        except Exception as e:
            logger.error(f"Error creating page from components: {str(e)}")
            raise RuntimeError(f"Error creating page from components: {str(e)}")

    def generate_doc_from_json_components(self, data, project_name):
        try:
            output_folder = f"{output_dir}/{project_name}"
            page_title = data.get("page_title", "Untitled Page")
            components = data.get("components", [])
            html_path = self.create_page_from_components(page_title, components, output_folder)
            if html_path:
                try:
                    docx_path = html_path.replace(".html", ".docx")
                    gdoc_url = upload_docx_as_gdoc(docx_path)
                    return {
                        "html_path": html_path,
                        "docx_path": docx_path,
                        "gdoc_url": gdoc_url
                    }
                except Exception as e:
                    logger.error(f"Error uploading to Google Docs: {str(e)}")
                    raise RuntimeError(f"Error uploading to Google Docs: {str(e)}")
            return {"error": "Failed to create document"}
        except Exception as e:
            logger.error(f"Error generating doc from components: {str(e)}")
            raise RuntimeError(f"Error generating doc from components: {str(e)}")
            

    async def process_image(self, indivProject, project_id, analyze_flag):
        try:
            print(indivProject.llm_response)
            print(indivProject.llm_processed)
            print(analyze_flag)
            if (indivProject.llm_response is not None) and (indivProject.llm_processed is True) and (analyze_flag is False):
                try:
                    image_data = indivProject.llm_response
                    image_data = json.loads(image_data)
                    token_data = None  # No token data available for cached results
                except json.decoder.JSONDecodeError as json_err:
                    logger.error(f"Error parsing stored JSON for image {indivProject.filepath}: {str(json_err)}")
                    # Fall back to re-analyzing the image
                    projects_repo = ProjectsRepo(self.db)
                    project_details = projects_repo.get_project_by_id(project_id=project_id)
                    analyze_args = {"image_path": indivProject.filepath}
                    if indivProject.matched_images is not None:
                        analyze_args["matched_images"] = indivProject.matched_images
                    if project_details.captions is not None:
                        analyze_args["captions"] = project_details.captions
                    logger.info(f"Re-analyzing image due to JSON error: {indivProject.filepath}")
                    image_data, token_data = self.analyze_image(**analyze_args)
            else:
                projects_repo = ProjectsRepo(self.db)
                project_details = projects_repo.get_project_by_id(project_id=project_id)
                analyze_args = {"image_path": indivProject.filepath}
                if indivProject.matched_images is not None:
                    analyze_args["matched_images"] = indivProject.matched_images
                if project_details.captions is not None:
                    analyze_args["captions"] = project_details.captions
                logger.info(f"Analyzing image: {indivProject.filepath}")
                image_data, token_data = self.analyze_image(**analyze_args)
            image_id = indivProject.id
            service = ImageProcessingService(self.db)
            try:
                await service.mark_as_processed(
                    image_id=image_id,
                    llm_response=image_data,
                    success=True
                )
            except Exception as db_err:
                logger.error(f"Error saving analysis results to database: {str(db_err)}")
            return image_data, token_data
        except Exception as e:
            logger.error(f"Error processing image {indivProject.filepath}: {str(e)}")
            raise RuntimeError(f"Error processing image {indivProject.filepath}: {str(e)}")

