from app.repositories.projects_repo import ProjectsRepo
from app.services.mapping_service import MappingService
import json
import os
import logging

import re
import unicodedata
import string

from google.genai import types

from app.helper.md_to_docx import html_to_docx
from app.helper.doc_format import Document, process_docx_tables
from app.helper.google_docs import upload_docx_as_gdoc
from app.services.upload_service_v2 import publish_for_file, preview_for_file, create_folder, upload_file_to_drive
from app.repositories.images_repo import ImagesRepository
from app.repositories.pages_repo import PagesRepo



logger = logging.getLogger(__name__)

try:
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    model = "gemini-2.5-pro-preview-05-06"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None


image_dir = "images"
output_dir = "output"
class GenerateDocsService:
    def __init__(self, db=None):
        self.db=db


    def render_markdown(self, client, model, page_payload):
        """
        Phase 2: Generate HTML content from the mapped JSON and block templates using Gemini.
        
        Args:
            client: Gemini API client
            model (str): Gemini model name
            page_payload (dict): Page payload with component data
            
        Returns:
            str: Generated HTML content
        """
        # Check if Gemini API client is available
        if client is None:
            logger.warning("Gemini API client not initialized. Returning dummy HTML.")
            return "<h1>Dummy HTML Content</h1><p>API key not available</p>"
        
        try:
            prompt = f"""
    You are an expert AEM content author.

    TASK
    ----
    Create HTML content based on the JSON page payload and HTML templates provided.

    STRICT RULES
    1. Use ONLY the HTML structure from the templates in `kb_html`, preserving tags, elements, and structure.
    2. Replace ALL content in the templates (titles, descriptions, text, image paths) with values from the JSON properties.
    3. NEVER copy any placeholder text or content from the template examples.
    4. All image src attributes should use the original image paths from the JSON properties.
    5. Output ONLY the final HTML content—no explanations or code fences.
    6. EXCEPTION: Preserve any metadata tables exactly as they appear in the original template.
    7. All HTML id attributes must be unique. Prefix each id with the block type and a running index (e.g., id="columns-1", id="cards-2"), or use a page slug as a prefix. No duplicate ids.

    For example, if kb_html contains:
    <h2>Example Heading</h2>
    <p>Lorem ipsum dolor sit amet</p>

    And your component specifies title "Weather Forecast", your output should be:
    <h2>Weather Forecast</h2>
    <p>Check the latest weather updates for your area.</p>

    CRITICAL: DO NOT KEEP ANY EXAMPLE TEXT FROM THE TEMPLATES EXCEPT FOR METADATA TABLES. Replace all other content while maintaining structure with json provided.

    page_payload:
    {json.dumps(page_payload, indent=2)}
    """
            contents = [
                types.Content(
                    role="user",
                    parts=[types.Part.from_text(text=prompt)]
                )
            ]
            config = types.GenerateContentConfig(
                thinking_config=types.ThinkingConfig(thinking_budget=0),
                response_mime_type="text/plain",
            )
            
            result = "".join(
                chunk.text 
                for chunk in client.models.generate_content_stream(
                    model=model, contents=contents, config=config
                )
            )
            return result
        except Exception as e:
            logger.error(f"Error rendering markdown: {str(e)}")
            return f"<h1>Error Rendering Content</h1><p>{str(e)}</p>"

    async def create_mapping_block(self,analyze_response):
        mapping_service = MappingService(self.db)
        analyze_data = json.loads(analyze_response)
        block_data = await mapping_service.map_ui_to_blocks(page_json=analyze_data, block_kb=mapping_service.load_block_kb())
        return block_data

    async def generate_doc_data_by_llm(self, map_data, project_name):
        data_final_page_wise,global_header_list = await self.generate_docs(mapped=map_data["mapped_data"], project_name=project_name,global_header_list=global_header_list)

    async def generate_docs(self, mapped, project_name, global_header_list=[]):
        """
        Generate HTML and DOCX documents from mapped components.
        
        Args:
            mapped (list): List of mapped components
            project_name (str): Name of the project
            global_header_list (list): List of global header types
            
        Returns:
            tuple: (JSON output with stats, list of global items)
        """
        try:
            global_blocks = {}  
            pages = [] 
            page_building = []
            global_items = []
            new_project = False

            if len(global_header_list) > 0:
                global_items = global_header_list

            # Check if project directory exists
            project_path = os.path.join(output_dir, project_name)
            global_path = os.path.join(project_path, "global")
            
            if not os.path.exists(project_path):
                new_project = True
                os.makedirs(project_path, exist_ok=True)
                os.makedirs(global_path, exist_ok=True)
                logger.info(f"Created new project directory: {project_path}")

            # Separate global blocks from page components
            for comp in mapped:
                if comp["element_type"] == "global":
                    global_blocks.setdefault(comp["type"], comp)
                else:
                    page_building.append(comp)
                    
            pages.append({
                "title": mapped[0].get("page_title", ""),
                "components": page_building
            })

            # Render and save global blocks
            for blk_type, comp in global_blocks.items():
                if blk_type not in global_items:
                    html = self.render_markdown(client, model, {"components": [comp]}).strip()
                    if html:
                        fname_base = os.path.join(global_path, self._slug(blk_type)) 
                        self.save_html_and_docx(html, fname_base)
                        global_items.append(blk_type)

            # Render and save pages
            for page in pages:
                if not page["components"]:
                    continue
                    
                html = self.render_markdown(client, model, {"components": page["components"]}).strip()
                if html:
                    fname_base = os.path.join(project_path, self._slug(page['title']))
                    self.save_html_and_docx(html, fname_base)

            json_output = {
                "no_of_global_blocks": len(global_blocks),
                "no_of_side_blocks": len(pages)
            }
            return json_output, global_items
        except Exception as e:
            logger.error(f"Error generating docs: {str(e)}")
            return {"error": str(e), "no_of_global_blocks": 0, "no_of_side_blocks": 0}, global_header_list

    async def generate_docs_service(self, project_id, page_id=None):
        #return google docs link
        try:
            #pass mapping api response in this mapped_data list to mapped_data
            #get data from database by project_id
            mapped_data = []
            project_repo=  ProjectsRepo(self.db)
            image_repo = ImagesRepository(self.db)
            pages_repo = PagesRepo(self.db)
            get_project_name = project_repo.get_project_by_id(project_id)
            project_name = get_project_name.project_name
            images = image_repo.get_images_by_project(project_id=project_id)
            mapping_service = MappingService(self.db)
            for image in images:
                analyze_data = json.loads(image.llm_response)
                block_data = await mapping_service.map_ui_to_blocks(page_json=analyze_data, block_kb=mapping_service.load_block_kb())
                upate_mapping = pages_repo.update_mapping_data(image.page_id, block_data)
                mapped_data.append(block_data)  

            google_docs_folder_created = False
            folder_id = ""
            page_data_return = {}
            global_header_list= []
            preview_url = ""
            for map_data in mapped_data:
                try:
                    data_final_page_wise,global_header_list = await self.generate_docs(mapped=map_data["mapped_data"], project_name=project_name,global_header_list=global_header_list)
                    print(global_header_list)
                    if not google_docs_folder_created:
                        print(f"Creating folder for project: {project_name}")
                        upload_folder_links = await create_folder(username=project_name)
                        print(upload_folder_links,"upload folder datat")
                        preview_url = upload_folder_links["preview_url"]
                        print(f"Folder creation response: {upload_folder_links}")
                        
                        if "error" in upload_folder_links:
                            print(f"Warning: Error in folder creation: {upload_folder_links['error']}")
                        
                        # Safely get folder IDs with fallbacks
                        
                        google_docs_folder_created = True
                    folder_id = upload_folder_links.get("folder_id", "default_folder_id")
                    folder_url = upload_folder_links.get("folder_url", "#")
                    global_folder_id = upload_folder_links.get("global_folder_id", "default_global_folder_id")
                    print(folder_id)
                    
                    # print(f"Processing output data: {data_final_page_wise}")
                except Exception as map_err:
                    print(f"Error processing mapped data: {str(map_err)}")
                    
            # Upload everything to google drive
            project_path = os.path.join("output",project_name)
            global_path = os.path.join(project_path,"global")
            
            # Verify directories exist
            if not os.path.exists(project_path):
                print(f"Warning: Project path does not exist: {project_path}")
                os.makedirs(project_path, exist_ok=True)
                
            if not os.path.exists(global_path):
                print(f"Warning: Global path does not exist: {global_path}")
                os.makedirs(global_path, exist_ok=True)
    
            page_data_return = {}
            global_pages=[]
            
            # Process main project files
            try:
                print(f"Processing files in directory: {project_path}")
                for file_name in os.listdir(project_path):   
                    full_path = os.path.join(project_path,file_name)
                    if not os.path.isdir(full_path):
                        # Skip HTML files - only process DOCX files
                        if file_name.endswith('.html'):
                            print(f"Skipping HTML file: {file_name}")
                            continue
                            
                        try:
                            print(f"Uploading file: {full_path}")
                            file_upload_url = await upload_file_to_drive(full_path, folder_id)
                            print(f"Upload response: {file_upload_url}")
                            

                            #do publish and preview for url and pass to frontend
                            #introducing wait time because it took some time for adobe yaml to run around 1 minutes
                            import time 
                            time.sleep(60)
                            do_preview_url = await preview_for_file("team-argo",site=project_name,path=file_name.split(".")[0])

                            # do_publish_url = await publish_for_file("team-argo",site=project_name,path=file_name.split(".")[0])



                            page_data_return[file_name] = {
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": file_upload_url.get("file_url", "#"),
                                "preview_url" : do_preview_url["message"],
                                # "publish_url" : do_publish_url["message"]
                            }
                            
                        except Exception as file_err:
                            print(f"Error uploading file {full_path}: {str(file_err)}")
                            page_data_return[file_name] = {
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": "#",
                                "error": str(file_err)
                            }
            except Exception as dir_err:
                print(f"Error processing project directory: {str(dir_err)}")
                    
            # Process global files
            try:
                print(f"Processing files in global directory: {global_path}")
                for file_name in os.listdir(global_path):  
                    full_path = os.path.join(global_path, file_name)
                    if not os.path.isdir(full_path):
                        try:  
                            path = await upload_file_to_drive(full_path, global_folder_id)
                            global_pages.append({
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": "#",
                                "url": path.get("file_url", "#"),
                                "preview_url" : f"{preview_url.replace(".page",".live")}/{project_name}/{file_name.split(".")[0]}"
                            })
                        except Exception as global_file_err:
                            print(f"Error uploading global file {full_path}: {str(global_file_err)}")
                            global_pages.append(f"Error with {file_name}: {str(global_file_err)}")
            except Exception as global_dir_err:
                print(f"Error processing global directory: {str(global_dir_err)}")
                global_pages.append("Error loading global files")

            page_data_return["global"]={
                        "name": "global",
                        "type": 'folder',
                        "nodeType": 'folder',
                        "children": global_pages
                    }

            return_json = {
                "documents": {
                    "name": "documents",
                    "type": "folder",
                    "nodeType": "folder",
                }
                }
            return_json["documents"]["children"] = page_data_return
            return return_json
        except Exception as e:
            print(f"Error in generate-doc endpoint: {str(e)}")
            # Return a minimal valid response that the frontend can handle
            return {
                "documents": {
                    "name": "documents",
                    "type": "folder",
                    "nodeType": "folder",
                    "children": {
                        "error": {
                            "name": "Error",
                            "type": "file",
                            "nodeType": "file",
                            "url": "#",
                            "error_details": str(e)
                        }
                    },
                    "error": str(e)
                }
            }
        
    def save_html_and_docx(self, html, fname_base):
        """
        Save HTML to file, convert to DOCX, and enhance DOCX formatting.
        
        Args:
            html (str): HTML content to save
            fname_base (str): Base filename (without extension)
        """
        try:
            html_fname = f"{fname_base}.html"
            docx_fname = f"{fname_base}.docx"
            
            with open(html_fname, "w") as f:
                f.write(html)
            logger.info(f"✓ saved → {html_fname}")
            
            html_to_docx(html_fname, docx_fname)
            logger.info(f"✓ converted to DOCX → {docx_fname}")
            
            doc = Document(docx_fname)
            process_docx_tables(doc)
            doc.save(docx_fname)
            logger.info(f"✓ enhanced DOCX formatting → {docx_fname}")
            
            return True
        except Exception as e:
            logger.error(f"Error saving HTML and DOCX: {str(e)}")
            return False    
        

    def _slug(txt: str, fallback: str = "page") -> str:
        """
        Convert a string to a safe filename slug (e.g., "Home Page!" -> "home_page").
        
        Args:
            txt (str): Text to convert to a slug
            fallback (str, optional): Default value if txt is empty
            
        Returns:
            str: Slugified string safe for filenames
        """
        if not txt:
            return fallback
            
        txt = unicodedata.normalize("NFKD", txt).encode("ascii", "ignore").decode()
        txt = txt.lower()
        allowed = string.ascii_lowercase + string.digits + "_"
        txt = "".join(c if c in allowed else "_" for c in txt)
        txt = re.sub(r"_+", "_", txt).strip("_")
        return txt or fallback