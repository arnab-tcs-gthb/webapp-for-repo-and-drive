import os
import uuid
from pathlib import Path
from typing import Dict
from fastapi import UploadFile, HTTPException
from PIL import Image
from app.core.config import settings
import zipfile
import mimetypes
import logging

class FileUploadService:
    def __init__(self):
        self.allowed_content_types = [
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
            'image/svg+xml',
            'application/zip',
            'application/x-zip-compressed',
        ]
        self.max_file_size = 10 * 1024 * 1024  # 10MB

    async def extract_zip_and_list_types(self, zip_path, extract_to):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                for member in zip_ref.namelist():
                    if member.startswith('__MACOSX') or member.endswith('/'):
                        continue
                    target_path = os.path.join(extract_to, os.path.basename(member))
                    with zip_ref.open(member) as source_file, open(target_path, 'wb') as target_file:
                        target_file.write(source_file.read())
                    mime_type, _ = mimetypes.guess_type(target_path)
                    print(f"File: {os.path.basename(member)}, MIME type: {mime_type}")
            os.remove(zip_path)
            return True
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error processing zip file: {str(e)}"
            )

    async def validate_file(self, file: UploadFile) -> None:
        if file.content_type not in self.allowed_content_types:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type. Allowed types: {', '.join(self.allowed_content_types)}"
            )
        file.file.seek(0, 2)
        file_size = file.file.tell()
        file.file.seek(0)

        if file_size > self.max_file_size:
            raise HTTPException(
                status_code=400,
                detail=f"File too large. Max size: {self.max_file_size // (1024 * 1024)}MB"
            )

    async def save_uploaded_file(self, file: UploadFile, project_id: int) -> Dict | None:
        try:
            await self.validate_file(file)
            file_ext = os.path.splitext(file.filename)[1].lower()
            filename = f"{uuid.uuid4().hex}{file_ext}"
            content = await file.read()

            # Ensure required directories exist
            static_assets = Path("static/assets")
            static_images = Path("static/images")
            static_assets.mkdir(parents=True, exist_ok=True)
            static_images.mkdir(parents=True, exist_ok=True)

            asset_folder = static_assets / f"project_{project_id}"
            image_folder = static_images / f"project_{project_id}"
            asset_folder.mkdir(parents=True, exist_ok=True)
            image_folder.mkdir(parents=True, exist_ok=True)

            if file_ext == ".zip":
                zip_path = asset_folder / filename
                with open(zip_path, "wb") as f:
                    f.write(content)
                await self.extract_zip_and_list_types(zip_path, asset_folder)
                logging.info(f"Zip file {file.filename} extracted successfully to {asset_folder}")
                # Return None to indicate no DB record to create
                return None
            else:
                save_path = image_folder / filename
                with open(save_path, "wb") as f:
                    f.write(content)

                width, height = None, None
                if file.content_type.startswith('image/'):
                    try:
                        with Image.open(save_path) as img:
                            width, height = img.size
                    except Exception as img_error:
                        if save_path.exists():
                            save_path.unlink()
                        raise HTTPException(
                            status_code=400,
                            detail=f"Invalid image file: {str(img_error)}"
                        )

                return {
                    "filename": filename,
                    "original_filename": file.filename,
                    "filepath": str(save_path),
                    "url": f"/static/images/project_{project_id}/{filename}",
                    "content_type": file.content_type,
                    "file_size": os.path.getsize(save_path),
                    "width": width,
                    "height": height
                }

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error processing file: {str(e)}"
            )

# Singleton instance to be imported
file_upload_service = FileUploadService()
