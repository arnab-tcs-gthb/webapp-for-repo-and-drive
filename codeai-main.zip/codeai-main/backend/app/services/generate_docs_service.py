from app.repositories.projects_repo import ProjectsRepo
from app.services.mapping_service import MappingService
import json
import os
import logging

import re
import unicodedata
import string

from google.genai import types

from app.helper.md_to_docx import html_to_docx
from app.helper.doc_format import Document, process_docx_tables
from app.helper.google_docs import upload_docx_as_gdoc
from app.services.upload_service_v2 import publish_for_file, preview_for_file, create_folder, upload_file_to_drive
from app.repositories.images_repo import ImagesRepository
from app.repositories.pages_repo import PagesRepo
from app.services.project_services import ProjectsService
from app.helper.gemini_openai_helper import call_gemini_openai
from app.services.page_service import PageService
import time
from app.services.logging_service import log_event
from app.helper.gemini_openai_helper import gemini_generate_content_stream

from app.helper.log_data import entry_logs



logger = logging.getLogger(__name__)
image_dir = "images"
output_dir = "output"
class GenerateDocsService:
    def __init__(self, db=None, global_files=False):
        self.db = db
        self.global_files =  global_files

    async def generate_docs_service(self, project_id, page_id):
        import asyncio
        pages_data = []
        upload_main_file_data = {}
        if page_id == 0:
            page_id = None
        project_repo = ProjectsRepo(self.db)
        pages_repo = PagesRepo(self.db)
        project = project_repo.get_project_by_id(project_id)
        if page_id is not None:
            pages = pages_repo.get_page_by_id(page_id)
        else:
            pages = pages_repo.get_page_by_project_id(project_id)
        # Run genrate_doc_threading for each page concurrently
        tasks = [self.genrate_doc_threading(page=page, project=project) for page in pages]
        pages_data = await asyncio.gather(*tasks, return_exceptions=True)
        try:
            folder_created_data = project.drive_info
            upload_main_file_data = await self.upload_main_file_to_drive(
                project.project_name,
                folder_created_data["folder_id"],
                folder_created_data["global_folder_id"],
                folder_created_data["preview_url"],
                page_id = page_id
            )
            pages_repo.update_status(page_id, status="completed")
            return upload_main_file_data
        except Exception as upload_err:
            logger.error(f"Error uploading main file to drive: {str(upload_err)}")
            pages_repo.update_status(page_id, status="error")
            raise RuntimeError(f"Error uploading main file to drive: {str(upload_err)}")
    

    async def genrate_doc_threading(self, page, project):
        """
        Orchestrates the document generation process for a given project.
        Retrieves project and image data, processes mappings, generates documents, and uploads them to Google Drive.
        Returns a structured response with document links or error details.
        """
        try:
            folder_created_data = None
            folder_created_data = project.drive_info
            project_name = project.project_name
            pages_repo = PagesRepo(self.db)
            mapped_data = []
            global_header_list = []
            try:
                token_data = None
                pages_repo.update_status(page.id, status="in-progress", action="generate")
                block_data = await self.create_mapping_block(page.page_components)
                pages_repo.update_mapping_data(page.id, block_data)
                mapped_data.append(block_data)
                try:
                    _, global_header_list, token_data = await self.generate_docs(
                        mapped=block_data["mapped_data"],
                        project_name=project_name,
                        global_header_list=global_header_list,
                        project_id = project.id,
                        page_id=str(page.id)
                    )
                    
                    pages_repo.update_status(page.id, status="completed", action="generate")
                except Exception as map_err:
                    pages_repo.update_status(page.id, status="error", action="generate")
                    logger.error(f"Error processing mapped data: {str(map_err)}")
                    raise
            except Exception as page_err:
                logger.error(f"Error processing page {getattr(page, 'id', None)}: {str(page_err)}")
                pages_repo.update_status(getattr(page, 'id', None), status="error", action="generate")
                raise RuntimeError(f"Error processing page {getattr(page, 'id', None)}: {str(page_err)}")
            return {"folder_create_data":folder_created_data}
        except Exception as e:
            logger.error(f"Error in generate-doc endpoint: {str(e)}")
            try:
                pages_repo.update_status(page.id, status="error")
            except Exception as status_err:
                logger.error(f"Error updating page status: {str(status_err)}")
            raise

    async def create_mapping_block(self, analyze_response):
        """
        Maps the LLM analysis response to UI blocks using the MappingService.
        """
        try:
            mapping_service = MappingService(self.db)
            block_data = await mapping_service.map_ui_to_blocks(
                page_json=analyze_response,
                block_kb=mapping_service.load_block_kb()
            )
            return block_data
        except Exception as e:
            logger.error(f"Error in create_mapping_block: {str(e)}")
            raise RuntimeError(f"Error in create_mapping_block: {str(e)}")

    async def create_folder_and_sub_folder(self, project_name):
        """
        Creates a main and global folder for the project in Google Drive.
        """
        try:
            upload_folder_links = await create_folder(username=project_name)
            if "error" in upload_folder_links:
                logger.warning(f"Error in folder creation: {upload_folder_links['error']}")
            else:
                logger.info("Folder creation response Success")
            
            folder_metadata = {
                "folder_id": upload_folder_links.get("folder_id", "default_folder_id"),
                "folder_url": upload_folder_links.get("folder_url", "#"),
                "global_folder_id": upload_folder_links.get("global_folder_id", "default_global_folder_id"),
                "preview_url": upload_folder_links.get("preview_url", "#")
            }
            #update data in project table for further use
            project_services = ProjectsService(self.db)
            updata_metadata = await project_services.update_upload_data_project_name(project_name, folder_metadata)
            return folder_metadata
        
        

        except Exception as e:
            logger.error(f"Error in create_folder_and_sub_folder: {str(e)}")
            raise

    async def upload_main_file_to_drive(self, project_name, folder_id, global_folder_id, preview_url, page_id=None):
        """
        Uploads generated DOCX files to Google Drive and prepares the response structure.
        """
        project_path = os.path.join(output_dir, project_name)
        global_path = os.path.join(project_path, "global")
        pages_repo =  PagesRepo(self.db)
        try:
            if not os.path.exists(project_path):
                logger.warning(f"Project path does not exist: {project_path}")
                os.makedirs(project_path, exist_ok=True)
            if not os.path.exists(global_path):
                logger.warning(f"Global path does not exist: {global_path}")
                os.makedirs(global_path, exist_ok=True)
            page_data_return = {}
            global_pages = []

            try:
                logger.info(f"Processing files in directory: {project_path}")
                for file_name in os.listdir(project_path):
                    #taking this extra folder, ignoring it would be best....
                    if file_name == ".DS_Store":
                        continue
                    full_path = os.path.join(project_path, file_name)
                    if not os.path.isdir(full_path):
                        if file_name.endswith('.html'):
                            logger.info(f"Skipping HTML file: {file_name}")
                            continue
                        try:
                            logger.info(f"Uploading file: {full_path}")
                            file_upload_url = await upload_file_to_drive(full_path, folder_id)
                            logger.info(f"Upload response: {file_upload_url}")
                            do_preview_url = await preview_for_file(
                                "team-argo",
                                site=project_name,
                                path=file_name.split(".")[0]
                            )
                            if page_id is not None:
                                pages_repo.update_preview_url(page_id, do_preview_url["message"])
                            page_data_return[file_name] = {
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": file_upload_url.get("file_url", "#"),
                                "preview_url": do_preview_url["message"],
                            }
                        except Exception as file_err:
                            logger.error(f"Error uploading file {full_path}: {str(file_err)}")
                            page_data_return[file_name] = {
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": "#",
                                "error": str(file_err)
                            }
                        # os.remove(full_path)
            except Exception as dir_err:
                logger.error(f"Error processing project directory: {str(dir_err)}")

            if not self.global_files:
                try:
                    logger.info(f"Processing files in global directory: {global_path}")
                    for file_name in os.listdir(global_path):
                        if file_name.endswith('.html'):
                            logger.info(f"Skipping HTML file: {file_name}")
                            continue
                        full_path = os.path.join(global_path, file_name)
                        if not os.path.isdir(full_path):
                            try:
                                print("fie name ---------", file_name)

                                path = await upload_file_to_drive(full_path, folder_id)
                                do_preview_url_global = await preview_for_file(
                                    "team-argo",
                                    site=project_name,
                                    path=file_name.split(".")[0]
                                )
                                print(do_preview_url_global)
                                global_pages.append({
                                    "name": file_name,
                                    "type": file_name.split(".")[1],
                                    "nodeType": 'file',
                                    "url": path.get("file_url", "#"),
                                    "preview_url": do_preview_url_global["message"]
                                })
                                self.global_files = True
                                # os.remove(full_path)
                            except Exception as global_file_err:
                                logger.error(f"Error uploading global file {full_path}: {str(global_file_err)}")
                                global_pages.append(f"Error with {file_name}: {str(global_file_err)}")
                except Exception as global_dir_err:
                    logger.error(f"Error processing global directory: {str(global_dir_err)}")
                    global_pages.append("Error loading global files")
            
            page_data_return["global"] = {
                "name": "global",
                "type": 'folder',
                "nodeType": 'folder',
                "children": global_pages
            }
            return_json = {
                "documents": {
                    "name": "documents",
                    "type": "folder",
                    "nodeType": "folder",
                    "children": page_data_return
                }
            }
            return return_json
        except Exception as e:
            logger.error(f"Error in upload_main_file_to_drive: {str(e)}")
            raise

    

    async def generate_docs(self, mapped, project_name, project_id, page_id,global_header_list=None, ):
        """
        Generate HTML and DOCX documents from mapped components.
        """
        try:
            global_blocks = {}
            token_data = {}
            pages = []
            page_building = []
            global_items = global_header_list or []
            new_project = False
            project_path = os.path.join(output_dir, project_name)
            global_path = os.path.join(project_path, "global")
            if not os.path.exists(project_path):
                new_project = True
                os.makedirs(project_path, exist_ok=True)
                os.makedirs(global_path, exist_ok=True)
                logger.info(f"Created new project directory: {project_path}")
            for comp in mapped:
                if comp["element_type"] == "global":
                    global_blocks.setdefault(comp["type"], comp)
                else:
                    page_building.append(comp)
            #save preview url
            page_service= PageService(self.db)
            

            pages.append({
                "title": mapped[0].get("page_title", ""),
                "components": page_building
            })
            for blk_type, comp in global_blocks.items():
                if blk_type not in global_items:
                    html,token_data = self.render_markdown({"components": [comp]})
                    html = html.strip()
                    await entry_logs(self.db,input_data={"components": [comp]}, output_data=html, project_id=project_id, page_id=page_id,token_data=token_data,endpoint="generate_docs")
                    if html:
                        fname_base = os.path.join(global_path, self._slug(blk_type))
                        self.save_html_and_docx(html, fname_base)
                        global_items.append(blk_type)
            for page in pages:
                if not page["components"]:
                    continue
                html,token_data = self.render_markdown({"components": page["components"]})
                html = html.strip()
                await entry_logs(self.db, input_data={"components": page["components"]}, output_data=html, project_id=project_id, page_id=page_id,token_data=token_data,endpoint="generate_docs")

                if html:
                    fname_base = os.path.join(project_path, self._slug(page['title']))
                    self.save_html_and_docx(html, fname_base)
                    save_preview_url = await page_service.save_preview_url(self._slug(page['title']), mapped[0].get("original_file_name", ""))
            json_output = {
                "no_of_global_blocks": len(global_blocks),
                "no_of_side_blocks": len(pages)
            }
            return json_output, global_items, token_data
        except Exception as e:
            logger.error(f"Error generating docs: {str(e)}")
            raise RuntimeError(f"Error generating docs: {str(e)}")

    def render_markdown(self, page_payload):
        """
        Generate HTML content from the mapped JSON and block templates using Gemini.
        """
        try:
            prompt = f"""
            **You are a highly precise, automated HTML templating engine. Your sole function is to convert a JSON data object into a final HTML document using a provided library of HTML component templates.**

        **TASK**
        Generate a complete HTML document by populating the provided HTML templates with data from the JSON payload. You must follow all rules without deviation.

        **INPUTS**
        1.  **JSON Payload (`{{page_payload}}`):** A JSON object containing the page data structured into a list of components.

        **CORE LOGIC & STRICT RULES**

        1.  **Iterate Through Components:** Process the `components` array in the `{{page_payload}}` one by one, in order.

        2.  **Match Template to Component:** For each JSON component, find the corresponding HTML template in the `{{page_payload}}` library based on its `type` or name.

        3.  **Structure Preservation:** You MUST use the exact HTML structure from the matched template. DO NOT add, remove, or reorder any HTML tags or elements.

        4.  **Content Replacement:**
            * You MUST replace ALL placeholder content (text, titles, descriptions, links) in the template with the corresponding values from the component's `properties` in the JSON.
            * You MUST replace the `src` attribute of all `<img>` tags with the image paths provided in the JSON.
            * **CRITICAL EXCEPTION:** Some templates contain a `<table>` where the first header (`<th>`) serves as a static label for the component (e.g., `<th>Columns</th>`). You MUST preserve this specific `<th>` element exactly as it appears in the template. All other `<td>` and content elements in that table must be populated from the JSON as usual.
            * You must Not put page title in the nav or header component if mentioned otherwise in the component body
        5.  **Unique ID Generation:**
            * All HTML `id` attributes in the final output MUST be unique.
            * To ensure uniqueness, prefix every `id` from the template with the component's type and its index. For example, if the third component is a 'cards' block with `id="card-container"`, the final ID MUST become `id="cards-2-card-container"`.

        **OUTPUT RULES**

        * Your response MUST contain ONLY the final, raw HTML content.
        * DO NOT include any explanations, comments, or markdown code fences (like ```html).
        * Before finalizing, perform a self-correction check to ensure NO placeholder text (e.g., "Lorem ipsum") remains and all IDs are unique.

        ---
        **JSON Payload:**
        `{page_payload}`
        ---
    """
            raw, token_data = gemini_generate_content_stream(prompt)
            return raw, token_data
        except Exception as e:
            logger.error(f"Error rendering markdown: {str(e)}")
            raise RuntimeError(f"Error rendering markdown: {str(e)}")

    def save_html_and_docx(self, html, fname_base):
        """
        Save HTML to file, convert to DOCX, and enhance DOCX formatting.
        """
        try:
            html_fname = f"{fname_base}.html"
            docx_fname = f"{fname_base}.docx"
            with open(html_fname, "w") as f:
                f.write(html)
            logger.info(f"✓ saved → {html_fname}")
            html_to_docx(html_fname, docx_fname)
            logger.info(f"✓ converted to DOCX → {docx_fname}")
            doc = Document(docx_fname)
            process_docx_tables(doc)
            doc.save(docx_fname)
            logger.info(f"✓ enhanced DOCX formatting → {docx_fname}")
            return True
        except Exception as e:
            logger.error(f"Error saving HTML and DOCX: {str(e)}")
            raise RuntimeError(f"Error saving HTML and DOCX: {str(e)}")

    @staticmethod
    def _slug(txt: str, fallback: str = "page") -> str:
        """
        Convert a string to a safe filename slug (e.g., "Home Page!" -> "home_page").
        """
        try:
            if not txt:
                return fallback
            txt = unicodedata.normalize("NFKD", txt).encode("ascii", "ignore").decode()
            txt = txt.lower()
            allowed = string.ascii_lowercase + string.digits + "_"
            txt = "".join(c if c in allowed else "_" for c in txt)
            txt = re.sub(r"_+", "_", txt).strip("_")
            if "footer" in txt:
                txt ="footer"
            if txt=="header":
                txt="nav"
            return txt or fallback
        except Exception as e:
            logger.error(f"Error in _slug: {str(e)}")
            return fallback