from app.repositories.log_entry_repo import create_log_entry
from app.schemas.log_entry import LogEntryCreate
from sqlalchemy.orm import Session

def log_event(
    db: Session,
    project_id: str,
    page_id: str=None,
    llm_input_tokens: int = None,
    llm_output_tokens: int = None,
    llm_total_tokens: int = None,
    llm_thinking_tokens: int = None,
    llm_input: str = None,
    llm_output: str = None,
    endpoint:str = None,
    extra: dict = None, 
    model_name:str = None,
    prompt_hash:str=None,
    latency_ms:str=None,
    temperature:str=None,
    provider:str=None
):
    log = LogEntryCreate(
        project_id=project_id,
        page_id=page_id,
        llm_input_tokens=llm_input_tokens,
        llm_output_tokens=llm_output_tokens,
        llm_total_tokens=llm_total_tokens,
        llm_thinking_tokens=llm_thinking_tokens,
        extra=extra,
        endpoint=endpoint,
        model_name=model_name,
        prompt_hash=prompt_hash,
        latency_ms=latency_ms,
        temperature=temperature,
        provider=provider
    )
    return create_log_entry(db, log)
