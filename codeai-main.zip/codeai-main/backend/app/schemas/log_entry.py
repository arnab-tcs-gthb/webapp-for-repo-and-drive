from pydantic import BaseModel
from typing import Optional, Any
import datetime

class LogEntryBase(BaseModel):
    project_id: str
    page_id: Optional[str] =None
    llm_input_tokens: Optional[int] = None
    llm_output_tokens: Optional[int] = None
    llm_total_tokens: Optional[int] = None
    llm_thinking_tokens: Optional[int] = None
    endpoint: Optional[str] = None
    prompt_hash: Optional[str] = None
    temperature: Optional[float] = None
    model_name:Optional[str] = None
    provider: Optional[str] = None
    latency_ms:Optional[float] = None
    prompt_hash:Optional[float] = None
    extra: Optional[Any] = None


class LogEntryCreate(LogEntryBase):
    pass

class LogEntryInDB(LogEntryBase):
    id: str
    created_at: datetime.datetime

    class Config:
        orm_mode = True

class LogEntryResponse(LogEntryInDB):
    pass
