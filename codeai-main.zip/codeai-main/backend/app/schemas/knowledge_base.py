from pydantic import BaseModel
from typing import Optional

class ProcessRequest(BaseModel):
    base_url: Optional[str] = "https://sidekick-library--aem-block-collection--adobe.aem.page"
    json_list_url: Optional[str] = "/tools/sidekick/library.json"
    docx_root: Optional[str] = "static/all_docx/"
    output_yaml: Optional[str] = "aem_block_kb/block_kb_from_docx_aem.yaml"
    formatted_yaml: Optional[str] = "aem_block_kb/block_kb_formatted.yaml"