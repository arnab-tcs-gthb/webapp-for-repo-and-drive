# app/schemas/captioning_schemas.py
from pydantic import BaseModel
from typing import List

class ImageCaptionRequest(BaseModel):
    folder_location: str

class ImageCaptionResponseItem(BaseModel):
    image_path: str
    description: str

class CaptionSummaryResponse(BaseModel):
    total_images_found: int
    successfully_captioned: int
    results: List[ImageCaptionResponseItem]
    message: str
    errors: List[str] = []
    
    def to_dict(self):
        """Convert to plain dictionary for JSON serialization"""
        captions = {}
        for item in self.results:
            captions[item.image_path] = item.description
        return {
            "captions": captions,
            "total_images_found": self.total_images_found,
            "successfully_captioned": self.successfully_captioned,
            "message": self.message,
            "errors": self.errors
        }
