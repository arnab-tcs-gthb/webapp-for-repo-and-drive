from pydantic import BaseModel, Field, validator, ConfigDict
from typing import Optional


class AnalyzeImage(BaseModel):
    project_id:str
    page_id:Optional[str] = None
    analyze_trigger_flag: Optional[bool] = False
    captions_trigger_flag: Optional[bool] = False


class AnalyzeResponse(BaseModel):
    llm_response: list[dict]

class MappingData(BaseModel):
    components_data:list[dict]

class GenerateDocs(BaseModel):
    img_name:str
    mapped_data:list