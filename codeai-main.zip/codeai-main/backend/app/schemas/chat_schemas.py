from pydantic import BaseModel, Field, validator, ConfigDict


class AnalyzeImage(BaseModel):
    project_id:int

class MappingData(BaseModel):
    components_data:list[dict]

class GenerateDocs(BaseModel):
    img_name:str
    mapped_data:list