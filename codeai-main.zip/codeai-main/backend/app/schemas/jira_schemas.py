from typing import Optional, List
from pydantic import BaseModel, Field, AnyUrl

class IssueField(BaseModel):
    summary: str = Field(..., min_length=1, description="The main summary or title of the issue.")
    description: Optional[str] = Field(None, description="Detailed description of the issue.")
    project_id: str = Field(..., description="The internal project ID to associate with this UAT entry.")
    page_id: str = Field(..., description="The internal page ID to associate with this UAT entry.")
    # assignee_name: Optional[str] = None # Add if needed for your Jira setup
    # labels: Optional[List[str]] = None # Add if needed

class EpicCreate(IssueField):
    epic_name: Optional[str] = Field(None, description="Epic name (will be used in description if no custom field available, or set to summary if specific field not used)")

class StoryCreate(IssueField):
    epic_link_key: Optional[str] = Field(None, description="Epic key to link to (e.g., 'PROJ-123'). Requires Epic Link custom field to be configured.")

class TaskCreate(IssueField):
    pass

class SubtaskCreate(IssueField):
    parent_key: str = Field(..., description="Key of the parent Story or Task (e.g., 'PROJ-124').")

class IssueResponse(BaseModel):
    key: str
    id: str
    self_url: str # Changed from 'self' to avoid Pydantic conflicts
    message: str

class JiraHealthResponse(BaseModel):
    status: str
    jira_connection: str
    jira_user: Optional[str] = None
    error: Optional[str] = None

class JiraConfigInfo(BaseModel):
    jira_url: Optional[str] # Kept as str for simplicity, can be AnyUrl if strict validation is needed
    jira_username: Optional[str]
    jira_project_key: Optional[str]
    epic_name_custom_field_id: Optional[str]
    epic_link_custom_field_id: Optional[str]
    api_token_configured: bool
    custom_fields_note: str

class PageUATCreate(BaseModel):
    project_id: str
    page_id: str
    jira: str