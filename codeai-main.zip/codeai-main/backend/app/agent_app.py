from fastapi import FastAPI, HTTPException, status
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, AsyncGenerator
from app.agentic_AI.aem_agent import get_aem_agent
import json
from logging import getLogger

logger = getLogger(__name__)

class ChatRequest(BaseModel):
    user_input: str
    project_id: Optional[str] = None
    user_id: Optional[str] = "web_user"
    session_id: Optional[str] = "web_session"
    debug_mode: Optional[bool] = False

agent_app = FastAPI()

agent_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

async def stream_agent_response(
    user_input: str,
    user_id: str,
    session_id: str,
    debug_mode: bool,
    project_id: str = None
) -> AsyncGenerator:
    """
    Stream agent responses chunk by chunk.
    """
    try:
        agent = await get_aem_agent(
            user_id=user_id,
            session_id=session_id,
            debug_mode=debug_mode,
            project_id=project_id  # Pass project_id if supported
        )
        response = await agent.arun(user_input)  # Await the response ONCE
        content = getattr(response, "content", None)
        if not content and hasattr(response, "messages"):
            for msg in reversed(response.messages):
                if getattr(msg, "role", None) == "assistant" and getattr(msg, "content", None):
                    content = msg.content
                    break
        if content:
            yield json.dumps({"content": content}) + "\n"
        else:
            yield json.dumps({"content": "(no response content)"}) + "\n"
        yield json.dumps({"end": True}) + "\n"
    except Exception as e:
        logger.error(f"Error during agent execution: {e}")
        yield json.dumps({"error": str(e), "status": "error"}) + "\n"
        yield json.dumps({"end": True}) + "\n"


@agent_app.post("/agentic-chat/stream")
async def stream_chat(request: ChatRequest):
    """
    Streams responses from the AEM agent.
    """
    print(f"Received request: {request}")
    return StreamingResponse(
        stream_agent_response(
            user_input=request.user_input,
            user_id=request.user_id or "web_user",
            session_id=request.session_id or "web_session",
            debug_mode=request.debug_mode or False,
            project_id=request.project_id
        ),
        media_type="application/x-ndjson"
    )
