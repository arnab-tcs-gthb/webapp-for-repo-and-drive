"""
LLM (Gemini) related helpers and tools.
"""
import os
import json
import re
import logging
from dotenv import load_dotenv
from agno.tools import tool
from typing import Dict, Any, List, Optional, Tuple

load_dotenv()

try:
    import google.generativeai as genai
    GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "dummy_key")
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model_name = "gemini-2.5-flash-preview-05-20"
    gemini = genai.GenerativeModel(gemini_model_name)
except Exception as e:
    gemini = None
    gemini_model_name = None
    logging.getLogger(__name__).error(f"Could not initialize Gemini API client: {str(e)}")

@tool(
    name="llm_map_user_input_to_schema",
    description="Use Gemini LLM to extract and map user-supplied values to schema keys. "
                "Takes user_message (str) and schema_params (list of parameter dicts) and returns a dict mapping parameter names to values."
)
async def llm_map_user_input_to_schema(user_message: str, schema_params: List[Dict[str, Any]]) -> Dict[str, Any]:
    schema_desc = "\n".join(
        [f"- {p['name']} ({p['type']}): {p.get('description','')}" for p in schema_params]
    )
    prompt = (
        "You are an expert API assistant.\n"
        "Given the following user message and API parameter schema, extract the values for each parameter.\n"
        "Return a JSON object mapping parameter names (as shown in the schema) to values. Only include parameters present in the user message.\n"
        "If the user uses a different format (e.g., 'project name'), map it to the schema key (e.g., 'project_name').\n"
        f"User message: {user_message}\n"
        f"Schema:\n{schema_desc}\n"
        "JSON:"
    )
    try:
        if gemini is None:
            raise RuntimeError("Gemini client is not initialized.")
        response =  gemini.generate_content(prompt)
        if hasattr(response, "text"):
            response_text = response.text
        elif hasattr(response, "candidates") and response.candidates:
            response_text = response.candidates[0].content.parts[0].text
        else:
            response_text = str(response)
        try:
            return json.loads(response_text)
        except Exception:
            return {"raw_response": response_text}
    except Exception as e:
        return {"error": str(e)}

async def llm_fill_path_parameters(endpoint_template: str, user_params: dict) -> str:
    def replacer(match):
        key = match.group(1)
        value = str(user_params.get(key, match.group(0)))
        return value
    filled = re.sub(r"{(\w+)}", replacer, endpoint_template)
    return filled

async def llm_select_endpoint(user_intent: str, openapi_schema: Dict[str, Any]) -> Optional[Tuple[str, str]]:
    endpoint_summaries = []
    for path, methods in openapi_schema.get("paths", {}).items():
        for method, details in methods.items():
            summary = details.get("summary", "")
            description = details.get("description", "")
            file_types = ""
            if "file type" in description.lower() or "supported" in description.lower():
                matches = re.findall(r"(image/\w+|application/\w+|text/\w+|audio/\w+|video/\w+|application/x-\w+)", description, re.IGNORECASE)
                if matches:
                    file_types = f" [Allowed types: {', '.join(sorted(set(matches)))}]"
            endpoint_summaries.append(f"{method.upper()} {path} - {summary} {description}{file_types}")
    endpoints_text = "\n".join(endpoint_summaries)
    prompt = (
        "You are an expert API assistant. "
        "Given the following list of API endpoints and a user request, "
        "select the single best endpoint (method and path) to fulfill the request. "
        "Pay special attention to the allowed file types in the endpoint descriptions. "
        "Return your answer as a JSON object with 'method' and 'path'.\n\n"
        f"API Endpoints:\n{endpoints_text}\n\n"
        f"User request: {user_intent}\n\n"
        "JSON:"
    )
    try:
        response = gemini.generate_content(prompt)
        if hasattr(response, "text"):
            response_text = response.text
        elif hasattr(response, "candidates") and response.candidates:
            response_text = response.candidates[0].content.parts[0].text
        else:
            response_text = str(response)
        response_text = response_text.strip()
        if response_text.startswith("```json"):
            response_text = response_text[len("```json"):].strip()
        if response_text.endswith("```"):
            response_text = response_text[:-3].strip()
        result = json.loads(response_text)
        return result.get("method"), result.get("path")
    except Exception as e:
        return None
