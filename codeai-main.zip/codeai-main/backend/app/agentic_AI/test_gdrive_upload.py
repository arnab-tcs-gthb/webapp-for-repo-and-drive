import asyncio
from gdocs_utils import upload_image_to_gdrive_and_get_url

async def test_upload():
    # Change this path to an actual image file in your workspace
    local_image_path = "backend/assets/ai coding.jpeg"
    result = await upload_image_to_gdrive_and_get_url(local_image_path)
    print(result)

if __name__ == "__main__":
    asyncio.run(test_upload())
