import asyncio
from app.agentic_AI.aem_agent import get_aem_agent

async def chat_with_agent():
    agent = await get_aem_agent(
        user_id="test_user",
        session_id="test_session",
        debug_mode=True
    )
    print("Multi-turn AEM Agent chat. Type 'exit' to quit.\n")
    while True:
        user_message = input("You: ")
        if user_message.lower() in {"exit", "quit"}:
            print("Exiting chat.")
            break
        try:
            response = await agent.arun(user_message)
            # Prefer response.content, fallback to last assistant message in response.messages
            content = getattr(response, "content", None)
            if not content and hasattr(response, "messages"):
                # Find the last assistant message with content
                for msg in reversed(response.messages):
                    if getattr(msg, "role", None) == "assistant" and getattr(msg, "content", None):
                        content = msg.content
                        break
            if content:
                print("Agent:", content)
            else:
                print("Agent: (no response content)")
        except Exception as e:
            print("Error during agent execution:", e)

if __name__ == "__main__":
    asyncio.run(chat_with_agent())