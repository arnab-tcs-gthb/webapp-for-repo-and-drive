import asyncio
from utils import (
    create_doc,
    edit_doc,
    share_doc,
    CreateDocInput,
    EditDocInput,
    ShareDocInput
)

async def main():
    print("--- Testing Google Docs Tools ---")
    # 1. Create a new doc
    create_input = CreateDocInput(title="Test Doc from Script")
    create_result = await create_doc(create_input)
    print("CreateDoc result:", create_result)
    if not create_result.get("success"):
        print("[FAIL] Could not create doc. Aborting test.")
        return
    doc_id = create_result["result"]["document_id"]

    # 2. Edit the doc
    edit_input = EditDocInput(document_id=doc_id, content="This is a test content added by script.")
    edit_result = await edit_doc(edit_input)
    print("EditDoc result:", edit_result)

    # 3. Share the doc (replace with a real email to test sharing)
    share_input = ShareDocInput(document_id=doc_id, email="ajayhazratrainingact@gmail.com", role="writer")
    share_result = await share_doc(share_input)
    print("ShareDoc result:", share_result)

if __name__ == "__main__":
    asyncio.run(main())
