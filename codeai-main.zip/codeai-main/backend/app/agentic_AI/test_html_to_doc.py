import asyncio
from doc_author_agent import get_doc_agent

async def test_html_to_doc():
    # Example HTML block for columns (converted from markdown)
    html = '''
<table>
  <tr>
    <th colspan="3">Columns</th>
  </tr>
  <tr>
    <td><img src="https://drive.usercontent.google.com/download?id=1ICnYx1g69E7n-pZqkszNrJetn0oOE05I&authuser=0" alt="A rocket and a headless suit"></td>
    <td><img src="https://drive.usercontent.google.com/download?id=1ICnYx1g69E7n-pZqkszNrJetn0oOE05I&authuser=0" alt="An iceberg"></td>
    <td><img src="https://drive.usercontent.google.com/download?id=1ICnYx1g69E7n-pZqkszNrJetn0oOE05I&authuser=0" alt="A dial with a hand on it"></td>
  </tr>
  <tr>
    <td><h2>Column 1</h2></td>
    <td><h2>Column 2</h2></td>
    <td><h2>Column 3</h2></td>
  </tr>
  <tr>
    <td>This and that</td>
    <td>This and that</td>
    <td>This and that</td>
  </tr>
</table>
'''
    # Document ID to test with (replace with your actual doc ID)
    document_id = "1hbJixZG7EC7t12RVoPpSRpAf0MBctz793Lh3tUrRPIA"
    agent = await get_doc_agent(session_id="test_session")
    print(f"DEBUG: Using document_id: {document_id}")
    user_message = f"For document with this exact ID: {document_id}, add the following HTML block in the last. (Do NOT alter the document ID in any way):\n{html}"
    response = await agent.arun(user_message)
    print(response)

if __name__ == "__main__":
    asyncio.run(test_html_to_doc())
