from agno.models.google import Gemini
import json
from agno.tools import tool

# LLM-powered HTML to doc instruction tool
@tool(name="html_to_doc_instruction", description="Parse HTML (tables, images, headings, etc.) into structured instructions for Google Docs editing using an LLM. Returns a dict with a summary instruction and a parsed structure.")
def html_to_doc_instruction(html: str) -> dict:
    """
    Use an LLM to analyze the HTML and return structured instructions for Google Docs editing.
    Returns a dict with a high-level instruction and a parsed structure.
    """
    prompt = f"""
You are an expert in document structure and Google Docs API formatting.
Analyze the following HTML and extract its structure, including tables, images, headings, lists, and text blocks.
Return a JSON object with:
  - 'instruction': a high-level summary of what should be done in Google Docs (e.g., create a table, insert images, format headings, etc.)
  - 'parsed': a structured representation of the HTML (e.g., type, columns, rows, images, headings, cell_texts, image_map, etc.)
Be as detailed as possible for tables, images, and formatting. If there are image references, include their mapping. If there are headings, include their text and level. If there are lists, include their items. If there is plain text, include it as content.
Respond ONLY with a valid JSON object.

HTML:
"""
    prompt += html

    llm = Gemini("gemini-2.5-flash-preview-05-20")
    response = llm.complete(prompt, response_format="json")
    try:
        result = json.loads(response)
    except Exception:
        result = {
            "instruction": "LLM failed to parse HTML. Please check input.",
            "parsed": {"raw": html, "llm_response": response}
        }
    return result

import re
from typing import Dict, Any
from agno.tools import tool
import logging
import json
import os
# Load environment variables
from dotenv import load_dotenv
load_dotenv()

try:
    import google.generativeai as genai
    GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "dummy_key")
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model_name = "gemini-2.5-flash-preview-05-20"
    gemini = genai.GenerativeModel(gemini_model_name)
except Exception as e:
    gemini = None
    gemini_model_name = None
    logging.getLogger(__name__).error(f"Could not initialize Gemini API client: {str(e)}")


@tool(name="markdown_to_doc_instruction", description="Parse markdown (tables, images, headings, etc.) into structured instructions for Google Docs editing using an LLM. Returns a dict with a summary instruction and a parsed structure.")
def markdown_to_doc_instruction(markdown: str) -> Dict[str, Any]:
    """
    Use an LLM to analyze the markdown and return structured instructions for Google Docs editing.
    Returns a dict with a high-level instruction and a parsed structure.
    """
    # Compose a prompt for the LLM
    prompt = f"""
You are an expert in document structure and Google Docs API formatting.
Analyze the following markdown and extract its structure, including tables, images, headings, lists, and text blocks. 
Return a JSON object with:
  - 'instruction': a high-level summary of what should be done in Google Docs (e.g., create a table, insert images, format headings, etc.)
  - 'parsed': a structured representation of the markdown (e.g., type, columns, rows, images, headings, cell_texts, image_map, etc.)
Be as detailed as possible for tables, images, and formatting. If there are image references, include their mapping. If there are headings, include their text and level. If there are lists, include their items. If there is plain text, include it as content.
Respond ONLY with a valid JSON object.

Markdown:
"""
    prompt += markdown

    try:
        if gemini is None:
            raise RuntimeError("Gemini client is not initialized.")
        response =  gemini.generate_content(prompt)
        if hasattr(response, "text"):
            response_text = response.text
        elif hasattr(response, "candidates") and response.candidates:
            response_text = response.candidates[0].content.parts[0].text
        else:
            response_text = str(response)
        try:
            return json.loads(response_text)
        except Exception:
            return {"raw_response": response_text}
    except Exception as e:
        return {"error": str(e)}
"""
Google Docs-specific utilities and tools.
"""
import asyncio
from typing import Optional, List, Dict
from pydantic import BaseModel
from google.oauth2 import service_account
from googleapiclient.discovery import build
from agno.tools import tool

# Load credentials from service account key JSON
SCOPES = ['https://www.googleapis.com/auth/documents', 'https://www.googleapis.com/auth/drive']
SERVICE_ACCOUNT_FILE = '/Users/ajayhazra/Desktop/My Space/ARGO/codeai/backend/credentials.json'  # Consider using env var

credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

docs_service = build('docs', 'v1', credentials=credentials)
drive_service = build('drive', 'v3', credentials=credentials)

class CreateDocInput(BaseModel):
    title: str

class EditDocInput(BaseModel):
    document_id: str
    content: str

class ShareDocInput(BaseModel):
    document_id: str
    email: str
    role: str = "writer"  # 'reader', 'writer', etc.

def _get_doc_sync(document_id: str) -> dict:
    try:
        doc = docs_service.documents().get(documentId=document_id).execute()
        return {"success": True, "result": doc}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_doc(document_id: str) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _get_doc_sync, document_id)

def _batch_update_doc_sync(document_id: str, requests: List[Dict]) -> dict:
    try:
        result = docs_service.documents().batchUpdate(
            documentId=document_id, body={"requests": requests}
        ).execute()
        return {"success": True, "result": result}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def batch_update_doc(document_id: str, requests: List[Dict]) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _batch_update_doc_sync, document_id, requests)

def _create_doc_sync(input: CreateDocInput) -> dict:
    try:
        body = {"title": input.title}
        doc = docs_service.documents().create(body=body).execute()
        url = f"https://docs.google.com/document/d/{doc.get('documentId')}/edit"
        return {"success": True, "result": {"title": doc.get('title'), "document_id": doc.get('documentId'), "url": url}}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def create_doc(input: CreateDocInput) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _create_doc_sync, input)

def _edit_doc_sync(input: EditDocInput) -> dict:
    try:
        requests = [
            {
                "insertText": {
                    "location": {
                        "index": 1
                    },
                    "text": input.content
                }
            }
        ]
        result = docs_service.documents().batchUpdate(
            documentId=input.document_id, body={"requests": requests}
        ).execute()
        return {"success": True, "result": "Document updated with new content."}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def edit_doc(input: EditDocInput) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _edit_doc_sync, input)

def _share_doc_sync(input: ShareDocInput) -> dict:
    try:
        permission = {
            "type": "user",
            "role": input.role,
            "emailAddress": input.email
        }
        drive_service.permissions().create(
            fileId=input.document_id,
            body=permission,
            sendNotificationEmail=False
        ).execute()
        return {"success": True, "result": f"Document shared with {input.email}."}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def share_doc(input: ShareDocInput) -> dict:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _share_doc_sync, input)

#@tool(name="upload_image_to_gdrive_and_get_url", description="Upload a local image file to Google Drive, set it to public, and return a direct image URL.")
async def upload_image_to_gdrive_and_get_url(local_image_path: str) -> dict:
    import os
    from googleapiclient.http import MediaFileUpload
    try:
        file_metadata = {
            'name': os.path.basename(local_image_path),
            'mimeType': 'image/jpeg'
        }
        media = MediaFileUpload(local_image_path, mimetype='image/jpeg')
        file = drive_service.files().create(body=file_metadata, media_body=media, fields='id').execute()
        file_id = file.get('id')
        drive_service.permissions().create(
            fileId=file_id,
            body={
                'type': 'anyone',
                'role': 'reader',
            },
        ).execute()
        public_url = f"https://drive.google.com/uc?id={file_id}"
        return {"success": True, "file_id": file_id, "public_url": public_url}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def ensure_public_image_url(image_path: str) -> str:
    if image_path.startswith("http://") or image_path.startswith("https://"):
        return image_path
    upload_result = await upload_image_to_gdrive_and_get_url(image_path)
    if upload_result.get("success") and upload_result.get("public_url"):
        return upload_result["public_url"]
    raise RuntimeError(f"Failed to upload image: {upload_result.get('error')}")

# Tool specs for agent registration

tool_specs = [
    {
        "name": "markdown_to_doc_instruction",
        "description": "Parse markdown (tables, images, headings, etc.) into structured instructions for Google Docs editing. Returns a dict with a summary instruction and a parsed structure.",
        "function": markdown_to_doc_instruction,
        "input_model": None,
    },
    {
        "name": "get_doc",
        "description": "Fetch the full structure/content of a Google Doc by document_id.",
        "function": get_doc,
        "input_model": None,
    },
    {
        "name": "create_google_doc",
        "description": "Create a new Google Doc with a given title.",
        "function": create_doc,
        "input_model": CreateDocInput,
    },
    {
        "name": "edit_google_doc",
        "description": "Insert or append content into an existing Google Doc.",
        "function": edit_doc,
        "input_model": EditDocInput,
    },
    {
        "name": "share_google_doc",
        "description": "Share a Google Doc with a specific email.",
        "function": share_doc,
        "input_model": ShareDocInput,
    },
    {
        "name": "batch_update_doc",
        "description": "Send advanced batchUpdate requests to Google Docs API for formatting, headings, and more. Input: document_id (str), requests (list of dicts) as per Google Docs API.",
        "function": batch_update_doc,
        "input_model": None,
    },
    {
        "name": "upload_image_to_gdrive_and_get_url",
        "description": "Upload a local image file to Google Drive, set it to public, and return a direct image URL.",
        "function": upload_image_to_gdrive_and_get_url,
        "input_model": None,
    }
]
