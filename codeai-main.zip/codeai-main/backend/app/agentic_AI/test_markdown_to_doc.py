import asyncio
from doc_author_agent import get_doc_agent

async def test_markdown_to_doc():
    # Example markdown block for columns
    markdown = """
+-------------------------------------------------------------------------------------------------------+
| Columns                                                                                               |
+-----------------------------------------+-----------------------+-------------------------------------+
| ![A rocket and a headless suit][image1] | ![An iceberg][image2] | ![A dial with a hand on it][image3] |
|                                         |                       |                                     |
| ## Column 1                             | ## Column 2           | ## Column 3                         |
|                                         |                       |                                     |
| This and that                           | This and that         | This and that                       |
+-----------------------------------------+-----------------------+-------------------------------------+

[image1]: https://drive.usercontent.google.com/download?id=1ICnYx1g69E7n-pZqkszNrJetn0oOE05I&authuser=0
[image2]: https://drive.usercontent.google.com/download?id=1ICnYx1g69E7n-pZqkszNrJetn0oOE05I&authuser=0
[image3]: https://drive.usercontent.google.com/download?id=1ICnYx1g69E7n-pZqkszNrJetn0oOE05I&authuser=0"""
    # Document ID to test with (replace with your actual doc ID)
    document_id = "1hbJixZG7EC7t12RVoPpSRpAf0MBctz793Lh3tUrRPIA"
    agent = await get_doc_agent(session_id="test_session")
    # Pass the document_id as a separate argument to avoid LLM or agent altering its case
    # If your agent/arun supports kwargs, use them directly. Otherwise, add a debug print to verify the ID.
    print(f"DEBUG: Using document_id: {document_id}")
    user_message = f"For document with this exact ID: {document_id}, add the following markdown block after the last content in the document. (Do NOT alter the document ID in any way):\n{markdown}"
    response = await agent.arun(user_message)
    print(response)

if __name__ == "__main__":
    asyncio.run(test_markdown_to_doc())
