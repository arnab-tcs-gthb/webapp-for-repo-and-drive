import asyncio
from doc_author_agent import get_doc_agent

async def chat_with_doc_agent():
    agent = await get_doc_agent(
        user_id="test_user",
        session_id="test_session",
        debug_mode=True
    )
    print("Multi-turn Google Docs Agent chat. Type 'exit' to quit.\n")
    doc_id = None
    while True:
        user_message = input("You: ")
        if user_message.lower() in {"exit", "quit"}:
            print("Exiting chat.")
            break
        # If doc_id is available and user message is an edit/share, append doc_id if not present
        if doc_id and "document id" not in user_message.lower() and ("edit" in user_message.lower() or "add" in user_message.lower() or "share" in user_message.lower()):
            user_message += f" Document ID: {doc_id}"
        try:
            response = await agent.arun(user_message)
            # Try to extract doc_id from the first response
            if not doc_id:
                import re
                url_match = re.search(r"https://docs.google.com/document/d/([\w-]+)/edit", str(response))
                if url_match:
                    doc_id = url_match.group(1)
                    print(f"[DEBUG] Extracted document_id: {doc_id}")
            # Prefer response.content, fallback to last assistant message in response.messages
            content = getattr(response, "content", None)
            if not content and hasattr(response, "messages"):
                for msg in reversed(response.messages):
                    if getattr(msg, "role", None) == "assistant" and getattr(msg, "content", None):
                        content = msg.content
                        break
            if content:
                print("Agent:", content)
            else:
                print("Agent:", response)
        except Exception as e:
            print("Error during agent execution:", e)

if __name__ == "__main__":
    asyncio.run(chat_with_doc_agent())
