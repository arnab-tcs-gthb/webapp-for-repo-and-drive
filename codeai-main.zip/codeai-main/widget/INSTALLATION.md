# Chrome Extension Installation Guide

## Argo UAT Chrome Extension

This guide will help you install the Argo UAT Chrome extension for User Acceptance Testing workflows.

## Quick Installation (Recommended)

### Method 1: Load Unpacked Extension (Development)
1. Open Google Chrome
2. Navigate to `chrome://extensions/`
3. Enable **Developer mode** (toggle switch in top-right corner)
4. Click **"Load unpacked"**
5. Select the `widget` folder (or `dist` folder if you built the extension)
6. The extension should now appear in your extensions list

### Method 2: Install from ZIP (Distribution)
1. Run the build script: `./build.sh`
2. Open Google Chrome
3. Navigate to `chrome://extensions/`
4. Enable **Developer mode**
5. Drag and drop the generated `.zip` file onto the extensions page

## Building the Extension

To create a distributable package:

```bash
# Make the build script executable
chmod +x build.sh

# Run the build script
./build.sh
```

This will create:
- `dist/` folder with clean extension files
- `argo-uat-extension-v1.0.zip` for distribution
- `argo-uat-extension-dev-v1.0.zip` with source files

## Extension Features

### 🎯 Core UAT Features
- **Element Selection**: Click any page element to capture detailed information
- **Issue Tracking**: Structured form with priority levels and comments
- **Click Blocking**: Prevent accidental interactions during testing
- **Search Functionality**: Real-time search across all issues
- **URL Tracking**: Automatic page URL capture for each issue

### 🎨 Interface Features
- **Floating Widget**: Toggle on/off via popup
- **Right Panel**: Collapsible issues list
- **Theme Toggle**: Dark/light mode support
- **Smart Margins**: Automatic page adjustment for widget visibility

## Usage Instructions

1. **Activate the Extension**: Click the Argo UAT icon in Chrome toolbar
2. **Enable Floating Widget**: Toggle the switch in the popup
3. **Start Testing**: 
   - Click elements on any webpage to select them
   - Fill out the issue form that appears
   - View all issues in the right panel
   - Search through issues using the search box

## Permissions Explained

The extension requires these permissions:
- **activeTab**: Access the currently active tab for element selection
- **storage**: Save issues and settings locally
- **tabs**: Get information about the current page

## Troubleshooting

### Extension Not Loading
- Ensure all files are present in the widget folder
- Check Chrome DevTools console for errors
- Verify manifest.json syntax

### Features Not Working
- Refresh the page after installing the extension
- Check if the floating widget is enabled in the popup
- Ensure you're not on a restricted page (chrome:// URLs)

### Issues Not Saving
- Check if storage permission is granted
- Clear extension data and reinstall if needed

## Development

For developers wanting to modify the extension:

### File Structure
```
widget/
├── manifest.json       # Extension configuration
├── background.js       # Service worker
├── content.js         # Main functionality (injected into pages)
├── content.css        # Styling for injected UI
├── popup.html         # Extension popup interface
├── popup.js           # Popup functionality
├── popup.css          # Popup styling
├── html2canvas.min.js # Screenshot library
└── icons/             # Extension icons (16, 32, 48, 128px)
```

### Key Components
- **Content Script**: Handles element selection, issue tracking, UI injection
- **Background Script**: Manages extension lifecycle and storage
- **Popup**: Provides quick controls and settings

## Chrome Web Store Submission

To submit to Chrome Web Store:
1. Create a ZIP package using `./build.sh`
2. Create a Chrome Web Store developer account
3. Upload the generated ZIP file
4. Fill out store listing details
5. Submit for review

## Support

For issues or questions:
- Check the browser console for error messages
- Verify all permissions are granted
- Test on different websites to isolate issues
