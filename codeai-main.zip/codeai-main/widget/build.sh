#!/bin/bash

# Chrome Extension Build Script for Argo UAT
# This script creates a distributable package for the Chrome extension

echo "🚀 Building Argo UAT Chrome Extension..."

# Define variables
EXTENSION_NAME="argo-uat-extension"
VERSION=$(grep '"version"' manifest.json | sed 's/.*"version": *"\([^"]*\)".*/\1/')
BUILD_DIR="dist"
ZIP_NAME="${EXTENSION_NAME}-v${VERSION}.zip"

# Create build directory
echo "📁 Creating build directory..."
rm -rf $BUILD_DIR
mkdir -p $BUILD_DIR

# Copy all necessary files to build directory
echo "📋 Copying extension files..."
cp manifest.json $BUILD_DIR/
cp background.js $BUILD_DIR/
cp content.js $BUILD_DIR/
cp content.css $BUILD_DIR/
cp popup.html $BUILD_DIR/
cp popup.js $BUILD_DIR/
cp popup.css $BUILD_DIR/
cp html2canvas.min.js $BUILD_DIR/
cp -r icons $BUILD_DIR/

# Validate manifest.json
echo "✅ Validating manifest.json..."
if ! python3 -m json.tool $BUILD_DIR/manifest.json > /dev/null 2>&1; then
    echo "❌ Error: Invalid JSON in manifest.json"
    exit 1
fi

# Create zip file for distribution
echo "📦 Creating distribution package..."
cd $BUILD_DIR
zip -r ../$ZIP_NAME *
cd ..

# Create developer package (includes source files)
DEV_ZIP_NAME="${EXTENSION_NAME}-dev-v${VERSION}.zip"
echo "🔧 Creating developer package..."
zip -r $DEV_ZIP_NAME * -x "dist/*" "*.git*" "*.DS_Store*" "build.sh" "*.log"

echo "✅ Build complete!"
echo "📦 Distribution package: $ZIP_NAME"
echo "🔧 Developer package: $DEV_ZIP_NAME"
echo ""
echo "📋 Installation Instructions:"
echo "1. Open Chrome and go to chrome://extensions/"
echo "2. Enable 'Developer mode' (toggle in top-right)"
echo "3. Click 'Load unpacked' and select the 'dist' folder"
echo "   OR"
echo "   Drag and drop the $ZIP_NAME file onto the extensions page"
echo ""
echo "🎯 For Chrome Web Store submission, use: $ZIP_NAME"
