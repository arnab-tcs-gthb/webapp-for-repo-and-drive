document.addEventListener('DOMContentLoaded', function() {
    // Initialize the widget
    //initializeWidget();
    
    // Set up event listeners
    setupEventListeners();
    
    // Load saved data
    loadSavedData();
});

// function initializeWidget() {
    // Update current time
    //updateCurrentTime();
    //setInterval(updateCurrentTime, 1000);
    
    // Get current tab URL
    //getCurrentTabInfo();
// }

function setupEventListeners() {
    // Widget activator toggle
    document.getElementById('widget-activator').addEventListener('change', toggleFloatingWidget);
    
    // Save page button
    // document.getElementById('save-page').addEventListener('click', savePage);
    
    // Copy URL button
    // document.getElementById('copy-url').addEventListener('click', copyCurrentUrl);
    
    // Toggle theme button
    document.getElementById('toggle-theme').addEventListener('click', toggleTheme);
    
    // Save notes button
    // document.getElementById('save-notes').addEventListener('click', saveNotes);
    
    // Auto-save notes on input
    // document.getElementById('notes').addEventListener('input', debounce(saveNotes, 1000));
}

// function updateCurrentTime() {
//     const now = new Date();
//     const timeString = now.toLocaleTimeString();
//     const dateString = now.toLocaleDateString();
//     document.getElementById('current-time').textContent = `${dateString} ${timeString}`;
// }

// function getCurrentTabInfo() {
//     chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//         if (tabs[0]) {
//             const url = tabs[0].url;
//             const title = tabs[0].title;
//             document.getElementById('current-url').textContent = `${title}`;
//         }
//     });
// }

// function savePage() {
//     chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//         if (tabs[0]) {
//             const pageData = {
//                 url: tabs[0].url,
//                 title: tabs[0].title,
//                 timestamp: new Date().toISOString()
//             };
            
//             // Get existing saved pages
//             chrome.storage.local.get(['savedPages'], function(result) {
//                 const savedPages = result.savedPages || [];
//                 savedPages.push(pageData);
                
//                 chrome.storage.local.set({savedPages: savedPages}, function() {
//                     showNotification('Page saved successfully!');
//                 });
//             });
//         }
//     });
// }

// function copyCurrentUrl() {
//     chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//         if (tabs[0]) {
//             navigator.clipboard.writeText(tabs[0].url).then(function() {
//                 showNotification('URL copied to clipboard!');
//             }).catch(function(err) {
//                 console.error('Failed to copy URL: ', err);
//                 showNotification('Failed to copy URL');
//             });
//         }
//     });
// }

function toggleTheme() {
    const body = document.body;
    body.classList.toggle('dark-theme');
    
    const isDarkTheme = body.classList.contains('dark-theme');
    chrome.storage.local.set({darkTheme: isDarkTheme}, function() {
        showNotification(`Switched to ${isDarkTheme ? 'dark' : 'light'} theme`);
    });
}

// function saveNotes() {
//     const notes = document.getElementById('notes').value;
//     chrome.storage.local.set({userNotes: notes}, function() {
//         showNotification('Notes saved!');
//     });
// }

function loadSavedData() {
    // Load theme preference
    chrome.storage.local.get(['darkTheme'], function(result) {
        if (result.darkTheme) {
            document.body.classList.add('dark-theme');
        }
    });
    
    // Load floating widget preference
    chrome.storage.local.get(['floatingWidgetEnabled'], function(result) {
        const isEnabled = result.floatingWidgetEnabled !== false; // Default to true
        document.getElementById('widget-activator').checked = isEnabled;
    });
    
    // Load saved notes
    // chrome.storage.local.get(['userNotes'], function(result) {
    //     if (result.userNotes) {
    //         document.getElementById('notes').value = result.userNotes;
    //     }
    // });
}

function showNotification(message) {
    // Create a temporary notification element
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        background: rgba(0,0,0,0.8);
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after 2 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 2000);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function toggleFloatingWidget() {
    const isEnabled = document.getElementById('widget-activator').checked;
    
    // Save the preference
    chrome.storage.local.set({floatingWidgetEnabled: isEnabled}, function() {
        showNotification(`Floating widget ${isEnabled ? 'enabled' : 'disabled'}`);
    });
    
    // Send message to all active tabs to show/hide the floating widget
    chrome.tabs.query({}, function(tabs) {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
                action: 'toggleFloatingWidget',
                enabled: isEnabled
            }).catch(() => {
                // Ignore errors for tabs that don't have the content script
            });
        });
    });
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);
