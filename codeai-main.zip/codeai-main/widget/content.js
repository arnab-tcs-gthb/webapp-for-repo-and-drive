// Content script that runs on all web pages
console.log('Chrome Widget content script loaded');
document.body.setAttribute('data-widget', 'argoWidget');
// Check if html2canvas is available
if (typeof html2canvas !== 'undefined') {
    console.log('html2canvas library loaded successfully');
} else {
    console.warn('html2canvas library not found');
}

// Store original styles to restore later
let originalBodyStyle = null;
let originalHeaderStyle = null;
let marginApplied = false;
let clickBlockingActive = false;
let clickInterceptor = null;
let elementSelectionMode = false;
let elementSelectionInterceptor = null;
let selectedElementsData = [];
let issuesList = [];
let selectedElementForForm = null;
let currentlyHighlightedElement = null;

// Function to add margin to page elements
function addPageMargins() {
    if (marginApplied) return; // Already applied
    
    const body = document.body;
    const header = document.querySelector('header') || 
                  document.querySelector('nav') || 
                  document.querySelector('.header') || 
                  document.querySelector('.navbar') ||
                  document.querySelector('#header') ||
                  document.querySelector('#navbar');
    
    // Store original styles
    if (body) {
        originalBodyStyle = {
            marginTop: body.style.marginTop,
            paddingTop: body.style.paddingTop
        };
          // Add transition data attribute
        body.setAttribute('data-argo-uat-margin-applied', 'true');
        
        // Apply margin to body
        const currentMarginTop = parseInt(window.getComputedStyle(body).marginTop) || 0;
        body.style.marginTop = (currentMarginTop + 90) + 'px';
    }
      // If there's a header element, add margin to it as well as body (but only if not fixed positioned)
    if (header) {
        const headerStyle = window.getComputedStyle(header);
        const isFixedPosition = headerStyle.position === 'fixed';
        
        if (!isFixedPosition) {
            originalHeaderStyle = {
                marginTop: header.style.marginTop,
                paddingTop: header.style.paddingTop
            };
              // Add transition data attribute
            header.setAttribute('data-argo-uat-margin-applied', 'true');
            
            const currentHeaderMargin = parseInt(window.getComputedStyle(header).marginTop) || 0;
            header.style.marginTop = (currentHeaderMargin) + 'px';
            
            console.log('Argo UAT: Applied margins to both body and header elements');
        } else {
            console.log('Argo UAT: Header is fixed positioned, skipping header margin');
        }
    }
    
    marginApplied = true;
    console.log('Argo UAT: Page margins added (90px)');
}

// Function to remove margin from page elements
function removePageMargins() {
    if (!marginApplied) return; // Not applied
    
    const body = document.body;
    const header = document.querySelector('header') || 
                  document.querySelector('nav') || 
                  document.querySelector('.header') || 
                  document.querySelector('.navbar') ||
                  document.querySelector('#header') ||
                  document.querySelector('#navbar');
    
    // Restore original body styles
    if (body && originalBodyStyle) {
        body.style.marginTop = originalBodyStyle.marginTop;
        body.style.paddingTop = originalBodyStyle.paddingTop;
        body.removeAttribute('data-argo-uat-margin-applied');
    }
      // Restore original header styles (only if they were modified)
    if (header && originalHeaderStyle) {
        const headerStyle = window.getComputedStyle(header);
        const isFixedPosition = headerStyle.position === 'fixed';
        
        // Only restore if header is not fixed positioned (meaning we applied margins to it)
        if (isFixedPosition) {
            header.style.marginTop = originalHeaderStyle.marginTop;
            header.style.paddingTop = originalHeaderStyle.paddingTop;
            header.removeAttribute('data-argo-uat-margin-applied');
        }
    }
    
    marginApplied = false;
    console.log('Argo UAT: Page margins removed');
}

// Add a floating widget button to the page (optional)
function createFloatingWidget() {
    // Check if widget already exists
    const existingWidget = document.getElementById('chrome-widget-float');
    if (existingWidget) {
        console.log('Argo UAT: Widget already exists, ensuring it is properly initialized');
        // Widget exists, just ensure it's visible and properly set up
        existingWidget.style.display = 'flex';
        
        // Check and apply saved collapse state
        chrome.storage.local.get(['widgetCollapsed'], function(result) {
            const isCollapsed = result.widgetCollapsed || false;
            if (isCollapsed) {
                existingWidget.style.height = '5px';
                existingWidget.setAttribute('data-collapsed', 'true');
                
                const collapseButton = existingWidget.querySelector('#widget-collapse-btn');
                if (collapseButton) {
                    collapseButton.innerHTML = '▼';
                    collapseButton.title = 'Expand Widget';
                }
                
                // Hide all content except collapse button
                const contentDivs = existingWidget.querySelectorAll('div');
                contentDivs.forEach(div => {
                    if (div.id !== 'widget-collapse-btn' && !div.contains(collapseButton)) {
                        div.style.display = 'none';
                        console.log(div)
                    }
                });
                
                removePageMargins();
            } else {
                existingWidget.setAttribute('data-collapsed', 'false');
                addPageMargins();
            }
        });
        
        activateClickBlocking();
        createIssuesList();
        
        // Reinitialize widget buttons to ensure they work properly
        setTimeout(() => {
            reinitializeWidgetButtons();
        }, 100);
        return;
    }

    // Check if floating widget is enabled
    chrome.storage.local.get(['floatingWidgetEnabled'], function(result) {
        const isEnabled = result.floatingWidgetEnabled !== false; // Default to true
        
        if (!isEnabled) {
            return; // Don't create if disabled
        }
        
        const floatingContainer = document.createElement('div');
        floatingContainer.id = 'chrome-widget-float';
        floatingContainer.title = 'Argo UAT Widget';
          // Create inner content for the container
        floatingContainer.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 0 20px; width: 100%; height: 100%;">
                <div style="display: flex; align-items: center; gap: 15px; position: relative;">
                    <img src="${chrome.runtime.getURL('icons/icon128.png')}" alt="Argo UAT Logo" style="
                        width: 60px;
                        height: 60px;
                        border-radius: 4px;
                        object-fit: contain;
                    ">
                    <span style="color: #333; font-size: 16px; font-weight: 500; font-family: Arial, sans-serif;">Element Annotation Tool</span>
                </div>
                <div style="position: relative;">
                    <span style="color: #555; font-size: 14px; font-family: Arial, sans-serif; margin-right: 10px;">Use the selected tool to annotate elements</span>
                    <button id="agro-select-element-btn" style="
                        background: #007bee;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 8px;
                        font-size: 14px;
                        font-weight: 500;
                        cursor: pointer;
                        transition: all 0.3s ease;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                        margin-right: 10px;
                    ">Select Element</button>
                    <button id="collapse-toggle-btn" style="
                        background: #007bee;
                        color: white;
                        border: none;
                        padding: 10px 16px;
                        border-radius: 8px;
                        font-size: 14px;
                        font-weight: 500;
                        cursor: pointer;
                        transition: all 0.3s ease;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                    ">📁 Annotations</button><div id="agro-element-dropdown" style="
                        position: absolute;
                        top: 100%;
                        right: 0;
                        background: white;
                        border: 1px solid #ddd;
                        border-radius: 8px;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                        min-width: 500px;
                        max-height: 80vh;
                        overflow-y: auto;
                        z-index: 10002;
                        display: none;
                        margin-top: 5px;
                    ">
                        <div style="padding: 15px; border-bottom: 1px solid #eee;">
                            <h2 style="margin: 0; color: #333; font-size: 20px;">Element Details Form</h2>
                        </div>
                          <!-- Element Form Section -->
                        <div id="agro-element-form" style="padding: 20px; display: none;">
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 16px;">Element Name <span style="color:red;">*</span></label>
                                <input type="text" id="element-name-input" placeholder="Enter element name..." style="
                                    width: 100%;
                                    padding: 8px;
                                    border: 1px solid #ddd;
                                    border-radius: 4px;
                                    font-size: 14px;
                                    box-sizing: border-box;
                                ">
                            </div>
                            
                            <!-- Element Preview Section - moved here -->
                            <div id="agro-selected-element-info" style="margin-bottom: 15px; padding: 12px; background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px; display: none;">
                                <h3 style="margin: 0 0 8px 0; color: #333; font-size: 16px; text-align:center;">Element Preview</h3>
                                <div id="selected-element-preview" style="font-size: 12px; color: #666;"></div>
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 16px;">Issue Type <span style="color:red;">*</span></label>
                                <select id="issue-type-select" style="
                                    width: 100%;
                                    padding: 8px;
                                    border: 1px solid #ddd;
                                    border-radius: 4px;
                                    font-size: 14px;
                                    box-sizing: border-box;
                                ">
                                    <option value="">Select issue type...</option>
                                    <option value="bug">Bug</option>
                                    <option value="enhancement">Enhancement</option>
                                    <option value="usability">Usability Issue</option>
                                    <option value="performance">Performance</option>
                                    <option value="accessibility">Accessibility</option>
                                    <option value="visual">Visual Issue</option>
                                    <option value="functional">Functional Issue</option>
                                </select>
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 16px;">Priority <span style="color:red;">*</span></label>
                                <select id="priority-select" style="
                                    width: 100%;
                                    padding: 8px;
                                    border: 1px solid #ddd;
                                    border-radius: 4px;
                                    font-size: 14px;
                                    box-sizing: border-box;
                                ">
                                    <option value="">Select priority...</option>
                                    <option value="critical">Critical</option>
                                    <option value="high">High</option>
                                    <option value="medium">Medium</option>
                                    <option value="low">Low</option>
                                </select>
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-weight: bold; margin-bottom: 5px; color: #333; font-size: 16px;">Comment <span style="color:red;">*</span></label>
                                <textarea id="element-comment-input" placeholder="Add your comment about this element..." style="
                                    width: 100%;
                                    height: 80px;
                                    padding: 8px;
                                    border: 1px solid #ddd;
                                    border-radius: 4px;
                                    font-size: 14px;
                                    resize: vertical;
                                    box-sizing: border-box;
                                    font-family: Arial, sans-serif;
                                "></textarea>
                            </div>
                            
                            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                                <button id="cancel-element-btn" style="
                                    background: #666;
                                    color: white;
                                    border: none;
                                    padding: 10px 20px;
                                    border-radius: 8px;
                                    cursor: pointer;
                                    font-size: 14px;
                                ">Cancel</button>
                                <button id="add-to-list-btn" style="
                                    background: #2469BC;
                                    color: white;
                                    border: none;
                                    padding: 10px 20px;
                                    border-radius: 8px;
                                    cursor: pointer;
                                    font-size: 14px;
                                    font-weight: bold;
                                ">Add to List</button>
                            </div>
                        </div>
                    </div>                
                </div>
            </div>
            
            <!-- Widget Collapse Button -->
            <div style="
                position: absolute;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%);
                z-index: 10001;
                height: 30px;
                width: 30px;
            ">
                <button id="widget-collapse-btn" style="
                    background: #2469BC;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    width: 30px;
                    height: 30px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 12px;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
                    transform: translateY(15px) scale(1);
                    transition: all 0.3s ease;
                    margin: 0;
                " title="Collapse Widget">
                    ▲
                </button>
            </div>
        `;
          // Style the floating container
        floatingContainer.style.cssText = `
            position: fixed;
            top: 0;
            right: 0;
            left: 0;
            width: 100%;
            height: 90px;
            background: #e5e7eb;
            border-radius: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            z-index: 10000;
            transition: all 0.3s ease;
            border: 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            cursor: default;
        `;
        
        // Add event listener for the select element button
        const selectButton = floatingContainer.querySelector('#agro-select-element-btn');
        selectButton.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleElementSelectionMode();
        });

        // Add event listener for the collapse button
        const collapseButton = floatingContainer.querySelector('#collapse-toggle-btn');
          // Load saved collapsed state and set initial button state
        chrome.storage.local.get(['issuesListCollapsed'], function(result) {
            const isCollapsed = result.issuesListCollapsed || false;
            updateCollapseButtonState(collapseButton, isCollapsed);
            
            // Set initial enabled/disabled state based on existing issues
            updateAnnotationsButtonState();
        });

        collapseButton.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Check if there are any issues before allowing click
            // if (!issuesList || issuesList.length === 0) {
            //     e.preventDefault();
            //     showNoIssuesMessage(collapseButton);
            //     return false;
            // }
            
            toggleAnnotationsPanel();
        });        
        
        // Add hover effects for both buttons
        [selectButton, collapseButton].forEach(button => {
            button.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.05)';
                this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
            });

            button.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
                this.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
            });
        });
        
        // Add event listener for the widget collapse button
        const widgetCollapseButton = floatingContainer.querySelector('#widget-collapse-btn');
        const widgetCollapseList = document.querySelector('#agro-issues-list');
        widgetCollapseButton.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleWidgetCollapse();
            if (document.querySelector('#agro-issues-list').style.display !== 'none') toggleAnnotationsPanel();
        });

        // Add hover effect for widget collapse button
        widgetCollapseButton.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(15px) scale(1.1)';
            this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.4)';
        });

        widgetCollapseButton.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(15px) scale(1)';
            this.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
        });

        // Add click outside to close dropdown
        document.addEventListener('click', function(e) {
            const dropdown = document.getElementById('agro-element-dropdown');
            const selectButton = document.getElementById('agro-select-element-btn');
            
            if (dropdown && !selectButton.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.style.display = 'none';
            }        
        });
        
        document.body.appendChild(floatingContainer);
        
        // Initialize widget collapse state
        chrome.storage.local.get(['widgetCollapsed'], function(result) {
            const isCollapsed = result.widgetCollapsed || false;
            if (isCollapsed) {
                // Apply collapsed state
                floatingContainer.style.height = '5px';
                floatingContainer.setAttribute('data-collapsed', 'true');
                
                const collapseButton = floatingContainer.querySelector('#widget-collapse-btn');
                if (collapseButton) {
                    collapseButton.innerHTML = '▼';
                    collapseButton.title = 'Expand Widget';
                }
                
                // Hide all content except collapse button
                const contentDivs = floatingContainer.querySelectorAll('#chrome-widget-float > div');
                contentDivs.forEach(div => {
                    if (div.id !== 'widget-collapse-btn' && !div.contains(collapseButton)) {
                        div.style.display = 'none';
                        console.log(div)
                    }
                });
                
                // Don't add page margins when collapsed
                removePageMargins();
            } else {
                floatingContainer.setAttribute('data-collapsed', 'false');
            }
        });
        
        // Create right column list
        createIssuesList();
        
        // Add form event listeners
        setupFormEventListeners();
        
        // Add page margins when widget is created
        addPageMargins();
        
        // Activate click blocking
        activateClickBlocking();
        
        // Initialize widget buttons with proper state
        setTimeout(() => {
            reinitializeWidgetButtons();
        }, 200);
    });
}

// Function to activate click blocking using event interception
function activateClickBlocking() {
    if (clickBlockingActive) return; // Already active    
        // Create click interceptor function
        clickInterceptor = function(event) {
        // Skip if we're in element selection mode
        if (elementSelectionMode) {
            return; // Let element selection handle it
        }
          // Skip if click is on our floating container, issues list, or collapse button
        if (event.target.closest('#chrome-widget-float') || 
            event.target.closest('#agro-issues-list') || 
            event.target.closest('#collapse-toggle-btn')) {
            return; // Allow clicks on our widget, issues list, and collapse button
        }
        
        // Check if the target is a clickable element
        const isClickable = isElementClickable(event.target);
        
        if (isClickable) {
            // event.preventDefault();
            // event.stopPropagation();
            // event.stopImmediatePropagation();
            
            // // Show blocked message at click location
            // showClickBlockedMessage(event.clientX, event.clientY);
            
            console.log('Argo UAT: Click blocked on', event.target.tagName.toLowerCase());
        }
    };
    
    // Add event listener to capture all clicks
    document.addEventListener('click', clickInterceptor, true); // Use capture phase
    document.addEventListener('mousedown', clickInterceptor, true);
    document.addEventListener('mouseup', clickInterceptor, true);
    
    clickBlockingActive = true;
    console.log('Argo UAT: Click blocking activated using event interception');
}

// Function to deactivate click blocking
function deactivateClickBlocking() {
    if (!clickBlockingActive) return; // Not active
    
    if (clickInterceptor) {
        document.removeEventListener('click', clickInterceptor, true);
        document.removeEventListener('mousedown', clickInterceptor, true);
        document.removeEventListener('mouseup', clickInterceptor, true);
        clickInterceptor = null;
    }
    
    clickBlockingActive = false;
    console.log('Argo UAT: Click blocking deactivated');
}

// Function to check if an element is clickable
function isElementClickable(element) {
    // Check for common clickable elements and attributes
    const clickableSelectors = [
        'a', 'button', 'img', 'input[type="button"]', 'input[type="submit"]', 'input[type="reset"]',
        'select', 'textarea', 'input[type="text"]', 'input[type="email"]', 'input[type="password"]',
        'input[type="number"]', 'input[type="tel"]', 'input[type="url"]', 'input[type="search"]',
        'input[type="checkbox"]', 'input[type="radio"]', '[contenteditable="true"]'
    ];
    
    // Check if element matches clickable selectors
    if (clickableSelectors.some(selector => element.matches(selector))) {
        return true;
    }
    
    // Check for elements with click handlers or roles
    if (element.hasAttribute('onclick') || 
        element.getAttribute('role') === 'button' ||
        element.classList.contains('btn') ||
        element.classList.contains('button') ||
        (element.hasAttribute('tabindex') && element.getAttribute('tabindex') !== '-1')) {
        return true;
    }
    
    // Check if element has cursor pointer (common for clickable elements)
    const computedStyle = window.getComputedStyle(element);
    if (computedStyle.cursor === 'pointer') {
        return true;
    }
    
    return false;
}

// Function to show a message when click is blocked
function showClickBlockedMessage(x, y) {
    const message = document.createElement('div');
    message.className = 'agro-uat-blocked-message';
    message.textContent = 'Element selection mode active - Click blocked';
    
    message.style.cssText = `
        position: fixed;
        top: ${y - 30}px;
        left: ${x - 100}px;
        background: rgba(255, 0, 0, 0.9);
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-family: Arial, sans-serif;
        z-index: 10001;
        pointer-events: none;
        transform: translateX(-50%);
        animation: fadeInOut 2s ease forwards;
    `;
      // Add CSS animation
    if (!document.querySelector('#agro-uat-animations')) {
        const style = document.createElement('style');
        style.id = 'agro-uat-animations';        style.textContent = `
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translateX(-50%) translateY(10px); }
                20% { opacity: 1; transform: translateX(-50%) translateY(0); }
                80% { opacity: 1; transform: translateX(-50%) translateY(0); }
                100% { opacity: 0; transform: translateX(-50%) translateY(-10px); }
            }
            
            @keyframes slideInFromTop {
                0% { 
                    opacity: 0; 
                    transform: translateY(-20px); 
                    max-height: 0;
                    padding-top: 0;
                    padding-bottom: 0;
                }
                100% { 
                    opacity: 1; 
                    transform: translateY(0); 
                    max-height: 200px;
                    padding-top: 12px;
                    padding-bottom: 12px;
                }
            }
            
            .agro-create-jira-btn:hover:not(:disabled) {
                background: #0065FF !important;
                transform: translateY(-1px);
                box-shadow: 0 4px 8px rgba(0,82,204,0.3) !important;
            }
            
            .agro-create-jira-btn:active:not(:disabled) {
                transform: translateY(0);
                box-shadow: 0 2px 4px rgba(0,82,204,0.2) !important;
            }
            
            .jira-response-details {
                animation: slideInFromTop 0.4s ease-out forwards;
                overflow: hidden;
            }
        `;
        document.head.appendChild(style);
    }
      document.body.appendChild(message);
    
    // Remove message after animation
    setTimeout(() => {
        if (message.parentNode) {
            message.parentNode.removeChild(message);
        }
    }, 2000);
}

// Create the floating widget when the page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeWidget);
} else {
    initializeWidget();
}

function initializeWidget() {
    // Check for URL parameter first
    const urlParams = new URLSearchParams(window.location.search);
    const shouldOpenFromUrl = urlParams.has('openArgoWidget');
    
    // Extract project_id and page_id parameters
    const projectId = urlParams.get('project_id');
    const pageId = urlParams.get('page_id');
    
    // Store these parameters globally for use in annotations
    window.argoProjectId = projectId;
    window.argoPageId = pageId;
    
    console.log('Argo UAT: URL Parameters detected:', {
        project_id: projectId,
        page_id: pageId,
        openArgoWidget: shouldOpenFromUrl
    });
    
    if (shouldOpenFromUrl) {
        console.log('Argo UAT: Detected openArgoWidget parameter in URL - forcing widget activation');

        // Force enable the widget and save preference
        chrome.storage.local.set({floatingWidgetEnabled: true}, function() {
            createFloatingWidget();
        });

        return;
    }
    
    // Check if floating widget should be enabled from storage
    chrome.storage.local.get(['floatingWidgetEnabled'], function(result) {
        const isEnabled = result.floatingWidgetEnabled !== false; // Default to true
        
        if (isEnabled) {
            createFloatingWidget();
        }
    });
}

// Function to check URL parameters for widget activation
function checkUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Extract project_id and page_id parameters
    const projectId = urlParams.get('project_id');
    const pageId = urlParams.get('page_id');
    
    // Store these parameters globally for use in annotations
    window.argoProjectId = projectId;
    window.argoPageId = pageId;
    
    console.log('Argo UAT: URL Parameters detected:', {
        project_id: projectId,
        page_id: pageId
    });
    
    // Check for openArgoWidget parameter
    if (urlParams.has('openArgoWidget')) {
        console.log('Argo UAT: URL parameter detected - activating widget');
          // Force activate the widget regardless of storage setting
        const existingWidget = document.getElementById('chrome-widget-float');
        
        if (existingWidget) {
            existingWidget.style.display = 'flex';
            addPageMargins();
            activateClickBlocking();
            createIssuesList();
            
            // Reinitialize widget buttons when widget is shown again
            //reinitializeWidgetButtons();
        } else {
            createFloatingWidget();
        }

        
        
        // Update storage to reflect the change
        chrome.storage.local.set({floatingWidgetEnabled: true});
        
        // Optional: Clean up URL parameter after activation
        cleanUpUrlParameter('openArgoWidget');
        
        return true;
    }
    
    return false;
}

// Function to remove the URL parameter after activation
function cleanUpUrlParameter(paramName) {
    try {
        const url = new URL(window.location.href);
        const urlParams = new URLSearchParams(url.search);
        
        if (urlParams.has(paramName)) {
            urlParams.delete(paramName);
            
            // Construct new URL without the parameter
            const newUrl = url.origin + url.pathname + 
                          (urlParams.toString() ? '?' + urlParams.toString() : '') + 
                          url.hash;
            
            // Update the URL without reloading the page
            history.replaceState(null, '', newUrl);
            currentUrl = newUrl; // Update our tracked URL
            
            console.log('Argo UAT: Cleaned up URL parameter:', paramName);
        }
    } catch (error) {
        console.warn('Argo UAT: Could not clean up URL parameter:', error);
    }
}

// Listen for messages from the popup or background script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'getPageInfo') {
        sendResponse({
            url: window.location.href,
            title: document.title,
            selectedText: window.getSelection().toString()
        });
    }    if (request.action === 'toggleFloatingWidget') {
        // Extract URL parameters when widget is toggled
        const urlParams = new URLSearchParams(window.location.search);
        const projectId = urlParams.get('project_id');
        const pageId = urlParams.get('page_id');
        
        // Store these parameters globally
        window.argoProjectId = projectId;
        window.argoPageId = pageId;
        
        if (projectId || pageId) {
            console.log('Argo UAT: URL Parameters detected on widget toggle:', {
                project_id: projectId,
                page_id: pageId
            });
        }
        
        const widget = document.getElementById('chrome-widget-float');
        
        if (request.enabled) {
            // Show/create the widget
            if (!widget) {
                createFloatingWidget();
            } else {
                widget.style.display = 'flex';
                addPageMargins();
                activateClickBlocking();
                createIssuesList(); // Recreate issues list
                
                // Reinitialize widget buttons when widget is toggled on
                reinitializeWidgetButtons();
            }
        } else {
            // Hide the widget
            if (widget) {
                widget.style.display = 'none';
                removePageMargins();
                deactivateClickBlocking();
                deactivateElementSelection(); // Also deactivate element selection
                removeIssuesList(); // Remove issues list
            }
        }
    }
    
    if (request.action === 'highlightText') {
        // Example: highlight selected text
        const selection = window.getSelection();
        if (selection.rangeCount > 0) {
            const range = selection.getRangeAt(0);
            const span = document.createElement('span');
            span.style.backgroundColor = 'yellow';
            span.style.padding = '2px';
            try {
                range.surroundContents(span);
            } catch (e) {
                console.log('Could not highlight selection:', e);
            }        
        }
    }
});

// Monitor URL changes for single-page applications
let currentUrl = window.location.href;

// Function to handle URL changes
function handleUrlChange() {
    const newUrl = window.location.href;
    
    if (newUrl !== currentUrl) {
        console.log('Argo UAT: URL changed from', currentUrl, 'to', newUrl);
        currentUrl = newUrl;
        
        // Check for URL parameters on the new URL
        setTimeout(() => {
            checkUrlParameters();
        }, 100); // Small delay to ensure page is ready
    }
}

// Listen for popstate events (back/forward navigation)
window.addEventListener('popstate', handleUrlChange);

// Override pushState and replaceState to detect programmatic URL changes
(function() {
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    
    history.pushState = function() {
        originalPushState.apply(history, arguments);
        setTimeout(handleUrlChange, 0);
    };
    
    history.replaceState = function() {
        originalReplaceState.apply(history, arguments);
        setTimeout(handleUrlChange, 0);
    };
})();


// Also check periodically for URL changes (fallback)
setInterval(() => {
    const newUrl = window.location.href;
    if (newUrl !== currentUrl) {
        handleUrlChange();
    }
}, 1000);

// Optional: Add keyboard shortcut listener
document.addEventListener('keydown', function(e) {
    // Shift+W to toggle widget visibility
    if (e.shiftKey && e.key === 'W') {
        const widget = document.getElementById('chrome-widget-float');
        if (widget) {
            const isVisible = widget.style.display !== 'none';
            
            if (isVisible) {
                widget.style.display = 'none';
                removePageMargins();
                deactivateClickBlocking();
                deactivateElementSelection(); // Also deactivate element selection
                removeIssuesList(); // Remove issues list
                
                // Update storage to reflect the change
                chrome.storage.local.set({floatingWidgetEnabled: false});
            } else {
                widget.style.display = 'flex';
                addPageMargins();
                activateClickBlocking();
                createIssuesList(); // Recreate issues list
                
                // Reinitialize widget buttons when widget is toggled on
                reinitializeWidgetButtons();
                
                // Update storage to reflect the change
                chrome.storage.local.set({floatingWidgetEnabled: true});
            }
        }
    }
});

// Function to toggle element selection mode
function toggleElementSelectionMode() {
    if (elementSelectionMode) {
        deactivateElementSelection();
    } else {
        activateElementSelection();
    }
}

// Function to activate element selection mode
function activateElementSelection() {
    if (elementSelectionMode) return; // Already active
    
    // Create element selection interceptor
    elementSelectionInterceptor = function(event) {
        // Skip if click is on our floating container, issues list, or collapse button
        if (event.target.closest('#chrome-widget-float') || 
            event.target.closest('#agro-issues-list') || 
            event.target.closest('#collapse-toggle-btn')) {
            return; // Allow clicks on our widget, issues list, and collapse button
        }
        
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        
        // Capture element information
        const elementInfo = captureElementInfo(event.target);
        selectedElementForForm = elementInfo;
        
        // Show element form
        showElementForm(elementInfo);
        
        // Add visual feedback
        highlightSelectedElement(event.target);
        
        console.log('Argo UAT: Element selected for form:', elementInfo);
    };
    
    // Add event listener for element selection
    document.addEventListener('click', elementSelectionInterceptor, true);
    
    // Update button appearance
    const selectButton = document.getElementById('agro-select-element-btn');
    if (selectButton) {
        selectButton.textContent = 'Stop Selecting';
        selectButton.style.background = 'rgb(247, 12, 142)';
    }
    
    // Add cursor style to indicate selection mode
    document.body.style.cursor = 'crosshair';
    
    elementSelectionMode = true;
    console.log('Argo UAT: Element selection mode activated');
}

// Function to deactivate element selection mode
function deactivateElementSelection() {
    if (!elementSelectionMode) return; // Not active
    
    if (elementSelectionInterceptor) {
        document.removeEventListener('click', elementSelectionInterceptor, true);
        elementSelectionInterceptor = null;
    }
    
    // Restore button appearance
    const selectButton = document.getElementById('agro-select-element-btn');
    if (selectButton) {
        selectButton.textContent = 'Select Element';
        selectButton.style.background = '#007bee';
    }
      // Restore cursor
    document.body.style.cursor = '';
    
    // Remove any current highlighting when exiting selection mode
    removeElementHighlight();
    
    elementSelectionMode = false;
    console.log('Argo UAT: Element selection mode deactivated');
}

// Function to show element form in dropdown
function showElementForm(elementInfo) {
    const dropdown = document.getElementById('agro-element-dropdown');
    const form = document.getElementById('agro-element-form');
    
    if (dropdown && form) {
        // Show the dropdown and form
        dropdown.style.display = 'block';
        form.style.display = 'block';
        
        // Update the element preview
        updateElementPreview(elementInfo);
        
        // Focus on the element name input
        const nameInput = document.getElementById('element-name-input');
        if (nameInput) {
            nameInput.focus();
        }
    }
}

// Function to update element preview in the form
function updateElementPreview(elementInfo) {
    const previewContainer = document.getElementById('agro-selected-element-info');
    const previewContent = document.getElementById('selected-element-preview');
    
    if (previewContainer && previewContent && elementInfo) {
        previewContainer.style.display = 'block';
        
        // Create preview HTML with image if available
        let previewHTML = `
            <div style="display: flex; align-items: start; gap: 12px;">
                <div style="flex: 1;">
                    <div style="margin-bottom: 8px;">
                        <strong style="color: #333;">Element:</strong> 
                        <span style="color: #333;">&lt;${elementInfo.tagName.toLowerCase()}&gt;</span>
                    </div>
                    
                    ${elementInfo.textContent !== 'N/A' ? `
                        <div style="margin-bottom: 8px;">
                            <strong style="color: #333;">Text:</strong> 
                            <span style="color: #666; font-style: italic;">"${elementInfo.textContent}"</span>
                        </div>
                    ` : ''}
                    
                    <div style="margin-bottom: 8px;">
                        <strong style="color: #333;">Size:</strong> 
                        <span style="color: #666;">${elementInfo.position.width} × ${elementInfo.position.height}px</span>
                    </div>
                    
                    <div>
                        <strong style="color: #333;">Position:</strong> 
                        <span style="color: #666;">(${elementInfo.position.x}, ${elementInfo.position.y})</span>
                    </div>
                </div>
        `;
        
        // Add screenshot if available
        if (elementInfo.screenshot) {
            previewHTML += `
                <div style="flex-shrink: 0;">
                    <img src="${elementInfo.screenshot}" alt="Element screenshot" style="
                        max-width: 200px;
                        max-height: 100px;
                        border: 1px solid #ddd;
                        border-radius: 4px;
                        background: white;
                        object-fit: contain;
                    ">
                </div>
            `;
        }
        
        previewHTML += '</div>';
        previewContent.innerHTML = previewHTML;
    }
}

// Function to hide element form
function hideElementForm() {
    const dropdown = document.getElementById('agro-element-dropdown');
    const form = document.getElementById('agro-element-form');
    
    if (dropdown) {
        dropdown.style.display = 'none';
    }
    
    if (form) {
        form.style.display = 'none';
    }
}

// Function to clear element form
function clearElementForm() {
    const nameInput = document.getElementById('element-name-input');
    const issueSelect = document.getElementById('issue-type-select');
    const prioritySelect = document.getElementById('priority-select');
    const commentInput = document.getElementById('element-comment-input');
    const previewContainer = document.getElementById('agro-selected-element-info');
    
    if (nameInput) nameInput.value = '';
    if (issueSelect) issueSelect.value = '';
    if (prioritySelect) prioritySelect.value = '';
    if (commentInput) commentInput.value = '';
    if (previewContainer) previewContainer.style.display = 'none';
}

// Function to capture element information
function captureElementInfo(element) {
    const rect = element.getBoundingClientRect();
    const computedStyle = window.getComputedStyle(element);
    
    // Get element path
    const getElementPath = (el) => {
        const path = [];
        while (el && el.tagName) {
            let selector = el.tagName.toLowerCase();
            if (el.id) {
                selector += `#${el.id}`;
            } else if (el.className) {
                const classes = el.className.toString().trim().split(/\s+/);
                if (classes.length > 0 && classes[0]) {
                    selector += `.${classes.slice(0, 2).join('.')}`;
                }
            }
            path.unshift(selector);
            el = el.parentElement;
        }
        return path.join(' > ');
    };    
    // Screenshot capture using html2canvas for accurate element rendering
    const captureElementScreenshot = async (element) => {
        try {
            console.log('Argo UAT: Starting screenshot capture with html2canvas...');
            
            // Check if html2canvas is available
            if (typeof html2canvas === 'undefined') {
                console.warn('Argo UAT: html2canvas not available, using fallback');
                return createFallbackScreenshot(element);
            }
            
            // Configure html2canvas options for best quality
            const options = {
                allowTaint: true,
                useCORS: true,
                scale: 1,
                logging: false,
                width: element.offsetWidth,
                height: element.offsetHeight,
                scrollX: 0,
                scrollY: 0,
                backgroundColor: '#808080',
                removeContainer: true,
                foreignObjectRendering: false,
                imageTimeout: 3000
            };
            
            // Capture the element as canvas
            const canvas = await html2canvas(element, options);
            
            // Add element type indicator overlay
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = 'rgba(76, 175, 80, 0.9)';
            ctx.fillRect(5, 5, 150, 22);
            ctx.fillStyle = 'white';
            ctx.font = 'bold 12px Arial';
            ctx.fillText(element.tagName.toUpperCase() + ' SCREENSHOT', 8, 19);
            
            // Convert to JPG with good quality
            const screenshot = canvas.toDataURL('image/jpeg', 1.0);
            
            console.log('Argo UAT: Screenshot captured successfully with html2canvas');
            return screenshot;
            
        } catch (error) {
            console.warn('Argo UAT: html2canvas failed, using fallback:', error);
            return createFallbackScreenshot(element);
        }
    };    
    // Fallback screenshot for when html2canvas fails
    const createFallbackScreenshot = (element) => {
        const rect = element.getBoundingClientRect();
        const computedStyle = window.getComputedStyle(element);
        
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        canvas.width = Math.max(rect.width, 200);
        canvas.height = Math.max(rect.height, 100);
        
        // Draw white background
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw element background color
        const bgColor = computedStyle.backgroundColor;
        if (bgColor && bgColor !== 'rgba(0, 0, 0, 0)' && bgColor !== 'transparent') {
            ctx.fillStyle = bgColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        
        // Draw borders
        const borderWidth = parseInt(computedStyle.borderWidth) || 0;
        if (borderWidth > 0) {
            ctx.strokeStyle = computedStyle.borderColor || '#cccccc';
            ctx.lineWidth = borderWidth;
            ctx.strokeRect(borderWidth/2, borderWidth/2, canvas.width - borderWidth, canvas.height - borderWidth);
        }
        
        // Draw text content
        const text = element.textContent ? element.textContent.trim() : '';
        if (text) {
            ctx.fillStyle = computedStyle.color || '#333333';
            ctx.font = `${parseInt(computedStyle.fontSize) || 14}px Arial`;
            
            const maxWidth = canvas.width - 20;
            const lineHeight = 18;
            const words = text.substring(0, 150).split(' ');
            let line = '';
            let y = 50;
            
            for (let n = 0; n < words.length; n++) {
                const testLine = line + words[n] + ' ';
                const metrics = ctx.measureText(testLine);
                
                if (metrics.width > maxWidth && n > 0) {
                    ctx.fillText(line, 10, y);
                    line = words[n] + ' ';
                    y += lineHeight;
                    if (y > canvas.height - 30) break;
                } else {
                    line = testLine;
                }
            }
            
            if (line && y <= canvas.height - 30) {
                ctx.fillText(line, 10, y);
            }
        }
        
        // Add element indicator
        ctx.fillStyle = 'rgba(255, 87, 34, 0.9)';
        ctx.fillRect(5, 5, 140, 20);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 11px Arial';
        ctx.fillText(element.tagName.toUpperCase() + ' (FALLBACK)', 8, 18);
        
        return canvas.toDataURL('image/jpeg', 0.8);
    };

    const elementInfo = {
        id: Date.now() + Math.random(), // Unique ID
        timestamp: new Date().toLocaleTimeString(),
        tagName: element.tagName.toLowerCase(),
        id: element.id || 'N/A',
        className: element.className || 'N/A',
        textContent: element.textContent ? element.textContent.substring(0, 100) + (element.textContent.length > 100 ? '...' : '') : 'N/A',
        textContentFull: element.textContent ? element.textContent : 'N/A',
        href: element.href || 'N/A',
        src: element.src || 'N/A',
        type: element.type || 'N/A',
        value: element.value || 'N/A',
        placeholder: element.placeholder || 'N/A',
        position: {
            x: Math.round(rect.left + window.scrollX),
            y: Math.round(rect.top + window.scrollY),
            width: Math.round(rect.width),
            height: Math.round(rect.height)
        },
        cssSelector: getElementPath(element),
        styles: {
            color: computedStyle.color,
            backgroundColor: computedStyle.backgroundColor,
            fontSize: computedStyle.fontSize,
            fontFamily: computedStyle.fontFamily,
            display: computedStyle.display,
            position: computedStyle.position
        },
        screenshot: null // Will be populated asynchronously
    };
    
    // Capture screenshot asynchronously
    captureElementScreenshot(element).then(screenshot => {
        elementInfo.screenshot = screenshot;
        // Update the form preview if it's currently showing this element
        updateElementPreview(elementInfo);
    });
    
    return elementInfo;
}

// Function to update elements dropdown content
function updateElementsDropdown() {
    const elementsList = document.getElementById('agro-elements-list');
    if (!elementsList) return;
    
    if (selectedElementsData.length === 0) {
        elementsList.innerHTML = '<p style="color: #666; text-align: center; margin: 20px 0;">No elements selected yet. Click "Select Element" then click on page elements.</p>';
        return;
    }
    
    elementsList.innerHTML = selectedElementsData.map((elementInfo, index) => `
        <div style="
            border: 1px solid #eee;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 8px;
            background: #f9f9f9;
            font-family: Arial, sans-serif;
            font-size: 12px;
        ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <strong style="color: #2E7D32;">${elementInfo.tagName.toUpperCase()}</strong>
                <span style="color: #666; font-size: 11px;">${elementInfo.timestamp}</span>
                <button onclick="removeSelectedElement(${index})" style="
                    background: #EF4444;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 2px 6px;
                    cursor: pointer;
                    font-size: 10px;
                ">Remove</button>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 8px;">
                ${elementInfo.id !== 'N/A' ? `<div><strong>ID:</strong> ${elementInfo.id}</div>` : ''}
                ${elementInfo.className !== 'N/A' ? `<div><strong>Class:</strong> ${elementInfo.className}</div>` : ''}
                ${elementInfo.type !== 'N/A' ? `<div><strong>Type:</strong> ${elementInfo.type}</div>` : ''}
                ${elementInfo.href !== 'N/A' ? `<div><strong>Href:</strong> <a href="${elementInfo.href}" target="_blank" style="color: #2196F3;">Link</a></div>` : ''}
            </div>
            
            ${elementInfo.textContent !== 'N/A' ? `<div style="margin-bottom: 8px;"><strong>Text:</strong> <em>"${elementInfo.textContent}"</em></div>` : ''}
            
            <div style="margin-bottom: 8px;">
                <strong>Position:</strong> (${elementInfo.position.x}, ${elementInfo.position.y}) - ${elementInfo.position.width}×${elementInfo.position.height}px
            </div>
            
            <details style="margin-bottom: 8px;">
                <summary style="cursor: pointer; color: #2469bc; font-weight: bold;">CSS Selector</summary>
                <code style="background: #eee; padding: 4px; border-radius: 3px; display: block; margin-top: 4px; word-break: break-all; font-size: 10px;">
                    ${elementInfo.cssSelector}
                </code>
            </details>
            
            <details>
                <summary style="cursor: pointer; color: #2469bc; font-weight: bold;">Styles</summary>
                <div style="margin-top: 4px; font-size: 10px;">
                    <div>Color: ${elementInfo.styles.color}</div>
                    <div>Background: ${elementInfo.styles.backgroundColor}</div>
                    <div>Font: ${elementInfo.styles.fontSize} ${elementInfo.styles.fontFamily}</div>
                    <div>Display: ${elementInfo.styles.display}</div>
                    <div>Position: ${elementInfo.styles.position}</div>
                </div>
            </details>
        </div>
    `).join('');
}

// Function to show elements dropdown
function showElementsDropdown() {
    const dropdown = document.getElementById('agro-element-dropdown');
    if (dropdown) {
        dropdown.style.display = 'block';
    }
}

// Function to highlight selected element with red color
function highlightSelectedElement(element) {
    // Remove any previous highlighting
    removeElementHighlight();
    
    // Store original styles
    const originalBackground = element.style.backgroundColor;
    const originalBorder = element.style.border;
    
    // Store element and original styles for later removal
    currentlyHighlightedElement = {
        element: element,
        originalBackground: originalBackground,
        originalBorder: originalBorder
    };
    
    // Apply red highlighting
    //element.style.backgroundColor = 'rgba(244, 67, 54, 0.3)';
    element.style.border = '2px solid #EF4444';
    element.style.transition = 'all 0.3s ease';
    
    console.log('Argo UAT: Element highlighted in red');
}

// Function to remove highlighting from currently highlighted element
function removeElementHighlight() {
    if (currentlyHighlightedElement) {
        const { element, originalBackground, originalBorder } = currentlyHighlightedElement;
        
        // Restore original styles
        element.style.backgroundColor = originalBackground;
        element.style.border = originalBorder;
        element.style.transition = '';
        
        currentlyHighlightedElement = null;
        console.log('Argo UAT: Element highlight removed');
    }
}

// Function to make current highlighting permanent (for added issues)
function makePermanentHighlight() {
    if (currentlyHighlightedElement) {
        const { element, originalBackground, originalBorder } = currentlyHighlightedElement;
          // Clean up temporary inline styles first
        element.style.backgroundColor = originalBackground;
        element.style.border = originalBorder;
        element.style.transition = '';
        
        // Add a data-attribute for permanent highlighting
        element.setAttribute('data-argo-uat-highlight', 'true');
        console.log('Argo UAT: Permanent highlight data-attribute added to element:', element);
        console.log('Argo UAT: Element has highlight attribute:', element.hasAttribute('data-argo-uat-highlight'));
        
        // Reset the currentlyHighlightedElement since it's now permanent
        currentlyHighlightedElement = null;
        
        console.log('Argo UAT: Element highlight made permanent');
    }
}

// Global function to remove selected element (called from dropdown button)
window.removeSelectedElement = function(index) {
    selectedElementsData.splice(index, 1);
    updateElementsDropdown();
}

// Function to reinitialize widget buttons when widget is shown again
function reinitializeWidgetButtons() {
    console.log('Argo UAT: Starting widget buttons reinitialization...');
    
    // Use a more robust approach with retry logic
    function attemptReinitialization(attempts = 0) {
        const selectButton = document.getElementById('agro-select-element-btn');
        const collapseButton = document.getElementById('collapse-toggle-btn');
        
        if (!selectButton || !collapseButton) {
            if (attempts < 5) {
                console.warn(`Argo UAT: Widget buttons not found for reinitialization (attempt ${attempts + 1}/5), retrying...`);
                setTimeout(() => attemptReinitialization(attempts + 1), 200);
                return;
            } else {
                console.error('Argo UAT: Widget buttons not found after multiple attempts');
                return;
            }
        }
        
        console.log('Argo UAT: Widget buttons found, reinitializing...');
        
        // Re-establish event listeners (remove existing ones first to avoid duplicates)
        const newSelectButton = selectButton.cloneNode(true);
        const newCollapseButton = collapseButton.cloneNode(true);
        
        selectButton.parentNode.replaceChild(newSelectButton, selectButton);
        collapseButton.parentNode.replaceChild(newCollapseButton, collapseButton);
        
        // Add event listeners to the new buttons
        newSelectButton.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleElementSelectionMode();
        });
        
        newCollapseButton.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Check if there are any issues before allowing click
            // if (!issuesList || issuesList.length === 0) {
            //     e.preventDefault();
            //     showNoIssuesMessage(newCollapseButton);
            //     return false;
            // }
            
            toggleAnnotationsPanel();
        });
        
        // Add hover effects for both buttons
        [newSelectButton, newCollapseButton].forEach(button => {
            button.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.05)';
                this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
            });

            button.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
                this.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
            });
        });
        
        // Update button states
        chrome.storage.local.get(['issuesListCollapsed'], function(result) {
            const isCollapsed = result.issuesListCollapsed || false;
            updateCollapseButtonState(newCollapseButton, isCollapsed);
            updateAnnotationsButtonState();
            
            console.log('Argo UAT: Button states updated - Issues count:', issuesList.length);
            console.log('Argo UAT: Widget buttons successfully reinitialized');
        });
    }
    
    // Start the reinitialization with a small delay
    setTimeout(() => attemptReinitialization(), 100);
}

// Function to update collapse button state
function updateCollapseButtonState(button, isCollapsed) {
    if (button) {
        const hasIssues = issuesList && issuesList.length > 0;
        const count = issuesList ? issuesList.length : 0;
        
        console.log(`Argo UAT: Updating collapse button state - Collapsed: ${isCollapsed}, Has issues: ${hasIssues}, Count: ${count}`);
        
        if (hasIssues) {
            button.innerHTML = isCollapsed ? `📂 Expand (${count})` : `📁 Collapse (${count})`;
            button.title = isCollapsed ? 'Expand Annotations' : 'Collapse Annotations';
        } else {
            button.innerHTML = '📁 Annotations (0)';
            button.title = 'No annotations yet - select elements first';
        }
        
        console.log(`Argo UAT: Collapse button updated - Text: ${button.innerHTML}`);
    }
}

// Function to show message when no issues are available
function showNoIssuesMessage(button) {
    const rect = button.getBoundingClientRect();
    const message = document.createElement('div');
    message.textContent = 'No annotations yet! Select elements first.';
    
    message.style.cssText = `
        position: fixed;
        top: ${rect.bottom + 10}px;
        left: ${rect.left}px;
        background: rgba(255, 87, 34, 0.9);
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-family: Arial, sans-serif;
        z-index: 10001;
        pointer-events: none;
        animation: fadeInOut 3s ease forwards;
        white-space: nowrap;
    `;
    
    document.body.appendChild(message);
    
    // Remove message after animation
    setTimeout(() => {
        if (message.parentNode) {
            message.parentNode.removeChild(message);
        }
    }, 3000);
}

// Function to update button enabled/disabled state based on issues
function updateAnnotationsButtonState() {
    const collapseButton = document.getElementById('collapse-toggle-btn');
    if (!collapseButton) {
        console.warn('Argo UAT: Collapse button not found when updating annotations state');
        return;
    }
    
    const hasIssues = issuesList && issuesList.length > 0;
    console.log(`Argo UAT: Updating annotations button state - Has issues: ${hasIssues}, Count: ${issuesList ? issuesList.length : 0}`);
    
    if (hasIssues) {
        // Enable button
        collapseButton.style.opacity = '1';
        collapseButton.style.cursor = 'pointer';
        collapseButton.style.pointerEvents = 'auto';
        collapseButton.style.background = '#2469bc';
        // Get current collapsed state and update button text with count
        const issuesListElement = document.getElementById('agro-issues-list');
        const isCollapsed = !issuesListElement || issuesListElement.style.display === 'none' || issuesListElement.style.width === '0px';
        updateCollapseButtonState(collapseButton, isCollapsed);
    } else {
        // Disable button completely
        //collapseButton.style.opacity = '0.5';
        //collapseButton.style.cursor = 'not-allowed';
        collapseButton.style.background = '#6f6f6f';
        //collapseButton.style.pointerEvents = 'none';
        collapseButton.title = 'No annotations yet - select elements first';
        collapseButton.innerHTML = '📁 Annotations (0)';
    }
    
    console.log('Argo UAT: Annotations button state updated successfully');
}

// Function to toggle annotations panel
function toggleAnnotationsPanel() {
    const issuesListElement = document.getElementById('agro-issues-list');
    const collapseButton = document.getElementById('collapse-toggle-btn');
    
    if (!issuesListElement || !collapseButton) return;
    
    // Check if there are any issues - only allow expansion if there are issues (safety fallback)
    // if (!issuesList || issuesList.length === 0) {
    //     // Show a brief message that no issues are available
    //     showNoIssuesMessage(collapseButton);
    //     return;
    // }
    
    const isCurrentlyCollapsed = issuesListElement.style.display === 'none' || issuesListElement.style.width === '0px';
    const newCollapsedState = !isCurrentlyCollapsed;
    
    if (newCollapsedState) {
        // Collapse the panel
        issuesListElement.style.width = '0px';
        issuesListElement.style.display = 'none';        document.body.style.marginRight = '0px';
    } else {
        // Expand the panel
        issuesListElement.style.width = '350px';
        issuesListElement.style.display = 'flex';
        document.body.style.marginRight = '350px';
    }
    
    // Update button state
    updateCollapseButtonState(collapseButton, newCollapsedState);
    
    // Save state
    chrome.storage.local.set({issuesListCollapsed: newCollapsedState});
      console.log('Argo UAT: Annotations panel', newCollapsedState ? 'collapsed' : 'expanded');
}

// Function to toggle widget collapse/expand
function toggleWidgetCollapse() {
    const widget = document.getElementById('chrome-widget-float');
    const collapseButton = document.getElementById('widget-collapse-btn');
    
    if (!widget || !collapseButton) return;
    
    // Check current state
    const isCollapsed = widget.getAttribute('data-collapsed') === 'true';
    
    if (isCollapsed) {
        // Expand widget
        widget.style.height = '90px';
        widget.style.top = '0';
        collapseButton.innerHTML = '▲';
        collapseButton.title = 'Collapse Widget';
        collapseButton.style.bottom = '-15px';
        widget.setAttribute('data-collapsed', 'false');
        
        // Restore page margins
        addPageMargins();
        
        // Show all content
        const contentDivs = widget.querySelectorAll('#chrome-widget-float > div');
        contentDivs.forEach(div => {
            if (div.id !== 'widget-collapse-btn' && !div.contains(collapseButton)) {
                div.style.display = 'flex';
            }
        });
        
        console.log('Argo UAT: Widget expanded');
    } else {
        // Collapse widget
        widget.style.height = '5px';
        widget.style.top = '0';
        collapseButton.innerHTML = '▼';
        collapseButton.title = 'Expand Widget';
        collapseButton.style.bottom = '-15px';
        widget.setAttribute('data-collapsed', 'true');
        
        // Remove page margins
        removePageMargins();
        
        // Hide all content except collapse button
        const contentDivs = widget.querySelectorAll('#chrome-widget-float > div');
        contentDivs.forEach(div => {
            if (div.id !== 'widget-collapse-btn' && !div.contains(collapseButton)) {
                div.style.display = 'none';
            }
        });
        
        console.log('Argo UAT: Widget collapsed');
    }
    
    // Save state
    chrome.storage.local.set({widgetCollapsed: !isCollapsed});
}

// Function to create the issues list (right column)
function createIssuesList() {
    // Only create if it doesn't already exist
    if (document.getElementById('agro-issues-list')) {
        document.getElementById('agro-issues-list').style.display = 'flex';
        return;
    }
    
    const issuesContainer = document.createElement('div');
    issuesContainer.id = 'agro-issues-list';
    
    // Load saved collapsed state for initial styling
    chrome.storage.local.get(['issuesListCollapsed'], function(result) {
        const isCollapsed = result.issuesListCollapsed || false;
        
        issuesContainer.innerHTML = `            <div id="issues-header" style="
                padding: 15px; 
                background: #f8f9fa; 
                display: flex;
                justify-content: center;
                align-items: center;
                user-select: none;
            ">
                <h3 style="margin: 0; color: rgb(36, 105, 188); font-size: 18px; display: flex; align-items: center; gap: 8px;">
                    Annotations
                    <span id="issues-count" style="background: #9f9f9f; color: white; border-radius: 8px; padding: 2px 8px; font-size: 12px;">0</span>
                </h3>
            </div>
            
            <div id="bulk-action-container" style="
                padding: 10px 15px;
                background: #ffffff;
                border-bottom: 1px solid #e0e0e0;
                display: none;
            ">
                <button id="all-annotations-to-jira-btn" style="
                    background: #DBEAFE;
                    color: #1D4ED8;
                    border: none;
                    padding: 10px 16px;
                    border-radius: 8px;
                    font-size: 14px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    width: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                " title="Create Jira tickets for all annotations that don't have one yet">
                    <span>🎫</span>
                    <span>All Annotations to Jira</span>
                </button>
            </div>
            
            <div id="issues-search-container" style="
                padding: 10px 15px;
                border-bottom: 1px solid #e0e0e0;
                background: #ffffff;
            ">
                <div style="position: relative;">
                    <input type="text" id="issues-search-input" placeholder="Search annotations..." style="
                        width: 100%;
                        padding: 8px 60px 8px 12px;
                        border: 1px solid #ddd;
                        border-radius: 20px;
                        font-size: 14px;
                        outline: none;
                        transition: border-color 0.2s ease;
                        box-sizing: border-box;
                    ">
                    <button id="clear-search-btn" style="
                        position: absolute;
                        right: 35px;
                        top: 50%;
                        transform: translateY(-50%);
                        background: none;
                        border: none;
                        color: #999;
                        font-size: 14px;
                        cursor: pointer;
                        padding: 0;
                        width: 20px;
                        height: 20px;
                        display: none;
                        align-items: center;
                        justify-content: center;
                    ">✕</button>
                    <span style="
                        position: absolute;
                        right: 12px;
                        top: 50%;
                        transform: translateY(-50%);
                        color: #999;
                        font-size: 16px;
                        pointer-events: none;
                    ">🔍</span>
                </div>
            </div>
            <div id="issues-content" style="
                padding: 15px; 
                min-height: calc(100vh - 334px); 
                overflow-y: auto;
                transition: all 0.3s ease;
            ">
                <div id="no-issues-message" style="text-align: center; color: #666; padding: 40px 20px;">
                    <div style="font-size: 48px; margin-bottom: 15px;">📝</div>
                    <p>No issues reported yet.</p>
                    <p style="font-size: 12px;">Select elements and add them to start tracking issues.</p>
                </div>
            </div>
        `;
        
        // Set initial styling for fixed right position
        issuesContainer.style.cssText = `
            position: fixed;
            top: 90px;
            right: 0;
            width: ${isCollapsed ? '0' : '350px'};
            height: calc(100vh - 90px);
            min-height: 60px;
            background: white;
            border-left: 2px solid rgb(36, 105, 188);
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            z-index: 9999;
            font-family: Arial, sans-serif;
            display: ${isCollapsed ? 'none' : 'flex'};
            flex-direction: column;
            transition: all 0.3s ease;
            overflow: hidden;
            cursor: default;       `;
        
        document.body.appendChild(issuesContainer);        // Add event delegation for remove buttons
        issuesContainer.addEventListener('click', function(e) {
            if (e.target.classList.contains('agro-remove-issue-btn')) {
                const index = parseInt(e.target.getAttribute('data-remove-index'));
                if (confirm('Are you sure you want to remove this issue?')) {
                    // Remove permanent highlighting from the element if it exists
                    const issue = issuesList[index];
                    console.log('Argo UAT: Removing issue at index:', index, 'Issue object:', issue);
                      if (issue && issue.domElement) {
                        console.log('Argo UAT: DOM element found:', issue.domElement);
                        console.log('Argo UAT: Element has permanent highlight attribute:', issue.domElement.hasAttribute('data-argo-uat-highlight'));
                        
                        // Check if element still exists in the DOM
                        if (document.contains(issue.domElement)) {
                            issue.domElement.removeAttribute('data-argo-uat-highlight');
                            console.log('Argo UAT: Permanent highlighting removed from element');
                        } else {
                            console.log('Argo UAT: Element no longer exists in DOM');
                        }
                    } else {
                        console.log('Argo UAT: No DOM element reference found for issue');
                    }
                    
                    issuesList.splice(index, 1);
                    updateIssuesDisplay();
                    
                    // Update annotations button state
                    updateAnnotationsButtonState();
                    
                    // Update bulk action button state immediately
                    updateBulkActionButton();
                    
                    console.log('Argo UAT: Issue removed from list');
                }
            }
              // Handle Jira ticket creation button clicks
            if (e.target.classList.contains('agro-create-jira-btn')) {
                const index = parseInt(e.target.getAttribute('data-issue-index'));
                createJiraTicket(issuesList[index], e.target);
            }
            
            // Handle bulk "All Annotations to Jira" button click
            if (e.target.id === 'all-annotations-to-jira-btn' || e.target.closest('#all-annotations-to-jira-btn')) {
                e.preventDefault();
                e.stopPropagation();
                createAllJiraTickets();
            }
        });// Add search functionality
        const searchInput = issuesContainer.querySelector('#issues-search-input');
        const clearSearchBtn = issuesContainer.querySelector('#clear-search-btn');
        
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                const value = e.target.value;
                filterIssues(value);
                
                // Show/hide clear button
                if (clearSearchBtn) {
                    clearSearchBtn.style.display = value ? 'flex' : 'none';
                }
            });
            
            // Style the search input on focus/blur
            searchInput.addEventListener('focus', function() {
                this.style.borderColor = '#4CAF50';
                this.style.boxShadow = '0 0 0 2px rgba(76, 175, 80, 0.2)';
            });
            
            searchInput.addEventListener('blur', function() {
                this.style.borderColor = '#ddd';
                this.style.boxShadow = 'none';
            });
        }
        
        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', function() {
                searchInput.value = '';
                clearSearchBtn.style.display = 'none';
                filterIssues('');
                searchInput.focus();
            });
        }
          // Adjust page margin for issues list
        document.body.style.marginRight = isCollapsed ? '0px' : '350px';
        document.body.style.transition = 'margin-right 0.3s ease';
        
        // Initialize bulk action button visibility
        setTimeout(() => {
            updateBulkActionButton();
        }, 100);
    });
}

// Function to filter issues based on search query
function filterIssues(searchQuery) {
    const issuesContent = document.getElementById('issues-content');
    const issuesCount = document.getElementById('issues-count');
    const noIssuesMessage = document.getElementById('no-issues-message');
    
    if (!issuesContent) return;
    
    // If no search query, show all issues
    if (!searchQuery.trim()) {
        updateIssuesDisplay();
        return;
    }
      // Filter issues based on search query
    const filteredIssues = issuesList.filter(issue => {
        const searchTerm = searchQuery.toLowerCase();
        
        // Search in multiple fields
        return (
            issue.name.toLowerCase().includes(searchTerm) ||
            issue.issueType.toLowerCase().includes(searchTerm) ||
            issue.priority.toLowerCase().includes(searchTerm) ||
            issue.comment.toLowerCase().includes(searchTerm) ||
            issue.element.tagName.toLowerCase().includes(searchTerm) ||
            issue.element.textContent.toLowerCase().includes(searchTerm) ||
            issue.element.cssSelector.toLowerCase().includes(searchTerm) ||
            (issue.url && issue.url.toLowerCase().includes(searchTerm)) ||
            (issue.project_id && issue.project_id.toLowerCase().includes(searchTerm)) ||
            (issue.page_id && issue.page_id.toLowerCase().includes(searchTerm))
        );
    });
    
    // Update count to show filtered/total
    if (issuesCount) {
        issuesCount.textContent = `${filteredIssues.length}/${issuesList.length}`;
        issuesCount.style.background = filteredIssues.length === issuesList.length ? '#9f9f9f' : '#ff9800';
    }
    
    // Update the display with filtered results
    updateIssuesDisplayWithFiltered(filteredIssues, searchQuery);
}

// Function to update issues display with filtered results
function updateIssuesDisplayWithFiltered(filteredIssues, searchQuery) {
    const issuesContent = document.getElementById('issues-content');
    const noIssuesMessage = document.getElementById('no-issues-message');
    
    if (!issuesContent) return;
    
    if (filteredIssues.length === 0) {
        // Show no results message
        issuesContent.innerHTML = `
            <div style="text-align: center; color: #666; padding: 40px 20px;">
                <div style="font-size: 48px; margin-bottom: 15px;">🔍</div>
                <p>No annotations found for "${searchQuery}"</p>
                <p style="font-size: 12px;">Try a different search term or clear the search to see all annotations.</p>
            </div>
        `;
        return;
    }
    
    // Hide no issues message
    if (noIssuesMessage) {
        noIssuesMessage.style.display = 'none';
    }
    
    // Create filtered issues HTML (using same logic as updateIssuesDisplay)
    const issuesHTML = filteredIssues.map((issue, displayIndex) => {
        // Find the original index in the full issuesList for proper removal
        const originalIndex = issuesList.findIndex(originalIssue => originalIssue.id === issue.id);
        
        const priorityColors = {
            critical: '#EF4444',
            high: '#ef8144',
            medium: '#EAB308',
            low: '#3B82F6'
        };
        
        const issueTypeIcons = {
            bug: '🐛',
            enhancement: '✨',
            usability: '👤',
            performance: '⚡',
            accessibility: '♿',
            visual: '👁️',
            functional: '⚙️'
        };
        
        return `
            <div class="annotation-item-container" style="
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-bottom: 12px;
                background: white;
                overflow: hidden;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            ">
                <div class="${issue.priority}" style="
                    color: ${priorityColors[issue.priority] || '#666'};
                    padding: 8px 12px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                ">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span>${issueTypeIcons[issue.issueType] || '📋'}</span>
                        <strong style="font-size: 14px;">${highlightSearchTerm(issue.name, searchQuery)}</strong>
                    </div>
                    <div>
                        <span style="
                            background: rgba(255,255,255,0.2);
                            padding: 2px 6px;
                            border-radius: 3px;
                            font-size: 10px;
                            text-transform: uppercase;
                        ">${issue.priority}</span>
                        <button data-remove-index="${originalIndex}" class="agro-remove-issue-btn" style="
                            background: rgba(255,255,255,0.2);
                            border: none;
                            color: white;
                            border-radius: 3px;
                            padding: 2px 6px;
                            cursor: pointer;
                            font-size: 10px;
                            margin:0;
                        ">✕</button>
                    </div>
                </div>
                
                <div style="padding: 12px;">
                    <div style="margin-top: 8px; padding-top: 8px; font-size: 10px; color: #999;">
                        Created: ${issue.timestamp}
                    </div>
                    <div style="margin-bottom: 8px;">
                        <strong style="color: #333; font-size: 12px;">Comment:</strong>
                        <div style="color: #666; font-size: 12px; margin-top: 4px; line-height: 1.4;">${highlightSearchTerm(issue.comment, searchQuery)}</div>
                    </div>
                    <details style="margin-top: 8px; border-top: 1px solid #eee;">
                        <summary style="cursor: pointer; color: #2469bc; font-size: 12px; font-weight: bold;">Element Details</summary>
                        <div style="margin-top: 8px; font-size: 11px; color: #666; background: #f9f9f9; padding: 8px; border-radius: 4px;">
                            ${issue.element.screenshot ? `
                                <div style="margin-bottom: 12px; text-align: center;">
                                    <img src="${issue.element.screenshot}" alt="Element screenshot" style="
                                        max-width: 100%;
                                        max-height: 120px;
                                        border: 1px solid #ddd;
                                        border-radius: 4px;
                                        background: white;
                                        object-fit: contain;
                                    ">
                                    <div style="font-size: 10px; color: #999; margin-top: 4px;">Element Preview</div>
                                </div>
                            ` : ''}
                            <div style="margin-bottom: 8px;"><strong style="color: #333; font-size: 12px;">CSS Selector:</strong> ${highlightSearchTerm(issue.element.cssSelector, searchQuery)}</div>
                            <div style="margin-bottom: 8px;"><strong style="color: #333; font-size: 12px;">Text:</strong> "${highlightSearchTerm(issue.element.textContent, searchQuery)}"</div>
                            <div style="margin-bottom: 8px;"><strong style="color: #333; font-size: 12px;">Size:</strong> ${issue.element.position.width}×${issue.element.position.height}px</div>
                            <div style="margin-bottom: 8px;">
                                <strong style="color: #333; font-size: 12px;">Position:</strong>
                                <span style="color: #666; font-size: 12px;">(${issue.element.position.x}, ${issue.element.position.y})</span>
                            </div>
                            <div style="margin-bottom: 8px;">
                                <strong style="color: #333; font-size: 12px;">Issue Type:</strong>
                                <span style="color: #666; font-size: 12px; text-transform: capitalize;">${highlightSearchTerm(issue.issueType, searchQuery)}</span>
                            </div>                            <div style="margin-bottom: 8px;">
                                <strong style="color: #333; font-size: 12px;">Element:</strong>
                                <span style="color: #666; font-size: 12px;">${highlightSearchTerm(issue.element.tagName.toUpperCase(), searchQuery)}</span>
                            </div>
                            ${issue.url ? `
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #333; font-size: 12px;">Page URL:</strong>
                                    <a href="${issue.url}" target="_blank" style="color: #2469BC; text-decoration: none; font-size: 10px; word-break: break-all;">
                                        ${highlightSearchTerm(issue.url.length > 40 ? issue.url.substring(0, 40) + '...' : issue.url, searchQuery)}
                                    </a>
                                </div>
                            ` : ''}
                            ${issue.project_id ? `
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #333; font-size: 12px;">Project ID:</strong>
                                    <span style="color: #666; font-size: 12px;">${highlightSearchTerm(issue.project_id, searchQuery)}</span>
                                </div>
                            ` : ''}
                            ${issue.page_id ? `
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #333; font-size: 12px;">Page ID:</strong>
                                    <span style="color: #666; font-size: 12px;">${highlightSearchTerm(issue.page_id, searchQuery)}</span>
                                </div>
                            ` : ''}
                            
                            
                        </div>
                    </details>
                    <div style="margin-top: 12px; padding-top: 8px; border-top: 1px solid #eee;">
                                ${issue.jiraTicket ? `
                                    <button data-issue-index="${originalIndex}" class="agro-create-jira-btn" style="
                                        background: #4CAF50;
                                        color: white;
                                        border: none;
                                        padding: 8px 16px;
                                        border-radius: 8px;
                                        font-size: 12px;
                                        font-weight: 500;
                                        cursor: not-allowed;
                                        transition: all 0.3s ease;
                                        width: 100%;
                                        opacity: 0.8;
                                    " disabled>✅ Ticket Created</button>
                                    <div class="jira-response-details">
                                        <div style="
                                            margin-top: 8px;
                                            padding: 12px;
                                            background: #f8f9fa;
                                            border: 1px solid #e9ecef;
                                            border-radius: 6px;
                                            font-size: 11px;
                                            font-family: Arial, sans-serif;
                                            line-height: 1.4;
                                        ">
                                            <div style="
                                                color: #4CAF50;
                                                font-weight: bold;
                                                margin-bottom: 8px;
                                                display: flex;
                                                align-items: center;
                                                gap: 6px;
                                            ">
                                                <span>🎫</span>
                                                <span>Jira Ticket Details</span>
                                            </div>
                                            
                                            <div style="display: grid; gap: 6px;">
                                                ${issue.jiraTicket.id ? `
                                                    <div style="display: flex; justify-content: space-between;">
                                                        <span style="color: #666; font-weight: 500;">ID:</span>
                                                        <span style="color: #333; font-family: monospace;">${issue.jiraTicket.id}</span>
                                                    </div>
                                                ` : ''}
                                                
                                                ${issue.jiraTicket.key ? `
                                                    <div style="display: flex; justify-content: space-between;">
                                                        <span style="color: #666; font-weight: 500;">Key:</span>
                                                        <span style="color: #1D4ED8; font-family: monospace; font-weight: 500;">${highlightSearchTerm(issue.jiraTicket.key, searchQuery)}</span>
                                                    </div>
                                                ` : ''}
                                                
                                                <div style="display: flex; justify-content: space-between;">
                                                    <span style="color: #666; font-weight: 500;">Status:</span>
                                                    <span style="color: #333;">${highlightSearchTerm(issue.jiraTicket.message, searchQuery)}</span>
                                                </div>
                                                
                                                ${issue.jiraTicket.self_url ? `
                                                    <div style="margin-top: 6px; padding-top: 6px; border-top: 1px solid #e0e0e0;">
                                                        <span style="color: #666; font-weight: 500; display: block; margin-bottom: 4px;">URL:</span>
                                                        <a href="${issue.jiraTicket.self_url}" target="_blank" style="
                                                            color: #1D4ED8;
                                                            text-decoration: none;
                                                            font-size: 10px;
                                                            word-break: break-all;
                                                            display: block;
                                                        " onmouseover="this.style.textDecoration='underline'" 
                                                           onmouseout="this.style.textDecoration='none'">
                                                            ${highlightSearchTerm(issue.jiraTicket.self_url, searchQuery)}
                                                        </a>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        </div>
                                    </div>                                ` : `
                                    ${!issue.project_id || !issue.page_id ? `
                                        <button data-issue-index="${originalIndex}" class="agro-create-jira-btn" style="
                                            background: #ff9800;
                                            color: white;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 8px;
                                            font-size: 12px;
                                            font-weight: 500;
                                            cursor: not-allowed;
                                            transition: all 0.3s ease;
                                            width: 100%;
                                            opacity: 0.7;
                                        " disabled title="Missing required parameters: ${!issue.project_id ? 'project_id' : ''}${!issue.project_id && !issue.page_id ? ' and ' : ''}${!issue.page_id ? 'page_id' : ''}">⚠️ Missing Parameters</button>
                                    ` : `
                                        <button data-issue-index="${originalIndex}" class="agro-create-jira-btn" style="
                                            background: #DBEAFE;
                                            color: #1D4ED8;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 8px;
                                            font-size: 12px;
                                            font-weight: 500;
                                            cursor: pointer;
                                            transition: all 0.3s ease;
                                            width: 100%;
                                        ">📋 Create Jira Ticket</button>
                                    `}
                                `}
                            </div>
                </div>
            </div>
        `;    }).join('');
    
    issuesContent.innerHTML = issuesHTML;
    
    // Update bulk action button visibility and state
    updateBulkActionButton();
}

// Function to highlight search terms in text
function highlightSearchTerm(text, searchQuery) {
    if (!searchQuery || !searchQuery.trim()) {
        return text;
    }
    
    const regex = new RegExp(`(${searchQuery.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<mark style="background: #ffeb3b; padding: 1px 2px; border-radius: 2px;">$1</mark>');
}

// Function to update issues display
function updateIssuesDisplay() {
    const issuesContent = document.getElementById('issues-content');
    const issuesCount = document.getElementById('issues-count');
    const noIssuesMessage = document.getElementById('no-issues-message');
    
    if (!issuesContent || !issuesCount) return;
    
    // Update count
    issuesCount.textContent = issuesList.length;
    issuesCount.style.background = '#9f9f9f'; // Reset to default color
    
    if (issuesList.length === 0) {
        if (noIssuesMessage) {
            noIssuesMessage.style.display = 'block';
        }
        // Clear any existing issues HTML when list is empty
        issuesContent.innerHTML = `
            <div id="no-issues-message" style="text-align: center; color: #666; padding: 40px 20px;">
                <div style="font-size: 48px; margin-bottom: 15px;">📝</div>
                <p>No issues reported yet.</p>
                <p style="font-size: 12px;">Select elements and add them to start tracking issues.</p>
            </div>
        `;
        return;
    }
    
    // Hide no issues message
    if (noIssuesMessage) {
        noIssuesMessage.style.display = 'none';
    }
    
    // Create issues HTML
    const issuesHTML = issuesList.map((issue, index) => {
        const priorityColors = {
            critical: '#EF4444',
            high: '#ef8144',
            medium: '#EAB308',
            low: '#3B82F6'
        };
        
        const issueTypeIcons = {
            bug: '🐛',
            enhancement: '✨',
            usability: '👤',
            performance: '⚡',
            accessibility: '♿',
            visual: '👁️',
            functional: '⚙️'
        };
        
        return `
            <div class="annotation-item-container" style="
                border: 1px solid ${priorityColors[issue.priority] || '#666'};
                border-radius: 8px;
                margin-bottom: 12px;
                background: white;
                overflow: hidden;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            ">
                <div class="${issue.priority}" style="
                    color: ${priorityColors[issue.priority] || '#666'};
                    padding: 8px 12px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                ">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span>${issueTypeIcons[issue.issueType] || '📋'}</span>
                        <strong style="font-size: 14px;">${issue.name}</strong>
                    </div>
                    <div style="display: flex; gap: 5px;">
                        <span style="
                            background: ${priorityColors[issue.priority] || '#666'};
                            padding: 2px 6px;
                            border-radius: 3px;
                            font-size: 10px;
                            text-transform: uppercase;
                            color: white;
                        ">${issue.priority}</span>
                        <button data-remove-index="${index}" class="agro-remove-issue-btn" style="
                            background: ${priorityColors[issue.priority] || '#666'};
                            border: none;
                            color: white;
                            border-radius: 3px;
                            padding: 2px 6px;
                            cursor: pointer;
                            font-size: 10px;
                            margin:0;
                        ">✕</button>
                    </div>
                </div>
                
                <div style="padding: 12px;">
                    <div style="font-size: 10px; color: #999; padding-bottom:8px;">
                        Added on ${issue.timestamp}
                    </div>
                    <div style="margin-bottom: 20px;">
                        <strong style="color: #666; font-size: 12px; display:none">Comment:</strong>
                        <div style="color: #333; font-size: 14px; margin-top: 4px; line-height: 1.4;">${issue.comment}</div>
                    </div>
                    <details style="padding-top: 8px;border-top: 1px solid #eee;">
                        <summary style="cursor: pointer; color: #2469bc; font-size: 12px; font-weight: bold;">Element Details</summary>
                        <div style="margin-top: 8px; font-size: 11px; color: #666; background: #f9f9f9; padding: 8px; border-radius: 4px;">
                            ${issue.element.screenshot ? `
                                <div style="margin-bottom: 12px; text-align: center;">
                                    <img src="${issue.element.screenshot}" alt="Element screenshot" style="
                                        max-width: 100%;
                                        max-height: 120px;
                                        border: 1px solid #ddd;
                                        border-radius: 4px;
                                        background: white;
                                        object-fit: contain;
                                    ">
                                    <div style="font-size: 10px; color: #999; margin-top: 4px;">Element Preview</div>
                                </div>
                            ` : ''}
                            <div style="margin-bottom: 8px;"><strong style="color: #333; font-size: 12px;">CSS Selector:</strong> ${issue.element.cssSelector}</div>
                            <div style="margin-bottom: 8px;"><strong style="color: #333; font-size: 12px;">Text:</strong> "${issue.element.textContent}"</div>
                            <div style="margin-bottom: 8px;"><strong style="color: #333; font-size: 12px;">Size:</strong> ${issue.element.position.width}×${issue.element.position.height}px</div>
                            <div style="margin-bottom: 8px;">
                                <strong style="color: #333; font-size: 12px;">Position:</strong>
                                <span style="color: #666; font-size: 12px;">(${issue.element.position.x}, ${issue.element.position.y})</span>
                            </div>
                            <div style="margin-bottom: 8px;">
                                <strong style="color: #333; font-size: 12px;">Issue Type:</strong>
                                <span style="color: #666; font-size: 12px; text-transform: capitalize;">${issue.issueType}</span>
                            </div>                            <div style="margin-bottom: 8px;">
                                <strong style="color: #333; font-size: 12px;">Element:</strong>
                                <span style="color: #666; font-size: 12px;">${issue.element.tagName.toUpperCase()}</span>
                            </div>
                            ${issue.url ? `
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #333; font-size: 12px;">Page URL:</strong>
                                    <a href="${issue.url}" target="_blank" style="color: #2469BC; text-decoration: none; font-size: 10px; word-break: break-all;">
                                        ${issue.url.length > 40 ? issue.url.substring(0, 40) + '...' : issue.url}
                                    </a>
                                </div>
                            ` : ''}
                            ${issue.project_id ? `
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #333; font-size: 12px;">Project ID:</strong>
                                    <span style="color: #666; font-size: 12px;">${issue.project_id}</span>
                                </div>
                            ` : ''}
                            ${issue.page_id ? `
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #333; font-size: 12px;">Page ID:</strong>
                                    <span style="color: #666; font-size: 12px;">${issue.page_id}</span>
                                </div>
                            ` : ''}
                            
                            
                        </div>
                    </details>
                    <div style="margin-top: 12px; padding-top: 8px; border-top: 1px solid #eee;">
                                ${issue.jiraTicket ? `
                                    <button data-issue-index="${index}" class="agro-create-jira-btn" style="
                                        background: #4CAF50;
                                        color: white;
                                        border: none;
                                        padding: 8px 16px;
                                        border-radius: 8px;
                                        font-size: 12px;
                                        font-weight: 500;
                                        cursor: not-allowed;
                                        transition: all 0.3s ease;
                                        width: 100%;
                                        opacity: 0.8;
                                    " disabled>✅ Ticket Created</button>
                                    <div class="jira-response-details">
                                        <div style="
                                            margin-top: 8px;
                                            padding: 12px;
                                            background: #f8f9fa;
                                            border: 1px solid #e9ecef;
                                            border-radius: 6px;
                                            font-size: 11px;
                                            font-family: Arial, sans-serif;
                                            line-height: 1.4;
                                        ">
                                            <div style="
                                                color: #4CAF50;
                                                font-weight: bold;
                                                margin-bottom: 8px;
                                                display: flex;
                                                align-items: center;
                                                gap: 6px;
                                            ">
                                                <span>🎫</span>
                                                <span>Jira Ticket Details</span>
                                            </div>
                                            
                                            <div style="display: grid; gap: 6px;">
                                                ${issue.jiraTicket.id ? `
                                                    <div style="display: flex; justify-content: space-between;">
                                                        <span style="color: #666; font-weight: 500;">ID:</span>
                                                        <span style="color: #333; font-family: monospace;">${issue.jiraTicket.id}</span>
                                                    </div>
                                                ` : ''}
                                                
                                                ${issue.jiraTicket.key ? `
                                                    <div style="display: flex; justify-content: space-between;">
                                                        <span style="color: #666; font-weight: 500;">Key:</span>
                                                        <span style="color: #1D4ED8; font-family: monospace; font-weight: 500;">${highlightSearchTerm(issue.jiraTicket.key, searchQuery)}</span>
                                                    </div>
                                                ` : ''}
                                                
                                                <div style="display: flex; justify-content: space-between;">
                                                    <span style="color: #666; font-weight: 500;">Status:</span>
                                                    <span style="color: #333;">${highlightSearchTerm(issue.jiraTicket.message, searchQuery)}</span>
                                                </div>
                                                
                                                ${issue.jiraTicket.self_url ? `
                                                    <div style="margin-top: 6px; padding-top: 6px; border-top: 1px solid #e0e0e0;">
                                                        <span style="color: #666; font-weight: 500; display: block; margin-bottom: 4px;">URL:</span>
                                                        <a href="${issue.jiraTicket.self_url}" target="_blank" style="
                                                            color: #1D4ED8;
                                                            text-decoration: none;
                                                            font-size: 10px;
                                                            word-break: break-all;
                                                            display: block;
                                                        " onmouseover="this.style.textDecoration='underline'" 
                                                           onmouseout="this.style.textDecoration='none'">
                                                            ${highlightSearchTerm(issue.jiraTicket.self_url, searchQuery)}
                                                        </a>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        </div>
                                    </div>                                ` : `
                                    ${!issue.project_id || !issue.page_id ? `
                                        <button data-issue-index="${index}" class="agro-create-jira-btn" style="
                                            background: #ff9800;
                                            color: white;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 8px;
                                            font-size: 12px;
                                            font-weight: 500;
                                            cursor: not-allowed;
                                            transition: all 0.3s ease;
                                            width: 100%;
                                            opacity: 0.7;
                                        " disabled title="Missing required parameters: ${!issue.project_id ? 'project_id' : ''}${!issue.project_id && !issue.page_id ? ' and ' : ''}${!issue.page_id ? 'page_id' : ''}">⚠️ Missing Parameters</button>
                                    ` : `
                                        <button data-issue-index="${index}" class="agro-create-jira-btn" style="
                                            background: #DBEAFE;
                                            color: #1D4ED8;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 8px;
                                            font-size: 12px;
                                            font-weight: 500;
                                            cursor: pointer;
                                            transition: all 0.3s ease;
                                            width: 100%;
                                        ">📋 Create Jira Ticket</button>
                                    `}
                                `}
                            </div>
                </div>
            </div>
        `;
    }).join('');
    
    issuesContent.innerHTML = issuesHTML;
    
    // Update bulk action button visibility and state
    updateBulkActionButton();
}

// Function to add element to issues list
function addElementToIssuesList() {
    if (!selectedElementForForm) return;
    
    const nameInput = document.getElementById('element-name-input');
    const issueSelect = document.getElementById('issue-type-select');
    const prioritySelect = document.getElementById('priority-select');
    const commentInput = document.getElementById('element-comment-input');
    
    // Validate form
    if (!nameInput.value.trim()) {
        alert('Please enter an element name.');
        nameInput.focus();
        return;
    }
    
    if (!issueSelect.value) {
        alert('Please select an issue type.');
        issueSelect.focus();
        return;
    }
    
    if (!prioritySelect.value) {
        alert('Please select a priority.');
        prioritySelect.focus();
        return;
    }
      // Create issue object
    const issue = {
        id: Date.now() + Math.random(),
        name: nameInput.value.trim(),
        issueType: issueSelect.value,
        priority: prioritySelect.value,
        comment: commentInput.value.trim() || 'No comment provided',
        element: selectedElementForForm,
        domElement: currentlyHighlightedElement ? currentlyHighlightedElement.element : null, // Store DOM reference
        timestamp: new Date().toLocaleString(),
        url: window.location.href,
        status: 'open',
        // Add new URL parameters
        project_id: window.argoProjectId || null,
        page_id: window.argoPageId || null
    };    console.log('Argo UAT: Creating issue with DOM element:', issue.domElement);
    console.log('Argo UAT: Current highlighted element:', currentlyHighlightedElement);
    console.log('Argo UAT: Issue includes URL parameters:', {
        project_id: issue.project_id,
        page_id: issue.page_id,
        url: issue.url
    });
    
    // Warn if mandatory parameters are missing
    if (!issue.project_id || !issue.page_id) {
        console.warn('Argo UAT: WARNING - Annotation created without required parameters for Jira submission:', {
            missing: {
                project_id: !issue.project_id,
                page_id: !issue.page_id
            },
            current_url: window.location.href,
            help: 'Add ?project_id=YOUR_PROJECT&page_id=YOUR_PAGE to the URL'
        });
    }      // Add to issues list
    issuesList.push(issue);
    
    // Update annotations button state
    updateAnnotationsButtonState();
    
    // Make current highlighting permanent
    makePermanentHighlight();
    
    // Update issues display
    updateIssuesDisplay();
    
    // Update bulk action button state immediately
    updateBulkActionButton();
    
    // Clear form and hide dropdown
    clearElementForm();
    hideElementForm();
    selectedElementForForm = null;
    
    console.log('Argo UAT: Issue added to list:', issue);
}

// Function to remove issues list
function removeIssuesList() {
    const issuesListElement = document.getElementById('agro-issues-list');
    
    if (issuesListElement) {
        issuesListElement.style.display = 'none';
    }
    
    // Reset page margin when removing issues list
    document.body.style.marginRight = '0';
    document.body.style.transition = 'margin-right 0.3s ease';
}

// Function to setup form event listeners
function setupFormEventListeners() {
    // Add to list button
    document.addEventListener('click', function(e) {
        if (e.target.id === 'add-to-list-btn') {
            addElementToIssuesList();
        }
        
        if (e.target.id === 'cancel-element-btn') {
            clearElementForm();
            hideElementForm();
            removeElementHighlight(); // Remove highlighting when cancelled
        }
    });
}

// Function to setup collapse functionality
function setupCollapseToggle(button, initialCollapsed) {
    button.addEventListener('click', function() {
        const issuesList = document.getElementById('agro-issues-list');
        const isCurrentlyCollapsed = issuesList.style.display === 'none';
        
        if (isCurrentlyCollapsed) {
            // Expand
            issuesList.style.display = 'flex';
            issuesList.style.width = '350px';
            button.style.right = '350px';
            button.innerHTML = '📁';
            button.title = 'Collapse Annotations';
            document.body.style.marginRight = '350px';
            
            // Save expanded state
            chrome.storage.local.set({issuesListCollapsed: false});
        } else {
            // Collapse
            issuesList.style.display = 'none';
            issuesList.style.width = '0';
            button.style.right = '0px';
            button.innerHTML = '📂';
            button.title = 'Expand Annotations';
            document.body.style.marginRight = '30px';
            
            // Save collapsed state
            chrome.storage.local.set({issuesListCollapsed: true});
        }
    });
}

// Function to create Jira ticket
async function createJiraTicket(issue, buttonElement) {
    if (!issue) {
        console.error('Argo UAT: No issue provided for Jira ticket creation');
        return;
    }
      // Check if Jira ticket already exists for this issue
    if (issue.jiraTicket) {
        console.log('Argo UAT: Jira ticket already exists for this issue:', issue.jiraTicket);
        
        // Disable button and show existing ticket
        buttonElement.innerHTML = '✅ Ticket Exists';
        buttonElement.style.background = '#4CAF50';
        buttonElement.disabled = true;
        buttonElement.style.opacity = '0.8';
        buttonElement.style.cursor = 'not-allowed';
        
        // Recreate the response div with existing data
        createJiraResponseDiv(buttonElement, issue.jiraTicket);
        return;
    }
    
    // Check for mandatory parameters
    if (!issue.project_id || !issue.page_id) {
        console.error('Argo UAT: Missing mandatory parameters for Jira ticket creation', {
            project_id: issue.project_id,
            page_id: issue.page_id
        });
        
        // Show error state
        buttonElement.innerHTML = '❌ Missing Parameters';
        buttonElement.style.background = '#f44336';
        buttonElement.disabled = true;
        buttonElement.style.opacity = '0.8';
        buttonElement.style.cursor = 'not-allowed';
        
        // Show error message
        const errorMessage = !issue.project_id && !issue.page_id ? 
            'project_id and page_id parameters are required' :
            !issue.project_id ? 'project_id parameter is required' : 'page_id parameter is required';
            
        console.log('Argo UAT: Jira ticket creation failed:', errorMessage);
        
        // Reset button after 5 seconds
        setTimeout(() => {
            buttonElement.innerHTML = '📋 Create Jira Ticket';
            buttonElement.style.background = '#DBEAFE';
            buttonElement.disabled = false;
            buttonElement.style.opacity = '1';
            buttonElement.style.cursor = 'pointer';
        }, 5000);
        
        return;
    }
    
    console.log('Argo UAT: Creating Jira ticket for issue:', issue);
    
    // Disable button and show loading state
    const originalText = buttonElement.innerHTML;
    buttonElement.innerHTML = '⏳ Creating Ticket...';
    buttonElement.disabled = true;
    buttonElement.style.opacity = '0.7';
    buttonElement.style.cursor = 'not-allowed';
    
    try {        // Prepare the request body
        const summary = issue.name;
        const description = `
Issue Type: ${issue.issueType}
Priority: ${issue.priority}
Comment: ${issue.comment}
Timestamp: ${issue.timestamp}
Page URL: ${issue.url}${issue.project_id ? `
Project ID: ${issue.project_id}` : ''}${issue.page_id ? `
Page ID: ${issue.page_id}` : ''}

Element Details:
- CSS Selector: ${issue.element.cssSelector}
- Text Content: "${issue.element.textContent}"
- Tag Name: ${issue.element.tagName.toUpperCase()}
- Size: ${issue.element.position.width}×${issue.element.position.height}px
- Position: (${issue.element.position.x}, ${issue.element.position.y})

Screenshot: ${issue.element.screenshot ? 'Available' : 'Not available'}
        `.trim();
        
        const requestBody = {
            summary: summary,
            description: description,
            // Include as separate fields for easier API processing
            project_id: issue.project_id,
            page_id: issue.page_id
        };
        
        console.log('Argo UAT: Sending Jira ticket request:', requestBody);
          // Make the API call
        const response = await fetch('http://127.0.0.1:8000/api/v1/jira/task', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });
        
        if (response.ok) {
            const result = await response.json();
            console.log('Argo UAT: Jira ticket created successfully:', result);
            
            // Store Jira ticket information in the issue object
            issue.jiraTicket = {
                id: result.id,
                key: result.key,
                message: result.message || 'Ticket created successfully',
                self_url: result.self_url || result.self,
                createdAt: new Date().toISOString()
            };              // Permanently disable the button and show success state
            buttonElement.innerHTML = '✅ Ticket Created';
            buttonElement.style.background = '#4CAF50';
            buttonElement.disabled = true;
            buttonElement.style.opacity = '0.8';
            buttonElement.style.cursor = 'not-allowed';
            
            // Create response details div below the button
            createJiraResponseDiv(buttonElement, result);
            
            // Update bulk action button since one less annotation is available for Jira
            updateBulkActionButton();
            
        } else {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
        }
    } catch (error) {
        console.error('Argo UAT: Error creating Jira ticket:', error);
        
        let errorMessage = error.message;
        
        // Provide more user-friendly error messages
        if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
            errorMessage = 'Network error - check if the Jira API server is running on 127.0.0.1:8000';
        } else if (error.message.includes('CORS')) {
            errorMessage = 'CORS error - API server needs to allow cross-origin requests';
        } else if (error.message.includes('401')) {
            errorMessage = 'Authentication required';
        } else if (error.message.includes('403')) {
            errorMessage = 'Access forbidden - check API permissions';
        } else if (error.message.includes('404')) {
            errorMessage = 'API endpoint not found - check if /api/v1/jira/task exists';
        } else if (error.message.includes('500')) {
            errorMessage = 'Server error - check API server logs';
        }
          // Show error feedback
        buttonElement.innerHTML = '❌ Creation Failed';
        buttonElement.style.background = '#f44336';
        buttonElement.style.color = '#fff';
        
        // Log error for debugging
        console.log('Argo UAT: Jira ticket creation failed:', errorMessage);
        
        // Reset button after 3 seconds
        setTimeout(() => {
            buttonElement.innerHTML = originalText;
            buttonElement.style.background = '#DBEAFE';
            buttonElement.disabled = false;
            buttonElement.style.opacity = '1';
            buttonElement.style.cursor = 'pointer';
            buttonElement.style.color = '#1D4ED8';
        }, 5000);
    }
}

// Function to create Jira response details div
function createJiraResponseDiv(buttonElement, result) {
    // Check if response div already exists for this button to avoid duplicates
    const existingDiv = buttonElement.parentNode.querySelector('.jira-response-details');
    if (existingDiv) {
        existingDiv.remove();
    }
    
    // Create the response details div
    const responseDiv = document.createElement('div');
    responseDiv.className = 'jira-response-details';
    responseDiv.innerHTML = `
        <div style="
            margin-top: 8px;
            padding: 12px;
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            font-size: 11px;
            font-family: Arial, sans-serif;
            line-height: 1.4;
        ">
            <div style="
                color: #4CAF50;
                font-weight: bold;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 6px;
            ">
                <span>🎫</span>
                <span>Jira Ticket Details</span>
            </div>
            
            <div style="display: grid; gap: 6px;">
                ${result.id ? `
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #666; font-weight: 500;">ID:</span>
                        <span style="color: #333; font-family: monospace;">${result.id}</span>
                    </div>
                ` : ''}
                
                ${result.key ? `
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #666; font-weight: 500;">Key:</span>
                        <span style="color: #1D4ED8; font-family: monospace; font-weight: 500;">${result.key}</span>
                    </div>
                ` : ''}
                
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666; font-weight: 500;">Status:</span>
                    <span style="color: #333;">${result.message || 'Ticket created successfully'}</span>
                </div>
                
                ${result.self_url || result.self ? `
                    <div style="margin-top: 6px; padding-top: 6px; border-top: 1px solid #e0e0e0;">
                        <span style="color: #666; font-weight: 500; display: block; margin-bottom: 4px;">URL:</span>
                        <a href="${result.self_url || result.self}" target="_blank" style="
                            color: #1D4ED8;
                            text-decoration: none;
                            font-size: 10px;
                            word-break: break-all;
                            display: block;
                        " onmouseover="this.style.textDecoration='underline'" 
                           onmouseout="this.style.textDecoration='none'">
                            ${result.self_url || result.self}
                        </a>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
    
    // Insert the response div after the button
    buttonElement.parentNode.insertBefore(responseDiv, buttonElement.nextSibling);
}

// Function to create Jira tickets for all annotations that don't have one yet
async function createAllJiraTickets() {
    console.log('Argo UAT: Creating Jira tickets for all annotations');
      // Find issues that don't have Jira tickets yet
    const issuesWithoutTickets = issuesList.filter(issue => !issue.jiraTicket);
    
    if (issuesWithoutTickets.length === 0) {
        console.log('Argo UAT: All annotations already have Jira tickets');
        showBulkActionMessage('All annotations already have Jira tickets', 'info');
        return;
    }
    
    // Check if any issues are missing mandatory parameters
    const issuesWithMissingParams = issuesWithoutTickets.filter(issue => !issue.project_id || !issue.page_id);
    
    if (issuesWithMissingParams.length > 0) {
        console.error('Argo UAT: Some annotations are missing mandatory parameters', issuesWithMissingParams);
        
        const missingCount = issuesWithMissingParams.length;
        const validCount = issuesWithoutTickets.length - missingCount;
        
        let errorMessage = `${missingCount} annotation${missingCount > 1 ? 's' : ''} missing required parameters (project_id/page_id).`;
        if (validCount > 0) {
            errorMessage += ` ${validCount} annotation${validCount > 1 ? 's' : ''} can be processed.`;
        }
        
        showBulkActionMessage(errorMessage, 'error');
        return;
    }
    
    console.log(`Argo UAT: Found ${issuesWithoutTickets.length} annotations without Jira tickets`);
    
    // Disable the bulk action button and show progress
    const bulkButton = document.getElementById('all-annotations-to-jira-btn');
    if (bulkButton) {
        const originalText = bulkButton.innerHTML;
        bulkButton.innerHTML = '<span>⏳</span><span>Creating Tickets...</span>';
        bulkButton.disabled = true;
        bulkButton.style.opacity = '0.7';
        bulkButton.style.cursor = 'not-allowed';
    }
    
    let successCount = 0;
    let errorCount = 0;
    const total = issuesWithoutTickets.length;
    
    // Process each issue one by one to avoid overwhelming the API
    for (let i = 0; i < issuesWithoutTickets.length; i++) {
        const issue = issuesWithoutTickets[i];
        const issueIndex = issuesList.findIndex(item => item.id === issue.id);
        
        if (issueIndex === -1) continue;
        
        try {
            // Update progress
            if (bulkButton) {
                bulkButton.innerHTML = `<span>⏳</span><span>Creating Tickets... (${i + 1}/${total})</span>`;
            }
            
            // Find the corresponding button element for this issue
            const issueButtons = document.querySelectorAll('.agro-create-jira-btn');
            let buttonElement = null;
            
            for (const btn of issueButtons) {
                if (parseInt(btn.getAttribute('data-issue-index')) === issueIndex) {
                    buttonElement = btn;
                    break;
                }
            }
            
            if (buttonElement) {
                // Create Jira ticket for this issue
                await createJiraTicket(issue, buttonElement);
                
                // Check if ticket was created successfully
                if (issue.jiraTicket) {
                    successCount++;
                } else {
                    errorCount++;
                }
            } else {
                console.warn('Argo UAT: Could not find button element for issue:', issue.name);
                errorCount++;
            }
            
            // Add a small delay between requests to be nice to the API
            await new Promise(resolve => setTimeout(resolve, 500));
            
        } catch (error) {
            console.error('Argo UAT: Error creating Jira ticket for issue:', issue.name, error);
            errorCount++;
        }
    }
    
    // Restore bulk button and show final result
    if (bulkButton) {
        bulkButton.innerHTML = '<span>🎫</span><span>All Annotations to Jira</span>';
        bulkButton.disabled = false;
        bulkButton.style.opacity = '1';
        bulkButton.style.cursor = 'pointer';
        
        // Update button visibility based on remaining issues
        updateBulkActionButton();
    }
    
    // Show completion message
    const message = successCount === total ? 
        `Successfully created ${successCount} Jira tickets!` :
        `Created ${successCount} tickets, ${errorCount} failed`;
    
    const messageType = errorCount === 0 ? 'success' : 'warning';
    showBulkActionMessage(message, messageType);
    
    console.log(`Argo UAT: Bulk Jira creation completed. Success: ${successCount}, Errors: ${errorCount}`);
}

// Function to show bulk action feedback messages
function showBulkActionMessage(text, type = 'info') {
    const bulkButton = document.getElementById('all-annotations-to-jira-btn');
    if (!bulkButton) return;
    
    const rect = bulkButton.getBoundingClientRect();
    const message = document.createElement('div');
    message.textContent = text;
    
    const colors = {
        success: 'rgba(76, 175, 80, 0.95)',
        warning: 'rgba(255, 152, 0, 0.95)',
        error: 'rgba(244, 67, 54, 0.95)',
        info: 'rgba(33, 150, 243, 0.95)'
    };
    
    message.style.cssText = `
        position: fixed;
        top: ${rect.top - 60}px;
        left: ${rect.left}px;
        background: ${colors[type] || colors.info};
        color: white;
        padding: 12px 16px;
        border-radius: 6px;
        font-size: 12px;
        font-family: Arial, sans-serif;
        font-weight: 500;
        z-index: 10001;
        pointer-events: none;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: fadeInOut 4s ease forwards;
        white-space: nowrap;
        max-width: 300px;
    `;
    
    document.body.appendChild(message);
    setTimeout(() => {
        if (message.parentNode) {
            message.parentNode.removeChild(message);
        }
    }, 4000);
}

// Function to update bulk action button visibility and state
function updateBulkActionButton() {
    const bulkContainer = document.getElementById('bulk-action-container');
    const bulkButton = document.getElementById('all-annotations-to-jira-btn');
    
    if (!bulkContainer || !bulkButton) {
        console.warn('Argo UAT: Bulk action button elements not found');
        return;
    }
      // Check if there are any issues without Jira tickets
    const issuesWithoutTickets = issuesList.filter(issue => !issue.jiraTicket);
    // Check if issues have mandatory parameters
    const issuesWithValidParams = issuesWithoutTickets.filter(issue => issue.project_id && issue.page_id);
    const issuesWithMissingParams = issuesWithoutTickets.filter(issue => !issue.project_id || !issue.page_id);
    
    const hasIssues = issuesList.length > 0;
    const hasUnticketed = issuesWithoutTickets.length > 0;
    const hasValidUnticketed = issuesWithValidParams.length > 0;
    
    console.log('Argo UAT: Updating bulk action button state:', {
        totalIssues: issuesList.length,
        issuesWithoutTickets: issuesWithoutTickets.length,
        issuesWithValidParams: issuesWithValidParams.length,
        issuesWithMissingParams: issuesWithMissingParams.length,
        hasIssues,
        hasUnticketed,
        hasValidUnticketed
    });
    
    if (hasIssues && hasValidUnticketed) {
        // Show the container and enable the button (has valid issues to process)
        bulkContainer.style.display = 'block';
        bulkButton.disabled = false;
        bulkButton.style.opacity = '1';
        bulkButton.style.cursor = 'pointer';
        
        let buttonText = `All Annotations to Jira (${issuesWithValidParams.length})`;
        if (issuesWithMissingParams.length > 0) {
            buttonText += ` - ${issuesWithMissingParams.length} missing params`;
        }
        bulkButton.innerHTML = `<span>🎫</span><span>${buttonText}</span>`;
        
    } else if (hasIssues && hasUnticketed && !hasValidUnticketed) {
        // Show the container but disable the button (issues exist but missing required params)
        bulkContainer.style.display = 'block';
        bulkButton.disabled = true;
        bulkButton.style.opacity = '0.5';
        bulkButton.style.cursor = 'not-allowed';
        bulkButton.innerHTML = '<span>⚠️</span><span>Missing Required Parameters</span>';
        bulkButton.title = 'project_id and page_id URL parameters are required for Jira submission';
        
    } else if (hasIssues && !hasUnticketed) {
        // Show the container but disable the button (all have tickets)
        bulkContainer.style.display = 'block';
        bulkButton.disabled = true;
        bulkButton.style.opacity = '0.5';
        bulkButton.style.cursor = 'not-allowed';
        bulkButton.innerHTML = '<span>✅</span><span>All Annotations Have Tickets</span>';
        bulkButton.title = 'All annotations already have Jira tickets';
        
    } else {
        // Hide the container (no issues)
        bulkContainer.style.display = 'none';
    }
}
