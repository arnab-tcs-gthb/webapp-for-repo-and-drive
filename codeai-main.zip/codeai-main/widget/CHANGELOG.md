# Argo UAT Chrome Extension - Changelog

## Version 2.3 - URL Tracking Enhancement 🌐

### ✨ **New Features Added**

#### 🌐 **URL Tracking & Search**
- **Page URL Capture**: Issues now automatically record the URL where they were reported
- **URL Display**: Clickable URLs shown in Element Details section (truncated to 50 chars for readability)
- **URL Search**: URL field included in search functionality - search by domain, page path, or specific URLs
- **New Tab Links**: URLs open in new tabs when clicked for easy navigation back to issue location

### 🔧 **Technical Enhancements**
- **Issue Object**: Enhanced with `url: window.location.href` field
- **Search Integration**: URL field included in multi-field search filtering
- **Display Updates**: Both normal and filtered issue displays show URL information
- **Link Styling**: Professional blue link styling with hover effects

---

## Version 2.2 - Search Functionality 🔍

### ✨ **New Features Added**

#### 🔍 **Annotations Search**
- **Search Input**: Added search box under "Annotations" heading for real-time filtering
- **Multi-field Search**: Search across issue names, types, priorities, comments, element details, and URLs
- **Smart Highlighting**: Matched search terms highlighted in yellow for easy identification
- **Clear Button**: ✕ button appears when typing, allows instant search reset
- **Enhanced Counter**: Shows filtered/total count (e.g., "3/8") with color coding
- **No Results Handling**: Custom message when no annotations match search terms
- **Case Insensitive**: Search works regardless of text capitalization

#### 🎨 **UI Enhancements**
- **Modern Design**: Rounded search input with search icon (🔍)
- **Focus States**: Green border and glow effect matching extension theme
- **Visual Feedback**: Counter changes color when filtering (orange for filtered results)
- **Preserved Functionality**: All existing features work seamlessly with search results

### 📊 **Search Capabilities**
- **Issue Properties**: Name, type, priority, comments
- **Element Details**: Tag name, text content, CSS selector, page URL
- **Real-time Results**: Updates instantly as you type
- **Partial Matching**: Finds results with partial text matches

### 📁 **Files Added**
- `search-test.html` - Comprehensive test page with diverse annotation scenarios
- `SEARCH-FUNCTIONALITY-SUMMARY.md` - Detailed implementation documentation

---

## Version 2.1 - Independent Collapse Button & Element Selection Fix 🆕

### 🛠️ **Bug Fixes**
- **Collapse Button Protection**: Fixed issue where collapse button could be selected during element selection mode
- **Event Exclusion**: Added collapse button (`#collapse-toggle-btn`) to exclusion list in element selection interceptor
- **Interaction Integrity**: Collapse button now functions normally even when element selection mode is active

### 🔧 **Code Refactoring**
- **Independent Button Creation**: Moved `createCollapseButton()` function outside of `createIssuesList()` for better modularity
- **Separate Management**: Collapse button is now created and managed independently from the issues list
- **Cleaner Architecture**: Removed collapse button logic from issues list creation for better separation of concerns

## Version 2.0 - Enhanced Panel Interactions

### ✨ **New Features Added**

#### 🎯 **Collapsible Issues Panel**
- **Collapse/Expand Button**: Click the folder icon (📁/📂) in the panel header
- **Space Saving**: Collapsed panel shows only the header to save screen real estate
- **State Persistence**: Collapsed/expanded state is remembered across browser sessions
- **Visual Feedback**: Smooth animations and hover effects for better UX

#### 🚀 **Draggable Panel Positioning**
- **Drag Handle**: Grab the panel header (look for ⋮⋮ drag indicator) to move anywhere
- **Viewport Constraints**: Panel stays within browser viewport boundaries
- **Position Memory**: Panel remembers its exact position across page reloads
- **Smooth Movement**: Fluid drag interactions with visual feedback

#### 🧠 **Smart Margin Management**
- **Adaptive Margins**: Page margin automatically adjusts based on panel position
- **Edge Detection**: When panel is at screen edges, page margin is applied
- **Dynamic Updates**: Margins adjust in real-time as panel is moved or collapsed
- **Smooth Transitions**: All margin changes use smooth CSS animations

#### 💾 **Enhanced Data Persistence**
- **Position Storage**: Panel position saved to Chrome local storage
- **State Memory**: Collapsed/expanded state persists across sessions
- **Automatic Restoration**: Panel returns to last position and state on page load

### 🎨 **UI/UX Improvements**

#### **Visual Enhancements**
- **Drag Indicators**: Clear visual cues (⋮⋮) show draggable areas
- **Hover Effects**: Headers highlight when hovering for better interaction feedback
- **Smooth Animations**: All transitions use cubic-bezier easing for professional feel
- **Border Styling**: Enhanced panel styling with rounded corners and better shadows

#### **Interaction Feedback**
- **Cursor Changes**: Cursor changes to grabbing/move states during interactions
- **Button States**: Collapse button changes icon and tooltip based on state
- **Visual Depth**: Panel gains elevation during drag operations
- **Resize Handle**: Panel can be resized by dragging bottom-right corner

### 🔧 **Technical Improvements**

#### **Code Architecture**
- **Modular Functions**: Added `makeDraggable()`, `setupCollapseToggle()`, `updatePageMarginForPosition()`
- **Event Management**: Proper event delegation and cleanup
- **Storage Integration**: Chrome storage API for persistence
- **Performance**: Optimized drag calculations and constraint checking

#### **CSS Enhancements**
- **Transition Classes**: Professional CSS transitions for all interactions
- **Responsive Design**: Panel adapts to different screen sizes
- **Visual States**: Proper styling for hover, active, and dragging states
- **Animation Performance**: Hardware-accelerated CSS transforms

### 📋 **Updated Documentation**

#### **README.md Updates**
- Added new feature descriptions with 🆕 indicators
- Updated feature list with collapsible and draggable capabilities
- Enhanced quick start guide with new interaction instructions

#### **TESTING-GUIDE.md Enhancements**
- New testing section for panel interactions
- Step-by-step instructions for drag and collapse testing
- Position memory verification procedures
- Updated feature descriptions

#### **test-page.html Improvements**
- Added testing instructions for new features
- Updated guidance with drag and collapse examples
- Enhanced visual layout with feature callouts

### 🏆 **Key Benefits**

1. **Better Screen Utilization**: Collapsible panel saves valuable screen space
2. **Flexible Positioning**: Draggable panel allows optimal workflow positioning
3. **Improved User Experience**: Smooth animations and intuitive interactions
4. **Persistent Preferences**: Settings remembered across browser sessions
5. **Professional Feel**: Enhanced visual design and interaction patterns

### 🧪 **Testing the New Features**

1. **Collapse Testing**: Click 📁/📂 button and verify panel collapses/expands
2. **Drag Testing**: Grab header and drag panel to different screen positions
3. **Memory Testing**: Refresh page and verify panel returns to same position
4. **Margin Testing**: Move panel to edges and verify page margins adjust
5. **State Testing**: Collapse panel, refresh, verify it stays collapsed

---

## Previous Versions

### Version 1.0 - Core UAT Functionality
- Element selection and highlighting system
- Issue tracking with priority color coding
- Click blocking for UAT workflows
- Right-column issues list
- Form validation and data management
- Permanent element highlighting for tracked issues

---

**Total Features**: 15+ comprehensive UAT testing capabilities
**Codebase**: 1,200+ lines of JavaScript, HTML, CSS
**Extension Type**: Manifest V3 Chrome Extension
**Compatibility**: All modern Chrome browsers
