import { render, screen } from '@testing-library/react';
import App from './App';

test('renders CodeAI homepage', () => {
  render(<App />);
  // Look for the main heading in the hero section instead of ambiguous "CodeAI" text
  const heroTitle = screen.getByRole('heading', { level: 1 });
  expect(heroTitle).toBeInTheDocument();
});

test('renders main navigation', () => {
  render(<App />);
  // Look specifically for the navigation with aria-label to avoid mobile/desktop duplicates
  const mainNav = screen.getByRole('navigation', { name: /main navigation/i });
  expect(mainNav).toBeInTheDocument();
});
