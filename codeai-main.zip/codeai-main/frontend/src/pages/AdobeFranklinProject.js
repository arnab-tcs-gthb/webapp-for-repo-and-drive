import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useLocation } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import DashboardSidebar from '../components/dashboard/DashboardSidebar';
import useNavigationCleanup from '../hooks/useNavigationCleanup';
import { AdobeFranklinWizard } from '../components/wizard';
import { ProjectProvider, FileProvider } from '../context';
import RightSidebar from '../components/common/RightSidebar';
import ChatView from '../components/common/ChatView';
import useChat from '../hooks/useChat';
import ApiServiceEnhanced from '../services/ApiServiceEnhanced';

// Helper function for file validation
const validateFileForProject = (file) => {
  // Define allowed MIME types based on backend requirements
  const ALLOWED_MIME_TYPES = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
    'application/zip',
    'application/x-zip-compressed'
  ];

  // File extension to MIME type mapping
  const FILE_TYPE_MAP = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.zip': 'application/x-zip-compressed'
  };

  // Special handling for zip files
  if (file.name.toLowerCase().endsWith('.zip')) {
    return new File([file], file.name, { type: 'application/x-zip-compressed' });
  }

  // Check if the file type is directly allowed
  if (ALLOWED_MIME_TYPES.includes(file.type)) {
    return file;
  }

  // Try to determine type from extension
  const extension = '.' + file.name.split('.').pop().toLowerCase();
  const detectedType = FILE_TYPE_MAP[extension];
  
  if (!detectedType) {
    throw new Error(
      `Unsupported file type for ${file.name}. Only images (.jpg, .jpeg, .png, .gif, .webp, .svg) and ZIP files are allowed.`
    );
  }

  if (!ALLOWED_MIME_TYPES.includes(detectedType)) {
    throw new Error(
      `File ${file.name} has an invalid type. Only images and ZIP files are allowed.`
    );
  }

  return new File([file], file.name, { type: detectedType });
};

// Page Layout Components
const PageContainer = styled.div`
  display: flex;
  min-height: 100vh;
  background-color: ${props => props.theme.colors?.background || '#f8f9fa'};
`;

const MainContent = styled.main.withConfig({
  shouldForwardProp: (prop) => !['sidebarCollapsed', 'chatOpen'].includes(prop),
})`
  flex: 1;
  margin-left: ${props => props.sidebarCollapsed ? '70px' : '240px'};
  margin-right: ${props => props.chatOpen ? '400px' : '50px'};
  width: calc(100% - ${props => props.sidebarCollapsed ? '70px' : '240px'} - ${props => props.chatOpen ? '400px' : '50px'});
  padding: 0;
  transition: margin-left 0.3s ease, margin-right 0.3s ease, width 0.3s ease;

  @media (max-width: 768px) {
    margin-left: 70px;
    margin-right: ${props => props.chatOpen ? '400px' : '50px'};
    width: calc(100% - 70px - ${props => props.chatOpen ? '400px' : '50px'});
    padding: 0;
  }
`;

/**
 * Adobe Franklin Project Page Component
 * 
 * This is the main page component that provides the context providers
 * and layout for the Adobe Franklin project wizard.
 */
const AdobeFranklinProjectPage = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  // Setup navigation cleanup
  useNavigationCleanup();

  // Extract project data from navigation state
  const projectData = location.state?.projectData;
  const projectId = projectData?.id || null;

  // Chat state management
  const {
    messages,
    isLoading: isChatLoading,
    sendMessage,
    clearMessages,
    addAIResponse,
    setIsLoading,
    updateMessage,
    getMessagesByType,
    addMessage,
    setMessages  // Add this line to destructure setMessages
  } = useChat([], {
    maxMessages: 100,
    autoScroll: true,
    simulateAIDelay: null // Disable local AI simulation
  });

  // Streaming chat handler
  const sendMessageStreaming = async (content, filePath = null) => {
    if (!content.trim()) return;

    // Create message content with file path if present
    const messageContent = filePath ? 
        `${content}\nFile: ${filePath}` : 
        content;

    // Add user message
    const userMessage = { 
        type: 'user', 
        content: messageContent, 
        timestamp: new Date().toISOString(),
        filePath // Store file path in message object
    };
    const userIndex = addMessage(userMessage);

    setIsLoading(true);
    let aiContent = '';
    // Add AI message immediately and get its index
    const aiMessage = { 
        type: 'ai', 
        content: '', 
        streaming: true, 
        timestamp: new Date().toISOString() 
    };
    const aiIndex = userIndex + 1;
    addMessage(aiMessage);

    try {
        await ApiServiceEnhanced.streamAemAgentChat(content, projectId, (chunk) => {
            if (chunk && chunk !== '[END_OF_STREAM]') {
                let parsedContent = '';
                if (chunk && typeof chunk === 'object' && chunk.content) {
                    parsedContent = chunk.content;
                } else if (typeof chunk === 'string') {
                    parsedContent = chunk;
                }
                aiContent += parsedContent;
                updateMessage(aiIndex, {
                    ...aiMessage,
                    content: aiContent
                });
            }
            if (chunk === '[END_OF_STREAM]') {
                updateMessage(aiIndex, {
                    ...aiMessage,
                    content: aiContent,
                    streaming: false
                });
            }
        });
    } catch (err) {
        console.error('Chat error:', err);
        updateMessage(aiIndex, {
            ...aiMessage,
            content: "Sorry, something went wrong while processing your request.",
            streaming: false
        });
    } finally {
        setIsLoading(false);
    }
  };

  // Handle sidebar collapse state
  const handleSidebarToggle = (collapsed) => {
    setSidebarCollapsed(collapsed);
  };

  // Filter out messages with no content, but keep user messages and streaming AI messages
  const filteredMessages = messages.filter(msg => 
    msg && typeof msg === 'object' && (
      msg.type === 'user' || // Always show user messages
      (msg.type === 'ai' && msg.content && msg.content.trim() !== '') // Only show AI messages with content
    )
  );

  return (
    <PageContainer theme={theme}>
      <DashboardSidebar onToggle={handleSidebarToggle} />
      <MainContent sidebarCollapsed={sidebarCollapsed} chatOpen={chatOpen}>
        <ProjectProvider projectId={projectId} projectData={projectData}>
          <FileProvider>
            <AdobeFranklinWizard 
              projectId={projectId}
              chatOpen={chatOpen}
              setChatOpen={setChatOpen}
            />
          </FileProvider>
        </ProjectProvider>
      </MainContent>
      <RightSidebar
        collapsed={!chatOpen}
        onToggle={(newCollapsedState) => setChatOpen(!newCollapsedState)}
        width="400px"
        zIndex={1000}
        tabs={[
          {
            id: 'chat',
            label: 'Chat',
            icon: '💬',
            content: (
              <ChatView
                title="Adobe Franklin Assistant"
                messages={filteredMessages}
                onSendMessage={sendMessageStreaming}
                isLoading={isChatLoading}
                placeholder="Ask me anything about your Adobe Franklin project..."
                showAttachment={true}
                maxMessageLength={2000}
                    acceptedFileTypes=".jpg,.jpeg,.png,.gif,.webp,.svg,.zip" // Only backend-allowed file types
                onFileSelect={(file) => {
                  try {
                    // Use validateAndSanitizeFile from ApiServiceEnhanced
                    // This will throw an error if file type is not supported
                    const validatedFile = validateFileForProject(file);
                    const filePath = validatedFile.path || URL.createObjectURL(validatedFile);
                    return filePath;
                  } catch (error) {
                    alert(`Error: ${error.message}`);
                    return null;
                  }
                }}
              />
            )
          },
          {
            id: 'help',
            label: 'Help',
            icon: '❓',
            content: (
              <div style={{ padding: '1rem' }}>
                <h3>Adobe Franklin Project Help</h3>
                <div style={{ marginTop: '1rem' }}>
                  <h4>Quick Tips:</h4>
                  <ul style={{ paddingLeft: '1rem' }}>
                    <li>Use the chat feature to ask questions about your project</li>
                    <li>Navigate between steps using the stepper at the top</li>
                    <li>Save your progress regularly</li>
                    <li>Preview your changes before proceeding</li>
                  </ul>
                </div>
              </div>
            )
          }
        ]}
      />
    </PageContainer>
  );
};

export default AdobeFranklinProjectPage;
