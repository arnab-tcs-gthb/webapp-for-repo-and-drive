import React, { useState } from 'react';
import styled from 'styled-components';
import { useLocation } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import DashboardSidebar from '../components/dashboard/DashboardSidebar';
import useNavigationCleanup from '../hooks/useNavigationCleanup';
import { AdobeFranklinWizard } from '../components/wizard';
import { ProjectProvider, FileProvider } from '../context';
import RightSidebar from '../components/common/RightSidebar';
import ChatView from '../components/common/ChatView';
import useChat from '../hooks/useChat';

// Page Layout Components
const PageContainer = styled.div`
  display: flex;
  min-height: 100vh;
  background-color: ${props => props.theme.colors?.background || '#f8f9fa'};
`;

const MainContent = styled.main.withConfig({
  shouldForwardProp: (prop) => !['sidebarCollapsed', 'chatOpen'].includes(prop),
})`
  flex: 1;
  margin-left: ${props => props.sidebarCollapsed ? '70px' : '240px'};
  margin-right: ${props => props.chatOpen ? '400px' : '50px'};
  width: calc(100% - ${props => props.sidebarCollapsed ? '70px' : '240px'} - ${props => props.chatOpen ? '400px' : '50px'});
  padding: 0;
  transition: margin-left 0.3s ease, margin-right 0.3s ease, width 0.3s ease;

  @media (max-width: 768px) {
    margin-left: 70px;
    margin-right: ${props => props.chatOpen ? '400px' : '50px'};
    width: calc(100% - 70px - ${props => props.chatOpen ? '400px' : '50px'});
    padding: 0;
  }
`;

/**
 * Adobe Franklin Project Page Component
 * 
 * This is the main page component that provides the context providers
 * and layout for the Adobe Franklin project wizard.
 */
const AdobeFranklinProjectPage = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  
  // Setup navigation cleanup
  useNavigationCleanup();

  // Extract project data from navigation state
  const projectData = location.state?.projectData;
  const projectId = projectData?.id || null;

  // Chat state management
  const {
    messages,
    isLoading: isChatLoading,
    sendMessage,
    clearMessages,
    addAIResponse
  } = useChat([], {
    maxMessages: 100,
    autoScroll: true,
    simulateAIDelay: 1000
  });

  // Handle sidebar collapse state
  const handleSidebarToggle = (collapsed) => {
    setSidebarCollapsed(collapsed);
  };

  return (
    <PageContainer theme={theme}>
      <DashboardSidebar onToggle={handleSidebarToggle} />
      <MainContent sidebarCollapsed={sidebarCollapsed} chatOpen={chatOpen}>
        <ProjectProvider projectId={projectId} projectData={projectData}>
          <FileProvider>
            <AdobeFranklinWizard 
              projectId={projectId}
              chatOpen={chatOpen}
              setChatOpen={setChatOpen}
            />
          </FileProvider>
        </ProjectProvider>
      </MainContent>
      
      {/* Chat Sidebar */}
      <RightSidebar
        collapsed={!chatOpen}
        onToggle={(newCollapsedState) => setChatOpen(!newCollapsedState)}
        width="400px"
        zIndex={1000}
        tabs={[
          {
            id: 'chat',
            label: 'Chat',
            icon: '💬',
            content: (
              <ChatView
                title="Adobe Franklin Assistant"
                messages={messages}
                onSendMessage={sendMessage}
                isLoading={isChatLoading}
                placeholder="Ask me anything about your Adobe Franklin project..."
                showAttachment={false}
              />
            )
          },
          {
            id: 'help',
            label: 'Help',
            icon: '❓',
            content: (
              <div style={{ padding: '1rem' }}>
                <h3>Adobe Franklin Project Help</h3>
                <div style={{ marginTop: '1rem' }}>
                  <h4>Quick Tips:</h4>
                  <ul style={{ paddingLeft: '1rem' }}>
                    <li>Use the chat feature to ask questions about your project</li>
                    <li>Navigate between steps using the stepper at the top</li>
                    <li>Save your progress regularly</li>
                    <li>Preview your changes before proceeding</li>
                  </ul>
                </div>
              </div>
            )
          }
        ]}
      />
    </PageContainer>
  );
};

export default AdobeFranklinProjectPage;
