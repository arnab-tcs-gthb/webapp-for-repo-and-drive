import axios from 'axios';
import config from '../config/config';
import { useLoading } from '../context/LoadingContext';

// Initialize loading context variables outside of service methods
let showLoading = () => {};
let hideLoading = () => {};

const setupLoadingHandlers = (loadingHandlers) => {
  if (loadingHandlers) {
    showLoading = loadingHandlers.showLoading;
    hideLoading = loadingHandlers.hideLoading;
  }
};

const ApiService = {
  setLoadingHandlers: setupLoadingHandlers,
  
  // Create a new project
  async createProject(projectData) {
    showLoading('Creating project...');
    try {
      const response = await axios.post(`${config.API_BASE_URL}/projects/`, projectData);
      hideLoading();
      return response.data;
    } catch (error) {
      hideLoading();
      console.error('Error creating project:', error);
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        const message = error.response.data?.detail || 'Server error occurred';
        throw new Error(message); // Don't add prefix to keep original error message
      } else if (error.request) {
        // The request was made but no response was received
        throw new Error('Network error. Please check your connection and try again.');
      } else {
        // Something happened in setting up the request
        throw error;
      }
    }
  },

  // Upload a file for a project
  async uploadProjectFile(projectId, file) {
    showLoading('Uploading file...');
    try {
      // Validate file size
      if (file.size > config.MAX_UPLOAD_SIZE) {
        hideLoading();
        throw new Error(`File size exceeds maximum allowed size of ${config.MAX_UPLOAD_SIZE / (1024 * 1024)}MB`);
      }
      
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await axios.post(
        `${config.API_BASE_URL}/projects/${projectId}/images/`, 
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      hideLoading();
      return response.data;
    } catch (error) {
      hideLoading();
      console.error('Error uploading file:', error);
      if (error.response) {
        const message = error.response.data?.detail || 'File upload failed';
        throw new Error(`Upload error: ${message}`);
      } else if (error.request) {
        throw new Error('Network error during upload. Please try again.');
      } else {
        throw error;
      }
    }
  },

  // Get images for a project
  async getProjectImages(projectId) {
    showLoading('Loading project images...');
    try {
      const response = await axios.get(`${config.API_BASE_URL}/projects/${projectId}/images/`);
      hideLoading();
      return response.data;
    } catch (error) {
      hideLoading();
      console.error('Error fetching project images:', error);
      if (error.response) {
        const message = error.response.data?.detail || 'Failed to load project images';
        throw new Error(`Image fetch error: ${message}`);
      } else if (error.request) {
        throw new Error('Network error when loading project images.');
      } else {
        throw error;
      }
    }
  },

  // Get templates
  async getTemplates(templateType = null) {
    showLoading('Loading templates...');
    try {
      const params = templateType ? { template_type: templateType } : {};
      const response = await axios.get(`${config.API_BASE_URL}/aem-templates/`, { params });
      hideLoading();
      return response.data;
    } catch (error) {
      hideLoading();
      console.error('Error fetching templates:', error);
      if (error.response) {
        const message = error.response.data?.detail || 'Failed to load templates';
        throw new Error(`Template error: ${message}`);
      } else if (error.request) {
        throw new Error('Network error when loading templates. Using default templates.');
      } else {
        throw error;
      }
    }
  },

  async getProjectAnalysis(projectId) {
    try {
      const response = await axios.get(`${config.API_BASE_URL}/projects/${projectId}/analysis`);
      return response.data;
    } catch (error) {
      console.error('Error fetching project analysis:', error);
      if (error.response) {
        const message = error.response.data?.detail || 'Failed to load project analysis';
        throw new Error(`Analysis fetch error: ${message}`);
      } else if (error.request) {
        throw new Error('Network error when loading project analysis.');
      } else {
        throw error;
      }
    }
  },

  // Get Metadata.
  async getMetadata(project_name) {
    showLoading('Analyzing project data...');
    try {
      if (!localStorage.getItem('analysis_api_call')) {
        localStorage.setItem('analysis_api_call', 'true');
        const response = await axios.post(`${config.API_BASE_URL}/analyze/`, {'project_name':project_name});
        if (response.data) {
          localStorage.removeItem('analysis_api_call');
        }
        hideLoading();
        return response.data;
      }
      hideLoading();
    } catch (error) {
      hideLoading();
      console.error('Error fetching metadata:', error);
      if (error.response) {
        const message = error.response.data?.detail || 'Failed to load metadata';
        throw new Error(`Metadata fetch error: ${message}`);
      } else if (error.request) {
        throw new Error('Network error when loading metadata. Please check the project name and try again.');
      } else {
        throw error;
      }
    }
  },

  // Get KB metadata
  async getKBMetadata() {
    showLoading('Loading knowledge base...');
    try {
      const response = await axios.get(`${config.API_BASE_URL}/kb-metadata/`);
      hideLoading();
      return response.data;
    } catch (error) {
      hideLoading();
      console.error('Error fetching KB metadata:', error);
      throw error;
    }
  },
  
  // Get all projects
  async getAllProjects() {
    showLoading('Loading projects...');
    try {
      const response = await axios.get(`${config.API_BASE_URL}/projects/`);
      hideLoading();
      return response.data;
    } catch (error) {
      hideLoading();
      console.error('Error fetching projects:', error);
      if (error.response) {
        const message = error.response.data?.detail || 'Failed to load projects';
        throw new Error(`Projects fetch error: ${message}`);
      } else if (error.request) {
        throw new Error('Network error when loading projects. Please try again later.');
      } else {
        throw error;
      }
    }
  }
};

export default ApiService;