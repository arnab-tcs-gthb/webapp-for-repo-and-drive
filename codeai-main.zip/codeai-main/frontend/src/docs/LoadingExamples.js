/**
 * This file contains example implementations of the loading state system.
 * These are not meant to be used directly but serve as reference examples.
 */
import React, { useState, useEffect } from 'react';
import ApiServiceEnhanced from '../services/ApiServiceEnhanced';
import { useApiRequest } from '../utils/apiUtils';
import useApiLoading from '../hooks/useApiLoading';
import { 
  Spinner, 
  SectionLoader, 
  LoadingGrid, 
  LoadingButton,
  SkeletonText 
} from '../components/common/LoadingStates';

/**
 * Example 1: Simple loading state with useApiLoading
 */
export const SimpleLoadingExample = () => {
  // Track all API calls
  const { isLoading } = useApiLoading();
  
  return (
    <div>
      <h2>Data</h2>
      {isLoading ? (
        <Spinner size="24px" />
      ) : (
        <div>Content is loaded!</div>
      )}
    </div>
  );
};

/**
 * Example 2: Component with API request using useApiRequest
 */
export const ApiRequestExample = () => {
  const { 
    isLoading, 
    error, 
    data, 
    execute: fetchProjects 
  } = useApiRequest(
    async () => {
      // API call is wrapped by the hook which handles loading state
      return await ApiServiceEnhanced.getAllProjects();
    },
    {
      // These callbacks are optional
      onSuccess: (data) => console.log('Data loaded successfully', data),
      onError: (err) => console.error('Error loading data', err)
    }
  );
  
  // Fetch data when component mounts
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);
  
  if (isLoading) {
    return (
      <SectionLoader>
        <Spinner />
        <p>Loading projects...</p>
      </SectionLoader>
    );
  }
  
  if (error) {
    return <div className="error">{error}</div>;
  }
  
  if (!data || data.length === 0) {
    return <div>No projects found.</div>;
  }
  
  return (
    <div>
      <h2>Projects</h2>
      <ul>
        {data.map(project => (
          <li key={project.id}>{project.name}</li>
        ))}
      </ul>
    </div>
  );
};

/**
 * Example 3: Skeleton loading for content
 */
export const SkeletonLoadingExample = () => {
  const [isLoading, setIsLoading] = useState(true);
  
  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="card">
      <h3>User Profile</h3>
      
      {isLoading ? (
        <>
          <SkeletonText width="70%" height="20px" />
          <SkeletonText width="40%" height="15px" />
          <SkeletonText width="90%" height="100px" />
        </>
      ) : (
        <>
          <h4>Jane Doe</h4>
          <p>Software Engineer</p>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Nulla facilisi. Sed euismod, nisl vel ultricies tincidunt.
          </p>
        </>
      )}
    </div>
  );
};

/**
 * Example 4: Loading button state
 */
export const LoadingButtonExample = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      console.log('Form submitted');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <form onSubmit={e => { e.preventDefault(); handleSubmit(); }}>
      <div>
        <label>
          Name:
          <input type="text" />
        </label>
      </div>
      
      <LoadingButton 
        isLoading={isSubmitting} 
        type="submit"
      >
        Submit
      </LoadingButton>
    </form>
  );
};

/**
 * Example 5: Tracking specific request with useApiLoading
 */
export const SpecificRequestExample = () => {
  // Track a specific request by its ID
  const { isLoading } = useApiLoading('get-user-data');
  
  const fetchUserData = async () => {
    // When using apiClient directly, you can specify a requestId
    await ApiServiceEnhanced.getUserData({
      requestId: 'get-user-data' // This ties to the useApiLoading hook above
    });
  };
  
  return (
    <div>
      <button onClick={fetchUserData} disabled={isLoading}>
        {isLoading ? 'Loading...' : 'Fetch User Data'}
      </button>
    </div>
  );
};
