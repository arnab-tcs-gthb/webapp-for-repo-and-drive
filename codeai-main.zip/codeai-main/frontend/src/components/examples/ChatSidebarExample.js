import React, { useState } from 'react';
import RightSidebar from '../common/RightSidebar';
import ChatView from '../common/ChatView';
import useChat from '../../hooks/useChat';

// Chat icon for tab
const ChatIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
  </svg>
);

// Help icon for tab
const HelpIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
    <point cx="12" cy="17"></point>
  </svg>
);

// Settings icon for tab  
const SettingsIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"></circle>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
  </svg>
);

/**
 * Example component showing how to use RightSidebar with ChatView
 * This can be used as a reference for implementing chat in other parts of the app
 */
const ChatSidebarExample = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  // Initialize chat with some demo messages
  const initialMessages = [
    {
      type: 'ai',
      content: 'Hello! I\'m your AI assistant. I can help you with your Adobe Franklin project. How can I assist you today?',
      timestamp: new Date().toISOString(),
    }
  ];

  const { messages, isLoading, sendMessage } = useChat(initialMessages, {
    simulateAIDelay: 1500,
    maxMessages: 50
  });

  // Handle sending messages from the chat
  const handleSendMessage = (content) => {
    sendMessage(content);
  };

  // Help content for the help tab
  const HelpContent = () => (
    <div style={{ padding: '1rem' }}>
      <h3>Adobe Franklin Assistant</h3>
      <div style={{ marginBottom: '1rem' }}>
        <h4>How to use:</h4>
        <ul style={{ paddingLeft: '1.5rem', lineHeight: '1.6' }}>
          <li>Ask questions about your project</li>
          <li>Get help with document mapping</li>
          <li>Request assistance with content generation</li>
          <li>Get deployment guidance</li>
        </ul>
      </div>
      <div style={{ marginBottom: '1rem' }}>
        <h4>Example questions:</h4>
        <ul style={{ paddingLeft: '1.5rem', lineHeight: '1.6' }}>
          <li>"How do I map my content to AEM blocks?"</li>
          <li>"What's the best practice for document structure?"</li>
          <li>"Help me with the deployment process"</li>
          <li>"How do I optimize my content for Franklin?"</li>
        </ul>
      </div>
    </div>
  );

  // Settings content for the settings tab
  const SettingsContent = () => (
    <div style={{ padding: '1rem' }}>
      <h3>Chat Settings</h3>
      <div style={{ marginBottom: '1rem' }}>
        <label style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
          <input type="checkbox" style={{ marginRight: '0.5rem' }} />
          Enable notifications
        </label>
        <label style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
          <input type="checkbox" style={{ marginRight: '0.5rem' }} />
          Auto-scroll to new messages
        </label>
        <label style={{ display: 'flex', alignItems: 'center', marginBottom: '0.5rem' }}>
          <input type="checkbox" defaultChecked style={{ marginRight: '0.5rem' }} />
          Show timestamps
        </label>
      </div>
      <div style={{ marginBottom: '1rem' }}>
        <label style={{ display: 'block', marginBottom: '0.5rem' }}>
          Max messages to keep:
        </label>
        <select style={{ width: '100%', padding: '0.5rem' }}>
          <option value="50">50 messages</option>
          <option value="100">100 messages</option>
          <option value="200">200 messages</option>
        </select>
      </div>
      <button style={{
        width: '100%',
        padding: '0.5rem',
        backgroundColor: '#dc3545',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
      }}>
        Clear Chat History
      </button>
    </div>
  );

  // Define tabs for the sidebar
  const tabs = [
    {
      id: 'chat',
      label: 'Chat',
      icon: <ChatIcon />,
      content: (
        <ChatView
          title="Adobe Franklin Assistant"
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          placeholder="Ask me anything about your Adobe Franklin project..."
          maxMessageLength={500}
        />
      )
    },
    {
      id: 'help',
      label: 'Help',
      icon: <HelpIcon />,
      content: <HelpContent />
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: <SettingsIcon />,
      content: <SettingsContent />
    }
  ];

  return (
    <RightSidebar
      collapsed={sidebarCollapsed}
      onToggle={setSidebarCollapsed}
      width="450px"
      tabs={tabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      zIndex={100}
    />
  );
};

export default ChatSidebarExample;
