import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import Button from '../ui/base/Button';
import { ThemeProvider } from '../../context/ThemeContext';

// Mock theme provider
const MockThemeProvider = ({ children }) => (
  <ThemeProvider>
    {children}
  </ThemeProvider>
);

describe('Button Component', () => {
  const renderButton = (props = {}) => {
    return render(
      <MockThemeProvider>
        <Button {...props} />
      </MockThemeProvider>
    );
  };

  it('renders with default props', () => {
    renderButton({ children: 'Click me' });
    
    const button = screen.getByRole('button', { name: /click me/i });
    expect(button).toBeInTheDocument();
    expect(button).toHaveAttribute('type', 'button');
  });

  it('renders different variants correctly', () => {
    const variants = ['primary', 'secondary', 'outline', 'ghost', 'danger', 'success'];
    
    variants.forEach(variant => {
      const { unmount } = renderButton({ 
        children: `${variant} button`, 
        variant 
      });
      
      const button = screen.getByRole('button', { name: new RegExp(variant, 'i') });
      expect(button).toBeInTheDocument();
      
      unmount();
    });
  });

  it('renders different sizes correctly', () => {
    const sizes = ['xs', 'sm', 'md', 'lg', 'xl'];
    
    sizes.forEach(size => {
      const { unmount } = renderButton({ 
        children: `${size} button`, 
        size 
      });
      
      const button = screen.getByRole('button', { name: new RegExp(size, 'i') });
      expect(button).toBeInTheDocument();
      
      unmount();
    });
  });

  it('handles click events', async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();
    
    renderButton({
      children: 'Click me',
      onClick: handleClick
    });
    
    const button = screen.getByRole('button', { name: /click me/i });
    await user.click(button);
    
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('is disabled when disabled prop is true', () => {
    renderButton({
      children: 'Disabled button',
      disabled: true
    });
    
    const button = screen.getByRole('button', { name: /disabled button/i });
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute('aria-disabled', 'true');
  });

  it('shows loading state', () => {
    renderButton({
      children: 'Loading button',
      loading: true
    });
    
    const button = screen.getByRole('button');
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute('aria-disabled', 'true');
  });

  it('does not trigger click when disabled', async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();
    
    renderButton({
      children: 'Disabled button',
      disabled: true,
      onClick: handleClick
    });
    
    const button = screen.getByRole('button', { name: /disabled button/i });
    await user.click(button);
    
    expect(handleClick).not.toHaveBeenCalled();
  });

  it('does not trigger click when loading', async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();
    
    renderButton({
      children: 'Loading button',
      loading: true,
      onClick: handleClick
    });
    
    const button = screen.getByRole('button');
    await user.click(button);
    
    expect(handleClick).not.toHaveBeenCalled();
  });

  it('renders with icons', () => {
    const leftIcon = <span data-testid="left-icon">←</span>;
    const rightIcon = <span data-testid="right-icon">→</span>;
    
    renderButton({
      children: 'Button with icons',
      leftIcon,
      rightIcon
    });
    
    expect(screen.getByTestId('left-icon')).toBeInTheDocument();
    expect(screen.getByTestId('right-icon')).toBeInTheDocument();
    expect(screen.getByText('Button with icons')).toBeInTheDocument();
  });

  it('hides icons when loading', () => {
    const leftIcon = <span data-testid="left-icon">←</span>;
    const rightIcon = <span data-testid="right-icon">→</span>;
    
    renderButton({
      children: 'Loading button',
      leftIcon,
      rightIcon,
      loading: true
    });
    
    expect(screen.queryByTestId('left-icon')).not.toBeInTheDocument();
    expect(screen.queryByTestId('right-icon')).not.toBeInTheDocument();
  });

  it('renders with full width', () => {
    renderButton({
      children: 'Full width button',
      fullWidth: true
    });
    
    const button = screen.getByRole('button', { name: /full width button/i });
    expect(button).toBeInTheDocument();
  });

  it('supports custom aria-label', () => {
    renderButton({
      children: 'Button',
      ariaLabel: 'Custom aria label'
    });
    
    const button = screen.getByRole('button', { name: /custom aria label/i });
    expect(button).toBeInTheDocument();
    expect(button).toHaveAttribute('aria-label', 'Custom aria label');
  });

  it('supports different button types', () => {
    const types = ['button', 'submit', 'reset'];
    
    types.forEach(type => {
      const { unmount } = renderButton({
        children: `${type} button`,
        type
      });
      
      const button = screen.getByRole('button', { name: new RegExp(type, 'i') });
      expect(button).toHaveAttribute('type', type);
      
      unmount();
    });
  });

  it('forwards ref correctly', () => {
    const ref = React.createRef();
    
    renderButton({
      children: 'Button with ref',
      ref
    });
    
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it('applies custom className', () => {
    renderButton({
      children: 'Custom button',
      className: 'custom-class'
    });
    
    const button = screen.getByRole('button', { name: /custom button/i });
    expect(button).toHaveClass('custom-class');
  });

  it('supports keyboard navigation', async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();
    
    renderButton({
      children: 'Keyboard button',
      onClick: handleClick
    });
    
    const button = screen.getByRole('button', { name: /keyboard button/i });
    button.focus();
    
    expect(button).toHaveFocus();
    
    await user.keyboard('{Enter}');
    expect(handleClick).toHaveBeenCalledTimes(1);
    
    await user.keyboard(' ');
    expect(handleClick).toHaveBeenCalledTimes(2);
  });
});
