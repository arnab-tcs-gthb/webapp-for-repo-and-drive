import React, { useState } from 'react';
import PropTypes from 'prop-types';
import RightSidebar from './RightSidebar';
import ChatView from './ChatView';

// Chat icon for the toggle button
const ChatIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
  </svg>
);

/**
 * ChatSidebar - A combined component that provides a chat interface in a right sidebar
 * This is a convenience component that combines RightSidebar and ChatView
 */
const ChatSidebar = ({
  // Sidebar props
  collapsed = true,
  onToggle,
  width = '400px',
  topOffset = '60px',
  zIndex = 10,
  
  // Chat props
  title = "Chat Assistant",
  messages = [],
  onSendMessage,
  onAttachment,
  placeholder = "Type your message here...",
  isTyping = false,
  showAttachment = true,
  disabled = false,
  welcomeMessage = "Hello! I'm your AI assistant. How can I help you today?",
  emptyStateMessage = "No messages yet. Start a conversation!",
  autoScroll = true,
  headerActions,
  
  // Combined props
  className
}) => {
  const [internalCollapsed, setInternalCollapsed] = useState(collapsed);
  
  const handleToggle = (newCollapsed) => {
    setInternalCollapsed(newCollapsed);
    if (onToggle) {
      onToggle(newCollapsed);
    }
  };

  const isCollapsed = onToggle ? collapsed : internalCollapsed;

  return (
    <RightSidebar
      collapsed={isCollapsed}
      onToggle={handleToggle}
      width={width}
      topOffset={topOffset}
      zIndex={zIndex}
      toggleIcon={<ChatIcon />}
      toggleTitle={isCollapsed ? "Show chat" : "Hide chat"}
      className={className}
    >
      <ChatView
        title={title}
        messages={messages}
        onSendMessage={onSendMessage}
        onAttachment={onAttachment}
        placeholder={placeholder}
        isTyping={isTyping}
        showAttachment={showAttachment}
        disabled={disabled}
        welcomeMessage={welcomeMessage}
        emptyStateMessage={emptyStateMessage}
        autoScroll={autoScroll}
        headerActions={headerActions}
      />
    </RightSidebar>
  );
};

ChatSidebar.propTypes = {
  // Sidebar props
  /** Whether the sidebar is collapsed */
  collapsed: PropTypes.bool,
  /** Callback function when toggle button is clicked */
  onToggle: PropTypes.func,
  /** Width of the sidebar when expanded */
  width: PropTypes.string,
  /** Top offset from the page top */
  topOffset: PropTypes.string,
  /** Z-index for layering */
  zIndex: PropTypes.number,
  
  // Chat props
  /** Title displayed in the chat header */
  title: PropTypes.string,
  /** Array of message objects */
  messages: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    type: PropTypes.oneOf(['user', 'ai', 'assistant', 'system']),
    content: PropTypes.string.isRequired,
    timestamp: PropTypes.string,
    sender: PropTypes.string
  })),
  /** Callback function when a message is sent */
  onSendMessage: PropTypes.func,
  /** Callback function when attachment button is clicked */
  onAttachment: PropTypes.func,
  /** Placeholder text for the input */
  placeholder: PropTypes.string,
  /** Whether to show typing indicator */
  isTyping: PropTypes.bool,
  /** Whether to show attachment button */
  showAttachment: PropTypes.bool,
  /** Whether the chat is disabled */
  disabled: PropTypes.bool,
  /** Welcome message to show when chat starts */
  welcomeMessage: PropTypes.string,
  /** Message to show when no messages exist */
  emptyStateMessage: PropTypes.string,
  /** Whether to auto-scroll to bottom on new messages */
  autoScroll: PropTypes.bool,
  /** Additional actions to show in the header */
  headerActions: PropTypes.node,
  
  // Combined props
  /** Additional CSS class */
  className: PropTypes.string
};

export default ChatSidebar;
