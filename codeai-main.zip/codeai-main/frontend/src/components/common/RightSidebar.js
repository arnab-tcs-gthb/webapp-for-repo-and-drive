import React, { useState } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { useTheme } from '../../context/ThemeContext';

// Sidebar container
const SidebarContainer = styled.div`
  position: fixed;
  right: 0;
  top: 0;
  bottom: 0;
  height: 100vh;
  width: ${props => props['data-collapsed'] === 'true' ? '50px' : props.width};
  background-color: ${props => props.theme.colors.cardBackground};
  border-left: 1px solid ${props => props.theme.colors.border};
  display: flex;
  flex-direction: column;
  transition: width 0.3s ease;
  overflow: hidden;
`;

// Toggle button container 
const ToggleContainer = styled.div`
  display: flex;
  justify-content: ${props => props['data-collapsed'] === 'true' ? 'center' : 'space-between'};
  align-items: center;
  height: 60px;
  padding: ${props => props['data-collapsed'] === 'true' ? '0' : '0 1rem'};
  border-bottom: ${props => props['data-collapsed'] === 'true' ? 'none' : `1px solid ${props.theme.colors.border}`};
  background-color: ${props => props.theme.colors.cardBackground};
`;

// Toggle button (for collapsed state and left side of expanded state)
const ToggleButton = styled.button`
  border: none;
  background: none;
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.theme.colors.text};
  cursor: pointer;
  transition: all 0.2s;
  padding: 0.5rem;
  border-radius: 4px;
  
  &:hover {
    background-color: ${props => props.theme.colors.inputBackground};
    color: ${props => props.theme.colors.primary};
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`;

// Close button (for right side of expanded state)
const CloseButton = styled.button`
  border: none;
  background: none;
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.theme.colors.textSecondary};
  cursor: pointer;
  transition: all 0.2s;
  padding: 0.5rem;
  border-radius: 4px;
  
  &:hover {
    background-color: ${props => props.theme.colors.inputBackground};
    color: ${props => props.theme.colors.text};
  }
  
  svg {
    width: 16px;
    height: 16px;
  }
`;

// Content area
const SidebarContent = styled.div`
  flex: 1;
  overflow: hidden;
  display: ${props => props.collapsed ? 'none' : 'flex'};
  flex-direction: column;
`;

// Tab navigation (if multiple tabs)
const TabNavigation = styled.div`
  display: flex;
  border-bottom: 1px solid ${props => props.theme.colors.border};
  background-color: ${props => props.theme.colors.surface};
`;

const TabButton = styled.button`
  flex: 1;
  padding: 0.75rem 1rem;
  border: none;
  background: none;
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.textSecondary};
  border-bottom: 2px solid ${props => props.active ? props.theme.colors.primary : 'transparent'};
  cursor: pointer;
  transition: all 0.2s;
  font-weight: ${props => props.active ? '600' : '400'};
  
  &:hover {
    color: ${props => props.theme.colors.primary};
    background-color: ${props => props.theme.colors.inputBackground};
  }
`;

// Tab content area
const TabContent = styled.div`
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

// Header for single content mode
const SidebarHeader = styled.div`
  padding: 1rem;
  border-bottom: 1px solid ${props => props.theme.colors.border};
  background-color: ${props => props.theme.colors.surface};
  font-weight: 600;
  color: ${props => props.theme.colors.text};
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

// Chat icon for toggle
const ChatIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
  </svg>
);

// Close icon for expanded state
const CloseIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"/>
    <line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);

/**
 * RightSidebar Component - A reusable collapsible right sidebar
 */
const RightSidebar = ({
  children,
  collapsed = false,
  onToggle,
  width = '400px',
  title,
  tabs = [],
  activeTab = 0,
  onTabChange,
  toggleIcon,
  zIndex = 10,
  className,
  style
}) => {
  const { theme } = useTheme();
  const [internalCollapsed, setInternalCollapsed] = useState(collapsed);
  const [internalActiveTab, setInternalActiveTab] = useState(activeTab);

  const isCollapsed = onToggle ? collapsed : internalCollapsed;
  const currentActiveTab = onTabChange ? activeTab : internalActiveTab;

  const handleToggle = () => {
    if (onToggle) {
      onToggle(!collapsed);
    } else {
      setInternalCollapsed(!internalCollapsed);
    }
  };

  const handleTabChange = (tabIndex) => {
    if (onTabChange) {
      onTabChange(tabIndex);
    } else {
      setInternalActiveTab(tabIndex);
    }
  };

  const renderContent = () => {
    if (tabs.length > 0) {
      return (
        <>
          <TabNavigation>
            {tabs.map((tab, index) => (
              <TabButton
                key={tab.id || index}
                active={currentActiveTab === index}
                onClick={() => handleTabChange(index)}
              >
                {tab.icon && <span style={{ marginRight: '0.5rem' }}>{tab.icon}</span>}
                {tab.label}
              </TabButton>
            ))}
          </TabNavigation>
          <TabContent>
            {tabs[currentActiveTab]?.content || children}
          </TabContent>
        </>
      );
    }

    return (
      <>
        {title && (
          <SidebarHeader>
            <span>{title}</span>
          </SidebarHeader>
        )}
        <TabContent>
          {children}
        </TabContent>
      </>
    );
  };

  return (
    <SidebarContainer
      data-collapsed={isCollapsed ? "true" : "false"}
      width={width}
      className={className}
      style={{ ...style, zIndex }}
    >
      <ToggleContainer data-collapsed={isCollapsed ? "true" : "false"}>
        {isCollapsed ? (
          // When collapsed, show only the chat icon in center
          <ToggleButton
            onClick={handleToggle}
            title="Open chat"
            type="button"
          >
            {toggleIcon || <ChatIcon />}
          </ToggleButton>
        ) : (
          // When expanded, show chat icon on left and close icon on right
          <>
            <ToggleButton
              onClick={handleToggle}
              title="Chat"
            >
              <ChatIcon />
            </ToggleButton>
            <CloseButton
              onClick={handleToggle}
              title="Close chat"
            >
              <CloseIcon />
            </CloseButton>
          </>
        )}
      </ToggleContainer>

      <SidebarContent collapsed={isCollapsed}>
        {renderContent()}
      </SidebarContent>
    </SidebarContainer>
  );
};

RightSidebar.propTypes = {
  /** Content to display in the sidebar */
  children: PropTypes.node,
  /** Whether the sidebar is collapsed */
  collapsed: PropTypes.bool,
  /** Callback when sidebar is toggled */
  onToggle: PropTypes.func,
  /** Width of the expanded sidebar */
  width: PropTypes.string,
  /** Title for single content mode */
  title: PropTypes.string,
  /** Array of tab objects with id, label, icon, and content */
  tabs: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string,
    label: PropTypes.string.isRequired,
    icon: PropTypes.node,
    content: PropTypes.node
  })),
  /** Active tab index */
  activeTab: PropTypes.number,
  /** Callback when tab changes */
  onTabChange: PropTypes.func,
  /** Custom toggle icon */
  toggleIcon: PropTypes.node,
  /** Z-index for the sidebar */
  zIndex: PropTypes.number,
  /** Additional CSS class */
  className: PropTypes.string,
  /** Additional inline styles */
  style: PropTypes.object
};

export default RightSidebar;