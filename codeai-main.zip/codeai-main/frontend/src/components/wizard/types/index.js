import PropTypes from 'prop-types';

// File type definitions
export const FileType = PropTypes.shape({
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  name: PropTypes.string.isRequired,
  extension: PropTypes.string,
  size: PropTypes.number,
  type: PropTypes.string,
  path: PropTypes.string,
  previewUrl: PropTypes.string,
  uploadedAt: PropTypes.string,
  originalFile: PropTypes.object
});

// Project metadata type
export const ProjectMetadataType = PropTypes.shape({
  pages: PropTypes.number,
  links: PropTypes.number,
  images: PropTypes.number,
  blocks: PropTypes.number,
  forms: PropTypes.number,
  videos: PropTypes.number
});

// Content mapping type
export const ContentMappingType = PropTypes.shape({
  isValid: PropTypes.bool,
  mappings: PropTypes.arrayOf(PropTypes.object)
});

// Preview type
export const PreviewType = PropTypes.shape({
  generated: PropTypes.bool,
  url: PropTypes.string
});

// Deployment type
export const DeploymentType = PropTypes.shape({
  configured: PropTypes.bool,
  status: PropTypes.oneOf(['pending', 'in-progress', 'completed', 'failed'])
});

// Project data type
export const ProjectDataType = PropTypes.shape({
  name: PropTypes.string,
  description: PropTypes.string,
  template: PropTypes.string,
  brand: PropTypes.string,
  url: PropTypes.string,
  metadata: ProjectMetadataType,
  files: PropTypes.arrayOf(FileType),
  contentMapping: ContentMappingType,
  preview: PreviewType,
  deployment: DeploymentType
});

// Step navigation type
export const StepNavigationType = PropTypes.shape({
  currentStep: PropTypes.number.isRequired,
  totalSteps: PropTypes.number.isRequired,
  stepName: PropTypes.string,
  canProceed: PropTypes.bool,
  isFirstStep: PropTypes.bool,
  isLastStep: PropTypes.bool
});

// Upload progress type
export const UploadProgressType = PropTypes.objectOf(PropTypes.number);

// File tree node type
export const FileTreeNodeType = PropTypes.shape({
  name: PropTypes.string.isRequired,
  type: PropTypes.oneOf(['file', 'folder']).isRequired,
  children: PropTypes.object,
  file: FileType
});

// Validation result type
export const ValidationResultType = PropTypes.shape({
  isValid: PropTypes.bool.isRequired,
  errors: PropTypes.arrayOf(PropTypes.string)
});

// Step component props type
export const StepComponentPropsType = PropTypes.shape({
  onStepComplete: PropTypes.func.isRequired,
  onStepError: PropTypes.func.isRequired,
  onStepValidate: PropTypes.func,
  stepData: PropTypes.object
});

// Common component props
export const ThemeType = PropTypes.shape({
  colors: PropTypes.object.isRequired,
  spacing: PropTypes.object,
  breakpoints: PropTypes.object,
  shadows: PropTypes.object,
  borderRadius: PropTypes.object
});

// File management hook return type
export const FileManagementHookType = PropTypes.shape({
  files: PropTypes.arrayOf(FileType),
  fileTree: PropTypes.object,
  uploadProgress: UploadProgressType,
  isUploading: PropTypes.bool,
  previewCache: PropTypes.object,
  uploadFiles: PropTypes.func,
  removeFile: PropTypes.func,
  getFilePreview: PropTypes.func,
  validateFiles: PropTypes.func,
  cancelUpload: PropTypes.func
});

// Project wizard hook return type
export const ProjectWizardHookType = PropTypes.shape({
  currentStep: PropTypes.number,
  totalSteps: PropTypes.number,
  stepName: PropTypes.string,
  stepErrors: PropTypes.object,
  completedSteps: PropTypes.arrayOf(PropTypes.number),
  goToStep: PropTypes.func,
  nextStep: PropTypes.func,
  previousStep: PropTypes.func,
  validateCurrentStep: PropTypes.func,
  canProceed: PropTypes.bool,
  isFirstStep: PropTypes.bool,
  isLastStep: PropTypes.bool
});

// Error state type
export const ErrorStateType = PropTypes.shape({
  message: PropTypes.string,
  code: PropTypes.string,
  details: PropTypes.object
});

// Loading state type
export const LoadingStateType = PropTypes.shape({
  project: PropTypes.bool,
  metadata: PropTypes.bool,
  analysis: PropTypes.bool,
  upload: PropTypes.bool,
  preview: PropTypes.bool
});

export default {
  FileType,
  ProjectMetadataType,
  ContentMappingType,
  PreviewType,
  DeploymentType,
  ProjectDataType,
  StepNavigationType,
  UploadProgressType,
  FileTreeNodeType,
  ValidationResultType,
  StepComponentPropsType,
  ThemeType,
  FileManagementHookType,
  ProjectWizardHookType,
  ErrorStateType,
  LoadingStateType
};
