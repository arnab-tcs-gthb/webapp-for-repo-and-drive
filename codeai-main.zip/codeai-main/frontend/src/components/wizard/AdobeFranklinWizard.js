/**
 * Adobe Franklin Project Wizard - Main Orchestrator Component
 * 
 * This is the refactored main component that orchestrates the Adobe Franklin
 * project creation wizard. It uses the modular architecture with contexts,
 * hooks, and step components.
 * 
 * Replaces the original 3,392-line monolithic implementation with a clean,
 * maintainable structure.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';

// Hooks
import { useProjectWizard } from '../../hooks/adobe-franklin/useProjectWizard';
import { useFileManagement } from '../../hooks/adobe-franklin/useFileManagement';
import { useAdobeFranklinAPI } from '../../hooks/adobe-franklin/useAdobeFranklinAPI';
import { useToast } from '../../components/common/Toast';

// Step components
import {
  StepProjectSetup,
  StepContentMapping,
  StepPreviewGeneration,
  StepTesting,
  StepDeployment
} from './steps';

// Styled components
import {
  WizardContainer,
  WizardContent,
  StepContent,
  StepperContainer,
  StepperStep,
  StepNumber,
  StepTitle,
  StepDescription,
  StepSeparator,
  ButtonGroup,
  PrimaryButton,
  SecondaryButton,
  BackButton,
  CancelButton,
  LoadingSpinner,
  LoadingContainer,
  theme
} from '../ui/adobe-franklin';

const mock_json = {
  "ticket_detail": [
    {
      "jira_url": "https://example.atlassian.net/browse/AEM-1",
      "jira_id": "AEM-1",
      "page_name": "Homepage",
      "preview_url": "https://example.com/preview/homepage"
    },
    {
      "jira_url": "https://example.atlassian.net/browse/AEM-6",
      "jira_id": "AEM-6",
      "page_name": "Homepage",
      "preview_url": "https://example.com/preview/homepage"
    },
    {
      "jira_url": "https://example.atlassian.net/browse/AEM-2",
      "jira_id": "AEM-2",
      "page_name": "About Us",
      "preview_url": "https://example.com/preview/about-us"
    },
    {
      "jira_url": "https://example.atlassian.net/browse/AEM-3",
      "jira_id": "AEM-3",
      "page_name": "Contact Us",
      "preview_url": "https://example.com/preview/contact-us"
    },
    {
      "jira_url": "https://example.atlassian.net/browse/AEM-4",
      "jira_id": "AEM-4",
      "page_name": "Services",
      "preview_url": "https://example.com/preview/services"
    },
    {
      // "jira_url":"https://example.atlassian.net/browse/AEM-5",
      // "jira_id":"AEM-5",
      "page_name": "Blog",
      "preview_url": "https://example.com/preview/blog"
    }
  ],
  "total_number_of_tickets": 5
}


/**
 * Main Adobe Franklin Wizard Component
 */
const AdobeFranklinWizard = ({
  projectId = null,
  initialStep = 1,
  onComplete = null,
  onCancel = null,
  chatOpen = false,
  setChatOpen = null
}) => {
  const navigate = useNavigate();
  const toast = useToast();

  // Fallback toast function in case the imported useToast doesn't work
  const showToast = (title, description, status = 'info') => {
    if (toast && typeof toast === 'function') {
      // Use the imported toast function if available
      toast({ title, description, status, duration: 5000, isClosable: true, position: 'top' });
    } else {
      // Fallback to a simple DOM-based toast
      const toastEl = document.createElement('div');
      toastEl.style.position = 'fixed';
      toastEl.style.bottom = '20px';
      toastEl.style.right = '20px';
      toastEl.style.backgroundColor = status === 'warning' ? '#f57c00' :
        status === 'error' ? '#d32f2f' :
          status === 'success' ? '#2e7d32' : '#2196f3';
      toastEl.style.color = 'white';
      toastEl.style.padding = '15px';
      toastEl.style.borderRadius = '4px';
      toastEl.style.zIndex = '1000';
      toastEl.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
      toastEl.innerHTML = `<strong>${title}</strong><br>${description}`;
      document.body.appendChild(toastEl);
      setTimeout(() => {
        if (toastEl.parentNode) {
          document.body.removeChild(toastEl);
        }
      }, 5000);
    }
  };

  // Project wizard state and functions
  const {
    activeStep: currentStep,
    completedSteps,
    goToStep,
    nextStep,
    previousStep,
    markStepComplete,
    isStepComplete,
    projectData,
    updateProjectData,
    saveProgress,
    loadProgress,
    isFirstStep,
    isLastStep,
    canGoNext,
    canGoPrevious,
    validateStep,
    errors,
    isLoading,
    timer,
    updateKbMetadata,
    updateAnalysisMetadata,
    updateProjectAnalysis,
    updateDocumentHierarchy
  } = useProjectWizard({
    initialStep,
    projectId,
    onComplete: handleWizardComplete,
    onCancel: handleWizardCancel
  });

  // File management state and functions
  const {
    uploadedFiles,
    uploadProgress,
    isUploading,
    previewCache,
    uploadFiles,
    removeFile,
    getFilePreview,
    validateFiles,
    getFileTree,
    clearFiles
  } = useFileManagement();
  // Adobe Franklin API integration
  const {
    projectId: apiProjectId,
    uploadedFiles: apiUploadedFiles,
    kbMetadata,
    analysisMetadata,
    projectAnalysis,
    documentHierarchy,
    project_details,
    isLoading: isApiLoading,
    isAnalysisLoading,
    setIsAnalysisLoading,
    isAnalysisDataLoading,
    isDocGenerationLoading,
    apiStartTime,
    elapsedTime,
    fetchKbMetadata,
    fetchAnalysisMetadata,
    fetchProjectImages,
    fetchProjectAnalysis,
    postMappingData,
    generateDocumentation,
    executeStepAction,
    getUATData,
    stopTimer: stopApiTimer,
    resetData
  } = useAdobeFranklinAPI(projectId); // Pass the projectId to the hook

  // Wizard step configuration
  const wizardSteps = [
    {
      id: 1,
      title: 'Project Setup',
      description: 'Configure project template and upload design files',
      component: StepProjectSetup,
      requiredFields: ['templateType', 'projectName'],
      estimatedTime: '5-10 minutes'
    },
    {
      id: 2,
      title: 'Content Mapping',
      description: 'Map content structure and analyze pages',
      component: StepContentMapping,
      requiredFields: ['contentMapping'],
      estimatedTime: '10-15 minutes'
    },
    {
      id: 3,
      title: 'Preview Generation',
      description: 'Generate document and website previews',
      component: StepPreviewGeneration,
      requiredFields: ['previewGenerated'],
      estimatedTime: '15-20 minutes'
    },
    {
      id: 4,
      title: 'QA Testing',
      description: 'Run Quality Assurance testing and validation',
      component: StepTesting,
      isUATStep: false,
      requiredFields: ['qaTestingComplete'],
      estimatedTime: '15-20 minutes'
    },
    {
      id: 5,
      title: 'UAT Testing',
      description: 'Run User Acceptance Testing',
      component: StepTesting,
      mockData: mock_json,
      isUATStep: true,
      requiredFields: ['uatTestingComplete'],
      estimatedTime: '20-30 minutes'
    },
    {
      id: 6,
      title: 'Deployment',
      description: 'Deploy to production environment',
      component: StepDeployment,
      requiredFields: ['deploymentComplete'],
      estimatedTime: '10-15 minutes'
    }
  ];

  // Handler functions
  function handleWizardComplete(finalData) {
    if (onComplete) {
      onComplete(finalData);
    } else {
      navigate('/projects', {
        state: {
          message: 'Adobe Franklin project created successfully!',
          projectData: finalData
        }
      });
    }
  }

  function handleWizardCancel() {
    if (onCancel) {
      onCancel();
    } else {
      navigate('/projects');
    }
  }

  function handleStepNavigation(stepId) {
    if (stepId < currentStep || validateStep(currentStep, projectData)) {
      goToStep(stepId);
    }
  }

  function handleBack() {
    previousStep();
  }

  function handleCancel() {
    if (window.confirm('Are you sure you want to cancel? All progress will be lost.')) {
      handleWizardCancel();
    }
  }

  // Step-specific action handlers that integrate API calls
  async function handleStepAction() {
    try {
      // Handle different actions based on current step
      switch (currentStep) {
        case 1:
          // Step 1: Run content mapping
          const result = await executeStepAction(1);
          if (!result.success) {
            throw new Error(result.message);
          }
          updateProjectData({
            step1Complete: true,
            contentMappingInitiated: true,
            lastCompletedStep: 1
          });
          await fetchProjectAnalysis();
          break;

        case 2:
          // Step 2: Generate documentation
          const docResult = await executeStepAction(2);
          if (!docResult.success) {
            throw new Error(docResult.message);
          }
          updateProjectData({
            step2Complete: true,
            documentationGenerated: true,
            lastCompletedStep: 2
          });
          break;

        case 3:
          // Step 3: Preview generation
          const analysisResult = await executeStepAction(3);
          if (!analysisResult.success) {
            throw new Error(analysisResult.message);
          }
          updateProjectData({
            step3Complete: true,
            previewGenerated: true,
            lastCompletedStep: 3
          });
          break;

        case 4:
          // Step 4: QA Testing setup and enable UAT
          console.log('✅ Setting up QA Testing and enabling UAT');
          updateProjectData({
            step4Complete: true,
            qaTestingSetup: true,
            qaTestingActive: true,
            uatTestingSetup: true, // Initialize UAT testing when moving to Step 5
            lastCompletedStep: 4
          });
          break;

        case 5:
          // Step 5: UAT Testing setup
          console.log('✅ Setting up UAT Testing');
          updateProjectData({
            step5Complete: true,
            uatTestingSetup: true,
            uatTestingActive: true,
            lastCompletedStep: 5
          });
          break;

        case 6:
          // Step 6: Deploy to production
          console.log('✅ Starting deployment process');
          updateProjectData({
            step6Complete: true,
            deploymentStarted: true,
            lastCompletedStep: 6
          });
          handleWizardComplete(projectData);
          return;
      }      // Move to next step if action was successful
      if (currentStep === 1) {        // Double-check that analysis has been completed
        if (!analysisMetadata || !analysisMetadata.images) {
          // Show toast notification
          showToast(
            'Analysis Required',
            'Please analyze your project images before proceeding to the mapping step.',
            'warning'
          ); return; // Stop here, don't proceed
        }

        // Success notification when proceeding to mapping step
        showToast(
          'Proceeding to Mapping',
          'Analysis data is ready for the content mapping step.',
          'success'
        );

        goToStep(2);
      } else {
        const stepTransitionSuccess = await nextStep();
        if (!stepTransitionSuccess) {
          goToStep(currentStep + 1);
        }
      }
    } catch (error) {
      console.error(`❌ Step ${currentStep} action failed:`, error);

      // Check for specific error types with enhanced error handling
      if (error.isPandocError || (error.message && error.message.includes('pandoc'))) {
        showToast(
          'Document Generation Failed',
          'Pandoc is not installed on the server. Please contact the administrator.',
          'error'
        );
      } else if (error.isImageError || (error.message && error.message.includes('images') && error.message.includes('found'))) {
        showToast(
          'Document Generation Failed',
          'One or more images referenced in the document could not be found. Please ensure all images are properly uploaded.',
          'error'
        );
      } else if (error.isDriveError || (error.message && error.message.includes('Drive folder'))) {
        showToast(
          'Document Generation Failed',
          'There was an issue with creating the necessary folder structure. Please try again.',
          'error'
        );
      } else {
        showToast(
          'Action Failed',
          error.message || 'An unexpected error occurred',
          'error'
        );
      }
    }
  }

  // Get button text based on current step
  function getStepActionText() {
    switch (currentStep) {
      case 1: return 'Continue to Mapping';
      case 2: return 'Generate Documentation';
      case 3: return 'Start QA Testing';
      case 4: return 'Start UAT Testing';
      case 5: return 'Deploy to Production';
      case 6: return 'Complete Project';
      default: return 'Next Step';
    }
  }
  // State for view controls
  const [projectFilter, setProjectFilter] = useState('');
  const [qaTableView, setQaTableView] = useState('table');
  const [uatTableView, setUatTableView] = useState('table');
  const [uatGroupByPage, setUatGroupByPage] = useState(false);

  // UAT data state management
  const [uatData, setUatData] = useState(null);
  const [isUatLoading, setIsUatLoading] = useState(false);
  const [uatError, setUatError] = useState(null);

  // Console log when uatTableView changes
  useEffect(() => {
    console.log('UAT Table View changed to:', uatTableView);
  }, [uatTableView]);

  // Handler for UAT table view changes
  const handleUatTableViewChange = useCallback((newView) => {
    console.log('Handling UAT table view change:', newView);
    setUatTableView(newView);
  }, []);

  // Handler for UAT group by page changes
  const handleUatGroupByPageChange = useCallback((newValue) => {
    console.log('Handling UAT group by page change:', newValue);
    setUatGroupByPage(newValue);
  }, []);

  // Get current step configuration
  const currentStepConfig = wizardSteps.find(step => step.id === currentStep);
  const StepComponent = currentStepConfig?.component;

  // Auto-save progress - using useRef to avoid infinite loops
  const saveProgressRef = useRef(saveProgress);
  saveProgressRef.current = saveProgress;

  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      saveProgressRef.current();
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, []); // Empty dependency array - stable interval

  // Load progress on mount only
  const loadProgressRef = useRef(loadProgress);
  loadProgressRef.current = loadProgress;

  useEffect(() => {
    if (projectId) {
      loadProgressRef.current(projectId);
    }
  }, [projectId]); // Only depend on projectId changes

  // Sync API data with wizard state - using refs to avoid circular dependencies
  const updateKbMetadataRef = useRef(updateKbMetadata);
  updateKbMetadataRef.current = updateKbMetadata;

  const prevKbMetadataRef = useRef();
  useEffect(() => {
    if (kbMetadata && kbMetadata !== prevKbMetadataRef.current) {
      prevKbMetadataRef.current = kbMetadata;
      updateKbMetadataRef.current(kbMetadata);
    }
  }, [kbMetadata]); // Only depend on kbMetadata changes

  const updateAnalysisMetadataRef = useRef(updateAnalysisMetadata);
  updateAnalysisMetadataRef.current = updateAnalysisMetadata;

  const prevAnalysisMetadataRef = useRef();
  useEffect(() => {
    if (analysisMetadata && analysisMetadata !== prevAnalysisMetadataRef.current) {
      prevAnalysisMetadataRef.current = analysisMetadata;
      updateAnalysisMetadataRef.current(analysisMetadata);
    }
  }, [analysisMetadata]); // Only depend on analysisMetadata changes

  const updateProjectAnalysisRef = useRef(updateProjectAnalysis);
  updateProjectAnalysisRef.current = updateProjectAnalysis;

  const prevProjectAnalysisRef = useRef();
  useEffect(() => {
    if (projectAnalysis && projectAnalysis.length > 0 && projectAnalysis !== prevProjectAnalysisRef.current) {
      prevProjectAnalysisRef.current = projectAnalysis;
      updateProjectAnalysisRef.current(projectAnalysis);
    }
  }, [projectAnalysis]); // Only depend on projectAnalysis changes

  const updateDocumentHierarchyRef = useRef(updateDocumentHierarchy);
  updateDocumentHierarchyRef.current = updateDocumentHierarchy;

  const prevDocumentHierarchyRef = useRef();
  useEffect(() => {
    if (documentHierarchy && documentHierarchy.length > 0 && documentHierarchy !== prevDocumentHierarchyRef.current) {
      prevDocumentHierarchyRef.current = documentHierarchy;
      updateDocumentHierarchyRef.current(documentHierarchy);
    }
  }, [documentHierarchy]); // Only depend on documentHierarchy changes

  // Auto-fetch project analysis when Step 2 becomes active
  useEffect(() => {
    // Trigger project analysis fetch when stepping into Step 2 (Content Mapping)
    // and there's no existing project analysis data
    if (currentStep === 2 && projectId && (!projectAnalysis || projectAnalysis.length === 0)) {
      console.log('📊 Step 2 active - fetching project analysis...');
      fetchProjectAnalysis();
    }
  }, [currentStep, projectId, projectAnalysis, fetchProjectAnalysis]);

  // Auto-fetch UAT data when Step 5 becomes active
  useEffect(() => {
    // Trigger UAT data fetch when stepping into Step 5 (UAT Testing)
    // and there's no existing UAT data
    if (currentStep === 5 && projectId && !uatData && !isUatLoading) {
      console.log('🧪 Step 5 active - fetching UAT data...');
      setIsUatLoading(true);
      setUatError(null);

      getUATData()
        .then((data) => {
          console.log('✅ UAT data fetched successfully:', data);
          setUatData(data);
        })
        .catch((error) => {
          console.error('❌ Failed to fetch UAT data:', error);
          setUatError(error.message || 'Failed to load UAT data');
        })
        .finally(() => {
          setIsUatLoading(false);
        });
    }
  }, [currentStep, projectId, uatData, isUatLoading, getUATData]);

  // Preview step state management
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewTab, setPreviewTab] = useState('document');
  const [isDocLoading, setIsDocLoading] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState(new Set());
  const docxPreviewRef = useRef(null);

  // File tree and preview functions
  const getFileTreeStructure = () => {
    const tree = {};

    // If documentHierarchy data exists and has structure, use that
    if (documentHierarchy) {
      console.log("Using documentHierarchy for file tree:", documentHierarchy);

      // Case 1: New hierarchical structure with nested 'documents' and 'children'
      if (documentHierarchy.documents && typeof documentHierarchy.documents === 'object') {
        // Process nested structure recursively
        const processNestedStructure = (node, currentTree = tree) => {
          if (!node) return;

          // Handle folder nodes with children
          if (node.type === 'folder' || node.nodeType === 'folder') {
            const folderName = node.name;

            // Create folder in tree if it doesn't exist
            if (!currentTree[folderName]) {
              currentTree[folderName] = {
                name: folderName,
                type: 'folder',
                children: {}
              };
            }

            // Process children if they exist
            if (node.children) {
              // Handle children as object (key-value pairs)
              if (typeof node.children === 'object' && !Array.isArray(node.children)) {
                Object.entries(node.children).forEach(([childName, childNode]) => {
                  processNestedStructure(childNode, currentTree[folderName].children);
                });
              }
              // Handle children as array
              else if (Array.isArray(node.children)) {
                node.children.forEach(childItem => {
                  if (typeof childItem === 'object') {
                    processNestedStructure(childItem, currentTree[folderName].children);
                  }
                });
              }
            }
          }
          // Handle file nodes
          else if (node.type === 'file' || node.nodeType === 'file') {
            const fileName = node.name;
            const fileExt = fileName.split('.').pop().toLowerCase();

            currentTree[fileName] = {
              id: node.id || `doc-${Math.random().toString(36).substr(2, 9)}`,
              name: fileName,
              type: node.type || (fileExt === 'docx' ? 'docx' : fileExt),
              path: node.url || node.path || '',
              url: node.url || '',
              preview_url: node.preview_url || '',
              publish_url: node.publish_url || '',
              size: node.size || 0,
              lastModified: node.lastModified || new Date().toLocaleDateString(),
              fileType: 'file'
            };
          }
        };

        processNestedStructure(documentHierarchy.documents);
      }
      // Case 2: Simple array structure
      else if (Array.isArray(documentHierarchy)) {
        documentHierarchy.forEach((doc, index) => {
          const fileName = doc.filename || doc.name || `Document ${index + 1}`;
          const fileExt = fileName.split('.').pop().toLowerCase();

          tree[fileName] = {
            id: doc.id || `doc-${index}`,
            name: fileName,
            type: fileExt === 'docx' ? 'docx' : fileExt,
            path: doc.url || doc.path || '',
            url: doc.url || '',
            preview_url: doc.preview_url || '',
            publish_url: doc.publish_url || '',
            size: doc.size || 0,
            lastModified: doc.lastModified || new Date().toLocaleDateString(),
            fileType: 'file'
          };
        });
      }
    }

    // If no documentHierarchy, fall back to uploaded files
    if (Object.keys(tree).length === 0 && apiUploadedFiles && apiUploadedFiles.length > 0) {
      apiUploadedFiles.forEach((file, index) => {
        const fileName = file.filename || file.name || `File ${index + 1}`;
        const fileExt = fileName.split('.').pop().toLowerCase();

        tree[fileName] = {
          id: file.id || `file-${index}`,
          name: fileName,
          type: fileExt,
          path: file.path || '',
          url: file.url || '',
          preview_url: file.preview_url || '',
          publish_url: file.publish_url || '',
          size: file.size || 0,
          lastModified: file.lastModified || new Date().toLocaleDateString(),
          fileType: 'file'
        };
      });
    }

    return tree;
  };

  const renderFileTree = (tree) => {
    const { TreeFile, TreeFileIcon, TreeFileName, TreeFolder, TreeFolderHeader, TreeFolderIcon, TreeFolderName, TreeFolderContent, FolderIcon } = require('../ui/adobe-franklin');

    return Object.keys(tree).map(key => {
      const item = tree[key];

      if (item.type === 'folder' || item.fileType === 'folder') {
        const isExpanded = expandedFolders.has(item.name);
        return (
          <TreeFolder key={item.name}>
            <TreeFolderHeader onClick={() => toggleFolder(item.name)}>
              <TreeFolderIcon>
                <FolderIcon />
              </TreeFolderIcon>
              <TreeFolderName>{item.name}</TreeFolderName>
            </TreeFolderHeader>
            {isExpanded && item.children && (
              <TreeFolderContent>
                {renderFileTree(item.children)}
              </TreeFolderContent>
            )}
          </TreeFolder>
        );
      } else {
        return (
          <TreeFile
            key={item.id || item.name}
            onClick={() => handleFileSelect(item)}
            style={{
              backgroundColor: selectedFile?.id === item.id ? 'rgba(0,0,0,0.1)' : 'transparent'
            }}
          >
            <TreeFileIcon>
              {getFileIcon(item.name)}
            </TreeFileIcon>
            <TreeFileName>{item.name}</TreeFileName>
          </TreeFile>
        );
      }
    });
  };

  const toggleFolder = (folderName) => {
    setExpandedFolders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(folderName)) {
        newSet.delete(folderName);
      } else {
        newSet.add(folderName);
      }
      return newSet;
    });
  };

  const handleFileSelect = (file) => {
    setSelectedFile(file);
  };

  const handlePreviewTabChange = (tab) => {
    setPreviewTab(tab);
  };

  const handleEditDocument = (document) => {
    console.log('Edit document:', document);

    // Check if document has a Google Docs URL
    if (document && document.url) {
      try {
        // Open Google Docs URL in new tab
        window.open(document.url, '_blank', 'noopener,noreferrer');
        console.log('Opened document for editing:', document.name);
      } catch (error) {
        console.error('Failed to open document:', error);
        alert('Failed to open the document. Please check if your browser allows pop-ups.');
      }
    } else {
      console.warn('No editable URL found for document:', document?.name || 'Unknown document');
      // Provide more specific feedback based on what's available
      if (!document) {
        alert('No document selected for editing.');
      } else if (!document.url) {
        alert(`The document "${document.name}" does not have an editable URL available.`);
      }
    }
  };

  const getFileIcon = (fileName) => {
    // Import utility function from styled components
    const { getFileIcon } = require('../ui/adobe-franklin');
    return getFileIcon(fileName);
  };

  // Base test data configuration
  const qaTestData = [
    {
      id: 'QA-001',
      title: 'Homepage Navigation Test',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Passed',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-002',
      title: 'Responsive Layout Validation',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Failed',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-003',
      title: 'Content Rendering Check',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Failed',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-004',
      title: 'Form Validation Test',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Blocked',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-005',
      title: 'Search Functionality',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Blocked',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-006',
      title: 'Image Loading Test',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Blocked',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-007',
      title: 'Performance Testing',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'Blocked',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-008',
      title: 'User Authentication',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'In Progress',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-009',
      title: 'Session Management',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'In Progress',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    },
    {
      id: 'QA-010',
      title: 'Error Handling',
      link: '/home',
      type: 'Functional',
      severity: 'Medium',
      status: 'In Progress',
      assignedTo: 'Lorem ipsum',
      lastUpdate: '01 Jun 2025'
    }
  ];

  // QA Test Summary Stats
  const qaStats = {
    passed: 1,
    failed: 2,
    blocked: 4,
    inProgress: 3,
    notRun: 4
  };

  // UAT test data configuration
  const uatTestData = [
    {
      id: 'UAT-001',
      pageName: 'Homepage',
      previewLink: '/preview/home',
      jiraTicket: 'AEM-123',
      type: 'Core Functionality',
      assignedTo: 'John Smith',
      severity: 'High',
      status: 'In Progress',
      lastUpdate: '10 Jun 2025'
    },
    {
      id: 'UAT-002',
      pageName: 'Homepage',
      previewLink: '/preview/home',
      jiraTicket: 'AEM-124',
      type: 'Navigation',
      assignedTo: 'Jane Doe',
      severity: 'Medium',
      status: 'Passed',
      lastUpdate: '10 Jun 2025'
    },
    {
      id: 'UAT-003',
      pageName: 'Product Listing',
      previewLink: '/preview/products',
      jiraTicket: 'AEM-125',
      type: 'Content',
      assignedTo: 'Mike Johnson',
      severity: 'High',
      status: 'Failed',
      lastUpdate: '10 Jun 2025'
    },
    {
      id: 'UAT-004',
      pageName: 'Product Listing',
      previewLink: '/preview/products',
      jiraTicket: 'AEM-126',
      type: 'Search',
      assignedTo: 'Sarah Wilson',
      severity: 'Critical',
      status: 'Blocked',
      lastUpdate: '10 Jun 2025'
    },
    {
      id: 'UAT-005',
      pageName: 'Contact Form',
      previewLink: '/preview/contact',
      jiraTicket: 'AEM-127',
      type: 'Form Validation',
      assignedTo: 'Tom Brown',
      severity: 'Medium',
      status: 'Not Started',
      lastUpdate: '10 Jun 2025'
    }
  ];

  // UAT Test Summary Stats
  const uatStats = {
    passed: 1,
    failed: 1,
    blocked: 1,
    inProgress: 1,
    notRun: 1
  };
  // Removed redundant state initialization - already defined above
  // Widget detection code temporarily disabled
  /*
  const [hasArgoWidget, setHasArgoWidget] = useState(false);

  useEffect(() => {
    const checkArgoWidget = () => {
      const bodyElement = document.querySelector('body');
      const hasWidget = bodyElement?.getAttribute('data-argo-widget') === 'true';
      setHasArgoWidget(hasWidget);
    };

    checkArgoWidget();

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'data-argo-widget') {
          checkArgoWidget();
        }
      });
    });

    const bodyElement = document.querySelector('body');
    if (bodyElement) {
      observer.observe(bodyElement, { attributes: true });
    }

    return () => observer.disconnect();
  }, []);
  */

  if (isLoading) {
    return (
      <LoadingContainer>
        <LoadingSpinner />
        <p>Loading Adobe Franklin Project Wizard...</p>
      </LoadingContainer>
    );
  }

  return (
    <WizardContainer>
      {/* Step Navigation */}
      <StepperContainer>
        {wizardSteps.map((step, index) => (
          <React.Fragment key={step.id}>
            <StepperStep
              active={step.id === currentStep}
              completed={step.id < currentStep}
              clickable={step.id <= currentStep}
              onClick={() => handleStepNavigation(step.id)}
            >
              <StepNumber
                active={step.id === currentStep}
                completed={step.id < currentStep}
              >
                {step.id < currentStep ? '✓' : step.id}
              </StepNumber>
              <div>
                <StepTitle
                  active={step.id === currentStep}
                  completed={step.id < currentStep}
                >
                  {step.title}
                </StepTitle>
                <StepDescription>{step.description}</StepDescription>
              </div>
            </StepperStep>
            {index < wizardSteps.length - 1 && <StepSeparator />}
          </React.Fragment>
        ))}
      </StepperContainer>

      {/* Main Content */}
      <WizardContent>
        <StepContent>              {StepComponent && (
          <StepComponent
            projectData={projectData}
            uploadedFiles={apiUploadedFiles || uploadedFiles}
            filePreviewCache={previewCache}
            isUploading={isUploading}
            uploadProgress={uploadProgress}
            onDataUpdate={updateProjectData}
            onFileUpload={uploadFiles}
            onFileRemove={removeFile}
            onPreviewGenerate={getFilePreview}
            mockData={currentStepConfig.mockData}
            isUATStep={currentStepConfig.isUATStep}
            errors={errors}
            {...(currentStepConfig.id === 1 && {
              projectDetails: project_details,
              kbMetadata: kbMetadata,
              analysisMetadata: analysisMetadata,
              isLoading: isApiLoading,
              isAnalysisLoading: isAnalysisLoading, onAnalyze: async () => {
                // Trigger analysis for the project
                if (!projectId) {
                  console.warn('Cannot analyze: No project ID available');
                  alert('Cannot analyze: No project ID available. Please create or select a project first.');
                  return;
                }

                try {
                  console.log('Starting image analysis for project:', projectId);
                  setIsAnalysisLoading(true);

                  // Log project ID information to help debug
                  console.log('Project ID details:', {
                    projectId,
                    projectIdType: typeof projectId,
                    projectIdValid: Boolean(projectId)
                  });

                  // Show a notification while analyzing
                  const toast = document.createElement('div');
                  toast.style.position = 'fixed';
                  toast.style.bottom = '20px';
                  toast.style.right = '20px';
                  toast.style.backgroundColor = '#4CAF50';
                  toast.style.color = 'white';
                  toast.style.padding = '15px';
                  toast.style.borderRadius = '4px';
                  toast.style.zIndex = '1000';
                  toast.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
                  toast.textContent = 'Analyzing images, please wait...';
                  document.body.appendChild(toast);

                  // First prepare captioning, then fetch metadata - force a fresh analysis
                  await fetchAnalysisMetadata(true); // Force refetch

                  // Update notification with success
                  toast.textContent = 'Image analysis completed successfully!';

                  // Remove notification after 3 seconds
                  setTimeout(() => {
                    if (toast.parentNode) {
                      document.body.removeChild(toast);
                    }
                  }, 3000);
                  console.log('Analysis completed successfully');
                } catch (error) {
                  console.error('Error during analysis:', error);
                  console.error('Error response data:', error.response?.data);
                  console.error('Error request details:', {
                    url: error.config?.url,
                    method: error.config?.method,
                    data: error.config?.data ? JSON.parse(error.config.data) : null,
                    headers: error.config?.headers,
                    status: error.response?.status
                  });

                  // Extract the most useful error message
                  let errorMessage = 'Failed to analyze images.';
                  if (error.response?.data?.detail) {
                    // Handle FastAPI validation errors
                    if (Array.isArray(error.response.data.detail)) {
                      console.log('FastAPI validation errors:', error.response.data.detail);
                      errorMessage += ' Validation errors:\n' +
                        error.response.data.detail.map(err => {
                          const field = err.loc?.slice(1).join('.') || 'unknown';
                          return `- ${field}: ${err.msg}`;
                        }).join('\n');
                    } else {
                      console.log('FastAPI error detail:', error.response.data.detail);
                      errorMessage += ' ' + error.response.data.detail;
                    }
                  } else if (error.message) {
                    errorMessage += ' ' + error.message;
                  }

                  alert(errorMessage);
                } finally {
                  setIsAnalysisLoading(false);
                }
              },
              getFileIcon: (fileName) => {
                // Import utility function from styled components
                const { getFileIcon } = require('../ui/adobe-franklin');
                return getFileIcon(fileName);
              },
              getFileColor: (extension) => {
                // Add utility function for file colors
                const colors = {
                  pdf: '#FF6B6B',
                  doc: '#4ECDC4',
                  docx: '#4ECDC4',
                  xlsx: '#45B7D1',
                  ppt: '#96CEB4',
                  pptx: '#96CEB4',
                  default: '#DDD6FE'
                };
                return colors[extension] || colors.default;
              },
              formatFileSize: (bytes) => {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
              }
            })}
            {...(currentStepConfig.id === 2 && {
              projectData: projectData,
              projectAnalysis: projectAnalysis,
              elapsedTime: elapsedTime,
              isAnalysisDataLoading: isAnalysisDataLoading,
              analysisMetadata: analysisMetadata,
              onMappingUpdate: (mapping) => updateProjectData({ contentMapping: mapping }),
              onRegeneratePages: () => {
                console.log('Regenerate pages clicked');
                // Trigger re-fetch of project analysis
                fetchProjectAnalysis();
              },
              onEditPage: (page) => {
                console.log('Edit page:', page);
                // Handle page editing logic
              },
              onRemovePage: (page) => {
                console.log('Remove page:', page);
                // Handle page removal logic
              }
            })}
            {...(currentStepConfig.id === 3 && {
              projectData: projectData,
              selectedFile: selectedFile,
              previewTab: previewTab,
              isDocLoading: isDocLoading,
              docxPreviewRef: docxPreviewRef,
              documentHierarchy: documentHierarchy,
              projectAnalysis: projectAnalysis,
              elapsedTime: elapsedTime,
              isAnalysisDataLoading: isAnalysisDataLoading,
              onPreviewTabChange: handlePreviewTabChange,
              onEditDocument: handleEditDocument,
              onFileSelect: handleFileSelect,
              renderFileTree: renderFileTree,
              getFileTreeStructure: getFileTreeStructure,
              onPreviewUpdate: (preview) => updateProjectData({ previewData: preview })
            })}                  {...(currentStepConfig.id === 4 && {
              qaTestData: qaTestData,
              qaStats: qaStats,
              onCreateTest: (testData) => {
                updateProjectData({
                  qaTestData: [...(projectData.qaTestData || []), testData]
                });
              },
              onTestAction: (action, data) => {
                updateProjectData({
                  testingData: {
                    ...projectData.testingData,
                    [action]: data
                  }
                });
              },
              isUATStep: false
            })}                  {...(currentStepConfig.id === 5 && {
              // UAT data from API
              uatData: uatData,
              isLoading: isUatLoading,
              error: uatError,
              getUATData: getUATData,

              // Legacy props for compatibility
              uatTestData: uatTestData,
              uatStats: uatStats,
              uatTableView: uatTableView,
              uatGroupByPage: uatGroupByPage,
              onUatTableViewChange: handleUatTableViewChange,
              onUatGroupByPageChange: handleUatGroupByPageChange,
              onCreateTest: (testData) => {
                updateProjectData({
                  uatTestData: [...(projectData.uatTestData || []), testData]
                });
              },
              onTestAction: (action, data) => {
                updateProjectData({
                  uatTestingData: {
                    ...projectData.uatTestingData,
                    [action]: data
                  }
                });
              },
              isUATStep: true
            })}                  {...(currentStepConfig.id === 6 && {
              projectData: projectData,
              uatTestData: uatTestData,
              onDeploymentAction: (action, data) => {
                console.log('Deployment action:', action, data);
                switch (action) {
                  case 'deployTicket':
                    // Handle ticket deployment
                    updateProjectData({
                      deployedTickets: [...(projectData.deployedTickets || []), data]
                    });
                    break;
                  default:
                    console.log('Unknown deployment action:', action);
                }
              },
              onEnvironmentAction: (action, env) => {
                console.log('Environment action:', action, env);
                switch (action) {
                  case 'deploy':
                    // Handle environment deployment
                    updateProjectData({
                      environments: (projectData.environments || []).map(e =>
                        e.name === env.name
                          ? { ...e, status: 'Deploying', lastDeployed: new Date().toLocaleDateString() }
                          : e
                      )
                    });
                    break;
                  case 'view':
                    // Handle environment view
                    window.open(env.url, '_blank', 'noopener,noreferrer');
                    break;
                  default:
                    console.log('Unknown environment action:', action);
                }
              }
            })}
          />
        )}
        </StepContent>

        {/* Loading indicator for API operations */}
        {(() => {
          // Show loading based on current step requirements
          switch (currentStep) {
            case 1:
              // For Step 1, only show loading if KB metadata is not loaded
              return isApiLoading && !kbMetadata;
            case 2:
              // For Step 2, show loading for documentation generation or analysis
              return isDocGenerationLoading || isAnalysisLoading || isAnalysisDataLoading;
            case 3:
              // For Step 3, show loading if analysis is still running
              return isAnalysisLoading || isAnalysisDataLoading;
            default:
              // For other steps, show loading if any critical operation is running
              return isApiLoading || isAnalysisLoading || isAnalysisDataLoading || isDocGenerationLoading;
          }
        })() && (
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '1rem',
              gap: '0.5rem'
            }}>
              <LoadingSpinner size="small" />
              <span>
                {currentStep === 1 && isApiLoading && 'Loading project data...'}
                {currentStep >= 2 && isDocGenerationLoading && 'Generating documentation...'}
                {currentStep > 1 && !isDocGenerationLoading && isAnalysisLoading && 'Analyzing project data...'}
                {currentStep > 1 && !isDocGenerationLoading && !isAnalysisLoading && isAnalysisDataLoading && `Processing analysis... ${elapsedTime}`}
              </span>
            </div>
          )}

        {/* Navigation Buttons */}
        <ButtonGroup>
          <div>
            <CancelButton onClick={handleCancel}>
              Cancel
            </CancelButton>
            {currentStep > 1 && (
              <BackButton onClick={handleBack}>
                Back
              </BackButton>
            )}
          </div>
          <div>
            {currentStep < wizardSteps.length ? (
              <PrimaryButton
                onClick={handleStepAction}
                disabled={(() => {
                  // Step-specific validation and loading conditions
                  switch (currentStep) {
                    case 1:
                      // For Step 1, check if kbMetadata is loaded and not currently loading
                      // Also check if analysis metadata exists for the project
                      const step1Valid = kbMetadata !== null;
                      const step1Loading = isApiLoading && !kbMetadata;
                      // Disable the "Continue to Mapping" button if analysis has not been run yet
                      const analysisNotComplete = !analysisMetadata || !analysisMetadata.images;
                      return !step1Valid || step1Loading || analysisNotComplete;
                    case 2:
                      // For Step 2, disable while documentation is generating or analysis is running
                      return isDocGenerationLoading || isAnalysisLoading || isAnalysisDataLoading;
                    case 3:
                      return isAnalysisLoading || isAnalysisDataLoading; case 4:
                      // For QA Testing step, enable button when QA testing is set up
                      return false; // Always enable "Start UAT Testing" button in QA step
                    case 5:
                      // For UAT Testing step, UAT testing should be set up
                      return isApiLoading;
                    default:
                      return isApiLoading || isAnalysisLoading || isAnalysisDataLoading || isDocGenerationLoading;
                  }
                })()}
              >
                {getStepActionText()}
              </PrimaryButton>
            ) : (
              <PrimaryButton
                onClick={() => handleWizardComplete(projectData)}
                disabled={isApiLoading || isAnalysisLoading || isAnalysisDataLoading || isDocGenerationLoading}
              >
                Complete Project
              </PrimaryButton>
            )}
          </div>
        </ButtonGroup>
      </WizardContent>
    </WizardContainer>
  );
};

// PropTypes
AdobeFranklinWizard.propTypes = {
  projectId: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  initialStep: PropTypes.number,
  onComplete: PropTypes.func,
  onCancel: PropTypes.func,
  chatOpen: PropTypes.bool,
  setChatOpen: PropTypes.func
};

export default AdobeFranklinWizard;