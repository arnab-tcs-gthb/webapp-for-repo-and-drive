/**
 * Adobe Franklin Project Wizard - Main Orchestrator Component
 * 
 * This is the refactored main component that orchestrates the Adobe Franklin
 * project creation wizard. It uses the modular architecture with contexts,
 * hooks, and step components.
 * 
 * Replaces the original 3,392-line monolithic implementation with a clean,
 * maintainable structure.
 */

import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';

// Hooks
import { useProjectWizard } from '../../hooks/adobe-franklin/useProjectWizard';
import { useFileManagement } from '../../hooks/adobe-franklin/useFileManagement';
import { useAdobeFranklinAPI } from '../../hooks/adobe-franklin/useAdobeFranklinAPI';

// Step components
import {
  StepProjectSetup,
  StepContentMapping,
  StepPreviewGeneration,
  StepTesting,
  StepDeployment
} from './steps';

// Styled components
import {
  WizardContainer,
  WizardContent,
  StepContent,
  StepperContainer,
  StepperStep,
  StepNumber,
  StepTitle,
  StepDescription,
  StepSeparator,
  ButtonGroup,
  PrimaryButton,
  SecondaryButton,
  BackButton,
  CancelButton,
  LoadingSpinner,
  LoadingContainer,
  theme
} from '../ui/adobe-franklin';

/**
 * Main Adobe Franklin Wizard Component
 */
const AdobeFranklinWizard = ({ 
  projectId = null,
  initialStep = 1,
  onComplete = null,
  onCancel = null,
  chatOpen = false,
  setChatOpen = null
}) => {
  const navigate = useNavigate();
  
  // Project wizard state and functions
  const {
    activeStep: currentStep,
    completedSteps,
    goToStep,
    nextStep,
    previousStep,
    markStepComplete,
    isStepComplete,
    projectData,
    updateProjectData,
    saveProgress,
    loadProgress,
    isFirstStep,
    isLastStep,
    canGoNext,
    canGoPrevious,
    validateStep,
    errors,
    isLoading,
    timer,
    updateKbMetadata,
    updateAnalysisMetadata,
    updateProjectAnalysis,
    updateDocumentHierarchy
  } = useProjectWizard({
    initialStep,
    projectId,
    onComplete: handleWizardComplete,
    onCancel: handleWizardCancel
  });

  // File management state and functions
  const {
    uploadedFiles,
    uploadProgress,
    isUploading,
    previewCache,
    uploadFiles,
    removeFile,
    getFilePreview,
    validateFiles,
    getFileTree,
    clearFiles
  } = useFileManagement();

  // Adobe Franklin API integration
  const {
    projectId: apiProjectId,
    uploadedFiles: apiUploadedFiles,
    kbMetadata,
    analysisMetadata,
    projectAnalysis,
    documentHierarchy,
    project_details,
    isLoading: isApiLoading,
    isAnalysisLoading,
    isAnalysisDataLoading,
    apiStartTime,
    elapsedTime,
    fetchKbMetadata,
    fetchAnalysisMetadata,
    fetchProjectImages,
    fetchProjectAnalysis,
    postMappingData,
    generateDocumentation,
    executeStepAction,
    stopTimer: stopApiTimer,
    resetData
  } = useAdobeFranklinAPI(projectId); // Pass the projectId to the hook

  // Wizard step configuration
  const wizardSteps = [
    {
      id: 1,
      title: 'Project Setup',
      description: 'Configure project template and upload design files',
      component: StepProjectSetup,
      requiredFields: ['templateType', 'projectName'],
      estimatedTime: '5-10 minutes'
    },
    {
      id: 2,
      title: 'Content Mapping',
      description: 'Map content structure and analyze pages',
      component: StepContentMapping,
      requiredFields: ['contentMapping'],
      estimatedTime: '10-15 minutes'
    },
    {
      id: 3,
      title: 'Preview Generation',
      description: 'Generate document and website previews',
      component: StepPreviewGeneration,
      requiredFields: ['previewGenerated'],
      estimatedTime: '15-20 minutes'
    },
    {
      id: 4,
      title: 'Testing',
      description: 'Run User Acceptance Testing',
      component: StepTesting,
      requiredFields: ['testingComplete'],
      estimatedTime: '20-30 minutes'
    },
    {
      id: 5,
      title: 'Deployment',
      description: 'Deploy to production environment',
      component: StepDeployment,
      requiredFields: ['deploymentComplete'],
      estimatedTime: '10-15 minutes'
    }
  ];

  // Handler functions
  function handleWizardComplete(finalData) {
    if (onComplete) {
      onComplete(finalData);
    } else {
      navigate('/projects', { 
        state: { 
          message: 'Adobe Franklin project created successfully!',
          projectData: finalData 
        }
      });
    }
  }

  function handleWizardCancel() {
    if (onCancel) {
      onCancel();
    } else {
      navigate('/projects');
    }
  }

  function handleStepNavigation(stepId) {
    if (stepId < currentStep || validateStep(currentStep, projectData)) {
      goToStep(stepId);
    }
  }

  function handleBack() {
    previousStep();
  }

  function handleCancel() {
    if (window.confirm('Are you sure you want to cancel? All progress will be lost.')) {
      handleWizardCancel();
    }
  }

  // Step-specific action handlers that integrate API calls
  async function handleStepAction() {
    try {
      console.log(`🔄 BUTTON CLICKED - Executing step ${currentStep} action...`);
      console.log('🔍 Current state before action:', {
        currentStep,
        projectData,
        kbMetadata: !!kbMetadata,
        analysisMetadata: !!analysisMetadata
      });
      
      // Handle different actions based on current step
      switch (currentStep) {
        case 1:
          // Step 1: Run content mapping
          console.log('📋 Starting step 1 - content mapping API call...');
          const result = await executeStepAction(1);
          console.log('📋 Step 1 API call result:', result);
          
          if (!result.success) {
            throw new Error(result.message);
          }
          console.log('✅ Step 1 API call successful:', result.message);
          
          // Update project data to indicate step 1 completion
          console.log('📝 Updating project data for step 1 completion...');
          updateProjectData({ 
            step1Complete: true,
            contentMappingInitiated: true,
            lastCompletedStep: 1
          });
          console.log('📝 Project data updated - waiting for state to sync...');
          
          // Immediately start project analysis for Step 2
          console.log('📊 Starting project analysis for Step 2...');
          fetchProjectAnalysis();
          
          // Wait a bit for state to update before moving to next step
          await new Promise(resolve => setTimeout(resolve, 100));
          break;

        case 2:
          // Step 2: Generate documentation
          const docResult = await executeStepAction(2);
          if (!docResult.success) {
            throw new Error(docResult.message);
          }
          console.log('✅ Step 2 API call successful:', docResult.message);
          
          // Update project data to indicate step 2 completion
          updateProjectData({ 
            step2Complete: true,
            documentationGenerated: true,
            lastCompletedStep: 2
          });
          break;

        case 3:
          // Step 3: Start project analysis for preview generation
          const analysisResult = await executeStepAction(3);
          if (!analysisResult.success) {
            throw new Error(analysisResult.message);
          }
          console.log('✅ Step 3 API call successful:', analysisResult.message);
          
          // Update project data to indicate step 3 completion
          updateProjectData({ 
            step3Complete: true,
            previewGenerated: true,
            lastCompletedStep: 3
          });
          break;

        case 4:
          // Step 4: Setup testing
          console.log('✅ Step 4 setup complete');
          
          // Update project data to indicate step 4 completion
          updateProjectData({ 
            step4Complete: true,
            testingSetup: true,
            lastCompletedStep: 4
          });
          break;

        case 5:
          // Step 5: Complete project
          console.log('✅ Project completion initiated');
          handleWizardComplete(projectData);
          return; // Don't call nextStep for final step
      }

      // Move to next step if action was successful
      console.log(`🚀 Attempting to move to next step from ${currentStep}...`);
      console.log('🔍 Current projectData before nextStep call:', projectData);
      
      // For step 1, we know the action was successful, so force the transition
      if (currentStep === 1) {
        console.log('🔧 Step 1 completed successfully - forcing transition to step 2');
        goToStep(2);
        console.log('✅ Force transition to step 2 completed');
      } else {
        const stepTransitionSuccess = await nextStep();
        console.log(`🔍 Step transition result: ${stepTransitionSuccess}`);
        
        if (!stepTransitionSuccess) {
          console.warn(`⚠️ Step transition from ${currentStep} failed, but API call was successful. Forcing transition...`);
          // Force step transition if API was successful but validation failed
          console.log(`🔧 Force transitioning from step ${currentStep} to ${currentStep + 1}`);
          goToStep(currentStep + 1);
          console.log(`✅ Force transition completed to step ${currentStep + 1}`);
        } else {
          console.log(`✅ Successfully transitioned from step ${currentStep} to ${currentStep + 1}`);
        }
      }
      
    } catch (error) {
      console.error(`❌ Step ${currentStep} action failed:`, error);
      // Show error to user - you could integrate with toast notifications here
      alert(`Action failed: ${error.message}`);
    }
  }

  // Get button text based on current step
  function getStepActionText() {
    switch (currentStep) {
      case 1: return 'Continue to Mapping';
      case 2: return 'Generate Documentation';
      case 3: return 'Start UAT Testing';
      case 4: return 'Deploy to Production';
      case 5: return 'Complete Project';
      default: return 'Next Step';
    }
  }

  // Get current step configuration
  const currentStepConfig = wizardSteps.find(step => step.id === currentStep);
  const StepComponent = currentStepConfig?.component;

  // Debug logging for step transitions
  console.log('🔍 Wizard Debug Info:', {
    currentStep,
    currentStepConfig: currentStepConfig?.title,
    StepComponent: StepComponent?.name,
    projectData,
    kbMetadata: !!kbMetadata,
    analysisMetadata: !!analysisMetadata,
    projectAnalysis: projectAnalysis?.length || 0
  });

  // Auto-save progress - using useRef to avoid infinite loops
  const saveProgressRef = useRef(saveProgress);
  saveProgressRef.current = saveProgress;
  
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      saveProgressRef.current();
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, []); // Empty dependency array - stable interval

  // Load progress on mount only
  const loadProgressRef = useRef(loadProgress);
  loadProgressRef.current = loadProgress;
  
  useEffect(() => {
    if (projectId) {
      loadProgressRef.current(projectId);
    }
  }, [projectId]); // Only depend on projectId changes

  // Sync API data with wizard state - using refs to avoid circular dependencies
  const updateKbMetadataRef = useRef(updateKbMetadata);
  updateKbMetadataRef.current = updateKbMetadata;
  
  const prevKbMetadataRef = useRef();
  useEffect(() => {
    if (kbMetadata && kbMetadata !== prevKbMetadataRef.current) {
      prevKbMetadataRef.current = kbMetadata;
      updateKbMetadataRef.current(kbMetadata);
    }
  }, [kbMetadata]); // Only depend on kbMetadata changes

  const updateAnalysisMetadataRef = useRef(updateAnalysisMetadata);
  updateAnalysisMetadataRef.current = updateAnalysisMetadata;
  
  const prevAnalysisMetadataRef = useRef();
  useEffect(() => {
    if (analysisMetadata && analysisMetadata !== prevAnalysisMetadataRef.current) {
      prevAnalysisMetadataRef.current = analysisMetadata;
      updateAnalysisMetadataRef.current(analysisMetadata);
    }
  }, [analysisMetadata]); // Only depend on analysisMetadata changes

  const updateProjectAnalysisRef = useRef(updateProjectAnalysis);
  updateProjectAnalysisRef.current = updateProjectAnalysis;
  
  const prevProjectAnalysisRef = useRef();
  useEffect(() => {
    if (projectAnalysis && projectAnalysis.length > 0 && projectAnalysis !== prevProjectAnalysisRef.current) {
      prevProjectAnalysisRef.current = projectAnalysis;
      updateProjectAnalysisRef.current(projectAnalysis);
    }
  }, [projectAnalysis]); // Only depend on projectAnalysis changes

  const updateDocumentHierarchyRef = useRef(updateDocumentHierarchy);
  updateDocumentHierarchyRef.current = updateDocumentHierarchy;
  
  const prevDocumentHierarchyRef = useRef();
  useEffect(() => {
    if (documentHierarchy && documentHierarchy.length > 0 && documentHierarchy !== prevDocumentHierarchyRef.current) {
      prevDocumentHierarchyRef.current = documentHierarchy;
      updateDocumentHierarchyRef.current(documentHierarchy);
    }
  }, [documentHierarchy]); // Only depend on documentHierarchy changes

  // Auto-fetch project analysis when Step 2 becomes active
  useEffect(() => {
    // Trigger project analysis fetch when stepping into Step 2 (Content Mapping)
    // and there's no existing project analysis data
    if (currentStep === 2 && projectId && (!projectAnalysis || projectAnalysis.length === 0)) {
      console.log('📊 Step 2 active - fetching project analysis...');
      fetchProjectAnalysis();
    }
  }, [currentStep, projectId, projectAnalysis, fetchProjectAnalysis]);

  // Preview step state management
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewTab, setPreviewTab] = useState('document');
  const [isDocLoading, setIsDocLoading] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState(new Set());
  const docxPreviewRef = useRef(null);

  // File tree and preview functions
  const getFileTreeStructure = () => {
    const tree = {};

    // If documentHierarchy data exists and has structure, use that
    if (documentHierarchy) {
      console.log("Using documentHierarchy for file tree:", documentHierarchy);

      // Case 1: New hierarchical structure with nested 'documents' and 'children'
      if (documentHierarchy.documents && typeof documentHierarchy.documents === 'object') {
        // Process nested structure recursively
        const processNestedStructure = (node, currentTree = tree) => {
          if (!node) return;

          // Handle folder nodes with children
          if (node.type === 'folder' || node.nodeType === 'folder') {
            const folderName = node.name;

            // Create folder in tree if it doesn't exist
            if (!currentTree[folderName]) {
              currentTree[folderName] = {
                name: folderName,
                type: 'folder',
                children: {}
              };
            }

            // Process children if they exist
            if (node.children) {
              // Handle children as object (key-value pairs)
              if (typeof node.children === 'object' && !Array.isArray(node.children)) {
                Object.entries(node.children).forEach(([childName, childNode]) => {
                  processNestedStructure(childNode, currentTree[folderName].children);
                });
              }
              // Handle children as array
              else if (Array.isArray(node.children)) {
                node.children.forEach(childItem => {
                 if (typeof childItem === 'object') {
                    processNestedStructure(childItem, currentTree[folderName].children);
                  }
                });
              }
            }
          }
          // Handle file nodes
          else if (node.type === 'file' || node.nodeType === 'file') {
            const fileName = node.name;
            const fileExt = fileName.split('.').pop().toLowerCase();

            currentTree[fileName] = {
              id: node.id || `doc-${Math.random().toString(36).substr(2, 9)}`,
              name: fileName,
              type: node.type || (fileExt === 'docx' ? 'docx' : fileExt),
              path: node.url || node.path || '',
              url: node.url || '',
              preview_url: node.preview_url || '',
              publish_url: node.publish_url || '',
              size: node.size || 0,
              lastModified: node.lastModified || new Date().toLocaleDateString(),
              fileType: 'file'
            };
          }
        };

        processNestedStructure(documentHierarchy.documents);
      }
      // Case 2: Simple array structure
      else if (Array.isArray(documentHierarchy)) {
        documentHierarchy.forEach((doc, index) => {
          const fileName = doc.filename || doc.name || `Document ${index + 1}`;
          const fileExt = fileName.split('.').pop().toLowerCase();
          
          tree[fileName] = {
            id: doc.id || `doc-${index}`,
            name: fileName,
            type: fileExt === 'docx' ? 'docx' : fileExt,
            path: doc.url || doc.path || '',
            url: doc.url || '',
            preview_url: doc.preview_url || '',
            publish_url: doc.publish_url || '',
            size: doc.size || 0,
            lastModified: doc.lastModified || new Date().toLocaleDateString(),
            fileType: 'file'
          };
        });
      }
    }
    
    // If no documentHierarchy, fall back to uploaded files
    if (Object.keys(tree).length === 0 && apiUploadedFiles && apiUploadedFiles.length > 0) {
      apiUploadedFiles.forEach((file, index) => {
        const fileName = file.filename || file.name || `File ${index + 1}`;
        const fileExt = fileName.split('.').pop().toLowerCase();
        
        tree[fileName] = {
          id: file.id || `file-${index}`,
          name: fileName,
          type: fileExt,
          path: file.path || '',
          url: file.url || '',
          preview_url: file.preview_url || '',
          publish_url: file.publish_url || '',
          size: file.size || 0,
          lastModified: file.lastModified || new Date().toLocaleDateString(),
          fileType: 'file'
        };
      });
    }

    return tree;
  };

  const renderFileTree = (tree) => {
    const { TreeFile, TreeFileIcon, TreeFileName, TreeFolder, TreeFolderHeader, TreeFolderIcon, TreeFolderName, TreeFolderContent, FolderIcon } = require('../ui/adobe-franklin');
    
    return Object.keys(tree).map(key => {
      const item = tree[key];
      
      if (item.type === 'folder' || item.fileType === 'folder') {
        const isExpanded = expandedFolders.has(item.name);
        return (
          <TreeFolder key={item.name}>
            <TreeFolderHeader onClick={() => toggleFolder(item.name)}>
              <TreeFolderIcon>
                <FolderIcon />
              </TreeFolderIcon>
              <TreeFolderName>{item.name}</TreeFolderName>
            </TreeFolderHeader>
            {isExpanded && item.children && (
              <TreeFolderContent>
                {renderFileTree(item.children)}
              </TreeFolderContent>
            )}
          </TreeFolder>
        );
      } else {
        return (
          <TreeFile 
            key={item.id || item.name}
            onClick={() => handleFileSelect(item)}
            style={{ 
              backgroundColor: selectedFile?.id === item.id ? 'rgba(0,0,0,0.1)' : 'transparent'
            }}
          >
            <TreeFileIcon>
              {getFileIcon(item.name)}
            </TreeFileIcon>
            <TreeFileName>{item.name}</TreeFileName>
          </TreeFile>
        );
      }
    });
  };

  const toggleFolder = (folderName) => {
    setExpandedFolders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(folderName)) {
        newSet.delete(folderName);
      } else {
        newSet.add(folderName);
      }
      return newSet;
    });
  };

  const handleFileSelect = (file) => {
    setSelectedFile(file);
  };

  const handlePreviewTabChange = (tab) => {
    setPreviewTab(tab);
  };

  const handleEditDocument = (document) => {
    console.log('Edit document:', document);
    
    // Check if document has a Google Docs URL
    if (document && document.url) {
      try {
        // Open Google Docs URL in new tab
        window.open(document.url, '_blank', 'noopener,noreferrer');
        console.log('Opened document for editing:', document.name);
      } catch (error) {
        console.error('Failed to open document:', error);
        alert('Failed to open the document. Please check if your browser allows pop-ups.');
      }
    } else {
      console.warn('No editable URL found for document:', document?.name || 'Unknown document');
      // Provide more specific feedback based on what's available
      if (!document) {
        alert('No document selected for editing.');
      } else if (!document.url) {
        alert(`The document "${document.name}" does not have an editable URL available.`);
      }
    }
  };

  const getFileIcon = (fileName) => {
    // Import utility function from styled components
    const { getFileIcon } = require('../ui/adobe-franklin');
    return getFileIcon(fileName);
  };

  if (isLoading) {
    return (
      <LoadingContainer>
        <LoadingSpinner />
        <p>Loading Adobe Franklin Project Wizard...</p>
      </LoadingContainer>
    );
  }

  return (
    <WizardContainer>
      {/* Step Navigation */}
      <StepperContainer>
        {wizardSteps.map((step, index) => (
          <React.Fragment key={step.id}>
            <StepperStep
              active={step.id === currentStep}
              completed={step.id < currentStep}
              clickable={step.id <= currentStep}
              onClick={() => handleStepNavigation(step.id)}
            >
              <StepNumber
                active={step.id === currentStep}
                completed={step.id < currentStep}
              >
                {step.id < currentStep ? '✓' : step.id}
              </StepNumber>
              <div>
                <StepTitle
                  active={step.id === currentStep}
                  completed={step.id < currentStep}
                >
                  {step.title}
                </StepTitle>
                <StepDescription>{step.description}</StepDescription>
              </div>
            </StepperStep>
            {index < wizardSteps.length - 1 && <StepSeparator />}
          </React.Fragment>
        ))}
      </StepperContainer>

          {/* Main Content */}
          <WizardContent>
            <StepContent>
              {StepComponent && (
                <StepComponent
                  projectData={projectData}
                  uploadedFiles={apiUploadedFiles || uploadedFiles}
                  filePreviewCache={previewCache}
                  isUploading={isUploading}
                  uploadProgress={uploadProgress}
                  onDataUpdate={updateProjectData}
                  onFileUpload={uploadFiles}
                  onFileRemove={removeFile}
                  onPreviewGenerate={getFilePreview}
                  errors={errors}
                  {...(currentStepConfig.id === 1 && {
                    projectDetails: project_details,
                    kbMetadata: kbMetadata,
                    analysisMetadata: analysisMetadata,
                    isLoading: isApiLoading,
                    isAnalysisLoading: isAnalysisLoading,
                    getFileIcon: (fileName) => {
                      // Import utility function from styled components
                      const { getFileIcon } = require('../ui/adobe-franklin');
                      return getFileIcon(fileName);
                    },
                    getFileColor: (extension) => {
                      // Add utility function for file colors
                      const colors = {
                        pdf: '#FF6B6B',
                        doc: '#4ECDC4',
                        docx: '#4ECDC4',
                        xlsx: '#45B7D1',
                        ppt: '#96CEB4',
                        pptx: '#96CEB4',
                        default: '#DDD6FE'
                      };
                      return colors[extension] || colors.default;
                    },
                    formatFileSize: (bytes) => {
                      if (bytes === 0) return '0 Bytes';
                      const k = 1024;
                      const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                      const i = Math.floor(Math.log(bytes) / Math.log(k));
                      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
                    }
                  })}
                  {...(currentStepConfig.id === 2 && {
                    projectData: projectData,
                    projectAnalysis: projectAnalysis,
                    elapsedTime: elapsedTime,
                    isAnalysisDataLoading: isAnalysisDataLoading,
                    analysisMetadata: analysisMetadata,
                    onMappingUpdate: (mapping) => updateProjectData({ contentMapping: mapping }),
                    onRegeneratePages: () => {
                      console.log('Regenerate pages clicked');
                      // Trigger re-fetch of project analysis
                      fetchProjectAnalysis();
                    },
                    onEditPage: (page) => {
                      console.log('Edit page:', page);
                      // Handle page editing logic
                    },
                    onRemovePage: (page) => {
                      console.log('Remove page:', page);
                      // Handle page removal logic
                    }
                  })}
                  {...(currentStepConfig.id === 3 && {
                    projectData: projectData,
                    selectedFile: selectedFile,
                    previewTab: previewTab,
                    isDocLoading: isDocLoading,
                    docxPreviewRef: docxPreviewRef,
                    documentHierarchy: documentHierarchy,
                    projectAnalysis: projectAnalysis,
                    elapsedTime: elapsedTime,
                    isAnalysisDataLoading: isAnalysisDataLoading,
                    onPreviewTabChange: handlePreviewTabChange,
                    onEditDocument: handleEditDocument,
                    onFileSelect: handleFileSelect,
                    renderFileTree: renderFileTree,
                    getFileTreeStructure: getFileTreeStructure,
                    onPreviewUpdate: (preview) => updateProjectData({ previewData: preview })
                  })}
                  {...(currentStepConfig.id === 4 && {
                    testingData: projectData.testingData,
                    onTestAction: (action, data) => {
                      // Handle test actions
                      updateProjectData({ 
                        testingData: { 
                          ...projectData.testingData, 
                          [action]: data 
                        } 
                      });
                    },
                    onCreateTest: (testData) => {
                      updateProjectData({ 
                        testingData: { 
                          ...projectData.testingData, 
                          tests: [...(projectData.testingData?.tests || []), testData] 
                        } 
                      });
                    }
                  })}
                  {...(currentStepConfig.id === 5 && {
                    deploymentData: projectData.deploymentData,
                    onDeploymentAction: (action, data) => {
                      // Handle deployment actions
                      updateProjectData({ 
                        deploymentData: { 
                          ...projectData.deploymentData, 
                          [action]: data 
                        } 
                      });
                    }
                  })}
                />
              )}
            </StepContent>

            {/* Loading indicator for API operations */}
            {(() => {
              // Show loading based on current step requirements
              switch (currentStep) {
                case 1:
                  // For Step 1, only show loading if KB metadata is not loaded
                  return isApiLoading && !kbMetadata;
                case 2:
                case 3:
                  // For steps 2-3, show loading if analysis is still running
                  return isAnalysisLoading || isAnalysisDataLoading;
                default:
                  // For other steps, show loading if any critical operation is running
                  return isApiLoading || isAnalysisLoading || isAnalysisDataLoading;
              }
            })() && (
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center', 
                padding: '1rem',
                gap: '0.5rem' 
              }}>
                <LoadingSpinner size="small" />
                <span>
                  {currentStep === 1 && isApiLoading && 'Loading project data...'}
                  {currentStep > 1 && isAnalysisLoading && 'Analyzing project data...'}
                  {currentStep > 1 && isAnalysisDataLoading && `Processing analysis... ${elapsedTime}`}
                </span>
              </div>
            )}

            {/* Navigation Buttons */}
            <ButtonGroup>
              <div>
                <CancelButton onClick={handleCancel}>
                  Cancel
                </CancelButton>
                {currentStep > 1 && (
                  <BackButton onClick={handleBack}>
                    Back
                  </BackButton>
                )}
              </div>
              <div>
                {currentStep < wizardSteps.length ? (
                  <PrimaryButton 
                    onClick={handleStepAction}
                    disabled={
                      (() => {
                        // Step-specific validation and loading conditions
                        switch (currentStep) {
                          case 1:
                            // For Step 1, check if kbMetadata is loaded and not currently loading
                            const step1Valid = kbMetadata !== null;
                            const step1Loading = isApiLoading && !kbMetadata;
                            const isDisabled = !step1Valid || step1Loading;
                            return isDisabled;
                          case 2:
                          case 3:
                            return isAnalysisLoading || isAnalysisDataLoading;
                          default:
                            return isApiLoading || isAnalysisLoading || isAnalysisDataLoading;
                        }
                      })()
                    }
                  >
                    {getStepActionText()}
                  </PrimaryButton>
                ) : (
                  <PrimaryButton 
                    onClick={() => handleWizardComplete(projectData)}
                    disabled={isApiLoading || isAnalysisLoading || isAnalysisDataLoading}
                  >
                    Complete Project
                  </PrimaryButton>
                )}
              </div>
            </ButtonGroup>
          </WizardContent>
        </WizardContainer>
    );
};

// PropTypes
AdobeFranklinWizard.propTypes = {
  projectId: PropTypes.string,
  initialStep: PropTypes.number,
  onComplete: PropTypes.func,
  onCancel: PropTypes.func,
  chatOpen: PropTypes.bool,
  setChatOpen: PropTypes.func
};

export default AdobeFranklinWizard;
