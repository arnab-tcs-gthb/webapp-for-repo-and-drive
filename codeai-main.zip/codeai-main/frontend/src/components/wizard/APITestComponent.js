import React, { useEffect } from 'react';
import { useAdobeFranklinAPI } from '../../hooks/adobe-franklin/useAdobeFranklinAPI';
import { useProjectWizard } from '../../hooks/adobe-franklin/useProjectWizard';

const APITestComponent = () => {
  const {
    kbMetadata,
    analysisMetadata,
    projectAnalysis,
    isLoading,
    isAnalysisLoading,
    projectId,
    uploadedFiles
  } = useAdobeFranklinAPI('5'); // Pass project ID directly to the hook

  const {
    validateStep,
    errors,
    timer,
    saveProgress,
    loadProgress
  } = useProjectWizard({ 
    initialStep: 1, 
    projectId: '5',
    onComplete: () => {},
    onCancel: () => {}
  });

  // Initialize with test project ID
  useEffect(() => {
    // Component mounted
  }, [projectId]);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Adobe Franklin API Integration Test</h2>
      
      <div style={{ marginBottom: '20px' }}>
        <h3>API Flow Status:</h3>
        <p><strong>Step 1:</strong> KB Metadata: {kbMetadata ? '✅ Loaded' : '⏳ Loading...'}</p>
        <p><strong>Step 2:</strong> Analysis Metadata: {analysisMetadata ? '✅ Loaded' : isAnalysisLoading ? '⏳ Loading...' : '⏸️ Waiting for project ID'}</p>
        <p><strong>Project ID:</strong> {projectId || 'Not set'}</p>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <h3>API Hook Status:</h3>
        <p>Project ID: {projectId || 'Not set'}</p>
        <p>Is Loading: {isLoading ? 'Yes' : 'No'}</p>
        <p>Is Analysis Loading: {isAnalysisLoading ? 'Yes' : 'No'}</p>
        <p>KB Metadata: {kbMetadata ? JSON.stringify(kbMetadata).substring(0, 100) + '...' : 'Not loaded'}</p>
        <p>Analysis Metadata: {analysisMetadata ? JSON.stringify(analysisMetadata).substring(0, 100) + '...' : 'Not loaded'}</p>
        <p>Project Analysis Items: {projectAnalysis ? projectAnalysis.length : 0}</p>
        <p>Uploaded Files: {uploadedFiles ? uploadedFiles.length : 0}</p>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <h3>Wizard Hook Status:</h3>
        <p>Validate Step Function: {typeof validateStep}</p>
        <p>Errors: {JSON.stringify(errors)}</p>
        <p>Timer: {JSON.stringify(timer)}</p>
        <p>Save Progress Function: {typeof saveProgress}</p>
        <p>Load Progress Function: {typeof loadProgress}</p>
      </div>

      <div>
        <button onClick={() => saveProgress()}>Test Save Progress</button>
        <button onClick={() => loadProgress('5')}>Test Load Progress</button>
        <button onClick={() => validateStep(1)}>Test Validate Step</button>
      </div>
    </div>
  );
};

export default APITestComponent;
