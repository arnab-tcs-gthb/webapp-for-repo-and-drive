import React from 'react';
import PropTypes from 'prop-types';
import {
  MetadataSection,
  MetadataHeader,
  MetadataGrid,
  MetadataCard,
  SectionTitle,
  CompleteBadge,
  CompleteIcon,
  MetadataLabel,
  MetadataValue,
  StatsGrid,
  StatCard,
  StatValue,
  StatLabel,
  UploadedFilesSection,
  FilesHeader,
  FilesTitle,
  FilesGrid,
  FileCard,
  FileImagePreview,
  FileIconPreview,
  FileInfo,
  FileName,
  FileSize,
  CheckIcon
} from '../../ui/adobe-franklin/SharedComponents';

/**
 * StepProjectSetup Component
 * 
 * Displays project template metadata, design analysis results, and uploaded files
 * for the first step of the Adobe Franklin project wizard.
 */
const StepProjectSetup = ({
  projectDetails,
  kbMetadata,
  analysisMetadata,
  uploadedFiles,
  getFileIcon,
  getFileColor,
  formatFileSize
}) => {
  return (
    <>
      {/* Template Metadata Section */}
      <MetadataSection>
        <MetadataHeader>
          <SectionTitle>Template Metadata</SectionTitle>
          <CompleteBadge>
            <CompleteIcon>
              <CheckIcon />
            </CompleteIcon>
            Complete
          </CompleteBadge>
        </MetadataHeader>

        <MetadataGrid>
          <MetadataCard>
            <MetadataLabel>Project Template</MetadataLabel>
            <MetadataValue>{projectDetails?.project_metadata?.selected_template}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Brand</MetadataLabel>
            <MetadataValue>{kbMetadata?.brand}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Total Blocks</MetadataLabel>
            <MetadataValue>{kbMetadata?.total_count}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Global Blocks</MetadataLabel>
            <MetadataValue>{kbMetadata?.global_count}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Site Building Blocks</MetadataLabel>
            <MetadataValue>{kbMetadata?.page_building_count}</MetadataValue>
          </MetadataCard>
        </MetadataGrid>
      </MetadataSection>

      {/* Design Metadata Section */}
      <MetadataSection>
        <MetadataHeader>
          <SectionTitle>Design Metadata</SectionTitle>
          <CompleteBadge>
            <CompleteIcon>
              <CheckIcon />
            </CompleteIcon>
            Complete
          </CompleteBadge>
        </MetadataHeader>

        <div>{analysisMetadata?.progress}</div>

        <StatsGrid>
          <StatCard>
            <StatValue>{analysisMetadata?.pages}</StatValue>
            <StatLabel>Pages</StatLabel>
          </StatCard>

          <StatCard>
            <StatValue>{analysisMetadata?.links}</StatValue>
            <StatLabel>Links</StatLabel>
          </StatCard>

          <StatCard>
            <StatValue>{analysisMetadata?.images}</StatValue>
            <StatLabel>Images</StatLabel>
          </StatCard>

          <StatCard>
            <StatValue>{analysisMetadata?.blocks}</StatValue>
            <StatLabel>Blocks</StatLabel>
          </StatCard>

          <StatCard>
            <StatValue>{analysisMetadata?.forms}</StatValue>
            <StatLabel>Forms</StatLabel>
          </StatCard>

          <StatCard>
            <StatValue>1</StatValue>
            <StatLabel>Videos</StatLabel>
          </StatCard>
        </StatsGrid>
      </MetadataSection>

      {/* Uploaded Files Section */}
      {uploadedFiles && uploadedFiles.length > 0 && (
        <UploadedFilesSection>
          <FilesHeader>
            <FilesTitle>Uploaded Files</FilesTitle>
          </FilesHeader>
          <FilesGrid>
            {uploadedFiles.map((file, index) => {
              // Check if file is an image by extension
              const imageExtensions = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'];
              const ext = file.extension || (file.name ? file.name.split('.').pop().toLowerCase() : '');
              const isImage = imageExtensions.includes(ext);
              
              return (
                <FileCard key={`file-${index}`}>
                  {isImage && file.previewUrl ? (
                    <FileImagePreview>
                      <img src={file.previewUrl} alt={file.name} />
                    </FileImagePreview>
                  ) : (
                    <FileIconPreview backgroundColor={getFileColor(ext)}>
                      {getFileIcon(ext)}
                    </FileIconPreview>
                  )}
                  <FileInfo>
                    <FileName title={file.name}>
                      {file.name.length > 20 ? file.name.substring(0, 17) + '...' : file.name}
                    </FileName>
                    <FileSize>{formatFileSize(file.size)}</FileSize>
                  </FileInfo>
                </FileCard>
              );
            })}
          </FilesGrid>
        </UploadedFilesSection>
      )}
    </>
  );
};

StepProjectSetup.propTypes = {
  /** Project details object containing metadata */
  projectDetails: PropTypes.shape({
    project_metadata: PropTypes.shape({
      selected_template: PropTypes.string
    })
  }),
  /** Knowledge base metadata */
  kbMetadata: PropTypes.shape({
    brand: PropTypes.string,
    total_count: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    global_count: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    page_building_count: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
  }),
  /** Analysis metadata containing statistics */
  analysisMetadata: PropTypes.shape({
    progress: PropTypes.string,
    pages: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    links: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    images: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    blocks: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    forms: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
  }),
  /** Array of uploaded files */
  uploadedFiles: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      extension: PropTypes.string,
      size: PropTypes.number,
      previewUrl: PropTypes.string
    })
  ),
  /** Function to get file icon based on extension */
  getFileIcon: PropTypes.func.isRequired,
  /** Function to get file color based on extension */
  getFileColor: PropTypes.func.isRequired,
  /** Function to format file size */
  formatFileSize: PropTypes.func.isRequired
};

StepProjectSetup.defaultProps = {
  projectDetails: null,
  kbMetadata: {},
  analysisMetadata: {},
  uploadedFiles: []
};

export default StepProjectSetup;
