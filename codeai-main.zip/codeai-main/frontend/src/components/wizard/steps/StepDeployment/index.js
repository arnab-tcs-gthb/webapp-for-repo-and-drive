import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../context/ThemeContext';
import {
  // Containers and layout
  DeploymentContainer,
  DeploymentSteps,
  DeploymentStep,
  MetadataHeader,
  SectionTitle,
  MetadataSection,
  MetadataGrid,
  StepContent,
  StepContentHeader,
  StepName,
  StepTime,
  StepIcon,
  EnvironmentContainer,
  
  // Cards
  MetadataCard,
  MetadataLabel,
  MetadataValue,
  EnvironmentCard,
  
  // Icons
  CheckIcon,
  ClockIcon,
  ServerIcon
} from '../../../ui/adobe-franklin';

/**
 * StepDeployment - Step 5 component for deployment pipeline and environment management
 * Displays deployment stages, status, and environment information
 */
const StepDeployment = ({
  projectData,
  onDeploymentAction,
  onEnvironmentAction
}) => {
  const { theme } = useTheme();

  return (
    <DeploymentContainer>
      <MetadataHeader>
        <SectionTitle>Deployment Pipeline</SectionTitle>
      </MetadataHeader>

      <DeploymentSteps>
        {projectData?.deploymentStages?.map((stage, index) => (
          <DeploymentStep key={stage.id}>
            <StepIcon status={stage.status}>
              {stage.status === 'completed' ? (
                <CheckIcon />
              ) : stage.status === 'in-progress' ? (
                <ClockIcon />
              ) : (
                index + 1
              )}
            </StepIcon>
            <StepContent>
              <StepContentHeader>
                <StepName>{stage.name}</StepName>
                <StepTime>{stage.time}</StepTime>
              </StepContentHeader>
              <div style={{ fontSize: '0.9rem', color: theme.colors.textSecondary }}>
                {stage.description}
              </div>
            </StepContent>
          </DeploymentStep>
        )) || (
          <div style={{ padding: '2rem', textAlign: 'center' }}>
            <p>No deployment stages configured.</p>
          </div>
        )}
      </DeploymentSteps>

      <MetadataHeader>
        <SectionTitle>Environments</SectionTitle>
      </MetadataHeader>

      <EnvironmentContainer>
        {projectData?.environments?.map(env => (
          <EnvironmentCard key={env.name}>
            <h5>
              <ServerIcon style={{ 
                marginRight: '0.5rem', 
                position: 'relative', 
                top: '4px' 
              }} />
              {env.name}
              <span
                style={{
                  display: 'inline-block',
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  marginLeft: '0.5rem',
                  backgroundColor:
                    env.status === 'Online' ? theme.colors.success :
                      env.status === 'Deploying' ? theme.colors.warning :
                        theme.colors.textSecondary
                }}
              />
            </h5>
            <div style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
              <a 
                href={env.url} 
                target="_blank"
                rel="noopener noreferrer"
                style={{ 
                  color: theme.colors.primary, 
                  textDecoration: 'none' 
                }}
              >
                {env.url}
              </a>
            </div>
            <div style={{ fontSize: '0.85rem', color: theme.colors.textSecondary }}>
              <div>Status: {env.status}</div>
              <div>Last Deployment: {env.lastDeployed}</div>
            </div>
            <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem' }}>
              <button
                onClick={() => onEnvironmentAction('deploy', env)}
                style={{
                  padding: '0.25rem 0.75rem',
                  fontSize: '0.8rem',
                  backgroundColor: theme.colors.primary,
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Deploy
              </button>
              <button
                onClick={() => onEnvironmentAction('view', env)}
                style={{
                  padding: '0.25rem 0.75rem',
                  fontSize: '0.8rem',
                  backgroundColor: 'transparent',
                  color: theme.colors.primary,
                  border: `1px solid ${theme.colors.primary}`,
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                View
              </button>
            </div>
          </EnvironmentCard>
        )) || (
          <div style={{ padding: '2rem', textAlign: 'center' }}>
            <p>No environments configured.</p>
          </div>
        )}
      </EnvironmentContainer>

      {/* Deployment Summary */}
      <MetadataSection style={{ marginTop: '2rem' }}>
        <MetadataHeader>
          <SectionTitle>Deployment Summary</SectionTitle>
        </MetadataHeader>

        <MetadataGrid>
          <MetadataCard>
            <MetadataLabel>Total Stages</MetadataLabel>
            <MetadataValue>{projectData?.deploymentStages?.length || 0}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Completed</MetadataLabel>
            <MetadataValue style={{ color: theme.colors.success }}>
              {projectData?.deploymentStages?.filter(stage => stage.status === 'completed').length || 0}
            </MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>In Progress</MetadataLabel>
            <MetadataValue style={{ color: theme.colors.warning }}>
              {projectData?.deploymentStages?.filter(stage => stage.status === 'in-progress').length || 0}
            </MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Pending</MetadataLabel>
            <MetadataValue style={{ color: theme.colors.textSecondary }}>
              {projectData?.deploymentStages?.filter(stage => stage.status === 'pending').length || 0}
            </MetadataValue>
          </MetadataCard>
        </MetadataGrid>
      </MetadataSection>
    </DeploymentContainer>
  );
};

StepDeployment.propTypes = {
  /** Project data containing deployment stages and environments */
  projectData: PropTypes.shape({
    deploymentStages: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
        name: PropTypes.string.isRequired,
        status: PropTypes.oneOf(['pending', 'in-progress', 'completed', 'failed']).isRequired,
        time: PropTypes.string,
        description: PropTypes.string
      })
    ),
    environments: PropTypes.arrayOf(
      PropTypes.shape({
        name: PropTypes.string.isRequired,
        url: PropTypes.string.isRequired,
        status: PropTypes.oneOf(['Online', 'Offline', 'Deploying']).isRequired,
        lastDeployed: PropTypes.string
      })
    )
  }),
  /** Callback function for deployment actions */
  onDeploymentAction: PropTypes.func.isRequired,
  /** Callback function for environment actions */
  onEnvironmentAction: PropTypes.func.isRequired
};

StepDeployment.defaultProps = {
  projectData: {
    deploymentStages: [],
    environments: []
  }
};

export default StepDeployment;
