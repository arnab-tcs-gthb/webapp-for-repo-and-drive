import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../context/ThemeContext';
import {
  MetadataSection,
  MetadataHeader,
  SectionTitle,
  CompleteBadge,
  CompleteIcon,
  CheckIcon
} from '../../../ui/adobe-franklin/SharedComponents';
import { 
  TestingContainer,
  TestingTitle
} from '../../../ui/adobe-franklin';

const EmptyStateMessage = ({ message, theme }) => (
  <div style={{ 
    padding: '2rem',
    textAlign: 'center',
    color: theme.colors.textSecondary,
    backgroundColor: theme.colors.surfaceAlt,
    borderRadius: '8px',
    margin: '1rem 0'
  }}>
    {message}
  </div>
);

const LoadingMessage = ({ theme }) => (
  <div style={{ 
    padding: '2rem',
    textAlign: 'center',
    color: theme.colors.textSecondary
  }}>
    Loading UAT data...
  </div>
);

const ErrorMessage = ({ message, theme }) => (
  <div style={{ 
    padding: '2rem',
    textAlign: 'center',
    color: theme.colors.error,
    backgroundColor: theme.colors.errorLight,
    borderRadius: '8px',
    margin: '1rem 0'
  }}>
    {message}
  </div>
);

/**
 * StepTesting Component
 * 
 * Displays QA and UAT testing status and management interface
 * for the Adobe Franklin project wizard testing steps.
 */
const StepTesting = ({ 
  projectData, 
  isUATStep = false, 
  uatData = null,
  isLoading = false,
  error = null,
  getUATData = null,
  qaTestData = [],
  uatTestData = [],
  qaStats = {},
  uatStats = {},
  onCreateTest = () => {},
  onTestAction = () => {},
  uatTableView = 'table',
  uatGroupByPage = false,
  onUatTableViewChange = () => {},
  onUatGroupByPageChange = () => {}
}) => {
  const { theme } = useTheme();
  const [expandedPages, setExpandedPages] = useState(new Set());
  const [localUatData, setLocalUatData] = useState(uatData);
  const [localIsLoading, setLocalIsLoading] = useState(isLoading);
  const [localError, setLocalError] = useState(error);

  // Fetch UAT data when component mounts if getUATData function is available
  useEffect(() => {
    const fetchUATData = async () => {
      // Only fetch if we're in UAT step, have a project ID, have the getUATData function,
      // and don't already have valid data
      if (isUATStep && projectData?.id && getUATData && !localUatData) {
        try {
          setLocalIsLoading(true);
          setLocalError(null);
          console.log('StepTesting: Fetching UAT data for project:', projectData.id);
          
          const data = await getUATData(''); // Use empty string for pageId as per our previous fixes
          setLocalUatData(data);
          console.log('StepTesting: UAT data fetched successfully:', data);
        } catch (err) {
          console.error('StepTesting: Error fetching UAT data:', err);
          setLocalError(err.message || 'Failed to load UAT data');
        } finally {
          setLocalIsLoading(false);
        }
      }
    };

    fetchUATData();
  }, [isUATStep, projectData?.id, getUATData, localUatData]);

  // Update local state when props change
  useEffect(() => {
    if (uatData !== null) {
      setLocalUatData(uatData);
    }
  }, [uatData]);

  useEffect(() => {
    setLocalIsLoading(isLoading);
  }, [isLoading]);

  useEffect(() => {
    if (error !== null) {
      setLocalError(error);
    }
  }, [error]);

  const togglePage = (pageName) => {
    setExpandedPages(prev => {
      const next = new Set(prev);
      if (next.has(pageName)) {
        next.delete(pageName);
      } else {
        next.add(pageName);
      }
      return next;
    });
  };

  // Determine which data to use (priority: localUatData > uatData prop)
  // Check for actual data content, not just truthiness
  const hasValidData = (data) => data && Array.isArray(data.pages) && data.pages.length > 0;
  
  let dataToUse = null;
  if (localUatData && hasValidData(localUatData)) {
    dataToUse = localUatData;
  } else if (uatData && hasValidData(uatData)) {
    dataToUse = uatData;
  }
  
  // Determine loading and error states
  const isCurrentlyLoading = localIsLoading;
  const currentError = localError;
  
  // Debug logging
  console.log('StepTesting: Data selection debug:', { 
    projectId: projectData?.id, 
    isUATStep, 
    hasUatDataProp: !!uatData,
    hasLocalUatData: !!localUatData,
    uatDataValid: hasValidData(uatData),
    localUatDataValid: hasValidData(localUatData),
    selectedDataSource: dataToUse === localUatData ? 'localUatData' : dataToUse === uatData ? 'uatData' : 'none',
    ticketCount: dataToUse?.ticket_detail?.length || 0,
    isCurrentlyLoading,
    currentError
  });

  // Show QA Testing step
  if (!isUATStep) {
    return (
      <>
        {/* QA Testing Metadata Section */}
        <MetadataSection>
          <MetadataHeader>
            <SectionTitle>QA Testing Status</SectionTitle>
            <CompleteBadge>
              <CompleteIcon>
                <CheckIcon />
              </CompleteIcon>
              Ready
            </CompleteBadge>
          </MetadataHeader>
          
          <EmptyStateMessage 
            message="QA Testing interface will be implemented in a future update." 
            theme={theme} 
          />
        </MetadataSection>
      </>
    );
  }

  // Show loading state
  if (isCurrentlyLoading) {
    return (
      <>
        <MetadataSection>
          <MetadataHeader>
            <SectionTitle>UAT Testing Status</SectionTitle>
          </MetadataHeader>
          <LoadingMessage theme={theme} />
        </MetadataSection>
      </>
    );
  }

  // Show error state
  if (currentError) {
    return (
      <>
        <MetadataSection>
          <MetadataHeader>
            <SectionTitle>UAT Testing Status</SectionTitle>
          </MetadataHeader>
          <ErrorMessage message={currentError} theme={theme} />
        </MetadataSection>
      </>
    );
  }

  // Show empty state for UAT step with no data
  if (isUATStep && (!dataToUse || !Array.isArray(dataToUse.pages) || dataToUse.pages.length === 0)) {
    return (
      <>
        <MetadataSection>
          <MetadataHeader>
            <SectionTitle>UAT Testing Status</SectionTitle>
            {getUATData && projectData?.id && (
              <button
                onClick={async () => {
                  try {
                    console.log('StepTesting: Start UAT Testing button clicked');
                    setLocalIsLoading(true);
                    setLocalError(null);
                    console.log('StepTesting: Calling getUATData for project:', projectData.id);
                    const data = await getUATData('');
                    console.log('StepTesting: UAT data received:', data);
                    setLocalUatData(data);
                  } catch (err) {
                    console.error('StepTesting: Error loading UAT data:', err);
                    setLocalError(err.message || 'Failed to load UAT data');
                  } finally {
                    setLocalIsLoading(false);
                  }
                }}
                style={{
                  padding: '0.75rem 1.5rem',
                  backgroundColor: theme.colors.primary,
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '1rem',
                  fontWeight: '600'
                }}
              >
                🚀 Start UAT Testing
              </button>
            )}
          </MetadataHeader>
          <EmptyStateMessage 
            message={
              !getUATData 
                ? "UAT data fetching function not available." 
                : !projectData?.id 
                  ? "Project ID is required to load UAT data."
                  : "No UAT tickets available at this time."
            } 
            theme={theme} 
          />
        </MetadataSection>
      </>
    );
  }

  // Group tickets by page_name using new JSON structure
  // Each page in dataToUse.pages has its own tickets array
  const groupedTickets = (dataToUse.pages || []).reduce((acc, page) => {
    acc[page.page_name] = {
      page_name: page.page_name,
      preview_url: page.preview_url,
      page_id: page.page_id,
      tickets: Array.isArray(page.tickets)
        ? page.tickets
            .filter(ticket => ticket.jira_id && ticket.jira_url)
            .map(ticket => ({
              jira_id: ticket.jira_id,
              jira_url: ticket.jira_url
            }))
        : []
    };
    return acc;
  }, {});

  // Main UAT interface with grouped tickets
  return (
    <>
      {/* UAT Testing Metadata Section */}
      <MetadataSection>
        <MetadataHeader>
          <SectionTitle>UAT Testing Status</SectionTitle>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <CompleteBadge>
              <CompleteIcon>
                <CheckIcon />
              </CompleteIcon>
              Active
            </CompleteBadge>
            {getUATData && projectData?.id && (
              <button
                onClick={async () => {
                  try {
                    setLocalIsLoading(true);
                    setLocalError(null);
                    const data = await getUATData('');
                    setLocalUatData(data);
                    console.log('StepTesting: UAT data refreshed');
                  } catch (err) {
                    console.error('StepTesting: Error refreshing UAT data:', err);
                    setLocalError(err.message || 'Failed to refresh UAT data');
                  } finally {
                    setLocalIsLoading(false);
                  }
                }}
                style={{
                  padding: '0.4rem 0.8rem',
                  backgroundColor: theme.colors.surface,
                  color: theme.colors.primary,
                  border: `1px solid ${theme.colors.primary}`,
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '0.8rem',
                  fontWeight: '500'
                }}
                title="Refresh UAT data"
              >
                🔄 Refresh
              </button>
            )}
          </div>
        </MetadataHeader>

        {Object.values(groupedTickets).map((page) => {
          const hasJiraTickets = page.tickets.length > 0;
          
          return (
            <div
              key={page.page_name}
              style={{
                marginBottom: '1rem',
                border: `1px solid ${theme.colors.textSecondary}`,
                borderRadius: '8px',
                overflow: 'hidden',
                backgroundColor: theme.colors.surface
              }}
            >
              <div
                onClick={hasJiraTickets ? () => togglePage(page.page_name) : undefined}
                style={{
                  padding: '1rem 1.5rem',
                  backgroundColor: theme.colors.surface,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: hasJiraTickets ? 'pointer' : 'default',
                  borderBottom: hasJiraTickets && expandedPages.has(page.page_name) ? `1px solid ${theme.colors.textSecondary}` : 'none'
                }}
              >
                <div style={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 500, color: theme.colors.text }}>
                      {page.page_name}
                    </h3>                    <span style={{ color: theme.colors.textSecondary }}>|</span>
                    {page.preview_url ? (
                      <a
                        href={`${page.preview_url}${page.preview_url.includes('?') ? '&' : '?'}project_id=${projectData?.id || ''}&page_id=${page.page_id || ''}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ 
                          color: theme.colors.primary,
                          textDecoration: 'none',
                          fontSize: '0.9rem',
                          opacity: 0.85,
                          transition: 'all 0.2s ease',
                          '&:hover': {
                            opacity: 1,
                            textDecoration: 'underline'
                          }
                        }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        Preview Link
                      </a>
                    ) : (
                      <span
                        style={{ 
                          color: theme.colors.textSecondary,
                          fontSize: '0.9rem',
                          fontStyle: 'italic'
                        }}
                      >
                        No preview link
                      </span>
                    )}
                  </div>
                </div>
                {hasJiraTickets && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <span style={{ 
                      fontSize: '0.8rem',
                      color: theme.colors.textSecondary,
                      backgroundColor: theme.colors.surfaceAlt,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '12px'
                    }}>
                      {page.tickets.length} {page.tickets.length === 1 ? 'ticket' : 'tickets'}
                    </span>
                    <span style={{ 
                      transform: expandedPages.has(page.page_name) ? 'rotate(180deg)' : 'none',
                      transition: 'transform 0.2s ease'
                    }}>▼</span>
                  </div>
                )}
              </div>

              {hasJiraTickets && expandedPages.has(page.page_name) && (
                <div style={{ padding: '0.75rem' }}>
                  <div style={{
                    backgroundColor: theme.colors.surfaceAlt,
                    borderRadius: '8px',
                    padding: '0.75rem',
                    display: 'flex',
                    flexDirection: 'column'
                  }}>
                    {page.tickets.map((ticket, index) => (
                      <div
                        key={ticket.jira_id}
                        style={{
                          borderBottom: index !== page.tickets.length - 1 ? `1px solid ${theme.colors.textSecondary}` : 'none',
                          paddingBottom: index !== page.tickets.length - 1 ? '0.5rem' : '0',
                          marginBottom: index !== page.tickets.length - 1 ? '0.5rem' : '0'
                        }}
                      >
                        <a
                          href={ticket.jira_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ 
                            color: theme.colors.primary,
                            textDecoration: 'none',
                            fontSize: '0.9rem',
                            fontWeight: 400,
                            opacity: 0.85,
                            transition: 'all 0.2s ease',
                            padding: '0.5rem',
                            display: 'block',
                            borderRadius: '4px',
                            '&:hover': {
                              opacity: 1,
                              textDecoration: 'underline'
                            }
                          }}
                          onClick={(e) => e.stopPropagation()}
                        >
                          {ticket.jira_id}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </MetadataSection>
    </>
  );
};

StepTesting.propTypes = {
  projectData: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    name: PropTypes.string
  }),
  isUATStep: PropTypes.bool,
  uatData: PropTypes.shape({
    ticket_detail: PropTypes.arrayOf(PropTypes.object)
  }),
  isLoading: PropTypes.bool,
  error: PropTypes.string,
  getUATData: PropTypes.func,
  qaTestData: PropTypes.array,
  uatTestData: PropTypes.array,
  qaStats: PropTypes.object,
  uatStats: PropTypes.object,
  onCreateTest: PropTypes.func,
  onTestAction: PropTypes.func,
  uatTableView: PropTypes.string,
  uatGroupByPage: PropTypes.bool,
  onUatTableViewChange: PropTypes.func,
  onUatGroupByPageChange: PropTypes.func
};

export default StepTesting;
