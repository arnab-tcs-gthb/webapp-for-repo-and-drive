import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../context/ThemeContext';
import {
  // Containers and layout
  ContentSection,
  TestingContainer,
  TestingGrid,
  ResponsiveGrid,
  MetadataSection,
  MetadataHeader,
  SectionTitle,
  MetadataGrid,
  
  // Cards
  MetadataCard,
  MetadataItem,
  MetadataLabel,
  MetadataValue,
  TestingCard,
  TestingCardHeader,
  TestingTitle,
  TestingStatus,
  TestingDescription,
  TestingDetails,
  TestCaseCard,
  TestCaseHeader,
  TestCaseTitle,
  TestCaseContent,
  TestResult,
  TestStatus,
  
  // Badges and status
  StatusBadge,
  
  // Buttons
  PrimaryButton,
  SecondaryButton,
  
  // Icons
  CheckCircleSvg,
  XCircleSvg,
  AlertCircleSvg
} from '../../../ui/adobe-franklin';

/**
 * StepTesting - Step 4 component for User Acceptance Testing
 * Displays test cases, status, and testing summary
 */
const StepTesting = ({
  projectData,
  onTestAction,
  onCreateTest
}) => {
  const { theme } = useTheme();

  return (
    <TestingContainer>
      <MetadataHeader>
        <SectionTitle>User Acceptance Testing</SectionTitle>
      </MetadataHeader>

      <p>Track and manage user acceptance tests for the AEM Franklin project:</p>

      <TestingGrid>
        {projectData?.userAcceptanceTests?.map(test => (
          <TestingCard key={test.id}>
            <TestingCardHeader>
              <TestingTitle>{test.name}</TestingTitle>
              <TestingStatus status={test.status}>{test.status}</TestingStatus>
            </TestingCardHeader>
            <TestingDescription>{test.description}</TestingDescription>
            <TestingDetails>
              <p><strong>Tester:</strong> {test.tester}</p>
              <p><strong>Date:</strong> {test.date}</p>
              <p><strong>Notes:</strong> {test.notes}</p>
            </TestingDetails>
            <div style={{ 
              marginTop: '1rem', 
              display: 'flex', 
              gap: '0.5rem', 
              justifyContent: 'flex-end' 
            }}>
              <button
                onClick={() => onTestAction('view', test)}
                style={{
                  padding: '0.25rem 0.75rem',
                  fontSize: '0.8rem',
                  backgroundColor: 'transparent',
                  color: theme.colors.primary,
                  border: `1px solid ${theme.colors.primary}`,
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                View
              </button>
              <button
                onClick={() => onTestAction('edit', test)}
                style={{
                  padding: '0.25rem 0.75rem',
                  fontSize: '0.8rem',
                  backgroundColor: theme.colors.primary,
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Edit
              </button>
            </div>
          </TestingCard>
        )) || (
          <div style={{ 
            gridColumn: '1 / -1', 
            padding: '2rem', 
            textAlign: 'center' 
          }}>
            <p>No test cases created yet.</p>
            <button
              onClick={onCreateTest}
              style={{
                marginTop: '1rem',
                padding: '0.5rem 1rem',
                backgroundColor: theme.colors.primary,
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Create First Test
            </button>
          </div>
        )}
      </TestingGrid>

      <MetadataSection style={{ marginTop: '2rem' }}>
        <MetadataHeader>
          <SectionTitle>Test Summary</SectionTitle>
        </MetadataHeader>

        <MetadataGrid>
          <MetadataCard>
            <MetadataLabel>Total Tests</MetadataLabel>
            <MetadataValue>{projectData?.userAcceptanceTests?.length || 0}</MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Passed</MetadataLabel>
            <MetadataValue style={{ color: theme.colors.success }}>
              {projectData?.userAcceptanceTests?.filter(t => t.status === 'Passed').length || 0}
            </MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>Failed</MetadataLabel>
            <MetadataValue style={{ color: theme.colors.error }}>
              {projectData?.userAcceptanceTests?.filter(t => t.status === 'Failed').length || 0}
            </MetadataValue>
          </MetadataCard>

          <MetadataCard>
            <MetadataLabel>In Progress</MetadataLabel>
            <MetadataValue style={{ color: theme.colors.warning }}>
              {projectData?.userAcceptanceTests?.filter(t => t.status === 'In Progress').length || 0}
            </MetadataValue>
          </MetadataCard>
        </MetadataGrid>
      </MetadataSection>

      {/* Action buttons */}
      <div style={{ 
        marginTop: '2rem', 
        display: 'flex', 
        gap: '1rem', 
        justifyContent: 'flex-end' 
      }}>
        <button
          onClick={onCreateTest}
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: theme.colors.primary,
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '0.9rem'
          }}
        >
          Add New Test
        </button>
        <button
          onClick={() => onTestAction('runAll')}
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: 'transparent',
            color: theme.colors.primary,
            border: `1px solid ${theme.colors.primary}`,
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '0.9rem'
          }}
        >
          Run All Tests
        </button>
      </div>
    </TestingContainer>
  );
};

StepTesting.propTypes = {
  /** Project data containing user acceptance tests */
  projectData: PropTypes.shape({
    userAcceptanceTests: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
        name: PropTypes.string.isRequired,
        description: PropTypes.string,
        status: PropTypes.oneOf(['Passed', 'Failed', 'In Progress', 'Pending']).isRequired,
        tester: PropTypes.string,
        date: PropTypes.string,
        notes: PropTypes.string
      })
    )
  }),
  /** Callback function for test actions */
  onTestAction: PropTypes.func.isRequired,
  /** Callback function to create a new test */
  onCreateTest: PropTypes.func.isRequired
};

StepTesting.defaultProps = {
  projectData: {
    userAcceptanceTests: []
  }
};

export default StepTesting;
