import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../context/ThemeContext';
import axios from 'axios';
import config from '../../../../config/config';
import {
  TestingContainer,
  MetadataSection,
  TestingTitle
} from '../../../ui/adobe-franklin';

const EmptyStateMessage = ({ message, theme }) => (
  <div style={{ 
    padding: '2rem',
    textAlign: 'center',
    color: theme.colors.textSecondary,
    backgroundColor: theme.colors.surfaceAlt,
    borderRadius: '8px',
    margin: '1rem 0'
  }}>
    {message}
  </div>
);

const LoadingMessage = ({ theme }) => (
  <div style={{ 
    padding: '2rem',
    textAlign: 'center',
    color: theme.colors.textSecondary
  }}>
    Loading UAT data...
  </div>
);

const ErrorMessage = ({ message, theme }) => (
  <div style={{ 
    padding: '2rem',
    textAlign: 'center',
    color: theme.colors.error,
    backgroundColor: theme.colors.errorLight,
    borderRadius: '8px',
    margin: '1rem 0'
  }}>
    {message}
  </div>
);

const StepTesting = ({ projectData, isUATStep = false }) => {
  const { theme } = useTheme();
  const [expandedPages, setExpandedPages] = useState(new Set());
  const [uatData, setUatData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const togglePage = (pageName) => {
    setExpandedPages(prev => {
      const next = new Set(prev);
      if (next.has(pageName)) {
        next.delete(pageName);
      } else {
        next.add(pageName);
      }
      return next;
    });
  };
  useEffect(() => {
    const fetchUATData = async () => {
      if (!isUATStep) return;
      
      setIsLoading(true);
      setError(null);
        try {        const response = await axios.post(
          `${config.API_BASE_URL}/get_uat_data`,
          {
            project_id: Number(projectData?.id) || 1,
            page_id: 0
          }
        );
        const data = response.data;
        if (!data || !Array.isArray(data.ticket_detail)) {
          throw new Error('Invalid data format received from server');
        }
        setUatData(data);
      } catch (err) {
        console.error('Error fetching UAT data:', err);
        setError(
          err.message === 'Failed to fetch' 
            ? 'Unable to connect to the server. Please check your internet connection and try again.'
            : err.message || 'Failed to load UAT data'
        );
      } finally {
        setIsLoading(false);
      }
    };    fetchUATData();
  }, [projectData?.id, isUATStep]);
  // Debug logging
  console.log('StepTesting: Component rendered with:', { 
    projectId: projectData?.id, 
    isUATStep, 
    uatData: uatData ? 'present' : 'missing',
    ticketCount: uatData?.ticket_detail?.length
  });

  // Show empty state for non-UAT step
  if (!isUATStep) {
    return (
      <TestingContainer>
        <MetadataSection>
          <TestingTitle>QA Testing Status</TestingTitle>
          <EmptyStateMessage 
            message="QA Testing interface will be implemented in a future update." 
            theme={theme} 
          />
        </MetadataSection>
      </TestingContainer>
    );
  }

  // Show loading state
  if (isLoading) {
    return (
      <TestingContainer>
        <MetadataSection>
          <div style={{ marginBottom: '2rem' }}>
            <TestingTitle>UAT Testing Status</TestingTitle>
          </div>
          <LoadingMessage theme={theme} />
        </MetadataSection>
      </TestingContainer>
    );
  }

  // Show error state
  if (error) {
    return (
      <TestingContainer>
        <MetadataSection>
          <div style={{ marginBottom: '2rem' }}>
            <TestingTitle>UAT Testing Status</TestingTitle>
          </div>
          <ErrorMessage message={error} theme={theme} />
        </MetadataSection>
      </TestingContainer>
    );
  }

  // Show empty state for UAT step with no data
  if (isUATStep && (!uatData || !Array.isArray(uatData.ticket_detail) || uatData.ticket_detail.length === 0)) {
    return (
      <TestingContainer>
        <MetadataSection>
          <div style={{ marginBottom: '2rem' }}>
            <TestingTitle>UAT Testing Status</TestingTitle>
          </div>
          <EmptyStateMessage 
            message="No UAT tickets available at this time." 
            theme={theme} 
          />
        </MetadataSection>
      </TestingContainer>
    );
  }

  // Group tickets by page_name
  const groupedTickets = uatData.ticket_detail.reduce((acc, ticket) => {
    if (!acc[ticket.page_name]) {
      acc[ticket.page_name] = {
        page_name: ticket.page_name,
        preview_url: ticket.preview_url,
        tickets: []
      };
    }
    if (ticket.jira_id && ticket.jira_url) {
      const ticketExists = acc[ticket.page_name].tickets.some(t => t.jira_id === ticket.jira_id);
      if (!ticketExists) {
        acc[ticket.page_name].tickets.push({
          jira_id: ticket.jira_id,
          jira_url: ticket.jira_url
        });
      }
    }
    return acc;
  }, {});

  // Main UAT interface with grouped tickets
  return (
    <TestingContainer>
      <MetadataSection>
        <div style={{ marginBottom: '2rem' }}>
          <TestingTitle>UAT Testing Status</TestingTitle>
        </div>

        {Object.values(groupedTickets).map((page) => {
          const hasJiraTickets = page.tickets.length > 0;
          
          return (
            <div
              key={page.page_name}
              style={{
                marginBottom: '1rem',
                border: `1px solid ${theme.colors.textSecondary}`,
                borderRadius: '8px',
                overflow: 'hidden',
                backgroundColor: theme.colors.surface
              }}
            >
              <div
                onClick={hasJiraTickets ? () => togglePage(page.page_name) : undefined}
                style={{
                  padding: '1rem 1.5rem',
                  backgroundColor: theme.colors.surface,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: hasJiraTickets ? 'pointer' : 'default',
                  borderBottom: hasJiraTickets && expandedPages.has(page.page_name) ? `1px solid ${theme.colors.textSecondary}` : 'none'
                }}
              >
                <div style={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 500, color: theme.colors.text }}>
                      {page.page_name}
                    </h3>                    <span style={{ color: theme.colors.textSecondary }}>|</span>
                    {page.preview_url ? (
                      <a
                        href={`${page.preview_url}${page.preview_url.includes('?') ? '&' : '?'}project_id=${projectData?.id || ''}&page_id=${page.page_id || ''}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ 
                          color: theme.colors.primary,
                          textDecoration: 'none',
                          fontSize: '0.9rem',
                          opacity: 0.85,
                          transition: 'all 0.2s ease',
                          '&:hover': {
                            opacity: 1,
                            textDecoration: 'underline'
                          }
                        }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        Preview Link
                      </a>
                    ) : (
                      <span
                        style={{ 
                          color: theme.colors.textSecondary,
                          fontSize: '0.9rem',
                          fontStyle: 'italic'
                        }}
                      >
                        No preview link
                      </span>
                    )}
                  </div>
                </div>
                {hasJiraTickets && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <span style={{ 
                      fontSize: '0.8rem',
                      color: theme.colors.textSecondary,
                      backgroundColor: theme.colors.surfaceAlt,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '12px'
                    }}>
                      {page.tickets.length} {page.tickets.length === 1 ? 'ticket' : 'tickets'}
                    </span>
                    <span style={{ 
                      transform: expandedPages.has(page.page_name) ? 'rotate(180deg)' : 'none',
                      transition: 'transform 0.2s ease'
                    }}>▼</span>
                  </div>
                )}
              </div>

              {hasJiraTickets && expandedPages.has(page.page_name) && (
                <div style={{ padding: '0.75rem' }}>
                  <div style={{
                    backgroundColor: theme.colors.surfaceAlt,
                    borderRadius: '8px',
                    padding: '0.75rem',
                    display: 'flex',
                    flexDirection: 'column'
                  }}>
                    {page.tickets.map((ticket, index) => (
                      <div
                        key={ticket.jira_id}
                        style={{
                          borderBottom: index !== page.tickets.length - 1 ? `1px solid ${theme.colors.textSecondary}` : 'none',
                          paddingBottom: index !== page.tickets.length - 1 ? '0.5rem' : '0',
                          marginBottom: index !== page.tickets.length - 1 ? '0.5rem' : '0'
                        }}
                      >
                        <a
                          href={ticket.jira_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ 
                            color: theme.colors.primary,
                            textDecoration: 'none',
                            fontSize: '0.9rem',
                            fontWeight: 400,
                            opacity: 0.85,
                            transition: 'all 0.2s ease',
                            padding: '0.5rem',
                            display: 'block',
                            borderRadius: '4px',
                            '&:hover': {
                              opacity: 1,
                              textDecoration: 'underline'
                            }
                          }}
                          onClick={(e) => e.stopPropagation()}
                        >
                          {ticket.jira_id}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </MetadataSection>
    </TestingContainer>
  );
};

StepTesting.propTypes = {
  projectData: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    name: PropTypes.string,
    // Add other project data fields as needed
  }),
  isUATStep: PropTypes.bool
};

export default StepTesting;
