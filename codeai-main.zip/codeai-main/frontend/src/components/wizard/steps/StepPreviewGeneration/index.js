import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../context/ThemeContext';
import {
  // Containers and layout
  MetadataSection,
  MetadataHeader,
  MetadataGrid,
  SectionTitle,
  FileExplorerContainer,
  FileTreeContainer,
  FileTreeHeader,
  FileTreeContent,
  PreviewContentContainer,
  
  // Cards
  MetadataCard,
  MetadataLabel,
  MetadataValue,
  
  // Preview components
  PreviewContainer,
  PreviewHeader,
  PreviewContent,
  DocumentPreviewContainer,
  PreviewFrame,
  WebsiteIframe,
  PreviewNavTabs,
  PreviewNavTab
} from '../../../ui/adobe-franklin';

/**
 * StepPreviewGeneration - Step 3 component for document and website preview
 * Displays generation status, file explorer, and dual preview modes
 */
const StepPreviewGeneration = ({
  projectData,
  selectedFile,
  previewTab,
  isDocLoading,
  docxPreviewRef,
  onPreviewTabChange,
  onEditDocument,
  onFileSelect,
  renderFileTree,
  getFileTreeStructure
}) => {
  const { theme } = useTheme();

  const renderDocumentPreview = () => {
    if (!selectedFile) {
      return (
        <div style={{ padding: '2rem', textAlign: 'center' }}>
          <p>Select a document from the file explorer to preview.</p>
        </div>
      );
    }

    if (isDocLoading) {
      return (
        <div style={{
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column'
        }}>
          <div style={{ marginBottom: '1rem' }}>
            <svg
              width="40"
              height="40"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
              style={{
                animation: 'spin 2s linear infinite',
                color: theme.colors.primary
              }}
            >
              <style>{`
                @keyframes spin {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
                }
              `}</style>
              <circle
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="2"
                fill="none"
                opacity="0.25"
              />
              <path
                d="M12 2C6.48 2 2 6.48 2 12"
                stroke="currentColor"
                strokeWidth="3"
                strokeLinecap="round"
                fill="none"
              />
            </svg>
          </div>
          <div>Loading document preview...</div>
        </div>
      );
    }

    // Check if we have a Google Docs URL for iframe preview
    if (selectedFile.url && selectedFile.url.includes('docs.google.com')) {
      return (
        <div style={{ height: '100%' }}>
          {/* Document information banner */}
          <div style={{
            marginBottom: '1rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '0.5rem 1rem',
            backgroundColor: theme.colors.cardBackground,
            borderRadius: '4px',
            border: `1px solid ${theme.colors.border}`
          }}>
            <div style={{ flex: 1 }}>
              <strong>{selectedFile.name}</strong>
              <div style={{
                fontSize: '0.8rem',
                color: theme.colors.textSecondary,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                maxWidth: '500px'
              }}>
                Path: {selectedFile.path}
              </div>
              <div style={{ fontSize: '0.8rem', color: theme.colors.textSecondary }}>
                Google Docs Preview
              </div>
            </div>
            <span style={{
              fontSize: '0.8rem',
              backgroundColor: theme.colors.primaryLight,
              color: theme.colors.primary,
              padding: '0.25rem 0.5rem',
              borderRadius: '4px',
              whiteSpace: 'nowrap'
            }}>
              Document Preview
            </span>
          </div>

          {/* Google Docs iframe */}
          <div style={{ 
            height: 'calc(100% - 80px)', 
            border: `1px solid ${theme.colors.border}`,
            borderRadius: '4px',
            overflow: 'hidden'
          }}>
            <WebsiteIframe
              src={selectedFile.url}
              title={`Document Preview - ${selectedFile.name}`}
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
              style={{ 
                width: '100%', 
                height: '100%', 
                border: 'none',
                backgroundColor: 'white'
              }}
              onError={(e) => console.error('Error loading document preview', e)}
            />
          </div>
        </div>
      );
    }

    // Fallback for files without Google Docs URL
    return (
      <div style={{ height: '100%', overflow: 'auto', padding: '1rem' }}>
        {/* Document information banner */}
        <div style={{
          marginBottom: '1rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '0.5rem 1rem',
          backgroundColor: theme.colors.cardBackground,
          borderRadius: '4px',
          border: `1px solid ${theme.colors.border}`
        }}>
          <div style={{ flex: 1 }}>
            <strong>{selectedFile.name}</strong>
            <div style={{
              fontSize: '0.8rem',
              color: theme.colors.textSecondary,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              maxWidth: '500px'
            }}>
              Path: {selectedFile.path}
            </div>
            <div style={{ fontSize: '0.8rem', color: theme.colors.textSecondary }}>
              {selectedFile.url ? 'File URL available' : 'Local preview'}
            </div>
          </div>
          <span style={{
            fontSize: '0.8rem',
            backgroundColor: theme.colors.primaryLight,
            color: theme.colors.primary,
            padding: '0.25rem 0.5rem',
            borderRadius: '4px',
            whiteSpace: 'nowrap'
          }}>
            Document Preview
          </span>
        </div>

        {/* Legacy DOCX preview container for backward compatibility */}
        <DocumentPreviewContainer
          data-testid="docx-container-wrapper"
          id="docx-container-wrapper"
        >
          <div
            ref={docxPreviewRef}
            className="docx-preview-container"
            id="docx-preview-container"
            style={{
              width: '100%',
              minHeight: '800px',
              height: 'calc(100vh - 300px)',
              backgroundColor: 'white',
              borderRadius: '4px',
              overflow: 'auto',
              padding: '10px',
              visibility: 'visible',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
            }}
            data-file-path={selectedFile.path}
            data-file-type={selectedFile.type || (selectedFile.name && selectedFile.name.toLowerCase().endsWith('.docx') ? 'docx' : 'unknown')}
            data-ready="true"
          >
            {selectedFile.url && !selectedFile.url.includes('docs.google.com') ? (
              <div style={{
                padding: '1rem',
                textAlign: 'center',
                color: '#666'
              }}>
                <p>Document URL: <a href={selectedFile.url} target="_blank" rel="noopener noreferrer">{selectedFile.url}</a></p>
                <p>Click the link above to view the document in a new tab.</p>
              </div>
            ) : (
              <div style={{
                padding: '1rem',
                textAlign: 'center',
                color: '#888'
              }}>
                Document preview not available for this file type.
              </div>
            )}
          </div>
        </DocumentPreviewContainer>
      </div>
    );
  };

  const renderWebPreview = () => {
    // Use preview_url from selected file if available, otherwise fall back to project URL
    const previewUrl = selectedFile?.preview_url || projectData?.url;
    const displayUrl = selectedFile?.preview_url ? 
      `${selectedFile.name} - AEM Preview` : 
      (projectData?.url || 'AEM Franklin Site');
    
    return (
      <div style={{ height: '100%' }}>
        <PreviewContainer style={{ margin: 0, height: '100%', border: 'none', borderRadius: 0 }}>
          <PreviewHeader>
            <div style={{ flex: 1 }}>
              <span style={{ marginRight: '10px' }}>Preview:</span>
              <strong>{displayUrl}</strong>
            </div>
          </PreviewHeader>
          <PreviewFrame>
            {previewUrl ? (
              <WebsiteIframe
                src={previewUrl}
                title={selectedFile ? `AEM Preview - ${selectedFile.name}` : "AEM Franklin Site Preview"}
                sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                onError={(e) => console.error('Error loading website preview', e)}
              />
            ) : (
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                textAlign: 'center',
                width: '100%',
                height: '100%'
              }}>
                <img
                  src="/logos/adobe-logo.svg"
                  alt="Adobe Logo"
                  style={{ width: '60px', marginBottom: '1rem', opacity: 0.6 }}
                />
                <h3>Website Preview</h3>
                <p>
                  {selectedFile ? 
                    'No preview URL available for this document' : 
                    'Select a document to preview its AEM site, or the general site preview will display here'
                  }
                </p>
              </div>
            )}
          </PreviewFrame>
        </PreviewContainer>
      </div>
    );
  };

  return (
    <MetadataSection>
      <MetadataHeader>
        <SectionTitle>Document Generation Summary</SectionTitle>
      </MetadataHeader>
      <MetadataGrid style={{ marginBottom: '1.5rem', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem', alignItems: 'center' }}>
        <MetadataCard>
          <MetadataLabel>Generation Status</MetadataLabel>
          <MetadataValue style={{ color: theme.colors.success }}>Complete</MetadataValue>
        </MetadataCard>

        <MetadataCard>
          <MetadataLabel>Documents Generated</MetadataLabel>
          <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>
            {projectData?.num_documents_generated !== undefined ? projectData.num_documents_generated : 0}
          </MetadataValue>
        </MetadataCard>

        <MetadataCard>
          <MetadataLabel>Last Generated</MetadataLabel>
          <MetadataValue>
            {new Date().toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
              hour: 'numeric',
              minute: '2-digit',
              hour12: true
            })}
          </MetadataValue>
        </MetadataCard>
      </MetadataGrid>

      <FileExplorerContainer>
        {/* File tree sidebar */}
        <FileTreeContainer>
          <FileTreeHeader>
            <div>Project Files</div>
          </FileTreeHeader>
          <FileTreeContent>
            {renderFileTree(getFileTreeStructure())}
          </FileTreeContent>
        </FileTreeContainer>

        {/* Preview content */}
        <PreviewContentContainer>
          <PreviewNavTabs>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <PreviewNavTab
                active={previewTab === 'document'}
                onClick={() => onPreviewTabChange('document')}
              >
                Document Preview
              </PreviewNavTab>
              <PreviewNavTab
                active={previewTab === 'web'}
                onClick={() => onPreviewTabChange('web')}
              >
                Web Preview
              </PreviewNavTab>
            </div>
            {(selectedFile || previewTab === 'web') && (
              <button
                onClick={() => {
                  if (previewTab === 'document') {
                    // For document preview, open the Google Docs URL for editing
                    onEditDocument(selectedFile);
                  } else {
                    // For web preview, open the preview URL in a new tab
                    const previewUrl = selectedFile?.preview_url || projectData?.url;
                    if (previewUrl) {
                      window.open(previewUrl, '_blank', 'noopener,noreferrer');
                    } else {
                      console.warn('No preview URL available');
                      alert('No preview URL available for this item.');
                    }
                  }
                }}
                style={{
                  backgroundColor: 'transparent',
                  border: `1px solid ${theme.colors.border}`,
                  borderRadius: '4px',
                  padding: '6px 12px',
                  fontSize: '0.9rem',
                  marginLeft: 'auto',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  cursor: 'pointer',
                  color: theme.colors.text
                }}
              >
                {previewTab === 'document' ? (
                  // Edit icon for document preview
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.84 1.83 3.75 3.75 1.84-1.83zM3 17.25V21h3.75L17.81 9.93l-3.75-3.75L3 17.25z" fill="currentColor" />
                  </svg>
                ) : (
                  // External link icon for web preview
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M15 3h6v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M10 14L21 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
                {previewTab === 'document' ? 'Edit' : 'Open in Browser'}
              </button>
            )}
          </PreviewNavTabs>

          <PreviewContent>
            {previewTab === 'document' ? renderDocumentPreview() : renderWebPreview()}
          </PreviewContent>
        </PreviewContentContainer>
      </FileExplorerContainer>
    </MetadataSection>
  );
};

StepPreviewGeneration.propTypes = {
  /** Project data containing generated files and URL */
  projectData: PropTypes.shape({
    url: PropTypes.string,
    generatedFiles: PropTypes.array
  }),
  /** Currently selected file for preview */
  selectedFile: PropTypes.shape({
    name: PropTypes.string,
    path: PropTypes.string,
    lastModified: PropTypes.string,
    type: PropTypes.string,
    url: PropTypes.string,
    preview_url: PropTypes.string,
    publish_url: PropTypes.string
  }),
  /** Current preview tab (document or web) */
  previewTab: PropTypes.oneOf(['document', 'web']).isRequired,
  /** Loading state for document preview */
  isDocLoading: PropTypes.bool,
  /** Ref for the DOCX preview container */
  docxPreviewRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any })
  ]),
  /** Callback function when preview tab changes */
  onPreviewTabChange: PropTypes.func.isRequired,
  /** Callback function to edit a document */
  onEditDocument: PropTypes.func.isRequired,
  /** Callback function when a file is selected */
  onFileSelect: PropTypes.func.isRequired,
  /** Function to render the file tree */
  renderFileTree: PropTypes.func.isRequired,
  /** Function to get file tree structure */
  getFileTreeStructure: PropTypes.func.isRequired
};

StepPreviewGeneration.defaultProps = {
  projectData: {},
  selectedFile: null,
  isDocLoading: false,
  docxPreviewRef: null
};

export default StepPreviewGeneration;
