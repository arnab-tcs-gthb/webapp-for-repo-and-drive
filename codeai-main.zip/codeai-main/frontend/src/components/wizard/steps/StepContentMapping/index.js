import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../context/ThemeContext';
import {
  // Containers and layout
  ContentSection,
  GridContainer,
  ResponsiveGrid,
  SectionContainer,
  MetadataSection,
  MetadataHeader,
  SectionTitle,
  PageCardsGrid,
  
  // Cards
  MetadataCard,
  MetadataItem,
  MetadataLabel,
  MetadataValue,
  PageCard,
  PageCardHeader,
  PageCardTitle,
  PageCardContent,
  PageStatus,
  PageMetrics,
  PageCardImagePreview,
  PageCardStatusBadge,
  PageCardInfo,
  PageCardPath,
  PageCardConfidence,
  PageCardStats,
  PageCardStat,
  PageCardStatValue,
  PageCardStatLabel,
  PageCardFooter,
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  
  // Buttons
  SecondaryButton,
  
  // Badges and status
  StatusBadge,
  
  // Icons
  CheckIcon,
  
  // Navigation
  StepTitle,
  
  // Icons
  CheckCircleSvg
} from '../../../ui/adobe-franklin';

/**
 * StepContentMapping - Step 2 component for content mapping and page analysis
 * Displays mapping summary, statistics, and page analysis results
 */
const StepContentMapping = ({
  projectData,
  projectAnalysis,
  elapsedTime,
  isAnalysisDataLoading,
  onRegeneratePages,
  onEditPage,
  onRemovePage
}) => {
  const { theme } = useTheme();

  return (
    <>
      <MetadataSection>
        <MetadataHeader style={{ justifyContent: 'space-between', marginBottom: '.5rem' }}>
          <SectionTitle style={{ color: theme.colors.textSecondary, fontSize: '95%' }}>
            Review and Migrate
          </SectionTitle>
        </MetadataHeader>

        <MetadataSection>
          <div style={{ marginBottom: '1rem' }}>
            <StepTitle>{projectData?.url}</StepTitle>
          </div>
        </MetadataSection>

        <MetadataSection>
          <MetadataHeader style={{ justifyContent: 'space-between' }}>
            <div style={{ 
              display: 'flex', 
              gap: '1.5rem', 
              justifyContent: 'space-between', 
              alignItems: 'center' 
            }}>
              <SectionTitle>Mapping Summary</SectionTitle>

              <MetadataCard style={{ 
                padding: '.50rem', 
                background: 'transparent', 
                border: 'none' 
              }}>
                <MetadataLabel>Design System</MetadataLabel>
                <MetadataValue>aem-block-collection</MetadataValue>
              </MetadataCard>

              <MetadataCard style={{ 
                padding: '.50rem', 
                background: 'transparent', 
                border: 'none' 
              }}>
                <MetadataLabel>Site Template</MetadataLabel>
                <MetadataValue>{projectData?.brand}</MetadataValue>
              </MetadataCard>
            </div>

            <SecondaryButton 
              onClick={onRegeneratePages} 
              style={{ fontSize: '0.9rem' }}
            >
              Regenerate All Pages
            </SecondaryButton>
          </MetadataHeader>

          {/* Statistics Grid */}
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(4, 1fr)', 
            gap: '1.5rem', 
            marginBottom: '2rem' 
          }}>
            <MetadataCard style={{ padding: '1.25rem' }}>
              <MetadataValue style={{ 
                color: theme.colors.primary, 
                fontWeight: 'bold', 
                fontSize: '1.2rem' 
              }}>
                100%
              </MetadataValue>
              <MetadataLabel>Mapping Status</MetadataLabel>
            </MetadataCard>

            <MetadataCard style={{ padding: '1.25rem' }}>
              <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>
                {projectAnalysis?.length || 0}/{projectAnalysis?.length || 0}
              </MetadataValue>
              <MetadataLabel>Pages Completed</MetadataLabel>
            </MetadataCard>

            <MetadataCard style={{ padding: '1.25rem' }}>
              <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>
                {elapsedTime}
              </MetadataValue>
              <MetadataLabel>Elapsed Time</MetadataLabel>
            </MetadataCard>

            <MetadataCard style={{ padding: '1.25rem' }}>
              <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>
                0
              </MetadataValue>
              <MetadataLabel>Content Changes</MetadataLabel>
            </MetadataCard>
          </div>

          {/* Page Status Section */}
          <div style={{ 
            backgroundColor: theme.colors.cardBackground, 
            border: `1px solid ${theme.colors.border}`, 
            borderRadius: '8px', 
            overflow: 'hidden' 
          }}>
            <div style={{ 
              padding: '1.25rem', 
              borderBottom: `1px solid ${theme.colors.border}`, 
              backgroundColor: theme.colors.inputBackground 
            }}>
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center' 
              }}>
                <div style={{ fontWeight: '500' }}>Page Status</div>
              </div>
            </div>

            {isAnalysisDataLoading ? (
              <div style={{ padding: '2rem', textAlign: 'center' }}>
                <p>Loading analysis data...</p>
              </div>
            ) : (
              <PageCardsGrid>
                {projectAnalysis && projectAnalysis.length > 0 ? (
                  projectAnalysis.map((analysis, index) => {
                    // Extract page title from llm_response if possible
                    let pageTitle = "Page";
                    let pageType = "Content Page";

                    if (analysis.llm_response) {
                      try {
                        const parsedResponse = JSON.parse(analysis.llm_response);
                        pageTitle = parsedResponse.page_title || `Page ${index + 1}`;
                        pageType = "Content Page";
                      } catch (e) {
                        console.error("Error parsing llm_response:", e);
                      }
                    }

                    return (
                      <PageCard key={analysis.id}>
                        <PageCardImagePreview>
                          <div style={{
                            width: '100%',
                            height: '100%',
                            background: `linear-gradient(135deg, ${theme.colors.primaryLight}, ${theme.colors.primary})`,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: 'white'
                          }}>
                            <div style={{ 
                              fontSize: '1.25rem', 
                              fontWeight: '600', 
                              marginBottom: '0.5rem' 
                            }}>
                              {pageTitle}
                            </div>
                            <div style={{ fontSize: '0.85rem', opacity: '0.8' }}>
                              {pageType}
                            </div>
                          </div>

                          <PageCardStatusBadge>
                            <CheckIcon />
                          </PageCardStatusBadge>
                        </PageCardImagePreview>

                        <PageCardInfo>
                          <PageCardHeader>
                            <div>
                              <PageCardTitle>{pageTitle}</PageCardTitle>
                              <PageCardPath>
                                {pageTitle
                                  ? `/${pageTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`
                                  : `/${analysis.filename.split('.')[0].toLowerCase()}`}
                              </PageCardPath>
                            </div>
                            <PageCardConfidence>High</PageCardConfidence>
                          </PageCardHeader>

                          <PageCardStats>
                            <PageCardStat>
                              <PageCardStatValue>
                                {analysis.llm_analysis?.reusable_components || 0}
                              </PageCardStatValue>
                              <PageCardStatLabel>Sitewide component</PageCardStatLabel>
                            </PageCardStat>

                            <PageCardStat>
                              <PageCardStatValue>
                                {analysis.llm_analysis?.total_components || 0}
                              </PageCardStatValue>
                              <PageCardStatLabel>Total components</PageCardStatLabel>
                            </PageCardStat>
                          </PageCardStats>

                          <PageCardFooter>
                            <SecondaryButton 
                              style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem' }}
                              onClick={() => onEditPage(analysis)}
                            >
                              Edit
                            </SecondaryButton>
                            <SecondaryButton 
                              style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem' }}
                              onClick={() => onRemovePage(analysis)}
                            >
                              Remove
                            </SecondaryButton>
                          </PageCardFooter>
                        </PageCardInfo>
                      </PageCard>
                    );
                  })
                ) : (
                  <div style={{ padding: '2rem', textAlign: 'center' }}>
                    <p>No analysis data available for this project.</p>
                  </div>
                )}
              </PageCardsGrid>
            )}
          </div>
        </MetadataSection>
      </MetadataSection>
    </>
  );
};

StepContentMapping.propTypes = {
  /** Project data containing URL and brand information */
  projectData: PropTypes.shape({
    url: PropTypes.string,
    brand: PropTypes.string
  }),
  /** Array of page analysis results */
  projectAnalysis: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      filename: PropTypes.string,
      llm_response: PropTypes.string,
      llm_analysis: PropTypes.shape({
        reusable_components: PropTypes.number,
        total_components: PropTypes.number
      })
    })
  ),
  /** Formatted elapsed time string */
  elapsedTime: PropTypes.string,
  /** Loading state for analysis data */
  isAnalysisDataLoading: PropTypes.bool,
  /** Callback function to regenerate all pages */
  onRegeneratePages: PropTypes.func.isRequired,
  /** Callback function to edit a specific page */
  onEditPage: PropTypes.func.isRequired,
  /** Callback function to remove a specific page */
  onRemovePage: PropTypes.func.isRequired
};

StepContentMapping.defaultProps = {
  projectData: {},
  projectAnalysis: [],
  elapsedTime: '0:00',
  isAnalysisDataLoading: false
};

export default StepContentMapping;
