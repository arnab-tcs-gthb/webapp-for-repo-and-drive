import styled from 'styled-components';
import { adobeFranklinTheme } from './theme';

// Base button styles
export const Button = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  font-size: ${props => props.theme.fontSize.md};
  font-weight: ${props => props.theme.fontWeight.medium};
  line-height: 1;
  text-decoration: none;
  cursor: pointer;
  transition: all ${props => props.theme.transitions.normal};
  border: 1px solid transparent;
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  &:focus {
    outline: 2px solid ${props => props.theme.colors.primary};
    outline-offset: 2px;
  }
`;

// Primary button variant
export const PrimaryButton = styled(Button)`
  background-color: ${props => props.theme.colors.primary};
  color: ${props => props.theme.colors.textInverse};
  border-color: ${props => props.theme.colors.primary};
  
  &:hover:not(:disabled) {
    background-color: ${props => props.theme.colors.primaryDark};
    border-color: ${props => props.theme.colors.primaryDark};
    transform: translateY(-1px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
  
  &:active:not(:disabled) {
    transform: translateY(0);
    box-shadow: 0 2px 4px ${props => props.theme.colors.shadow};
  }
`;

// Secondary button variant
export const SecondaryButton = styled(Button)`
  background-color: transparent;
  color: ${props => props.theme.colors.text};
  border-color: ${props => props.theme.colors.border};
  
  &:hover:not(:disabled) {
    background-color: ${props => props.theme.colors.inputBackground};
    border-color: ${props => props.theme.colors.borderDark};
  }
  
  &:active:not(:disabled) {
    background-color: ${props => props.theme.colors.borderLight};
  }
`;

// Cancel button variant
export const CancelButton = styled(Button)`
  background-color: transparent;
  color: ${props => props.theme.colors.textSecondary};
  border-color: transparent;
  padding: 0.75rem 1rem;
  
  &:hover:not(:disabled) {
    color: ${props => props.theme.colors.text};
    background-color: ${props => props.theme.colors.inputBackground};
  }
`;

// Back button variant
export const BackButton = styled(Button)`
  background-color: transparent;
  color: ${props => props.theme.colors.textSecondary};
  border-color: ${props => props.theme.colors.border};
  
  &:hover:not(:disabled) {
    color: ${props => props.theme.colors.text};
    background-color: ${props => props.theme.colors.inputBackground};
    border-color: ${props => props.theme.colors.borderDark};
  }
`;

// Form components
export const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

export const FormLabel = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: ${props => props.theme.fontWeight.medium};
  color: ${props => props.theme.colors.text};
  font-size: ${props => props.theme.fontSize.sm};
`;

export const FormInput = styled.input`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  background-color: ${props => props.theme.colors.cardBackground};
  color: ${props => props.theme.colors.text};
  font-size: ${props => props.theme.fontSize.md};
  transition: all ${props => props.theme.transitions.normal};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.colors.primaryLight}33;
  }
  
  &:disabled {
    background-color: ${props => props.theme.colors.inputBackground};
    color: ${props => props.theme.colors.textMuted};
    cursor: not-allowed;
  }
  
  &::placeholder {
    color: ${props => props.theme.colors.textMuted};
  }
`;

export const FormTextarea = styled.textarea`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  background-color: ${props => props.theme.colors.cardBackground};
  color: ${props => props.theme.colors.text};
  font-size: ${props => props.theme.fontSize.md};
  font-family: inherit;
  resize: vertical;
  min-height: 100px;
  transition: all ${props => props.theme.transitions.normal};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.colors.primaryLight}33;
  }
  
  &:disabled {
    background-color: ${props => props.theme.colors.inputBackground};
    color: ${props => props.theme.colors.textMuted};
    cursor: not-allowed;
  }
  
  &::placeholder {
    color: ${props => props.theme.colors.textMuted};
  }
`;

export const FormSelect = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  background-color: ${props => props.theme.colors.cardBackground};
  color: ${props => props.theme.colors.text};
  font-size: ${props => props.theme.fontSize.md};
  cursor: pointer;
  transition: all ${props => props.theme.transitions.normal};
  
  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
    box-shadow: 0 0 0 3px ${props => props.theme.colors.primaryLight}33;
  }
  
  &:disabled {
    background-color: ${props => props.theme.colors.inputBackground};
    color: ${props => props.theme.colors.textMuted};
    cursor: not-allowed;
  }
`;

// Search input component
export const SearchInput = styled(FormInput)`
  padding-left: 2.5rem;
  background-image: url('data:image/svg+xml;charset=UTF-8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%23666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><path d="M21 21l-4.35-4.35"></path></svg>');
  background-repeat: no-repeat;
  background-position: 0.75rem center;
  background-size: 16px;
`;

// Badge components
export const Badge = styled.span`
  display: inline-flex;
  align-items: center;
  padding: 0.25rem 0.5rem;
  border-radius: ${adobeFranklinTheme.borderRadius.small};
  font-size: ${props => props.theme.fontSize.xs};
  font-weight: ${props => props.theme.fontWeight.medium};
  line-height: 1;
  white-space: nowrap;
`;

export const CompleteBadge = styled(Badge)`
  background-color: ${props => props.theme.colors.successLight};
  color: ${props => props.theme.colors.success};
  gap: 0.25rem;
`;

export const CompleteIcon = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
`;

// Checkbox and radio components
export const FormCheckbox = styled.input`
  width: 1rem;
  height: 1rem;
  accent-color: ${props => props.theme.colors.primary};
  cursor: pointer;
`;

export const FormRadio = styled.input`
  width: 1rem;
  height: 1rem;
  accent-color: ${props => props.theme.colors.primary};
  cursor: pointer;
`;

export const FormCheckGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
`;

// Form validation styles
export const FormError = styled.div`
  color: ${props => props.theme.colors.error};
  font-size: ${props => props.theme.fontSize.sm};
  margin-top: 0.25rem;
`;

export const FormHelp = styled.div`
  color: ${props => props.theme.colors.textMuted};
  font-size: ${props => props.theme.fontSize.sm};
  margin-top: 0.25rem;
`;

// Progress components
export const ProgressBar = styled.div`
  width: 100%;
  height: 8px;
  background-color: ${props => props.theme.colors.border};
  border-radius: 4px;
  overflow: hidden;
  margin: 0.5rem 0;
`;

export const ProgressFill = styled.div`
  height: 100%;
  background-color: ${props => props.theme.colors.primary};
  border-radius: 4px;
  transition: width 0.3s ease;
  width: ${props => props.progress || 0}%;
`;

// Button group component
export const ButtonGroup = styled.div`
  display: flex;
  gap: 1rem;
  align-items: center;
  justify-content: flex-end;
  
  &.left {
    justify-content: flex-start;
  }
  
  &.center {
    justify-content: center;
  }
  
  &.spaced {
    justify-content: space-between;
  }
`;
