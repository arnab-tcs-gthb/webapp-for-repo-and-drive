import React from 'react';
import styled from 'styled-components';
import { Button } from './forms';

// Base icon button for table controls
export const IconButton = styled(Button)`
  width: 36px;
  height: 36px;
  padding: 6px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.textSecondary};
  background-color: ${props => props.active ? props.theme.colors.primarySoft : props.theme.colors.cardBackground};
  border: 1px solid ${props => props.active ? props.theme.colors.primary : props.theme.colors.inputBorder};
  
  &:hover {
    background-color: ${props => props.active ? props.theme.colors.primarySoft : props.theme.colors.inputHoverBackground};
    color: ${props => props.theme.colors.primary};
  }
`;

// Tooltip component for table controls
export const Tooltip = styled.div.attrs(props => ({
  'data-content': props.content
}))`
  position: relative;
  display: inline-block;
  
  &:hover::after {
    content: attr(data-content);
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 8px;
    background-color: ${props => props.theme.colors.tooltipBackground || 'rgba(0, 0, 0, 0.8)'};
    color: ${props => props.theme.colors.tooltipText || 'white'};
    font-size: 12px;
    border-radius: 4px;
    white-space: nowrap;
    z-index: 1000;
    margin-bottom: 6px;
  }
`;
