import styled from 'styled-components';
import { adobeFranklinTheme } from './theme';

// Shared containers
export const StepContainer = styled.div`
  padding: ${props => props.theme.spacing?.xl || '2rem'};
  max-width: 1200px;
  margin: 0 auto;
`;

export const StepHeader = styled.header`
  margin-bottom: ${props => props.theme.spacing?.xl || '2rem'};
  
  h2 {
    font-size: 1.875rem;
    font-weight: 700;
    color: ${props => props.theme.colors.text};
    margin-bottom: ${props => props.theme.spacing?.sm || '0.5rem'};
  }
  
  p {
    color: ${props => props.theme.colors.textSecondary};
    font-size: 1rem;
  }
`;

export const StepContent = styled.div`
  background: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.large};
  box-shadow: ${props => props.theme.shadows?.md || '0 4px 6px -1px rgba(0, 0, 0, 0.1)'};
  padding: ${props => props.theme.spacing?.xl || '2rem'};
`;

// Metadata components
export const MetadataSection = styled.div`
  margin-bottom: 2rem;
`;

export const MetadataHeader = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
`;

export const SectionTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 500;
  color: ${props => props.theme.colors.text};
  margin: 0;
`;

export const CompleteBadge = styled.div`
  display: flex;
  align-items: center;
  background-color: ${props => props.theme.colors.successLight};
  color: ${props => props.theme.colors.success};
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
  margin-left: 1rem;
`;

export const CompleteIcon = styled.div`
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.success};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 0.5rem;
  
  svg {
    width: 10px;
    height: 10px;
    color: white;
  }
`;

export const MetadataGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (max-width: 576px) {
    grid-template-columns: 1fr;
  }
`;

export const MetadataCard = styled.div`
  background-color: ${props => props.theme.colors.borderLight || props.theme.colors.inputBackground};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1rem;
`;

export const MetadataLabel = styled.div`
  font-size: 0.8rem;
  color: ${props => props.theme.colors.textSecondary};
  margin-bottom: 0.25rem;
`;

export const MetadataValue = styled.div`
  font-weight: 500;
  color: ${props => props.theme.colors.text};
  font-size: 0.95rem;
  word-break: break-all;
`;

// Stats components
export const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 1rem;
  margin-top: 0.5rem;
  
  @media (max-width: 992px) {
    grid-template-columns: repeat(3, 1fr);
  }
  
  @media (max-width: 576px) {
    grid-template-columns: repeat(2, 1fr);
  }
`;

export const StatCard = styled.div`
  background-color: ${props => props.theme.colors.borderLight || props.theme.colors.inputBackground};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1rem;
`;

export const StatValue = styled.div`
  font-size: 1.5rem;
  font-weight: 600;
  color: ${props => props.theme.colors.text};
  margin-bottom: 0.25rem;
`;

export const StatLabel = styled.div`
  font-size: 0.75rem;
  color: ${props => props.theme.colors.textSecondary};
`;

// File components
export const UploadedFilesSection = styled.div`
  margin-top: 2rem;
`;

export const FilesHeader = styled.div`
  margin-bottom: 1rem;
`;

export const FilesTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 500;
  color: ${props => props.theme.colors.text};
  margin: 0;
`;

export const FilesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1rem;
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  }
`;

export const FileCard = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: 8px;
  padding: 1rem;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow || 'rgba(0, 0, 0, 0.1)'};
  }
`;

export const FileImagePreview = styled.div`
  width: 100%;
  height: 120px;
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 0.75rem;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

export const FileIconPreview = styled.div`
  width: 100%;
  height: 120px;
  background-color: ${props => props.backgroundColor || props.theme.colors.primary};
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 0.75rem;
  
  svg {
    width: 48px;
    height: 48px;
    color: white;
  }
`;

export const FileInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

export const FileName = styled.div`
  font-size: 0.875rem;
  font-weight: 500;
  color: ${props => props.theme.colors.text};
  margin-bottom: 0.25rem;
  word-break: break-word;
`;

export const FileSize = styled.div`
  font-size: 0.75rem;
  color: ${props => props.theme.colors.textSecondary};
`;

// Icons
export const CheckIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="20 6 9 17 4 12"></polyline>
  </svg>
);
