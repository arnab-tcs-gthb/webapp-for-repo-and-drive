import React from 'react';
import styled from 'styled-components';

const IconWrapper = styled.svg.attrs(props => ({
  xmlns: 'http://www.w3.org/2000/svg',
  width: props.size || '24',
  height: props.size || '24',
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: '2',
  strokeLinecap: 'round',
  strokeLinejoin: 'round'
}))``;

export const TableViewIcon = (props) => (
  <IconWrapper {...props}>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <line x1="3" y1="9" x2="21" y2="9" />
    <line x1="3" y1="15" x2="21" y2="15" />
    <line x1="9" y1="3" x2="9" y2="21" />
    <line x1="15" y1="3" x2="15" y2="21" />
  </IconWrapper>
);

export const GridViewIcon = (props) => (
  <IconWrapper {...props}>
    <rect x="3" y="3" width="7" height="7" rx="1" />
    <rect x="14" y="3" width="7" height="7" rx="1" />
    <rect x="3" y="14" width="7" height="7" rx="1" />
    <rect x="14" y="14" width="7" height="7" rx="1" />
  </IconWrapper>
);

export const GroupIcon = (props) => (
  <IconWrapper {...props}>
    <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/>
  </IconWrapper>
);

export const JiraIcon = (props) => (
  <IconWrapper {...props}>
    <path d="M11.5 2L3 10.5l8.5 8.5 8.5-8.5L11.5 2zM11.5 6l4.5 4.5-4.5 4.5L7 10.5 11.5 6z"/>
  </IconWrapper>
);
