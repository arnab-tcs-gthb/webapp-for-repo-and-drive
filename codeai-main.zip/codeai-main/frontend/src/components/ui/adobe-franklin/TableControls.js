import React from 'react';
import styled from 'styled-components';
import Button from '../base/Button';

export const IconButton = styled(Button)`
  padding: 8px;
  min-width: auto;
  background: ${props => props.active ? props.theme.colors.primary : 'transparent'};
  color: ${props => props.active ? props.theme.colors.textInverse : props.theme.colors.textSecondary};
  border: 1px solid ${props => props.active ? 'transparent' : props.theme.colors.border};
  
  &:hover {
    background: ${props => props.active ? props.theme.colors.primaryDark : props.theme.colors.borderLight};
  }

  svg {
    width: 16px;
    height: 16px;
  }
`;

export const Tooltip = styled.div`
  position: relative;

  &::before {
    content: attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 5px);
    left: 50%;
    transform: translateX(-50%);
    padding: 5px 10px;
    background: ${props => props.theme.colors.text};
    color: white;
    font-size: 12px;
    border-radius: 4px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.2s;
  }

  &:hover::before {
    opacity: 1;
  }
`;

export const TableViewContainer = styled.div`
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
`;
