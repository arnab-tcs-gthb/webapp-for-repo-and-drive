import styled from 'styled-components';
import { adobeFranklinTheme } from './theme';

// Preview container components
export const PreviewContainer = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  border: 1px solid ${props => props.theme.colors.border};
  margin: 1rem 0;
  overflow: hidden;
  height: 600px;
  display: flex;
  flex-direction: column;
`;

export const PreviewHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1rem;
  background-color: ${props => props.theme.colors.inputBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textSecondary};
`;

export const PreviewFrame = styled.div`
  flex: 1;
  overflow: hidden;
  position: relative;
`;

export const PreviewContent = styled.div`
  flex: 1;
  overflow: auto;
  background-color: ${props => props.theme.colors.inputBackground};
`;

// Website iframe for web preview
export const WebsiteIframe = styled.iframe`
  width: 100%;
  height: 100%;
  border: none;
  background-color: ${props => props.theme.colors.cardBackground};
`;

// Document preview components
export const DocumentPreviewContainer = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  min-height: 500px;
  padding: 1rem;
  box-shadow: 0 0 10px ${props => props.theme.colors.shadowLight} inset;
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  
  /* Styling for docx-preview content */
  .docx-wrapper {
    max-width: 100%;
    margin: 0 auto;
    padding: 0.5rem;
  }
  
  .docx-wrapper .docx-pages {
    box-shadow: 0 0 10px ${props => props.theme.colors.shadow};
  }
  
  .docx-wrapper .docx-page {
    margin-bottom: 20px;
    border: 1px solid ${props => props.theme.colors.border};
    padding: 20px;
    background-color: ${props => props.theme.colors.cardBackground};
    box-shadow: 0 2px 5px ${props => props.theme.colors.shadowLight};
  }
  
  /* Improve heading styles in DOCX preview */
  .docx-wrapper h1, .docx-wrapper h2, .docx-wrapper h3 {
    color: ${props => props.theme.colors.primary};
  }
  
  .docx-wrapper table {
    border-collapse: collapse;
    margin: 1rem 0;
  }
  
  .docx-wrapper table td, .docx-wrapper table th {
    border: 1px solid ${props => props.theme.colors.border};
    padding: 8px;
  }
  
  .docx-wrapper table tr:nth-child(even) {
    background-color: ${props => props.theme.colors.inputBackground};
  }
  
  /* Page number styling */
  .docx-wrapper .docx-page::after {
    content: attr(data-page-number);
    position: absolute;
    bottom: 20px;
    right: 20px;
    font-size: 12px;
    color: ${props => props.theme.colors.textMuted};
  }
`;

export const DocumentPage = styled.div`
  width: 595px;
  min-height: 842px;
  background-color: ${props => props.theme.colors.cardBackground};
  box-shadow: 0 2px 8px ${props => props.theme.colors.shadow};
  padding: 72px 72px;
  margin-bottom: 2rem;
  position: relative;
`;

export const PageNumber = styled.div`
  position: absolute;
  bottom: 36px;
  left: 0;
  right: 0;
  text-align: center;
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textMuted};
`;

// File management components
export const FileCard = styled.div`
  background-color: ${props => props.theme.colors.inputBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  overflow: hidden;
  border: 1px solid ${props => props.theme.colors.border};
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
`;

export const FileImagePreview = styled.div`
  width: 100%;
  height: 120px;
  background-color: ${props => props.theme.colors.cardBackground};
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

export const FileIconPreview = styled.div`
  width: 100%;
  height: 120px;
  background-color: ${props => props.backgroundColor || props.theme.colors.cardBackground};
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: ${props => props.theme.colors.textInverse};
  font-size: 2rem;
`;

export const FileInfo = styled.div`
  padding: 0.75rem;
`;

export const FileName = styled.div`
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize.sm};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: ${props => props.theme.colors.text};
`;

export const FileSize = styled.div`
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textSecondary};
  margin-top: 0.25rem;
`;

// Tab container components
export const TabContainer = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  border: 1px solid ${props => props.theme.colors.border};
  overflow: hidden;
`;

export const TabHeader = styled.div`
  display: flex;
  background-color: ${props => props.theme.colors.inputBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
`;

export const TabButton = styled.button`
  padding: 0.75rem 1rem;
  border: none;
  background: none;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.textSecondary};
  font-weight: ${props => props.active ? props.theme.fontWeight.medium : props.theme.fontWeight.normal};
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    color: ${props => props.theme.colors.primary};
    background-color: ${props => props.theme.colors.borderLight};
  }
  
  &.active {
    border-bottom-color: ${props => props.theme.colors.primary};
  }
`;

export const TabContent = styled.div`
  padding: 1rem;
  background-color: ${props => props.theme.colors.cardBackground};
`;

export const CodeBlock = styled.pre`
  background-color: ${props => props.theme.colors.inputBackground};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${adobeFranklinTheme.borderRadius.medium};
  padding: 1rem;
  overflow-x: auto;
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  font-size: ${props => props.theme.fontSize.sm};
  line-height: 1.4;
  color: ${props => props.theme.colors.text};
  margin: 0;
`;

// Loading and placeholder components
export const LoadingSpinner = styled.div`
  width: 40px;
  height: 40px;
  border: 3px solid ${props => props.theme.colors.borderLight};
  border-top: 3px solid ${props => props.theme.colors.primary};
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;

export const PlaceholderContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  text-align: center;
  color: ${props => props.theme.colors.textMuted};
  min-height: 200px;
`;

export const PlaceholderIcon = styled.div`
  font-size: 2rem;
  margin-bottom: 1rem;
  opacity: 0.6;
`;

export const PlaceholderText = styled.div`
  font-size: ${props => props.theme.fontSize.md};
  margin-bottom: 0.5rem;
`;

export const PlaceholderSubtext = styled.div`
  font-size: ${props => props.theme.fontSize.sm};
  color: ${props => props.theme.colors.textMuted};
`;
