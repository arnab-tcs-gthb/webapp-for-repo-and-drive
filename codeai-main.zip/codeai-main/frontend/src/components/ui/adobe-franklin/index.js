/**
 * Styled Components - Centralized Exports
 * 
 * This file provides a single entry point for all styled components
 * used in the Adobe Franklin Project wizard. Components are organized
 * by functionality and imported from their respective files.
 */

// Import theme for re-exports
import { adobeFranklinTheme } from './theme';

// Import table-specific components and icons
import { IconButton, Tooltip } from './table-controls';
import {
  TableViewIcon,
  GridViewIcon,
  GroupIcon,
  JiraIcon
} from './icons/table-icons';

// Theme configuration
export { adobeFranklinTheme as theme } from './theme';

// Export table controls and icons
export {
  IconButton,
  Tooltip,
  TableViewIcon,
  GridViewIcon,
  GroupIcon,
  JiraIcon
};

// Regular icons
export {
  ArrowLeftIcon,
  CheckIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronUpIcon,
  ClockIcon,
  CloseIcon,
  FileTextIcon,
  FolderIcon,
  InfoIcon,
  LinkIcon,
  MinusIcon,
  PlusIcon,
  SearchIcon,
  ServerIcon,
  SettingsIcon,
  WarningIcon,
  getFileColor,
  getFileIcon
} from './icons';

// Testing components
export {
  Table,
  TableHeader, 
  TableBody,
  StatBox,
  SeverityBadge,
  StatusBadge
} from './testing';

// Layout and container components
export {
  PageContainer,
  MainContent,
  Header,
  PageTitle,
  ContentCard,
  CardTitle,
  MetadataSection,
  MetadataHeader,
  SectionTitle,
  ActionContainer,
  MetadataGrid,
  StatsGrid,
  FileExplorerContainer,
  FileTreeContainer,
  FileTreeHeader,
  FileTreeContent,
  PreviewContentContainer,
  TestingContainer,
  TestingGrid,
  DeploymentContainer,
  DeploymentSteps,
  DeploymentStep,
  EnvironmentContainer,
  UploadedFilesSection,
  FilesHeader,
  FilesTitle,
  FilesGrid,
  PageCardsGrid,
  LoadingContainer,
  WizardContainer,
  ProgressContainer,
  WizardContent,
  StepContent,
  ButtonGroup as ContainerButtonGroup
} from './containers';

// Navigation components
export {
  StepperContainer,
  Step,
  Step as StepperStep,
  StepNumber,
  StepLabel,
  StepTitle,
  StepDescription,
  StepConnector,
  StepSeparator,
  PreviewNavTabs,
  PreviewNavTab,
  TreeFolder,
  TreeFolderHeader,
  TreeFolderIcon,
  TreeFolderName,
  TreeFolderContent,
  TreeFile,
  TreeFileIcon,
  TreeFileName
} from './navigation';

// Form and input components
export {
  Button,
  PrimaryButton,
  SecondaryButton,
  CancelButton,
  BackButton,
  FormGroup,
  FormLabel,
  FormInput,
  FormTextarea,
  FormSelect,
  SearchInput,
  Badge,
  CompleteBadge,
  CompleteIcon,
  FormCheckbox,
  FormRadio,
  FormCheckGroup,
  FormError,
  FormHelp,
  ProgressBar,
  ProgressFill,
  ButtonGroup
} from './forms';

// Preview and file management components
export {
  PreviewContainer,
  PreviewHeader,
  PreviewFrame,
  PreviewContent,
  WebsiteIframe,
  DocumentPreviewContainer,
  DocumentPage,
  PageNumber,
  FileCard,
  FileImagePreview,
  FileIconPreview,
  FileInfo,
  FileName,
  FileSize,
  TabContainer,
  TabHeader,
  TabButton,
  TabContent,
  CodeBlock,
  LoadingSpinner,
  PlaceholderContainer,
  PlaceholderIcon,
  PlaceholderText,
  PlaceholderSubtext
} from './previews';

// Card components
export {
  Card,
  MetadataCard,
  MetadataLabel,
  MetadataValue,
  StatCard,
  StatValue,
  StatLabel,
  PageCard,
  PageCardImagePreview,
  PageCardStatusBadge,
  PageCardInfo,
  PageCardHeader,
  PageCardTitle,
  PageCardPath,
  PageCardConfidence,
  PageCardStats,
  PageCardStat,
  PageCardStatValue,
  PageCardStatLabel,
  PageCardFooter,
  TestingCard,
  TestingCardHeader,
  TestingTitle,
  TestingStatus,
  TestingDescription,
  TestingDetails,
  EnvironmentCard,
  StepContentHeader,
  StepName,
  StepTime,
  StepIcon
} from './cards';

// Re-export theme utilities for easy access
export const {
  colors,
  spacing,
  typography,
  breakpoints,
  transitions,
  shadows,
  borderRadius,
  zIndex
} = adobeFranklinTheme;

// Common styled component utilities
export const commonStyles = {
  // Flexbox utilities
  flexCenter: `
    display: flex;
    align-items: center;
    justify-content: center;
  `,
  flexBetween: `
    display: flex;
    align-items: center;
    justify-content: space-between;
  `,
  flexColumn: `
    display: flex;
    flex-direction: column;
  `,
  
  // Text utilities
  textEllipsis: `
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  `,
  textCenter: `
    text-align: center;
  `,
  
  // Spacing utilities
  marginAuto: `
    margin: 0 auto;
  `,
  
  // Border utilities
  defaultBorder: `
    border: 1px solid ${adobeFranklinTheme.colors.border};
  `,
  roundedBorder: `
    border-radius: ${adobeFranklinTheme.borderRadius.medium};
  `,
  
  // Shadow utilities
  cardShadow: `
    box-shadow: ${adobeFranklinTheme.shadows.card};
  `,
  
  // Responsive utilities
  hideOnMobile: `
    @media (max-width: ${adobeFranklinTheme.breakpoints.tablet}) {
      display: none;
    }
  `,
  hideOnDesktop: `
    @media (min-width: ${adobeFranklinTheme.breakpoints.desktop}) {
      display: none;
    }
  `
};

// Animation keyframes for common animations
export const animations = {
  fadeIn: `
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `,
  slideIn: `
    @keyframes slideIn {
      from { transform: translateX(-100%); }
      to { transform: translateX(0); }
    }
  `,
  spin: `
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
  `,
  pulse: `
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
  `
};
