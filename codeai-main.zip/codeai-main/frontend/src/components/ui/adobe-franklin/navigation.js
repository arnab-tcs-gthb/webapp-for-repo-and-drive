import styled from 'styled-components';

// Navigation stepper components
export const StepperContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 1.5rem 2rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  overflow-x: auto;
  flex-shrink: 0;
`;

export const Step = styled.div.withConfig({
  shouldForwardProp: (prop) => !['active', 'completed', 'clickable'].includes(prop),
})`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 140px;
  text-align: center;
  cursor: ${props => props.clickable ? 'pointer' : 'default'};
`;

export const StepNumber = styled.div.withConfig({
  shouldForwardProp: (prop) => !['active', 'completed'].includes(prop),
})`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
  border: 2px solid ${props => 
    props.active ? props.theme.colors.primary :
    props.completed ? props.theme.colors.success :
    props.theme.colors.borderLight
  };
  background-color: ${props => 
    props.active ? props.theme.colors.primary :
    props.completed ? props.theme.colors.success :
    props.theme.colors.cardBackground
  };
  color: ${props => 
    props.active || props.completed ? props.theme.colors.textInverse :
    props.theme.colors.textSecondary
  };
  transition: all ${props => props.theme.transitions.normal};
`;

export const StepLabel = styled.div.withConfig({
  shouldForwardProp: (prop) => !['active', 'completed'].includes(prop),
})`
  font-size: 0.85rem;
  color: ${props => 
    props.active ? props.theme.colors.primary :
    props.theme.colors.textSecondary
  };
  font-weight: ${props => props.active ? '500' : '400'};
  transition: all ${props => props.theme.transitions.normal};
`;

export const StepConnector = styled.div.withConfig({
  shouldForwardProp: (prop) => !['completed'].includes(prop),
})`
  flex: 1;
  height: 2px;
  margin: 0 1rem;
  margin-bottom: 1.5rem;
  background-color: ${props => 
    props.completed ? props.theme.colors.success : props.theme.colors.borderLight
  };
  transition: background-color ${props => props.theme.transitions.normal};
`;

export const StepDescription = styled.div`
  font-size: 0.875rem;
  color: ${props => props.theme.colors.textSecondary};
  margin-top: 0.25rem;
  line-height: 1.4;
`;

export const StepSeparator = styled.div.withConfig({
  shouldForwardProp: (prop) => !['completed'].includes(prop),
})`
  width: 2px;
  height: 30px;
  background-color: ${props => props.theme.colors.border};
  margin: 0.5rem auto;
  opacity: ${props => props.completed ? 1 : 0.3};
`;

export const StepTitle = styled.h3.withConfig({
  shouldForwardProp: (prop) => !['active', 'completed'].includes(prop),
})`
  font-size: 1.125rem;
  font-weight: 600;
  color: ${props => props.theme.colors.text};
  margin: 0 0 0.5rem 0;
`;

// Preview navigation tabs
export const PreviewNavTabs = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: ${props => props.theme.colors.inputBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  padding: 0 1rem;
`;

export const PreviewNavTab = styled.button`
  background: none;
  border: none;
  padding: 1rem 1.5rem;
  cursor: pointer;
  border-bottom: 2px solid ${props => props.active ? props.theme.colors.primary : 'transparent'};
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.textSecondary};
  font-weight: ${props => props.active ? '500' : '400'};
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    color: ${props => props.theme.colors.primary};
  }
`;

// File tree navigation components
export const TreeFolder = styled.div`
  margin-bottom: 0.25rem;
`;

export const TreeFolderHeader = styled.div`
  display: flex;
  align-items: center;
  padding: 0.5rem;
  cursor: pointer;
  border-radius: 4px;
  transition: background-color ${props => props.theme.transitions.fast};
  
  &:hover {
    background-color: ${props => props.theme.colors.borderLight};
  }
`;

export const TreeFolderIcon = styled.div`
  margin-right: 0.5rem;
  color: ${props => props.theme.colors.textSecondary};
  display: flex;
  align-items: center;
`;

export const TreeFolderName = styled.div`
  font-size: 0.9rem;
  color: ${props => props.theme.colors.text};
  font-weight: 500;
`;

export const TreeFolderContent = styled.div`
  margin-left: 1rem;
  border-left: 1px solid ${props => props.theme.colors.borderLight};
  padding-left: 0.5rem;
`;

export const TreeFile = styled.div`
  display: flex;
  align-items: center;
  padding: 0.5rem;
  cursor: pointer;
  border-radius: 4px;
  margin-bottom: 0.25rem;
  background-color: ${props => props.active ? props.theme.colors.primaryLight : 'transparent'};
  color: ${props => props.active ? props.theme.colors.textInverse : props.theme.colors.text};
  transition: all ${props => props.theme.transitions.fast};
  
  &:hover {
    background-color: ${props => 
      props.active ? props.theme.colors.primaryLight : props.theme.colors.borderLight
    };
  }
`;

export const TreeFileIcon = styled.div`
  margin-right: 0.5rem;
  color: ${props => props.active ? props.theme.colors.textInverse : props.theme.colors.textSecondary};
  display: flex;
  align-items: center;
`;

export const TreeFileName = styled.div`
  font-size: 0.85rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
`;
