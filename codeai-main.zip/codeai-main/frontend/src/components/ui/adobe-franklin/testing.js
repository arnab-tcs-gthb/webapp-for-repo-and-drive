import styled from 'styled-components';
import { adobeFranklinTheme } from './theme';

// Table components
export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: 8px;
  overflow: hidden;
`;

export const TableHeader = styled.thead`
  background: ${props => props.theme.colors.cardBackground};
  th {
    padding: 12px 15px;
    text-align: left;
    font-weight: 600;
    font-size: 14px;    
    color: ${props => props.theme.colors.text};
    border-bottom: 2px solid ${props => props.theme.colors.border};
    transition: background-color 0.2s, color 0.2s;
  }
`;

export const TableBody = styled.tbody`
  tr {
    &:hover {
      background-color: ${props => props.theme.colors.surfaceHover};
    }
    td {
      padding: 12px 15px;
      border-bottom: 1px solid ${props => props.theme.colors.border};
      font-size: 14px;
      color: ${props => props.theme.colors.text};
      transition: background-color 0.2s, color 0.2s;
    }
  }
`;

// Statistics box component
export const StatBox = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border: 1px solid ${props => props.theme.colors.border};
  color: ${props => props.theme.colors.text};
  padding: 15px 25px;
  border-radius: 8px;
  transition: background-color 0.2s, border-color 0.2s, color 0.2s;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  text-align: center;
  min-width: 100px;

  span {
    display: block;
    font-size: 24px;
    font-weight: bold;
    color: #495057;
    margin-bottom: 5px;
  }

  label {
    font-size: 14px;
    color: #6c757d;
  }
`;

// Badge components
export const SeverityBadge = styled.span`
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  background-color: ${props => {
    switch (props.severity?.toLowerCase()) {
      case 'high':
        return '#ffebed';
      case 'medium':
        return '#fff4e5';
      case 'low':
        return '#e8f5e9';
      default:
        return '#f8f9fa';
    }
  }};
  color: ${props => {
    switch (props.severity?.toLowerCase()) {
      case 'high':
        return '#d32f2f';
      case 'medium':
        return '#ed6c02';
      case 'low':
        return '#2e7d32';
      default:
        return '#212529';
    }
  }};
`;

export const StatusBadge = styled.span`
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  background-color: ${props => {
    switch (props.status?.toLowerCase()) {
      case 'passed':
        return '#e8f5e9';
      case 'failed':
        return '#ffebed';
      case 'blocked':
        return '#fff4e5';
      case 'in progress':
        return '#e3f2fd';
      default:
        return '#f8f9fa';
    }
  }};
  color: ${props => {
    switch (props.status?.toLowerCase()) {
      case 'passed':
        return '#2e7d32';
      case 'failed':
        return '#d32f2f';
      case 'blocked':
        return '#ed6c02';
      case 'in progress':
        return '#1976d2';
      default:
        return '#212529';
    }
  }};
`;
