import React from 'react';
import styled from 'styled-components';
import { Button } from '../forms/Button';

const IconButtonWrapper = styled(Button)`
  padding: 8px;
  min-width: auto;
  background: ${props => props.active ? props.theme.colors.primary : 'transparent'};
  color: ${props => props.active ? 'white' : props.theme.colors.text};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.sm};

  &:hover {
    background: ${props => props.active ? props.theme.colors.primaryDark : props.theme.colors.backgroundAlt};
  }

  svg {
    width: 20px;
    height: 20px;
  }
`;

const TooltipWrapper = styled.div`
  position: relative;

  &:hover::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 8px;
    background: ${props => props.theme.colors.tooltipBackground || '#333'};
    color: ${props => props.theme.colors.tooltipText || '#fff'};
    font-size: 12px;
    border-radius: 4px;
    white-space: nowrap;
    z-index: 1000;
  }
`;

export const IconButton = ({ children, ...props }) => (
  <IconButtonWrapper {...props}>
    {children}
  </IconButtonWrapper>
);

export const Tooltip = ({ children, content, ...props }) => (
  <TooltipWrapper data-tooltip={content} {...props}>
    {children}
  </TooltipWrapper>
);
