import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { createPortal } from 'react-dom';
import { useTheme } from '../../../context/ThemeContext';
import Button from './Button';

const Modal = ({
  isOpen = false,
  onClose = () => {},
  title = '',
  size = 'md',
  closeOnOverlay = true,
  closeOnEscape = true,
  showCloseButton = true,
  className = '',
  style = {},
  children,
  ...props
}) => {
  const { theme } = useTheme();
  const modalRef = useRef(null);
  const overlayRef = useRef(null);
  const previousFocusRef = useRef(null);

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e) => {
      if (closeOnEscape && e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }
  }, [isOpen, closeOnEscape, onClose]);

  // Handle focus management
  useEffect(() => {
    if (isOpen) {
      // Store the currently focused element
      previousFocusRef.current = document.activeElement;
      
      // Focus the modal
      if (modalRef.current) {
        modalRef.current.focus();
      }
      
      // Prevent body scroll
      document.body.style.overflow = 'hidden';
    } else {
      // Restore focus to the previously focused element
      if (previousFocusRef.current) {
        previousFocusRef.current.focus();
      }
      
      // Restore body scroll
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Handle overlay click
  const handleOverlayClick = (e) => {
    if (closeOnOverlay && e.target === overlayRef.current) {
      onClose();
    }
  };

  // Trap focus within modal
  const handleKeyDown = (e) => {
    if (e.key === 'Tab') {
      const focusableElements = modalRef.current?.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      
      if (focusableElements?.length) {
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        if (e.shiftKey && document.activeElement === firstElement) {
          e.preventDefault();
          lastElement.focus();
        } else if (!e.shiftKey && document.activeElement === lastElement) {
          e.preventDefault();
          firstElement.focus();
        }
      }
    }
  };

  if (!isOpen) return null;

  // Size variants
  const sizeStyles = {
    xs: {
      maxWidth: '320px',
      width: '90vw'
    },
    sm: {
      maxWidth: '480px',
      width: '90vw'
    },
    md: {
      maxWidth: '640px',
      width: '90vw'
    },
    lg: {
      maxWidth: '768px',
      width: '90vw'
    },
    xl: {
      maxWidth: '1024px',
      width: '90vw'
    },
    full: {
      width: '95vw',
      height: '95vh',
      maxWidth: 'none'
    }
  };

  // Overlay styles
  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    padding: 'var(--spacing-md, 16px)',
    backdropFilter: 'blur(4px)'
  };

  // Modal styles
  const modalStyle = {
    backgroundColor: theme.colors.surface || '#ffffff',
    borderRadius: theme.borderRadius?.lg || '12px',
    boxShadow: theme.shadows?.xl || '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
    border: `1px solid ${theme.colors.border || '#e5e7eb'}`,
    maxHeight: size === 'full' ? '95vh' : '90vh',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    ...sizeStyles[size],
    ...style
  };

  // Header styles
  const headerStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 'var(--spacing-lg, 20px)',
    borderBottom: `1px solid ${theme.colors.border || '#e5e7eb'}`,
    backgroundColor: theme.colors.surfaceVariant || theme.colors.surface || '#f9fafb'
  };

  // Title styles
  const titleStyle = {
    fontSize: '1.25rem',
    fontWeight: '600',
    color: theme.colors.text || '#111827',
    margin: 0
  };

  // Content styles
  const contentStyle = {
    flex: 1,
    overflow: 'auto',
    padding: 'var(--spacing-lg, 20px)'
  };

  const modalContent = (
    <div
      ref={overlayRef}
      style={overlayStyle}
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? 'modal-title' : undefined}
    >
      <div
        {...props}
        ref={modalRef}
        style={modalStyle}
        className={className}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        {(title || showCloseButton) && (
          <div style={headerStyle}>
            {title && (
              <h2 id="modal-title" style={titleStyle}>
                {title}
              </h2>
            )}
            {showCloseButton && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                aria-label="Close modal"
                style={{
                  marginLeft: 'auto',
                  padding: 'var(--spacing-xs, 8px)'
                }}
              >
                ✕
              </Button>
            )}
          </div>
        )}
        
        <div style={contentStyle}>
          {children}
        </div>
      </div>
    </div>
  );

  // Render modal in portal
  return createPortal(modalContent, document.body);
};

// Compound components for better structure
const ModalHeader = ({ children, className = '', style = {} }) => {
  const { theme } = useTheme();
  
  const headerStyle = {
    padding: 'var(--spacing-lg, 20px)',
    borderBottom: `1px solid ${theme.colors.border || '#e5e7eb'}`,
    backgroundColor: theme.colors.surfaceVariant || theme.colors.surface || '#f9fafb',
    ...style
  };

  return (
    <div style={headerStyle} className={className}>
      {children}
    </div>
  );
};

const ModalTitle = ({ children, className = '', style = {} }) => {
  const { theme } = useTheme();
  
  const titleStyle = {
    fontSize: '1.25rem',
    fontWeight: '600',
    color: theme.colors.text || '#111827',
    margin: 0,
    ...style
  };

  return (
    <h2 style={titleStyle} className={className}>
      {children}
    </h2>
  );
};

const ModalContent = ({ children, className = '', style = {} }) => {
  const contentStyle = {
    flex: 1,
    overflow: 'auto',
    padding: 'var(--spacing-lg, 20px)',
    ...style
  };

  return (
    <div style={contentStyle} className={className}>
      {children}
    </div>
  );
};

const ModalFooter = ({ children, className = '', style = {} }) => {
  const { theme } = useTheme();
  
  const footerStyle = {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: 'var(--spacing-sm, 12px)',
    padding: 'var(--spacing-lg, 20px)',
    borderTop: `1px solid ${theme.colors.border || '#e5e7eb'}`,
    backgroundColor: theme.colors.surfaceVariant || theme.colors.surface || '#f9fafb',
    ...style
  };

  return (
    <div style={footerStyle} className={className}>
      {children}
    </div>
  );
};

// Attach sub-components
Modal.Header = ModalHeader;
Modal.Title = ModalTitle;
Modal.Content = ModalContent;
Modal.Footer = ModalFooter;

// PropTypes for main Modal component
Modal.propTypes = {
  /** Whether modal is open */
  isOpen: PropTypes.bool.isRequired,
  /** Function called when modal should close */
  onClose: PropTypes.func.isRequired,
  /** Modal title */
  title: PropTypes.string,
  /** Modal size */
  size: PropTypes.oneOf(['sm', 'md', 'lg', 'xl', 'full']),
  /** Whether clicking overlay closes modal */
  closeOnOverlay: PropTypes.bool,
  /** Whether escape key closes modal */
  closeOnEscape: PropTypes.bool,
  /** Whether to show close button */
  showCloseButton: PropTypes.bool,
  /** Modal content */
  children: PropTypes.node,
  /** Additional CSS class name */
  className: PropTypes.string,
  /** Inline styles */
  style: PropTypes.object
};

Modal.defaultProps = {
  title: '',
  size: 'md',
  closeOnOverlay: true,
  closeOnEscape: true,
  showCloseButton: true,
  className: '',
  style: {}
};

// PropTypes for sub-components
Modal.Header.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  style: PropTypes.object
};

Modal.Title.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  style: PropTypes.object
};

Modal.Content.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  style: PropTypes.object
};

Modal.Footer.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  style: PropTypes.object
};

export default Modal;
