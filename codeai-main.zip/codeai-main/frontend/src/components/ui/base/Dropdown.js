import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../context/ThemeContext';
import Button from './Button';

const Dropdown = ({
  trigger,
  children,
  placement = 'bottom-start',
  disabled = false,
  closeOnSelect = true,
  className = '',
  style = {},
  onOpen = () => {},
  onClose = () => {},
  ...props
}) => {
  const { theme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const triggerRef = useRef(null);
  const menuRef = useRef(null);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen, onClose]);

  // Handle escape key
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
        onClose();
        triggerRef.current?.focus();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }
  }, [isOpen, onClose]);

  // Handle arrow keys navigation
  const handleKeyDown = (event) => {
    if (!isOpen) return;

    const menuItems = menuRef.current?.querySelectorAll('[role="menuitem"]');
    if (!menuItems?.length) return;

    const currentIndex = Array.from(menuItems).findIndex(item => 
      item === document.activeElement
    );

    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        const nextIndex = currentIndex < menuItems.length - 1 ? currentIndex + 1 : 0;
        menuItems[nextIndex].focus();
        break;
      case 'ArrowUp':
        event.preventDefault();
        const prevIndex = currentIndex > 0 ? currentIndex - 1 : menuItems.length - 1;
        menuItems[prevIndex].focus();
        break;
      case 'Home':
        event.preventDefault();
        menuItems[0].focus();
        break;
      case 'End':
        event.preventDefault();
        menuItems[menuItems.length - 1].focus();
        break;
    }
  };

  const toggleDropdown = () => {
    if (disabled) return;
    
    const newState = !isOpen;
    setIsOpen(newState);
    
    if (newState) {
      onOpen();
      // Focus first menu item after a short delay
      setTimeout(() => {
        const firstMenuItem = menuRef.current?.querySelector('[role="menuitem"]');
        firstMenuItem?.focus();
      }, 0);
    } else {
      onClose();
    }
  };

  // Get placement styles
  const getPlacementStyles = () => {
    const baseStyles = {
      position: 'absolute',
      zIndex: 1000,
      minWidth: '160px'
    };

    switch (placement) {
      case 'top-start':
        return { ...baseStyles, bottom: '100%', left: 0, marginBottom: '4px' };
      case 'top-end':
        return { ...baseStyles, bottom: '100%', right: 0, marginBottom: '4px' };
      case 'bottom-start':
        return { ...baseStyles, top: '100%', left: 0, marginTop: '4px' };
      case 'bottom-end':
        return { ...baseStyles, top: '100%', right: 0, marginTop: '4px' };
      case 'left':
        return { ...baseStyles, right: '100%', top: 0, marginRight: '4px' };
      case 'right':
        return { ...baseStyles, left: '100%', top: 0, marginLeft: '4px' };
      default:
        return { ...baseStyles, top: '100%', left: 0, marginTop: '4px' };
    }
  };

  // Container styles
  const containerStyle = {
    position: 'relative',
    display: 'inline-block',
    ...style
  };

  // Menu styles
  const menuStyle = {
    ...getPlacementStyles(),
    backgroundColor: theme.colors.surface || '#ffffff',
    border: `1px solid ${theme.colors.border || '#e5e7eb'}`,
    borderRadius: theme.borderRadius?.md || '8px',
    boxShadow: theme.shadows?.lg || '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
    padding: 'var(--spacing-xs, 8px)',
    maxHeight: '300px',
    overflowY: 'auto'
  };

  return (
    <div
      {...props}
      ref={dropdownRef}
      style={containerStyle}
      className={className}
      onKeyDown={handleKeyDown}
    >
      {/* Trigger */}
      <div
        ref={triggerRef}
        onClick={toggleDropdown}
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-expanded={isOpen}
        aria-haspopup="menu"
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            toggleDropdown();
          }
        }}
        style={{ 
          cursor: disabled ? 'not-allowed' : 'pointer',
          opacity: disabled ? 0.6 : 1
        }}
      >
        {trigger}
      </div>

      {/* Menu */}
      {isOpen && (
        <div
          ref={menuRef}
          role="menu"
          style={menuStyle}
          aria-orientation="vertical"
        >
          {React.Children.map(children, (child, index) => {
            if (React.isValidElement(child)) {
              return React.cloneElement(child, {
                key: index,
                onClick: (...args) => {
                  child.props.onClick?.(...args);
                  if (closeOnSelect) {
                    setIsOpen(false);
                    onClose();
                  }
                }
              });
            }
            return child;
          })}
        </div>
      )}
    </div>
  );
};

// Dropdown Item component
const DropdownItem = ({
  children,
  onClick = () => {},
  disabled = false,
  variant = 'default',
  className = '',
  style = {},
  ...props
}) => {
  const { theme } = useTheme();

  const itemStyle = {
    display: 'flex',
    alignItems: 'center',
    width: '100%',
    padding: 'var(--spacing-sm, 12px) var(--spacing-md, 16px)',
    margin: 0,
    border: 'none',
    borderRadius: theme.borderRadius?.sm || '6px',
    backgroundColor: 'transparent',
    color: disabled ? 
      (theme.colors.textDisabled || theme.colors.textSecondary || '#9ca3af') : 
      variant === 'danger' ? 
        (theme.colors.error || '#ef4444') : 
        (theme.colors.text || '#111827'),
    fontSize: '0.875rem',
    lineHeight: '1.25rem',
    textAlign: 'left',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.6 : 1,
    transition: 'all 0.2s ease-in-out',
    outline: 'none',
    ':hover': {
      backgroundColor: disabled ? 'transparent' : (theme.colors.surfaceHover || theme.colors.surfaceVariant || '#f3f4f6')
    },
    ':focus': {
      backgroundColor: theme.colors.surfaceHover || theme.colors.surfaceVariant || '#f3f4f6',
      outline: `2px solid ${theme.colors.primary || '#3b82f6'}`,
      outlineOffset: '-2px'
    },
    ...style
  };

  const handleClick = (e) => {
    if (!disabled) {
      onClick(e);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleClick(e);
    }
  };

  return (
    <button
      {...props}
      role="menuitem"
      tabIndex={-1}
      style={itemStyle}
      className={className}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      disabled={disabled}
      onMouseEnter={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = theme.colors.surfaceHover || theme.colors.surfaceVariant || '#f3f4f6';
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = 'transparent';
        }
      }}
      onFocus={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = theme.colors.surfaceHover || theme.colors.surfaceVariant || '#f3f4f6';
          e.target.style.outline = `2px solid ${theme.colors.primary || '#3b82f6'}`;
          e.target.style.outlineOffset = '-2px';
        }
      }}
      onBlur={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = 'transparent';
          e.target.style.outline = 'none';
        }
      }}
    >
      {children}
    </button>
  );
};

// Dropdown Divider component
const DropdownDivider = ({ className = '', style = {} }) => {
  const { theme } = useTheme();

  const dividerStyle = {
    height: '1px',
    backgroundColor: theme.colors.border || '#e5e7eb',
    margin: 'var(--spacing-xs, 8px) 0',
    ...style
  };

  return <div role="separator" style={dividerStyle} className={className} />;
};

// Dropdown Label component
const DropdownLabel = ({ children, className = '', style = {} }) => {
  const { theme } = useTheme();

  const labelStyle = {
    padding: 'var(--spacing-xs, 8px) var(--spacing-md, 16px)',
    fontSize: '0.75rem',
    fontWeight: '600',
    color: theme.colors.textSecondary || '#6b7280',
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    ...style
  };

  return (
    <div role="presentation" style={labelStyle} className={className}>
      {children}
    </div>
  );
};

// Attach sub-components
Dropdown.Item = DropdownItem;
Dropdown.Divider = DropdownDivider;
Dropdown.Label = DropdownLabel;

// PropTypes for main Dropdown component
Dropdown.propTypes = {
  /** Trigger element that opens the dropdown */
  trigger: PropTypes.node.isRequired,
  /** Dropdown content */
  children: PropTypes.node.isRequired,
  /** Dropdown placement relative to trigger */
  placement: PropTypes.oneOf([
    'top-start', 'top', 'top-end',
    'bottom-start', 'bottom', 'bottom-end',
    'left-start', 'left', 'left-end',
    'right-start', 'right', 'right-end'
  ]),
  /** Whether dropdown is disabled */
  disabled: PropTypes.bool,
  /** Whether to close dropdown when item is selected */
  closeOnSelect: PropTypes.bool,
  /** Function called when dropdown opens */
  onOpen: PropTypes.func,
  /** Function called when dropdown closes */
  onClose: PropTypes.func,
  /** Additional CSS class name */
  className: PropTypes.string,
  /** Inline styles */
  style: PropTypes.object
};

Dropdown.defaultProps = {
  placement: 'bottom-start',
  disabled: false,
  closeOnSelect: true,
  onOpen: () => {},
  onClose: () => {},
  className: '',
  style: {}
};

// PropTypes for sub-components
Dropdown.Item.propTypes = {
  children: PropTypes.node.isRequired,
  onClick: PropTypes.func,
  disabled: PropTypes.bool,
  destructive: PropTypes.bool,
  className: PropTypes.string,
  style: PropTypes.object
};

Dropdown.Divider.propTypes = {
  className: PropTypes.string,
  style: PropTypes.object
};

Dropdown.Label.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  style: PropTypes.object
};

export default Dropdown;
