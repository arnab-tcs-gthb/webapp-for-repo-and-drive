import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components';
import { useTheme } from '../../../context/ThemeContext';

// Card elevation levels
const cardElevations = {
  none: {
    boxShadow: 'none'
  },
  sm: {
    boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)'
  },
  md: {
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
  },
  lg: {
    boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
  },
  xl: {
    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
  }
};

// Card size configurations
const cardSizes = {
  sm: {
    padding: '1rem',
    borderRadius: '6px'
  },
  md: {
    padding: '1.5rem',
    borderRadius: '8px'
  },
  lg: {
    padding: '2rem',
    borderRadius: '10px'
  },
  xl: {
    padding: '2.5rem',
    borderRadius: '12px'
  }
};

const StyledCard = styled.div`
  display: flex;
  flex-direction: column;
  background-color: ${({ theme }) => theme.colors.cardBackground};
  border: 1px solid ${({ theme }) => theme.colors.cardBorder};
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
  width: 100%;
  
  /* Size styles */
  ${({ $size }) => {
    const size = cardSizes[$size] || cardSizes.md;
    return css`
      padding: ${size.padding};
      border-radius: ${size.borderRadius};
    `;
  }}
  
  /* Elevation styles */
  ${({ $elevation, theme }) => {
    const elevation = cardElevations[$elevation] || cardElevations.sm;
    const shadowColor = theme.name === 'dark' ? 'rgba(0, 0, 0, 0.3)' : 'rgba(0, 0, 0, 0.1)';
    return css`
      box-shadow: ${elevation.boxShadow.replace(/rgba\(0, 0, 0, [\d.]+\)/g, shadowColor)};
    `;
  }}
  
  /* Hoverable state */
  ${({ $hoverable, theme }) => $hoverable && css`
    cursor: pointer;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 15px -3px ${theme.name === 'dark' ? 'rgba(0, 0, 0, 0.4)' : 'rgba(0, 0, 0, 0.15)'}, 
                  0 4px 6px -2px ${theme.name === 'dark' ? 'rgba(0, 0, 0, 0.2)' : 'rgba(0, 0, 0, 0.08)'};
      border-color: ${theme.colors.primary};
    }
    
    &:focus-visible {
      outline: 2px solid ${theme.colors.primary};
      outline-offset: 2px;
    }
  `}
  
  /* Clickable state */
  ${({ $clickable }) => $clickable && css`
    cursor: pointer;
    
    &:active {
      transform: translateY(0);
    }
  `}
  
  /* Full width */
  ${({ $fullWidth }) => $fullWidth && css`
    width: 100%;
  `}
  
  /* Reduced motion support */
  @media (prefers-reduced-motion: reduce) {
    transition: none;
    
    &:hover {
      transform: none;
    }
    
    &:active {
      transform: none;
    }
  }
  
  /* High contrast mode support */
  @media (prefers-contrast: high) {
    border-width: 2px;
  }
  
  /* Mobile responsive padding */
  @media (max-width: 768px) {
    padding: ${({ $size }) => 
      $size === 'sm' ? '0.75rem' : 
      $size === 'lg' ? '1.5rem' : 
      $size === 'xl' ? '2rem' : 
      '1.25rem'
    };
  }
`;

const CardHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${({ $hasContent }) => $hasContent ? '1rem' : '0'};
  
  @media (max-width: 768px) {
    flex-direction: ${({ $stackOnMobile }) => $stackOnMobile ? 'column' : 'row'};
    align-items: ${({ $stackOnMobile }) => $stackOnMobile ? 'flex-start' : 'center'};
    gap: ${({ $stackOnMobile }) => $stackOnMobile ? '0.5rem' : '0'};
  }
`;

const CardTitle = styled.h3`
  margin: 0;
  color: ${({ theme }) => theme.colors.text};
  font-size: 1.125rem;
  font-weight: 600;
  line-height: 1.5;
  
  @media (max-width: 768px) {
    font-size: 1rem;
  }
`;

const CardSubtitle = styled.p`
  margin: 0.25rem 0 0 0;
  color: ${({ theme }) => theme.colors.textSecondary};
  font-size: 0.875rem;
  line-height: 1.4;
  
  @media (max-width: 768px) {
    font-size: 0.8125rem;
  }
`;

const CardContent = styled.div`
  flex: 1;
  color: ${({ theme }) => theme.colors.text};
  line-height: 1.6;
  
  /* Ensure proper spacing for nested elements */
  > *:first-child {
    margin-top: 0;
  }
  
  > *:last-child {
    margin-bottom: 0;
  }
`;

const CardFooter = styled.div`
  display: flex;
  align-items: center;
  justify-content: ${({ $justify }) => $justify || 'flex-end'};
  gap: 0.75rem;
  margin-top: ${({ $hasContent }) => $hasContent ? '1.5rem' : '0'};
  padding-top: ${({ $divider }) => $divider ? '1rem' : '0'};
  border-top: ${({ $divider, theme }) => $divider ? `1px solid ${theme.colors.border}` : 'none'};
  
  @media (max-width: 768px) {
    flex-direction: ${({ $stackOnMobile }) => $stackOnMobile ? 'column' : 'row'};
    align-items: ${({ $stackOnMobile }) => $stackOnMobile ? 'stretch' : 'center'};
    gap: ${({ $stackOnMobile }) => $stackOnMobile ? '0.5rem' : '0.75rem'};
  }
`;

/**
 * Card Component
 * 
 * A flexible, accessible card component for displaying content in a contained layout.
 * Supports various sizes, elevations, and interactive states.
 * 
 * @param {string} size - Card size: 'sm' | 'md' | 'lg' | 'xl'
 * @param {string} elevation - Shadow depth: 'none' | 'sm' | 'md' | 'lg' | 'xl'
 * @param {boolean} hoverable - Adds hover effects and focus states
 * @param {boolean} clickable - Makes the entire card clickable
 * @param {boolean} fullWidth - Makes card take full width of container
 * @param {ReactNode} children - Card content
 * @param {function} onClick - Click handler when clickable is true
 * @param {string} role - ARIA role for accessibility
 * @param {string} ariaLabel - Accessible label for screen readers
 * @param {object} ...props - Additional props passed to card element
 */
export const Card = forwardRef(({
  size = 'md',
  elevation = 'sm',
  hoverable = false,
  clickable = false,
  fullWidth = false,
  children,
  onClick,
  role,
  ariaLabel,
  ...props
}, ref) => {
  const { theme } = useTheme();
  
  const handleClick = (event) => {
    if (clickable && onClick) {
      onClick(event);
    }
  };
  
  const handleKeyDown = (event) => {
    if (clickable && onClick && (event.key === 'Enter' || event.key === ' ')) {
      event.preventDefault();
      onClick(event);
    }
  };
  
  return (
    <StyledCard
      ref={ref}
      theme={theme}
      $size={size}
      $elevation={elevation}
      $hoverable={hoverable || clickable}
      $clickable={clickable}
      $fullWidth={fullWidth}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      role={clickable ? 'button' : role}
      tabIndex={clickable ? 0 : undefined}
      aria-label={ariaLabel}
      {...props}
    >
      {children}
    </StyledCard>
  );
});

/**
 * CardHeader Component
 * 
 * Header section for Card component, typically containing title and actions.
 */
Card.Header = forwardRef(({ 
  children, 
  stackOnMobile = false,
  ...props 
}, ref) => {
  const { theme } = useTheme();
  const hasContent = React.Children.count(children) > 0;
  
  return (
    <CardHeader 
      ref={ref}
      theme={theme}
      $hasContent={hasContent}
      $stackOnMobile={stackOnMobile}
      {...props}
    >
      {children}
    </CardHeader>
  );
});

/**
 * CardTitle Component
 * 
 * Title heading for Card component.
 */
Card.Title = forwardRef(({ children, ...props }, ref) => {
  const { theme } = useTheme();
  
  return (
    <CardTitle ref={ref} theme={theme} {...props}>
      {children}
    </CardTitle>
  );
});

/**
 * CardSubtitle Component
 * 
 * Subtitle text for Card component.
 */
Card.Subtitle = forwardRef(({ children, ...props }, ref) => {
  const { theme } = useTheme();
  
  return (
    <CardSubtitle ref={ref} theme={theme} {...props}>
      {children}
    </CardSubtitle>
  );
});

/**
 * CardContent Component
 * 
 * Main content area of Card component.
 */
Card.Content = forwardRef(({ children, ...props }, ref) => {
  const { theme } = useTheme();
  
  return (
    <CardContent ref={ref} theme={theme} {...props}>
      {children}
    </CardContent>
  );
});

/**
 * CardFooter Component
 * 
 * Footer section for Card component, typically containing actions.
 */
Card.Footer = forwardRef(({ 
  children, 
  justify = 'flex-end',
  divider = false,
  stackOnMobile = false,
  ...props 
}, ref) => {
  const { theme } = useTheme();
  const hasContent = React.Children.count(children) > 0;
  
  return (
    <CardFooter 
      ref={ref}
      theme={theme}
      $hasContent={hasContent}
      $justify={justify}
      $divider={divider}
      $stackOnMobile={stackOnMobile}
      {...props}
    >
      {children}
    </CardFooter>
  );
});

// Set display names for debugging
Card.displayName = 'Card';
Card.Header.displayName = 'Card.Header';
Card.Title.displayName = 'Card.Title';
Card.Subtitle.displayName = 'Card.Subtitle';
Card.Content.displayName = 'Card.Content';
Card.Footer.displayName = 'Card.Footer';

// PropTypes for main Card component
Card.propTypes = {
  /** Card content */
  children: PropTypes.node,
  /** Card size variant */
  size: PropTypes.oneOf(['sm', 'md', 'lg', 'xl']),
  /** Shadow elevation level */
  elevation: PropTypes.oneOf(['none', 'sm', 'md', 'lg', 'xl']),
  /** Whether card is interactive (hover effects) */
  interactive: PropTypes.bool,
  /** Whether card can be selected */
  selectable: PropTypes.bool,
  /** Whether card is currently selected */
  selected: PropTypes.bool,
  /** Click handler for interactive cards */
  onClick: PropTypes.func,
  /** Additional CSS class name */
  className: PropTypes.string
};

Card.defaultProps = {
  size: 'md',
  elevation: 'sm',
  interactive: false,
  selectable: false,
  selected: false,
  onClick: undefined,
  className: ''
};

// PropTypes for Card sub-components
Card.Header.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string
};

Card.Title.propTypes = {
  children: PropTypes.node,
  as: PropTypes.string,
  className: PropTypes.string
};

Card.Subtitle.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string
};

Card.Content.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string
};

Card.Footer.propTypes = {
  children: PropTypes.node,
  /** Justify content alignment */
  justify: PropTypes.oneOf(['flex-start', 'center', 'flex-end', 'space-between', 'space-around']),
  /** Whether to show top divider */
  divider: PropTypes.bool,
  /** Whether to stack buttons on mobile */
  stackOnMobile: PropTypes.bool,
  className: PropTypes.string
};

Card.Footer.defaultProps = {
  justify: 'flex-end',
  divider: false,
  stackOnMobile: false,
  className: ''
};

export default Card;