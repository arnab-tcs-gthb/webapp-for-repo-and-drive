import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components';
import { useTheme } from '../../../context/ThemeContext';

// Button size configurations
const buttonSizes = {
  xs: {
    padding: '0.375rem 0.75rem',
    fontSize: '0.75rem',
    minHeight: '32px',
    borderRadius: '4px'
  },
  sm: {
    padding: '0.5rem 1rem',
    fontSize: '0.875rem',
    minHeight: '36px',
    borderRadius: '6px'
  },
  md: {
    padding: '0.75rem 1.5rem',
    fontSize: '0.875rem',
    minHeight: '44px',
    borderRadius: '8px'
  },
  lg: {
    padding: '1rem 2rem',
    fontSize: '1rem',
    minHeight: '48px',
    borderRadius: '8px'
  },
  xl: {
    padding: '1.25rem 2.5rem',
    fontSize: '1.125rem',
    minHeight: '56px',
    borderRadius: '10px'
  }
};

// Button variant styles
const getButtonVariantStyles = (variant, theme) => {
  const { colors } = theme;
  
  switch (variant) {
    case 'primary':
      return css`
        background-color: ${colors.primary};
        color: white;
        border: 1px solid ${colors.primary};
        
        &:hover:not(:disabled) {
          background-color: ${colors.primaryHover};
          border-color: ${colors.primaryHover};
          transform: translateY(-1px);
          box-shadow: 0 4px 12px ${colors.primaryShadow};
        }
        
        &:active:not(:disabled) {
          transform: translateY(0);
          box-shadow: 0 2px 4px ${colors.primaryShadow};
        }
        
        &:focus-visible {
          box-shadow: 0 0 0 3px ${colors.primarySoft};
        }
      `;
      
    case 'secondary':
      return css`
        background-color: ${colors.surface};
        color: ${colors.text};
        border: 1px solid ${colors.border};
        
        &:hover:not(:disabled) {
          background-color: ${colors.surfaceHover};
          border-color: ${colors.primary};
          transform: translateY(-1px);
          box-shadow: 0 4px 12px ${colors.shadow};
        }
        
        &:active:not(:disabled) {
          transform: translateY(0);
          box-shadow: 0 2px 4px ${colors.shadow};
        }
        
        &:focus-visible {
          box-shadow: 0 0 0 3px ${colors.primarySoft};
        }
      `;
      
    case 'outline':
      return css`
        background-color: transparent;
        color: ${colors.primary};
        border: 1px solid ${colors.primary};
        
        &:hover:not(:disabled) {
          background-color: ${colors.primarySoft};
          transform: translateY(-1px);
          box-shadow: 0 4px 12px ${colors.primaryShadow};
        }
        
        &:active:not(:disabled) {
          transform: translateY(0);
          box-shadow: 0 2px 4px ${colors.primaryShadow};
        }
        
        &:focus-visible {
          box-shadow: 0 0 0 3px ${colors.primarySoft};
        }
      `;
      
    case 'ghost':
      return css`
        background-color: transparent;
        color: ${colors.text};
        border: 1px solid transparent;
        
        &:hover:not(:disabled) {
          background-color: ${colors.surfaceHover};
          color: ${colors.primary};
          transform: translateY(-1px);
        }
        
        &:active:not(:disabled) {
          transform: translateY(0);
        }
        
        &:focus-visible {
          box-shadow: 0 0 0 3px ${colors.primarySoft};
        }
      `;
      
    case 'danger':
      return css`
        background-color: ${colors.error};
        color: white;
        border: 1px solid ${colors.error};
        
        &:hover:not(:disabled) {
          background-color: #c5392a;
          border-color: #c5392a;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(234, 67, 53, 0.3);
        }
        
        &:active:not(:disabled) {
          transform: translateY(0);
          box-shadow: 0 2px 4px rgba(234, 67, 53, 0.3);
        }
        
        &:focus-visible {
          box-shadow: 0 0 0 3px rgba(234, 67, 53, 0.15);
        }
      `;
      
    case 'success':
      return css`
        background-color: ${colors.success};
        color: white;
        border: 1px solid ${colors.success};
        
        &:hover:not(:disabled) {
          background-color: #2d8f47;
          border-color: #2d8f47;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(52, 168, 83, 0.3);
        }
        
        &:active:not(:disabled) {
          transform: translateY(0);
          box-shadow: 0 2px 4px rgba(52, 168, 83, 0.3);
        }
        
        &:focus-visible {
          box-shadow: 0 0 0 3px rgba(52, 168, 83, 0.15);
        }
      `;
      
    default:
      return getButtonVariantStyles('primary', theme);
  }
};

const StyledButton = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  font-family: inherit;
  font-weight: 500;
  text-align: center;
  text-decoration: none;
  white-space: nowrap;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
  outline: none;
  
  /* Size styles */
  ${({ $size }) => {
    const size = buttonSizes[$size] || buttonSizes.md;
    return css`
      padding: ${size.padding};
      font-size: ${size.fontSize};
      min-height: ${size.minHeight};
      border-radius: ${size.borderRadius};
    `;
  }}
  
  /* Variant styles */
  ${({ $variant, theme }) => getButtonVariantStyles($variant, theme)}
  
  /* Full width */
  ${({ $fullWidth }) => $fullWidth && css`
    width: 100%;
  `}
  
  /* Loading state */
  ${({ $loading }) => $loading && css`
    cursor: not-allowed;
    opacity: 0.7;
    
    &::before {
      content: '';
      position: absolute;
      width: 16px;
      height: 16px;
      border: 2px solid transparent;
      border-top: 2px solid currentColor;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
  `}
  
  /* Disabled state */
  &:disabled {
    cursor: not-allowed;
    opacity: 0.5;
    transform: none !important;
    box-shadow: none !important;
  }
  
  /* Loading animation */
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
  
  /* High contrast mode support */
  @media (prefers-contrast: high) {
    border-width: 2px;
  }
  
  /* Reduced motion support */
  @media (prefers-reduced-motion: reduce) {
    transition: none;
    
    &:hover:not(:disabled) {
      transform: none;
    }
    
    &:active:not(:disabled) {
      transform: none;
    }
    
    &::before {
      animation: none;
    }
  }
  
  /* Mobile touch targets - ensure minimum 44px */
  @media (max-width: 768px) {
    min-height: 44px;
    padding: ${({ $size }) => 
      $size === 'xs' ? '0.75rem 1rem' : 
      $size === 'sm' ? '0.75rem 1.25rem' : 
      buttonSizes[$size]?.padding || buttonSizes.md.padding
    };
  }
`;

const LoadingSpinner = styled.span`
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid transparent;
  border-top: 2px solid currentColor;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin-right: 0.5rem;
  
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
  
  @media (prefers-reduced-motion: reduce) {
    animation: none;
    &::after {
      content: '⋯';
      display: block;
      text-align: center;
      animation: none;
    }
  }
`;

/**
 * Button Component
 * 
 * A comprehensive, accessible button component with multiple variants, sizes,
 * and states. Follows WCAG 2.1 AA guidelines and supports responsive design.
 * 
 * @param {string} variant - Button style variant: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success'
 * @param {string} size - Button size: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
 * @param {boolean} loading - Shows loading spinner and disables button
 * @param {boolean} disabled - Disables the button
 * @param {boolean} fullWidth - Makes button take full width of container
 * @param {ReactNode} children - Button content
 * @param {ReactNode} leftIcon - Icon to display on the left
 * @param {ReactNode} rightIcon - Icon to display on the right
 * @param {string} ariaLabel - Accessible label for screen readers
 * @param {function} onClick - Click handler
 * @param {object} ...props - Additional props passed to button element
 */
export const Button = forwardRef(({
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  fullWidth = false,
  children,
  leftIcon,
  rightIcon,
  ariaLabel,
  onClick,
  type = 'button',
  ...props
}, ref) => {
  const { theme } = useTheme();
  
  const handleClick = (event) => {
    if (loading || disabled) {
      event.preventDefault();
      return;
    }
    onClick?.(event);
  };
  
  return (
    <StyledButton
      ref={ref}
      type={type}
      theme={theme}
      $variant={variant}
      $size={size}
      $loading={loading}
      $fullWidth={fullWidth}
      disabled={disabled || loading}
      onClick={handleClick}
      aria-label={ariaLabel}
      aria-disabled={disabled || loading}
      {...props}
    >
      {loading && <LoadingSpinner />}
      {!loading && leftIcon && <span className="button-left-icon">{leftIcon}</span>}
      {children && <span className="button-text">{children}</span>}
      {!loading && rightIcon && <span className="button-right-icon">{rightIcon}</span>}
    </StyledButton>
  );
});

Button.displayName = 'Button';

Button.propTypes = {
  /** Button content */
  children: PropTypes.node,
  /** Button variant style */
  variant: PropTypes.oneOf(['primary', 'secondary', 'outline', 'ghost', 'danger', 'success']),
  /** Button size */
  size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
  /** Button type attribute */
  type: PropTypes.oneOf(['button', 'submit', 'reset']),
  /** Whether button is disabled */
  disabled: PropTypes.bool,
  /** Whether button is in loading state */
  loading: PropTypes.bool,
  /** Whether button takes full width of container */
  fullWidth: PropTypes.bool,
  /** Icon to display on the left side */
  leftIcon: PropTypes.node,
  /** Icon to display on the right side */
  rightIcon: PropTypes.node,
  /** Click handler function */
  onClick: PropTypes.func,
  /** Accessible label for screen readers */
  ariaLabel: PropTypes.string,
  /** Additional CSS class name */
  className: PropTypes.string
};

Button.defaultProps = {
  variant: 'primary',
  size: 'md',
  type: 'button',
  disabled: false,
  loading: false,
  fullWidth: false,
  leftIcon: null,
  rightIcon: null,
  onClick: undefined,
  ariaLabel: undefined,
  className: ''
};

export default Button;