import React, { forwardRef, useState } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../context/ThemeContext';

const Input = forwardRef(({
  type = 'text',
  variant = 'default',
  size = 'md',
  fullWidth = false,
  disabled = false,
  error = false,
  helperText = '',
  label = '',
  placeholder = '',
  leftIcon = null,
  rightIcon = null,
  className = '',
  style = {},
  onFocus = () => {},
  onBlur = () => {},
  onChange = () => {},
  ...props
}, ref) => {
  const { theme } = useTheme();
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = (e) => {
    setIsFocused(true);
    onFocus(e);
  };

  const handleBlur = (e) => {
    setIsFocused(false);
    onBlur(e);
  };

  const handleChange = (e) => {
    onChange(e);
  };

  // Base styles
  const baseStyles = {
    display: 'flex',
    alignItems: 'center',
    position: 'relative',
    fontFamily: theme.typography?.fontFamily || '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    transition: 'all 0.2s ease-in-out',
    borderRadius: theme.borderRadius?.md || '8px',
    border: `2px solid ${error ? 
      (theme.colors.error || '#ef4444') : 
      isFocused ? 
        (theme.colors.primary || '#3b82f6') : 
        (theme.colors.border || '#d1d5db')
    }`,
    backgroundColor: disabled ? 
      (theme.colors.surfaceDisabled || theme.colors.surface || '#f9fafb') : 
      (theme.colors.surface || '#ffffff'),
    color: disabled ? 
      (theme.colors.textDisabled || theme.colors.textSecondary || '#9ca3af') : 
      (theme.colors.text || '#111827'),
    opacity: disabled ? 0.6 : 1,
    cursor: disabled ? 'not-allowed' : 'text',
    width: fullWidth ? '100%' : 'auto'
  };

  // Size variants
  const sizeStyles = {
    xs: {
      padding: 'var(--spacing-xs, 8px) var(--spacing-sm, 12px)',
      fontSize: '0.75rem',
      lineHeight: '1rem',
      minHeight: '32px'
    },
    sm: {
      padding: 'var(--spacing-sm, 12px) var(--spacing-md, 16px)',
      fontSize: '0.875rem',
      lineHeight: '1.25rem',
      minHeight: '36px'
    },
    md: {
      padding: 'var(--spacing-md, 16px)',
      fontSize: '1rem',
      lineHeight: '1.5rem',
      minHeight: '44px'
    },
    lg: {
      padding: 'var(--spacing-md, 16px) var(--spacing-lg, 20px)',
      fontSize: '1.125rem',
      lineHeight: '1.75rem',
      minHeight: '48px'
    },
    xl: {
      padding: 'var(--spacing-lg, 20px) var(--spacing-xl, 24px)',
      fontSize: '1.25rem',
      lineHeight: '1.75rem',
      minHeight: '52px'
    }
  };

  // Variant styles
  const variantStyles = {
    default: {},
    filled: {
      backgroundColor: theme.colors.surfaceVariant || theme.colors.surface || '#f3f4f6',
      border: `2px solid transparent`
    },
    outlined: {
      backgroundColor: 'transparent',
      border: `2px solid ${error ? 
        (theme.colors.error || '#ef4444') : 
        isFocused ? 
          (theme.colors.primary || '#3b82f6') : 
          (theme.colors.border || '#d1d5db')
      }`
    }
  };

  // Container styles
  const containerStyle = {
    position: 'relative',
    width: fullWidth ? '100%' : 'auto'
  };

  // Input wrapper styles
  const inputWrapperStyle = {
    ...baseStyles,
    ...sizeStyles[size],
    ...variantStyles[variant],
    gap: leftIcon || rightIcon ? 'var(--spacing-sm, 12px)' : '0'
  };

  // Input field styles
  const inputFieldStyle = {
    border: 'none',
    outline: 'none',
    backgroundColor: 'transparent',
    color: 'inherit',
    fontSize: 'inherit',
    lineHeight: 'inherit',
    fontFamily: 'inherit',
    flex: 1,
    width: '100%',
    '::placeholder': {
      color: theme.colors.textSecondary || '#9ca3af'
    }
  };

  // Label styles
  const labelStyle = {
    display: 'block',
    fontSize: '0.875rem',
    fontWeight: '500',
    color: error ? 
      (theme.colors.error || '#ef4444') : 
      (theme.colors.text || '#374151'),
    marginBottom: 'var(--spacing-xs, 8px)'
  };

  // Helper text styles
  const helperTextStyle = {
    fontSize: '0.75rem',
    color: error ? 
      (theme.colors.error || '#ef4444') : 
      (theme.colors.textSecondary || '#6b7280'),
    marginTop: 'var(--spacing-xs, 8px)'
  };

  // Icon styles
  const iconStyle = {
    color: theme.colors.textSecondary || '#6b7280',
    fontSize: sizeStyles[size].fontSize,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  };

  const inputId = props.id || `input-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div style={{ ...containerStyle, ...style }} className={className}>
      {label && (
        <label 
          htmlFor={inputId}
          style={labelStyle}
        >
          {label}
        </label>
      )}
      
      <div style={inputWrapperStyle}>
        {leftIcon && (
          <span style={iconStyle} aria-hidden="true">
            {leftIcon}
          </span>
        )}
        
        <input
          {...props}
          ref={ref}
          id={inputId}
          type={type}
          placeholder={placeholder}
          disabled={disabled}
          style={inputFieldStyle}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onChange={handleChange}
          aria-invalid={error}
          aria-describedby={helperText ? `${inputId}-helper` : undefined}
        />
        
        {rightIcon && (
          <span style={iconStyle} aria-hidden="true">
            {rightIcon}
          </span>
        )}
      </div>
      
      {helperText && (
        <div 
          id={`${inputId}-helper`}
          style={helperTextStyle}
          role={error ? 'alert' : 'status'}
          aria-live={error ? 'assertive' : 'polite'}
        >
          {helperText}
        </div>
      )}
    </div>
  );
});

Input.displayName = 'Input';

Input.propTypes = {
  /** Input type attribute */
  type: PropTypes.oneOf(['text', 'email', 'password', 'number', 'tel', 'url', 'search']),
  /** Input visual variant */
  variant: PropTypes.oneOf(['default', 'filled', 'outlined']),
  /** Input size */
  size: PropTypes.oneOf(['sm', 'md', 'lg']),
  /** Whether input takes full width of container */
  fullWidth: PropTypes.bool,
  /** Whether input is disabled */
  disabled: PropTypes.bool,
  /** Whether input has error state */
  error: PropTypes.bool,
  /** Helper text shown below input */
  helperText: PropTypes.string,
  /** Label text */
  label: PropTypes.string,
  /** Placeholder text */
  placeholder: PropTypes.string,
  /** Icon to display on the left side */
  leftIcon: PropTypes.node,
  /** Icon to display on the right side */
  rightIcon: PropTypes.node,
  /** Input value */
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  /** Default value for uncontrolled input */
  defaultValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  /** Change handler function */
  onChange: PropTypes.func,
  /** Focus handler function */
  onFocus: PropTypes.func,
  /** Blur handler function */
  onBlur: PropTypes.func,
  /** Additional CSS class name */
  className: PropTypes.string,
  /** Inline styles */
  style: PropTypes.object
};

Input.defaultProps = {
  type: 'text',
  variant: 'default',
  size: 'md',
  fullWidth: false,
  disabled: false,
  error: false,
  helperText: '',
  label: '',
  placeholder: '',
  leftIcon: null,
  rightIcon: null,
  onChange: () => {},
  onFocus: () => {},
  onBlur: () => {},
  className: '',
  style: {}
};

export default Input;
