import React, { useState, useRef, useEffect } from 'react';
import styled from 'styled-components';
import DashboardSidebar from '../dashboard/DashboardSidebar';
import { useTheme } from '../../context/ThemeContext';
import Editor from "@monaco-editor/react";
import * as monaco from 'monaco-editor';
import FileExplorer from './FileExplorer';
import RightSidebar from '../common/RightSidebar';
import ChatView from '../common/ChatView';
import useChat from '../../hooks/useChat';

// Main container
const Container = styled.div`
  display: flex;
  min-height: 100vh;
  background-color: ${props => props.theme.colors.background};
`;

// Main content area - adjust to be more responsive to sidebar states
const ContentArea = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  margin-left: ${props => props.sidebarCollapsed ? '70px' : '240px'};
  width: calc(100% - ${props => props.sidebarCollapsed ? '70px' : '240px'});
  transition: margin-left 0.3s ease, width 0.3s ease;
  position: relative; /* Ensure proper positioning of absolute elements */
  
  @media (max-width: 768px) {
    margin-left: 70px;
    width: calc(100% - 70px);
  }
`;

// Standardizing heights for consistent UI
const headerHeight = '60px';

// Top navigation bar
const TopBar = styled.div`
  height: ${headerHeight};
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1.5rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
`;

const ProjectTitle = styled.div`
  font-weight: 600;
  display: flex;
  align-items: center;
  font-size: 16px;
  color: ${props => props.theme.colors.text}; /* Ensure text is visible in dark mode */
  
  .file-name {
    color: ${props => props.theme.colors.primary};
    margin-left: 8px;
  }
`;

const ActionButtons = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const Button = styled.button`
  display: flex;
  align-items: center;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  
  &.primary {
    background-color: ${props => props.theme.colors.primary};
    color: white;
    border: none;
    
    &:hover {
      background-color: ${props => props.theme.colors.primaryHover};
    }
  }
  
  &.secondary {
    background-color: transparent;
    color: ${props => props.theme.colors.text};
    border: 1px solid ${props => props.theme.colors.border};
    
    &:hover {
      background-color: ${props => props.theme.colors.inputBackground};
    }
  }
  
  svg {
    margin-right: 6px;
  }
`;

// Main workspace area
const Workspace = styled.div`
  display: flex;
  flex: 1;
  overflow: hidden;
  position: relative;
`;

// Code editor area - now takes full width since sidebar is separate
const CodeEditorArea = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  background-color: ${props => props.theme.colors.cardBackground};
  transition: all 0.3s ease;
  margin-right: ${props => props.chatCollapsed ? '50px' : '450px'};
  overflow: hidden;
  box-sizing: border-box;
`;

// Editor header - adjusted for consistent height with chat header
const EditorHeader = styled.div`
  height: ${headerHeight};
  padding: 0 1rem;
  border-bottom: 1px solid ${props => props.theme.colors.border};
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: ${props => props.theme.colors.cardBackground};
`;

// EditorTabs - adjusted to align with the editor content
const EditorTabs = styled.div`
  display: flex;
  gap: 0.5rem;
  height: 100%;
  align-items: center;
  overflow-x: auto;
  flex-grow: 1;

  /* Hide scrollbar but allow scrolling */
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    display: none;
  }
`;

const EditorTab = styled.div`
  padding: 0 1rem;
  border-radius: 4px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  user-select: none;
  position: relative;
  color: ${props => props.theme.colors.text};
  height: calc(${headerHeight} - 20px);
  
  &.active {
    background-color: ${props => props.theme.colors.inputBackground};
    
    &::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 0;
      right: 0;
      height: 2px;
      background-color: ${props => props.theme.colors.primary};
      border-radius: 1px;
    }
    
    span {
      color: ${props => props.theme.colors.primary};
    }
  }
  
  .close-tab {
    opacity: 0.5;
    &:hover {
      opacity: 1;
    }
  }
`;

const EditorTools = styled.div`
  display: flex;
  gap: 0.75rem;
`;

const EditorContainer = styled.div`
  flex: 1;
  overflow: hidden;
`;

const EditorWorkspace = styled.div`
  display: flex;
  flex: 1;
  overflow: hidden;
`;

// Icons
const SendIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="22" y1="2" x2="11" y2="13"></line>
    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
  </svg>
);

const AttachmentIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
  </svg>
);

const PlayIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="5 3 19 12 5 21 5 3"></polygon>
  </svg>
);

const DownloadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
    <polyline points="7 10 12 15 17 10"></polyline>
    <line x1="12" y1="15" x2="12" y2="3"></line>
  </svg>
);

const FileIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
    <polyline points="14 2 14 8 20 8"></polyline>
    <line x1="16" y1="13" x2="8" y2="13"></line>
    <line x1="16" y1="17" x2="8" y2="17"></line>
    <polyline points="10 9 9 9 8 9"></polyline>
  </svg>
);

const CloseIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="close-tab">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);

// Add new Chat Icon
const ChatIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
  </svg>
);

// Add collapse icon - Keep this icon for potential future use
const CollapseIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 18 9 12 15 6"></polyline>
  </svg>
);

// When initializing the component state, set chatCollapsed to true by default
// so the chat is initially collapsed
const CodeAssistant = () => {
  const { theme } = useTheme();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatCollapsed, setChatCollapsed] = useState(true);
  
  // Initialize chat with AI assistant
  const initialMessages = [
    {
      type: 'ai',
      content: 'Hello! I\'m your AI assistant. I can help you with your code. How can I assist you today?',
      timestamp: new Date().toISOString(),
    }
  ];

  const { messages, isLoading, sendMessage } = useChat(initialMessages, {
    simulateAIDelay: 1000,
    maxMessages: 50
  });
  
  // Reference to Monaco editor instance
  const editorRef = useRef(null);
  const resizeTimerRef = useRef(null);
  
  // Handle editor mounting
  const handleEditorDidMount = (editor, monaco) => {
    editorRef.current = editor;
  };
  
  // Force editor layout update when chat panel is toggled
  useEffect(() => {
    if (resizeTimerRef.current) {
      clearTimeout(resizeTimerRef.current);
    }
    
    // Wait for transition to complete before relayouting
    resizeTimerRef.current = setTimeout(() => {
      if (editorRef.current) {
        try {
          editorRef.current.layout();
        } catch (err) {
          console.log("Editor layout error:", err);
        }
      }
    }, 350); // Slightly longer than transition
    
    return () => {
      if (resizeTimerRef.current) {
        clearTimeout(resizeTimerRef.current);
      }
    };
  }, [chatCollapsed]);
  
  // File content state
  const [files, setFiles] = useState({
    'index.js': `// Imports
import mongoose, { Schema } from "mongoose";

// Collection name
export const collection = 'Product';

// Schema
const schema = new Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String
  }
}, {timestamps: true});

// Model
export default mongoose.model(collection, schema, collection);`,
    'App.js': `import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to My App</h1>
        <p>Start editing to see some magic happen!</p>
      </header>
    </div>
  );
}

export default App;`,
    'Button.js': `import React from 'react';
import styled from 'styled-components';

const StyledButton = styled.button\`
  padding: 10px 16px;
  border-radius: 4px;
  border: none;
  background-color: #3498db;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  
  &:hover {
    background-color: #2980b9;
  }
\`;

const Button = ({ children, ...props }) => {
  return <StyledButton {...props}>{children}</StyledButton>;
};

export default Button;`
  });
  
  // Tabs management
  const [openTabs, setOpenTabs] = useState(['index.js']);
  const [activeTab, setActiveTab] = useState('index.js');
  
  // Handle file selection from explorer
  const handleFileSelect = (filename, path) => {
    // If file isn't in tabs, add it
    if (!openTabs.includes(filename)) {
      setOpenTabs(prev => [...prev, filename]);
    }
    setActiveTab(filename);
  };
  
  // Handle tab close
  const handleCloseTab = (e, tab) => {
    e.stopPropagation(); // Prevent tab activation when closing
    
    // Remove tab
    const newTabs = openTabs.filter(t => t !== tab);
    setOpenTabs(newTabs);
    
    // If we're closing the active tab, activate another tab
    if (activeTab === tab && newTabs.length > 0) {
      setActiveTab(newTabs[0]);
    }
  };
  
  // Handle tab click
  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };
  
  // Handle code change in editor
  const handleEditorChange = (value) => {
    setFiles(prev => ({
      ...prev,
      [activeTab]: value
    }));
  };
  
  // Handle sidebar toggle
  const handleSidebarToggle = (collapsed) => {
    setSidebarCollapsed(collapsed);
  };

  // Handle chat message sending
  const handleSendMessage = (content) => {
    sendMessage(content);
  };

  // Toggle chat panel
  const toggleChat = () => {
    setChatCollapsed(!chatCollapsed);
  };

  // Set Monaco editor options based on theme
  const getEditorOptions = () => {
    return {
      selectOnLineNumbers: true,
      roundedSelection: false,
      readOnly: false,
      cursorStyle: 'line',
      automaticLayout: false, // Disable automatic layout to prevent ResizeObserver errors
      minimap: {
        enabled: true
      },
      scrollBeyondLastLine: false,
      scrollbar: {
        useShadows: false,
        verticalHasArrows: true,
        horizontalHasArrows: true,
        vertical: 'visible',
        horizontal: 'visible',
        verticalScrollbarSize: 12,
        horizontalScrollbarSize: 12,
        arrowSize: 15
      }
    };
  };

  // Handle editor theme based on the app theme
  const getEditorTheme = () => {
    return theme.mode === 'dark' ? 'vs-dark' : 'vs';
  };

  // Determine language based on file extension
  const getLanguageByFilename = (filename) => {
    const extension = filename.split('.').pop().toLowerCase();
    switch (extension) {
      case 'js':
      case 'jsx':
        return 'javascript';
      case 'ts':
      case 'tsx':
        return 'typescript';
      case 'css':
        return 'css';
      case 'html':
        return 'html';
      case 'json':
        return 'json';
      case 'md':
        return 'markdown';
      default:
        return 'plaintext';
    }
  };

  return (
    <Container>
      <DashboardSidebar onToggle={handleSidebarToggle} />
      <ContentArea sidebarCollapsed={sidebarCollapsed}>
        <TopBar>
          <ProjectTitle>
            <FileIcon />
            <span className="file-name">{activeTab}</span>
          </ProjectTitle>
          <ActionButtons>
            <Button className="secondary">
              <DownloadIcon />
              Export
            </Button>
            <Button className="primary">
              <PlayIcon />
              Run
            </Button>
          </ActionButtons>
        </TopBar>
        
        <Workspace>
          <CodeEditorArea chatCollapsed={chatCollapsed}>
            <EditorHeader>
              <EditorTabs>
                {openTabs.map(tab => (
                  <EditorTab 
                    key={tab} 
                    className={tab === activeTab ? 'active' : ''}
                    onClick={() => handleTabClick(tab)}
                  >
                    <FileIcon extension={tab.split('.').pop()} />
                    <span>{tab}</span>
                    <div onClick={(e) => handleCloseTab(e, tab)}>
                      <CloseIcon />
                    </div>
                  </EditorTab>
                ))}
              </EditorTabs>
              <EditorTools>
                {/* You can add editor tools here like save, format, etc. */}
              </EditorTools>
            </EditorHeader>
            <EditorWorkspace>
              <FileExplorer onFileSelect={handleFileSelect} />
              <EditorContainer>
                <Editor
                  height="100%"
                  defaultLanguage={getLanguageByFilename(activeTab)}
                  value={files[activeTab]}
                  onChange={handleEditorChange}
                  theme={getEditorTheme()}
                  options={getEditorOptions()}
                  path={activeTab}
                  key={activeTab} /* Important to re-render editor when switching tabs */
                  onMount={handleEditorDidMount}
                />
              </EditorContainer>
            </EditorWorkspace>
          </CodeEditorArea>
        </Workspace>

        {/* Chat Sidebar using our reusable components */}
        <RightSidebar
          collapsed={chatCollapsed}
          onToggle={setChatCollapsed}
          width="450px"
          title="Code Assistant"
          toggleIcon={<ChatIcon />}
          zIndex={10}
        >
          <ChatView
            title="Code Assistant"
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            placeholder="Ask me about your code..."
            maxMessageLength={500}
          />
        </RightSidebar>
      </ContentArea>
    </Container>
  );
};

export default CodeAssistant;