const config = {
  API_BASE_URL: 'http://localhost:8000/api/v1',
  UPLOAD_BASE_DIR: '/uploads/',  // Base directory for uploads
  MAX_UPLOAD_SIZE: 50 * 1024 * 1024, // 50MB max upload size
};

export default config;