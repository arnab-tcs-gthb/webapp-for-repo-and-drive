import React from 'react';

/**
 * Form Validation Utilities
 * Provides comprehensive validation functions for form inputs
 */

export const validationRules = {
  required: (value) => {
    if (value === null || value === undefined || value === '') {
      return 'This field is required';
    }
    return null;
  },

  email: (value) => {
    if (!value) return null;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  },

  minLength: (min) => (value) => {
    if (!value) return null;
    if (value.length < min) {
      return `Must be at least ${min} characters long`;
    }
    return null;
  },

  maxLength: (max) => (value) => {
    if (!value) return null;
    if (value.length > max) {
      return `Must be no more than ${max} characters long`;
    }
    return null;
  },

  password: (value) => {
    if (!value) return null;
    
    const errors = [];
    if (value.length < 8) {
      errors.push('At least 8 characters');
    }
    if (!/[A-Z]/.test(value)) {
      errors.push('One uppercase letter');
    }
    if (!/[a-z]/.test(value)) {
      errors.push('One lowercase letter');
    }
    if (!/\d/.test(value)) {
      errors.push('One number');
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
      errors.push('One special character');
    }
    
    if (errors.length > 0) {
      return `Password must contain: ${errors.join(', ')}`;
    }
    return null;
  },

  url: (value) => {
    if (!value) return null;
    try {
      new URL(value);
      return null;
    } catch {
      return 'Please enter a valid URL';
    }
  },

  phone: (value) => {
    if (!value) return null;
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
      return 'Please enter a valid phone number';
    }
    return null;
  },

  number: (value) => {
    if (!value) return null;
    if (isNaN(Number(value))) {
      return 'Please enter a valid number';
    }
    return null;
  },

  min: (minValue) => (value) => {
    if (!value) return null;
    const numValue = Number(value);
    if (isNaN(numValue) || numValue < minValue) {
      return `Value must be at least ${minValue}`;
    }
    return null;
  },

  max: (maxValue) => (value) => {
    if (!value) return null;
    const numValue = Number(value);
    if (isNaN(numValue) || numValue > maxValue) {
      return `Value must be no more than ${maxValue}`;
    }
    return null;
  },

  custom: (validator, message) => (value) => {
    if (!validator(value)) {
      return message;
    }
    return null;
  }
};

/**
 * Validates a single field with multiple rules
 * @param {any} value - The value to validate
 * @param {Array} rules - Array of validation functions
 * @returns {string|null} - Error message or null if valid
 */
export const validateField = (value, rules) => {
  for (const rule of rules) {
    const error = rule(value);
    if (error) {
      return error;
    }
  }
  return null;
};

/**
 * Validates an entire form object
 * @param {Object} values - Form values object
 * @param {Object} validationSchema - Schema defining validation rules for each field
 * @returns {Object} - Object containing errors for each field
 */
export const validateForm = (values, validationSchema) => {
  const errors = {};
  
  Object.keys(validationSchema).forEach(fieldName => {
    const rules = validationSchema[fieldName];
    const fieldValue = values[fieldName];
    const error = validateField(fieldValue, rules);
    
    if (error) {
      errors[fieldName] = error;
    }
  });
  
  return errors;
};

/**
 * Custom hook for form validation
 * @param {Object} initialValues - Initial form values
 * @param {Object} validationSchema - Validation schema
 * @returns {Object} - Form state and handlers
 */
export const useFormValidation = (initialValues, validationSchema) => {
  const [values, setValues] = React.useState(initialValues);
  const [errors, setErrors] = React.useState({});
  const [touched, setTouched] = React.useState({});
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const validateSingleField = (name, value) => {
    if (validationSchema[name]) {
      const error = validateField(value, validationSchema[name]);
      setErrors(prev => ({
        ...prev,
        [name]: error
      }));
      return !error;
    }
    return true;
  };

  const handleChange = (name, value) => {
    setValues(prev => ({
      ...prev,
      [name]: value
    }));

    // Validate field on change if it has been touched
    if (touched[name]) {
      validateSingleField(name, value);
    }
  };

  const handleBlur = (name) => {
    setTouched(prev => ({
      ...prev,
      [name]: true
    }));

    // Validate field on blur
    validateSingleField(name, values[name]);
  };

  const validateAll = () => {
    const formErrors = validateForm(values, validationSchema);
    setErrors(formErrors);
    
    // Mark all fields as touched
    const allTouched = {};
    Object.keys(validationSchema).forEach(key => {
      allTouched[key] = true;
    });
    setTouched(allTouched);

    return Object.keys(formErrors).length === 0;
  };

  const handleSubmit = async (onSubmit) => {
    setIsSubmitting(true);
    
    const isValid = validateAll();
    
    if (isValid && onSubmit) {
      try {
        await onSubmit(values);
      } catch (error) {
        console.error('Form submission error:', error);
      }
    }
    
    setIsSubmitting(false);
    return isValid;
  };

  const reset = () => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
  };

  const isValid = Object.keys(errors).length === 0 && Object.keys(touched).length > 0;

  return {
    values,
    errors,
    touched,
    isSubmitting,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit,
    validateAll,
    reset
  };
};
