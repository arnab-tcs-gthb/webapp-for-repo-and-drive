/**
 * Debug utilities for loading states
 * This helps troubleshoot long-running or orphaned loading states
 */

import apiClient from './apiClient';

// Debug log for tracking loading states
const loadingDebugLog = [];

// Maximum number of log entries to keep
const MAX_LOG_SIZE = 100;

/**
 * Loading state debugger
 * Provides tools to monitor and troubleshoot loading states
 */
const loadingDebugger = {
  /**
   * Start monitoring loading state changes
   */
  startMonitoring() {
    // Listen for loading start events
    apiClient.loading.onStart((requestId) => {
      const timestamp = new Date().toISOString();
      loadingDebugLog.push({
        id: requestId,
        status: 'started',
        timestamp,
      });
      
      // Trim log if it gets too large
      if (loadingDebugLog.length > MAX_LOG_SIZE) {
        loadingDebugLog.shift();
      }
      
      console.log(`[Loading] Started: ${requestId} at ${timestamp}`);
    });
    
    // Listen for loading end events
    apiClient.loading.onEnd((requestId) => {
      const timestamp = new Date().toISOString();
      loadingDebugLog.push({
        id: requestId,
        status: 'ended',
        timestamp,
      });
      
      // Trim log if it gets too large
      if (loadingDebugLog.length > MAX_LOG_SIZE) {
        loadingDebugLog.shift();
      }
      
      console.log(`[Loading] Ended: ${requestId} at ${timestamp}`);
    });
    
    console.log('[Loading Debugger] Monitoring started');
  },
  
  /**
   * Stop monitoring loading state changes
   */
  stopMonitoring() {
    // Remove all listeners to prevent memory leaks
    apiClient.loading.offStart();
    apiClient.loading.offEnd();
    console.log('[Loading Debugger] Monitoring stopped');
  },
  
  /**
   * Get the current loading log
   * @returns {Array} Array of loading events
   */
  getLog() {
    return [...loadingDebugLog];
  },
  
  /**
   * Clear the loading log
   */
  clearLog() {
    loadingDebugLog.length = 0;
    console.log('[Loading Debugger] Log cleared');
  },
  
  /**
   * Get active loading requests
   * @returns {Array} Array of active request IDs
   */
  getActiveRequests() {
    return apiClient.loading.getActiveRequests();
  },
  
  /**
   * Get the count of active loading requests
   * @returns {number} Number of active requests
   */
  getActiveCount() {
    return apiClient.loading.getActiveCount();
  },
  
  /**
   * Find orphaned loading states
   * These are loading states that have been active for longer than the specified threshold
   * @param {number} thresholdMs - Threshold in milliseconds (default: 10000ms)
   * @returns {Array} Array of potentially orphaned request IDs and their durations
   */
  findOrphanedLoadingStates(thresholdMs = 10000) {
    const now = Date.now();
    const activeRequests = apiClient.loading.getActiveRequests();
    const orphaned = [];
    
    // Check each active request to see if it's been running for too long
    activeRequests.forEach(requestId => {
      // Find start timestamp for this request
      const startEvent = loadingDebugLog.find(
        entry => entry.id === requestId && entry.status === 'started'
      );
      
      if (startEvent) {
        const startTime = new Date(startEvent.timestamp).getTime();
        const duration = now - startTime;
        
        if (duration > thresholdMs) {
          orphaned.push({
            id: requestId,
            duration: `${(duration / 1000).toFixed(2)}s`,
            startedAt: startEvent.timestamp
          });
        }
      }
    });
    
    return orphaned;
  },
  
  /**
   * Force cleanup of all loading states
   * @returns {number} Number of cleared requests
   */
  forceCleanup() {
    apiClient.loading.clearAll();
    return loadingDebugLog.push({
      id: 'manual-cleanup',
      status: 'force-cleared',
      timestamp: new Date().toISOString()
    });
  }
};

// For development environment, automatically start monitoring
if (process.env.NODE_ENV === 'development') {
  loadingDebugger.startMonitoring();
  console.log('[Loading Debugger] Automatically started in development mode');
  
  // Add to window for console access
  if (typeof window !== 'undefined') {
    window.loadingDebugger = loadingDebugger;
    console.log('[Loading Debugger] Access via window.loadingDebugger in console');
  }
}

export default loadingDebugger;
