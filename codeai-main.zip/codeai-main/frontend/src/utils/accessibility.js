import React from 'react';

/**
 * Accessibility Utilities
 * Provides helper functions for improving accessibility
 */

/**
 * Generates a unique ID for form elements
 * @param {string} prefix - Prefix for the ID
 * @returns {string} - Unique ID
 */
export const generateId = (prefix = 'element') => {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
};

/**
 * Creates ARIA attributes for form inputs
 * @param {Object} options - Configuration options
 * @returns {Object} - ARIA attributes object
 */
export const createAriaAttributes = ({
  label,
  error,
  helperText,
  required = false,
  describedBy = []
}) => {
  const attributes = {};
  
  if (label) {
    attributes['aria-label'] = label;
  }
  
  if (required) {
    attributes['aria-required'] = 'true';
  }
  
  if (error) {
    attributes['aria-invalid'] = 'true';
  }
  
  const describedByIds = [...describedBy];
  if (error && error.id) {
    describedByIds.push(error.id);
  }
  if (helperText && helperText.id) {
    describedByIds.push(helperText.id);
  }
  
  if (describedByIds.length > 0) {
    attributes['aria-describedby'] = describedByIds.join(' ');
  }
  
  return attributes;
};

/**
 * Keyboard navigation handler for lists
 * @param {Event} event - Keyboard event
 * @param {Array} items - Array of items
 * @param {number} currentIndex - Currently focused item index
 * @param {Function} onSelect - Function to call when item is selected
 * @param {Function} onNavigate - Function to call when navigation changes
 */
export const handleKeyboardNavigation = (
  event,
  items,
  currentIndex,
  onSelect,
  onNavigate
) => {
  if (!items || items.length === 0) return;
  
  let newIndex = currentIndex;
  
  switch (event.key) {
    case 'ArrowDown':
      event.preventDefault();
      newIndex = currentIndex < items.length - 1 ? currentIndex + 1 : 0;
      break;
      
    case 'ArrowUp':
      event.preventDefault();
      newIndex = currentIndex > 0 ? currentIndex - 1 : items.length - 1;
      break;
      
    case 'Home':
      event.preventDefault();
      newIndex = 0;
      break;
      
    case 'End':
      event.preventDefault();
      newIndex = items.length - 1;
      break;
      
    case 'Enter':
    case ' ':
      event.preventDefault();
      if (currentIndex >= 0 && currentIndex < items.length) {
        onSelect(items[currentIndex], currentIndex);
      }
      return;
      
    case 'Escape':
      event.preventDefault();
      // Handle escape - typically close dropdown/modal
      if (onNavigate) {
        onNavigate(-1, 'escape');
      }
      return;
      
    default:
      return;
  }
  
  if (onNavigate) {
    onNavigate(newIndex, event.key);
  }
};

/**
 * Focus management utilities
 */
export const focusManager = {
  /**
   * Sets focus to an element by selector or ref
   * @param {string|React.RefObject} target - CSS selector or React ref
   * @param {Object} options - Focus options
   */
  focus: (target, options = {}) => {
    const element = typeof target === 'string' 
      ? document.querySelector(target)
      : target?.current;
      
    if (element && typeof element.focus === 'function') {
      element.focus(options);
    }
  },

  /**
   * Creates a focus trap within a container
   * @param {Element} container - Container element
   * @returns {Function} - Cleanup function
   */
  createFocusTrap: (container) => {
    if (!container) return () => {};
    
    const focusableSelectors = [
      'button:not([disabled])',
      'input:not([disabled])',
      'select:not([disabled])',
      'textarea:not([disabled])',
      'a[href]',
      '[tabindex]:not([tabindex="-1"])'
    ].join(', ');
    
    const focusableElements = container.querySelectorAll(focusableSelectors);
    const firstFocusable = focusableElements[0];
    const lastFocusable = focusableElements[focusableElements.length - 1];
    
    const handleTabKey = (event) => {
      if (event.key !== 'Tab') return;
      
      if (event.shiftKey) {
        if (document.activeElement === firstFocusable) {
          event.preventDefault();
          lastFocusable?.focus();
        }
      } else {
        if (document.activeElement === lastFocusable) {
          event.preventDefault();
          firstFocusable?.focus();
        }
      }
    };
    
    container.addEventListener('keydown', handleTabKey);
    
    // Focus first element
    firstFocusable?.focus();
    
    return () => {
      container.removeEventListener('keydown', handleTabKey);
    };
  },

  /**
   * Saves and restores focus
   * @returns {Function} - Restore function
   */
  saveFocus: () => {
    const activeElement = document.activeElement;
    
    return () => {
      if (activeElement && typeof activeElement.focus === 'function') {
        activeElement.focus();
      }
    };
  }
};

/**
 * Screen reader utilities
 */
export const screenReader = {
  /**
   * Announces text to screen readers
   * @param {string} message - Message to announce
   * @param {string} priority - Priority level ('polite' or 'assertive')
   */
  announce: (message, priority = 'polite') => {
    const announcer = document.createElement('div');
    announcer.setAttribute('aria-live', priority);
    announcer.setAttribute('aria-atomic', 'true');
    announcer.setAttribute('class', 'sr-only');
    announcer.style.position = 'absolute';
    announcer.style.left = '-10000px';
    announcer.style.width = '1px';
    announcer.style.height = '1px';
    announcer.style.overflow = 'hidden';
    
    document.body.appendChild(announcer);
    announcer.textContent = message;
    
    setTimeout(() => {
      document.body.removeChild(announcer);
    }, 1000);
  }
};

/**
 * Color contrast utilities
 */
export const colorContrast = {
  /**
   * Calculates relative luminance of a color
   * @param {string} color - Color in hex format
   * @returns {number} - Relative luminance value
   */
  getLuminance: (color) => {
    const hex = color.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16) / 255;
    const g = parseInt(hex.substr(2, 2), 16) / 255;
    const b = parseInt(hex.substr(4, 2), 16) / 255;
    
    const sRGB = [r, g, b].map(c => {
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    
    return 0.2126 * sRGB[0] + 0.7152 * sRGB[1] + 0.0722 * sRGB[2];
  },

  /**
   * Calculates contrast ratio between two colors
   * @param {string} color1 - First color in hex
   * @param {string} color2 - Second color in hex
   * @returns {number} - Contrast ratio
   */
  getContrastRatio: (color1, color2) => {
    const lum1 = colorContrast.getLuminance(color1);
    const lum2 = colorContrast.getLuminance(color2);
    const lighter = Math.max(lum1, lum2);
    const darker = Math.min(lum1, lum2);
    
    return (lighter + 0.05) / (darker + 0.05);
  },

  /**
   * Checks if color combination meets WCAG guidelines
   * @param {string} foreground - Foreground color
   * @param {string} background - Background color
   * @param {string} level - WCAG level ('AA' or 'AAA')
   * @returns {boolean} - Whether colors meet guidelines
   */
  meetsWCAG: (foreground, background, level = 'AA') => {
    const ratio = colorContrast.getContrastRatio(foreground, background);
    const required = level === 'AAA' ? 7 : 4.5;
    
    return ratio >= required;
  }
};

/**
 * Hook for managing reduced motion preferences
 * @returns {boolean} - Whether user prefers reduced motion
 */
export const useReducedMotion = () => {
  const [prefersReducedMotion, setPrefersReducedMotion] = React.useState(false);
  
  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    
    const handleChange = (event) => {
      setPrefersReducedMotion(event.matches);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleChange);
    };
  }, []);
  
  return prefersReducedMotion;
};

/**
 * Hook for managing high contrast preferences
 * @returns {boolean} - Whether user prefers high contrast
 */
export const useHighContrast = () => {
  const [prefersHighContrast, setPrefersHighContrast] = React.useState(false);
  
  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-contrast: high)');
    setPrefersHighContrast(mediaQuery.matches);
    
    const handleChange = (event) => {
      setPrefersHighContrast(event.matches);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleChange);
    };
  }, []);
  
  return prefersHighContrast;
};
