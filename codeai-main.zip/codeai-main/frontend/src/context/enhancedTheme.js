// Enhanced theme system with semantic tokens and responsive breakpoints

// Base theme colors (defined here to avoid circular dependency)
const baseLightTheme = {
  name: 'light',
  colors: {
    background: '#f5f7fa',
    surface: '#ffffff',
    surfaceHover: '#f0f2f5',
    border: '#e1e4e8',
    borderLight: '#f0f2f5',
    primary: '#4285f4',
    primaryLight: '#e8f0fe',
    primaryDark: '#1a73e8',
    primarySoft: 'rgba(66, 133, 244, 0.15)',
    primaryHover: '#1a73e8',
    primaryShadow: 'rgba(66, 133, 244, 0.3)',
    success: '#34a853',
    successLight: '#e6f4ea',
    info: '#4285f4',
    infoLight: '#e8f0fe',
    warning: '#fbbc05',
    warningLight: '#fef7e0',
    error: '#ea4335',
    errorLight: '#fce8e6',
    text: '#2c303a',
    textSecondary: '#6c757d',
    sidebarBackground: '#ffffff',
    sidebarBorder: '#e1e4e8',
    cardBackground: '#ffffff'
  }
};

const baseDarkTheme = {
  name: 'dark',
  colors: {
    background: '#1a1a1a',
    surface: '#2d2d2d',
    surfaceHover: '#3a3a3a',
    border: '#404040',
    borderLight: '#333333',
    primary: '#4285f4',
    primaryLight: '#1a2332',
    primaryDark: '#5a9aff',
    primarySoft: 'rgba(66, 133, 244, 0.2)',
    primaryHover: '#5a9aff',
    primaryShadow: 'rgba(66, 133, 244, 0.4)',
    success: '#34a853',
    successLight: '#1e2e23',
    info: '#4285f4',
    infoLight: '#1a2332',
    warning: '#fbbc05',
    warningLight: '#332a0d',
    error: '#ea4335',
    errorLight: '#2e1a1a',
    text: '#ffffff',
    textSecondary: '#b0b0b0',
    sidebarBackground: '#2d2d2d',
    sidebarBorder: '#404040',
    cardBackground: '#2d2d2d'
  }
};

// Responsive breakpoints
export const breakpoints = {
  xs: '320px',
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px'
};

// Typography scale
export const typography = {
  fontFamily: {
    sans: [
      'Inter',
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif'
    ].join(', '),
    mono: [
      '"Fira Code"',
      '"SF Mono"',
      'Monaco',
      'Inconsolata',
      '"Roboto Mono"',
      '"Source Code Pro"',
      'monospace'
    ].join(', ')
  },
  fontSize: {
    xs: '0.75rem',      // 12px
    sm: '0.875rem',     // 14px
    base: '1rem',       // 16px
    lg: '1.125rem',     // 18px
    xl: '1.25rem',      // 20px
    '2xl': '1.5rem',    // 24px
    '3xl': '1.875rem',  // 30px
    '4xl': '2.25rem',   // 36px
    '5xl': '3rem',      // 48px
    '6xl': '3.75rem',   // 60px
    '7xl': '4.5rem',    // 72px
    '8xl': '6rem',      // 96px
    '9xl': '8rem'       // 128px
  },
  fontWeight: {
    thin: '100',
    extralight: '200',
    light: '300',
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
    extrabold: '800',
    black: '900'
  },
  lineHeight: {
    none: '1',
    tight: '1.25',
    snug: '1.375',
    normal: '1.5',
    relaxed: '1.625',
    loose: '2'
  },
  letterSpacing: {
    tighter: '-0.05em',
    tight: '-0.025em',
    normal: '0em',
    wide: '0.025em',
    wider: '0.05em',
    widest: '0.1em'
  }
};

// Spacing scale
export const spacing = {
  0: '0px',
  0.5: '0.125rem',  // 2px
  1: '0.25rem',     // 4px
  1.5: '0.375rem',  // 6px
  2: '0.5rem',      // 8px
  2.5: '0.625rem',  // 10px
  3: '0.75rem',     // 12px
  3.5: '0.875rem',  // 14px
  4: '1rem',        // 16px
  5: '1.25rem',     // 20px
  6: '1.5rem',      // 24px
  7: '1.75rem',     // 28px
  8: '2rem',        // 32px
  9: '2.25rem',     // 36px
  10: '2.5rem',     // 40px
  11: '2.75rem',    // 44px
  12: '3rem',       // 48px
  14: '3.5rem',     // 56px
  16: '4rem',       // 64px
  20: '5rem',       // 80px
  24: '6rem',       // 96px
  28: '7rem',       // 112px
  32: '8rem',       // 128px
  36: '9rem',       // 144px
  40: '10rem',      // 160px
  44: '11rem',      // 176px
  48: '12rem',      // 192px
  52: '13rem',      // 208px
  56: '14rem',      // 224px
  60: '15rem',      // 240px
  64: '16rem',      // 256px
  72: '18rem',      // 288px
  80: '20rem',      // 320px
  96: '24rem'       // 384px
};

// Border radius scale
export const borderRadius = {
  none: '0px',
  sm: '0.125rem',    // 2px
  base: '0.25rem',   // 4px
  md: '0.375rem',    // 6px
  lg: '0.5rem',      // 8px
  xl: '0.75rem',     // 12px
  '2xl': '1rem',     // 16px
  '3xl': '1.5rem',   // 24px
  full: '9999px'
};

// Enhanced semantic tokens
export const semanticTokens = {
  // Intent colors
  intent: {
    primary: 'colors.primary',
    secondary: 'colors.text',
    success: 'colors.success',
    warning: 'colors.warning',
    error: 'colors.error',
    info: 'colors.info'
  },
  
  // Component-specific tokens
  button: {
    primary: {
      bg: 'colors.primary',
      color: '#ffffff',
      hoverBg: 'colors.primaryHover',
      activeBg: 'colors.primaryDark',
      focusRing: 'colors.primarySoft'
    },
    secondary: {
      bg: 'colors.surface',
      color: 'colors.text',
      hoverBg: 'colors.surfaceHover',
      activeBg: 'colors.border',
      focusRing: 'colors.primarySoft'
    }
  },
  
  card: {
    bg: 'colors.cardBackground',
    border: 'colors.cardBorder',
    shadow: 'colors.cardShadow'
  },
  
  input: {
    bg: 'colors.inputBackground',
    border: 'colors.inputBorder',
    color: 'colors.inputText',
    placeholder: 'colors.inputPlaceholder',
    hoverBg: 'colors.inputHoverBackground',
    focusRing: 'colors.primarySoft'
  },
  
  sidebar: {
    bg: 'colors.sidebarBackground',
    border: 'colors.sidebarBorder'
  }
};

// Elevation shadows
export const elevation = {
  none: 'none',
  xs: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
  sm: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
  md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
  lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
  '2xl': '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
  inner: 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)'
};

// Transition configurations
export const transitions = {
  duration: {
    fastest: '75ms',
    faster: '100ms',
    fast: '150ms',
    normal: '200ms',
    slow: '300ms',
    slower: '500ms',
    slowest: '1000ms'
  },
  easing: {
    linear: 'linear',
    in: 'cubic-bezier(0.4, 0, 1, 1)',
    out: 'cubic-bezier(0, 0, 0.2, 1)',
    'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)'
  }
};

// Z-index scale
export const zIndex = {
  auto: 'auto',
  base: 0,
  docked: 10,
  dropdown: 1000,
  sticky: 1100,
  banner: 1200,
  overlay: 1300,
  modal: 1400,
  popover: 1500,
  skipLink: 1600,
  toast: 1700,
  tooltip: 1800
};

// Enhanced light theme with semantic tokens
export const enhancedLightTheme = {
  ...baseLightTheme,
  breakpoints,
  typography,
  spacing,
  borderRadius,
  elevation,
  transitions,
  zIndex,
  semanticTokens,
  // Additional color tokens
  colors: {
    ...baseLightTheme.colors,
    // Gray scale
    gray: {
      50: '#f9fafb',
      100: '#f3f4f6',
      200: '#e5e7eb',
      300: '#d1d5db',
      400: '#9ca3af',
      500: '#6b7280',
      600: '#4b5563',
      700: '#374151',
      800: '#1f2937',
      900: '#111827'
    },
    // Blue scale (primary)
    blue: {
      50: '#eff6ff',
      100: '#dbeafe',
      200: '#bfdbfe',
      300: '#93c5fd',
      400: '#60a5fa',
      500: '#3b82f6',
      600: '#2563eb',
      700: '#1d4ed8',
      800: '#1e40af',
      900: '#1e3a8a'
    },
    // Accent colors
    accent: {
      50: '#f0f9ff',
      100: '#e0f2fe',
      200: '#bae6fd',
      300: '#7dd3fc',
      400: '#38bdf8',
      500: '#0ea5e9',
      600: '#0284c7',
      700: '#0369a1',
      800: '#075985',
      900: '#0c4a6e'
    }
  }
};

// Enhanced dark theme with semantic tokens
export const enhancedDarkTheme = {
  ...baseDarkTheme,
  breakpoints,
  typography,
  spacing,
  borderRadius,
  elevation: {
    ...elevation,
    // Adjust shadows for dark mode
    xs: '0 1px 2px 0 rgba(0, 0, 0, 0.3)',
    sm: '0 1px 3px 0 rgba(0, 0, 0, 0.3), 0 1px 2px 0 rgba(0, 0, 0, 0.2)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.15)',
    '2xl': '0 25px 50px -12px rgba(0, 0, 0, 0.4)'
  },
  transitions,
  zIndex,
  semanticTokens,
  // Additional color tokens
  colors: {
    ...baseDarkTheme.colors,
    // Gray scale (adjusted for dark mode)
    gray: {
      50: '#18212f',
      100: '#1e293b',
      200: '#334155',
      300: '#475569',
      400: '#64748b',
      500: '#94a3b8',
      600: '#cbd5e1',
      700: '#e2e8f0',
      800: '#f1f5f9',
      900: '#f8fafc'
    },
    // Blue scale (primary - same as light)
    blue: {
      50: '#eff6ff',
      100: '#dbeafe',
      200: '#bfdbfe',
      300: '#93c5fd',
      400: '#60a5fa',
      500: '#3b82f6',
      600: '#2563eb',
      700: '#1d4ed8',
      800: '#1e40af',
      900: '#1e3a8a'
    },
    // Accent colors (same as light)
    accent: {
      50: '#f0f9ff',
      100: '#e0f2fe',
      200: '#bae6fd',
      300: '#7dd3fc',
      400: '#38bdf8',
      500: '#0ea5e9',
      600: '#0284c7',
      700: '#0369a1',
      800: '#075985',
      900: '#0c4a6e'
    }
  }
};

// Utility functions for responsive design
export const mediaQueries = {
  xs: `@media (min-width: ${breakpoints.xs})`,
  sm: `@media (min-width: ${breakpoints.sm})`,
  md: `@media (min-width: ${breakpoints.md})`,
  lg: `@media (min-width: ${breakpoints.lg})`,
  xl: `@media (min-width: ${breakpoints.xl})`,
  '2xl': `@media (min-width: ${breakpoints['2xl']})`,
  
  // Max-width queries
  maxXs: `@media (max-width: ${breakpoints.xs})`,
  maxSm: `@media (max-width: ${breakpoints.sm})`,
  maxMd: `@media (max-width: ${breakpoints.md})`,
  maxLg: `@media (max-width: ${breakpoints.lg})`,
  maxXl: `@media (max-width: ${breakpoints.xl})`,
  max2xl: `@media (max-width: ${breakpoints['2xl']})`,
  
  // Special queries
  touch: '@media (hover: none) and (pointer: coarse)',
  hover: '@media (hover: hover) and (pointer: fine)',
  reducedMotion: '@media (prefers-reduced-motion: reduce)',
  highContrast: '@media (prefers-contrast: high)',
  darkMode: '@media (prefers-color-scheme: dark)',
  lightMode: '@media (prefers-color-scheme: light)'
};

// Token resolver utility
export const resolveToken = (tokenPath, theme) => {
  const path = tokenPath.split('.');
  let value = theme;
  
  for (const key of path) {
    if (value && typeof value === 'object') {
      value = value[key];
    } else {
      return tokenPath; // Return original if not found
    }
  }
  
  return value || tokenPath;
};

// Export object assigned to variable to fix ESLint warning
const enhancedThemeSystem = {
  enhancedLightTheme,
  enhancedDarkTheme,
  breakpoints,
  typography,
  spacing,
  borderRadius,
  elevation,
  transitions,
  zIndex,
  semanticTokens,
  mediaQueries,
  resolveToken
};

export default enhancedThemeSystem;
