import { useState, useCallback } from 'react';

/**
 * Custom hook for managing chat functionality
 */
const useChat = (initialMessages = [], options = {}) => {
  const {
    maxMessages = 100,
    autoScroll = true,
    simulateAIDelay = 1000,
    onMessageSent,
    onAIResponse
  } = options;

  const [messages, setMessages] = useState(() => {
    // Ensure initial messages have timestamps if missing
    return initialMessages.map(msg => ({
      ...msg,
      timestamp: msg.timestamp || new Date().toISOString()
    }));
  });

  const [isLoading, setIsLoading] = useState(false);

  // Add a new message to the chat
  const addMessage = useCallback((message) => {
    const newMessage = {
      ...message,
      timestamp: message.timestamp || new Date().toISOString()
    };

    setMessages(prevMessages => {
      const updatedMessages = [...prevMessages, newMessage];
      // Limit messages to maxMessages
      return updatedMessages.slice(-maxMessages);
    });

    return newMessage;
  }, [maxMessages]);

  // Send a user message
  const sendMessage = useCallback((content, additionalData = {}) => {
    if (!content.trim() || isLoading) return;

    const userMessage = {
      type: 'user',
      content: content.trim(),
      ...additionalData
    };

    const addedMessage = addMessage(userMessage);
    
    // Call the onMessageSent callback if provided
    if (onMessageSent) {
      onMessageSent(addedMessage);
    }

    // Simulate AI response if configured
    if (simulateAIDelay && !onAIResponse) {
      setIsLoading(true);
      setTimeout(() => {
        simulateAIResponse(content);
        setIsLoading(false);
      }, simulateAIDelay);
    }

    return addedMessage;
  }, [addMessage, isLoading, onMessageSent, simulateAIDelay, onAIResponse]);

  // Add an AI response
  const addAIResponse = useCallback((content, additionalData = {}) => {
    const aiMessage = {
      type: 'ai',
      content,
      ...additionalData
    };

    const addedMessage = addMessage(aiMessage);
    
    // Call the onAIResponse callback if provided
    if (onAIResponse) {
      onAIResponse(addedMessage);
    }

    return addedMessage;
  }, [addMessage, onAIResponse]);

  // Simulate an AI response (for demo purposes)
  const simulateAIResponse = useCallback((userMessage) => {
    const responses = [
      "I understand your question. Let me help you with that.",
      `You mentioned: "${userMessage}". That's an interesting point.`,
      "I'm here to assist you. Could you provide more details?",
      "Based on what you've shared, I'd recommend the following approach...",
      "That's a great question! Here's what I think about it:",
      "I can help you with that. Let me break it down for you."
    ];

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    addAIResponse(randomResponse);
  }, [addAIResponse]);

  // Clear all messages
  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  // Delete a specific message
  const deleteMessage = useCallback((messageIndex) => {
    setMessages(prevMessages => 
      prevMessages.filter((_, index) => index !== messageIndex)
    );
  }, []);

  // Update a specific message
  const updateMessage = useCallback((messageIndex, updates) => {
    setMessages(prevMessages => 
      prevMessages.map((msg, index) => 
        index === messageIndex ? { ...msg, ...updates } : msg
      )
    );
  }, []);

  // Get messages by type
  const getMessagesByType = useCallback((type) => {
    return messages.filter(msg => msg.type === type);
  }, [messages]);

  // Get conversation stats
  const getStats = useCallback(() => {
    return {
      totalMessages: messages.length,
      userMessages: getMessagesByType('user').length,
      aiMessages: getMessagesByType('ai').length,
      lastMessage: messages[messages.length - 1] || null,
      firstMessage: messages[0] || null
    };
  }, [messages, getMessagesByType]);

  return {
    // State
    messages,
    isLoading,
    
    // Actions
    sendMessage,
    addMessage,
    addAIResponse,
    clearMessages,
    deleteMessage,
    updateMessage,
    setIsLoading,
    
    // Utilities
    getMessagesByType,
    getStats
  };
};

export default useChat;