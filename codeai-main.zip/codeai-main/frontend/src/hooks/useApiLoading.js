import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import apiClient from '../utils/apiClient';

/**
 * Custom hook to track loading state of API requests
 * 
 * @param {string} requestId - Optional specific request ID to track (will track all requests if not provided)
 * @returns {Object} - Loading state info
 */
const useApiLoading = (requestId = null) => {
  const [isLoading, setIsLoading] = useState(false);
  const [activeRequests, setActiveRequests] = useState([]);
  const location = useLocation();

  // Reset loading state when location changes (URL navigation)
  useEffect(() => {
    // Instantly hide any loading indicators when route changes
    setIsLoading(false);
    // Don't clear active requests here as they might finish naturally
  }, [location]);

  useEffect(() => {
    // Handler for when a request starts
    const handleLoadingStart = (id) => {
      if (!requestId || requestId === id) {
        setIsLoading(true);
      }
      
      setActiveRequests((current) => {
        if (!current.includes(id)) {
          return [...current, id];
        }
        return current;
      });
    };

    // Handler for when a request ends
    const handleLoadingEnd = (id) => {
      setActiveRequests((current) => {
        const updated = current.filter(req => req !== id);
        
        // If we're tracking a specific request and it ended, or if we have no active requests
        if ((requestId === id || !requestId) && updated.length === 0) {
          setIsLoading(false);
        }
        
        return updated;
      });
    };

    // Register the loading event listeners
    apiClient.loading.onStart(handleLoadingStart);
    apiClient.loading.onEnd(handleLoadingEnd);

    // Check if there are already active requests
    const currentActive = apiClient.loading.getActiveRequests();
    if (currentActive.length > 0) {
      setActiveRequests(currentActive);
      
      // Set loading state based on current active requests
      if (requestId) {
        setIsLoading(currentActive.includes(requestId));
      } else {
        setIsLoading(true);
      }
    }

    // Cleanup function to remove event listeners
    return () => {
      apiClient.loading.offStart(handleLoadingStart);
      apiClient.loading.offEnd(handleLoadingEnd);
    };
  }, [requestId]);

  return {
    isLoading,
    activeRequests,
    activeCount: activeRequests.length
  };
};

export default useApiLoading;
