import { useState, useCallback, useRef, useEffect } from 'react';
import { useProjectContext } from '../../context';

const TOTAL_STEPS = 5;
const STEP_NAMES = {
  1: 'Project Setup',
  2: 'Document Upload', 
  3: 'Content Mapping',
  4: 'Preview Generation',
  5: 'Deployment'
};

const STEP_DESCRIPTIONS = {
  1: 'Configure your project settings and template selection',
  2: 'Upload documents and files for conversion',
  3: 'Map content and review component structure',
  4: 'Generate and review preview of your site',
  5: 'Configure deployment settings and go live'
};

export const useProjectWizard = () => {
  const { 
    currentStep, 
    setCurrentStep, 
    projectData, 
    updateProjectData,
    setError,
    resetError 
  } = useProjectContext();
  
  const [stepErrors, setStepErrors] = useState({});
  const [completedSteps, setCompletedSteps] = useState(new Set());
  
  // Timer management states
  const [elapsedTime, setElapsedTime] = useState('0:00');
  const [apiStartTime, setApiStartTime] = useState(null);
  const [timerInterval, setTimerInterval] = useState(null);
  const timerIntervalRef = useRef(null);
  
  // Data states that were in original component
  const [kbMetadata, setKbMetadata] = useState(null);
  const [analysisMetadata, setAnalysisMetadata] = useState(null);
  const [projectAnalysis, setProjectAnalysis] = useState([]);
  const [documentHierarchy, setDocumentHierarchy] = useState([]);
  
  // Loading states
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalysisLoading, setIsAnalysisLoading] = useState(true);
  const [isAnalysisDataLoading, setIsAnalysisDataLoading] = useState(true);

  const goToStep = useCallback((stepNumber) => {
    console.log(`🎯 goToStep called: attempting to go to step ${stepNumber} (current: ${currentStep})`);
    
    if (stepNumber >= 1 && stepNumber <= TOTAL_STEPS) {
      console.log(`✅ Valid step number ${stepNumber} - calling setCurrentStep`);
      setCurrentStep(stepNumber);
      resetError('step');
      console.log(`🎯 setCurrentStep(${stepNumber}) called successfully`);
    } else {
      console.error(`❌ Invalid step number: ${stepNumber}. Must be between 1 and ${TOTAL_STEPS}`);
    }
  }, [setCurrentStep, resetError, currentStep]);

  const nextStep = useCallback(async () => {
    console.log(`🔄 NEXTSTEP CALLED - Moving from step ${currentStep}`);
    console.log('🔍 NextStep validation data:', {
      currentStep,
      kbMetadata: !!kbMetadata,
      projectData,
      totalSteps: TOTAL_STEPS
    });
    
    if (currentStep < TOTAL_STEPS) {
      try {
        // Simplified validation logic - allow progression after successful API calls
        let isValid = true; // Default to true, override for specific cases
        
        switch (currentStep) {
          case 1:
            // For Step 1, check if we have basic project setup OR kbMetadata loaded
            // Be more lenient to allow progression after API success
            const hasKbData = kbMetadata !== null;
            const hasBasicProject = projectData && (projectData.step1Complete || projectData.contentMappingInitiated);
            isValid = hasKbData || hasBasicProject;
            console.log('🔍 Step 1 validation details:', {
              hasKbData,
              hasBasicProject,
              kbMetadata,
              projectDataKeys: projectData ? Object.keys(projectData) : 'null',
              step1Complete: projectData?.step1Complete,
              contentMappingInitiated: projectData?.contentMappingInitiated,
              finalResult: isValid
            });
            break;
          case 2:
            // For Step 2, allow progression after content mapping
            isValid = true; // Allow progression if we reach this point
            break;
          case 3:
            // For Step 3, allow progression after documentation generation
            isValid = true;
            break;
          case 4:
            // For Step 4, allow progression after testing setup
            isValid = true;
            break;
          case 5:
            // Final step validation
            isValid = true;
            break;
          default:
            isValid = true;
        }
        
        console.log(`🔍 Step ${currentStep} validation result:`, isValid);
        
        if (isValid) {
          console.log(`✅ Validation passed - marking step ${currentStep} complete and moving to ${currentStep + 1}`);
          setCompletedSteps(prev => new Set([...prev, currentStep]));
          console.log(`🚀 Calling goToStep(${currentStep + 1})`);
          goToStep(currentStep + 1);
          console.log(`✅ Successfully moved to step ${currentStep + 1}`);
          return true;
        } else {
          console.log(`❌ Step ${currentStep} validation failed - staying on current step`);
        }
        return false;
      } catch (error) {
        console.error('📋 Error in nextStep:', error);
        if (setError) {
          setError('step', error.message);
        }
        return false;
      }
    }
    return false;
  }, [currentStep, goToStep, setError, kbMetadata, projectData]);

  const previousStep = useCallback(() => {
    if (currentStep > 1) {
      goToStep(currentStep - 1);
    }
  }, [currentStep, goToStep]);

  const validateCurrentStep = useCallback(async () => {
    try {
      const isValid = await validateStep(currentStep, projectData);
      if (!isValid) {
        const errorMessage = getStepValidationError(currentStep);
        setStepErrors(prev => ({ ...prev, [currentStep]: errorMessage }));
        return false;
      }
      setStepErrors(prev => ({ ...prev, [currentStep]: null }));
      return true;
    } catch (error) {
      setStepErrors(prev => ({ ...prev, [currentStep]: error.message }));
      return false;
    }
  }, [currentStep, projectData]);

  const validateStep = useCallback(async (stepNumber, data) => {
    // If no data provided, use current projectData
    const validationData = data || projectData;
    
    // Safety check - if no data available, return false for steps that require data
    if (!validationData && stepNumber > 1) {
      return false;
    }
    
    switch (stepNumber) {
      case 1:
        return validationData && validationData.name && validationData.description && validationData.template;
      case 2:
        return validationData && validationData.files && validationData.files.length > 0;
      case 3:
        return validationData && validationData.contentMapping && validationData.contentMapping.isValid;
      case 4:
        return validationData && validationData.preview && validationData.preview.generated;
      case 5:
        return validationData && validationData.deployment && validationData.deployment.configured;
      default:
        return true;
    }
  }, [projectData]);

  const getStepValidationError = useCallback((stepNumber) => {
    switch (stepNumber) {
      case 1:
        return 'Please provide project name, description, and select a template';
      case 2:
        return 'Please upload at least one document';
      case 3:
        return 'Please complete the content mapping process';
      case 4:
        return 'Please generate the preview';
      case 5:
        return 'Please configure deployment settings';
      default:
        return 'Validation failed';
    }
  }, []);

  const markStepComplete = useCallback((stepNumber) => {
    setCompletedSteps(prev => new Set([...prev, stepNumber]));
  }, []);

  const isStepComplete = (step) => {
    return completedSteps.has(step);
  };

  // Timer management
  const startTimer = () => {
    const startTime = Date.now();
    setApiStartTime(startTime);

    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const minutes = Math.floor(elapsed / 60);
      const seconds = elapsed % 60;
      setElapsedTime(`${minutes}:${seconds.toString().padStart(2, '0')}`);
    }, 1000);

    setTimerInterval(interval);
  };

  const stopTimer = () => {
    if (timerInterval) {
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
  };

  // Reset timer when component unmounts
  useEffect(() => {
    return () => {
      if (timerInterval) {
        clearInterval(timerInterval);
      }
    };
  }, [timerInterval]);

  // Data loading functions
  const updateKbMetadata = (data) => {
    setKbMetadata(data);
    setIsLoading(false);
  };

  const updateAnalysisMetadata = (data) => {
    setAnalysisMetadata(data);
    setIsAnalysisLoading(false);
  };

  const updateProjectAnalysis = (data) => {
    setProjectAnalysis(data);
    setIsAnalysisDataLoading(false);
  };

  const updateDocumentHierarchy = (data) => {
    setDocumentHierarchy(data);
  };

  // Reset all data
  const resetWizard = () => {
    setCurrentStep(1);
    setCompletedSteps(new Set());
    setKbMetadata(null);
    setAnalysisMetadata(null);
    setProjectAnalysis([]);
    setDocumentHierarchy([]);
    setIsLoading(true);
    setIsAnalysisLoading(true);
    setIsAnalysisDataLoading(true);
    stopTimer();
    setElapsedTime('0:00');
  };

  // Save progress to localStorage
  const saveProgress = useCallback(() => {
    if (!projectData) return;
    
    try {
      const progressData = {
        currentStep,
        completedSteps: Array.from(completedSteps),
        projectData,
        kbMetadata,
        analysisMetadata,
        projectAnalysis,
        documentHierarchy,
        timestamp: new Date().toISOString()
      };
      
      const key = `wizard_progress_${projectData.id || 'temp'}`;
      localStorage.setItem(key, JSON.stringify(progressData));        
        // Save successful
      } catch (error) {
      console.error('Failed to save progress:', error);
    }
  }, [currentStep, completedSteps, projectData, kbMetadata, analysisMetadata, projectAnalysis, documentHierarchy]);

  // Load progress from localStorage
  const loadProgress = useCallback((projectId) => {
    if (!projectId) return;
    
    try {
      const key = `wizard_progress_${projectId}`;
      const savedData = localStorage.getItem(key);
      
      if (savedData) {
        const progressData = JSON.parse(savedData);
        
        // Restore wizard state
        setCurrentStep(progressData.currentStep || progressData.activeStep || 1);
        setCompletedSteps(new Set(progressData.completedSteps || []));
        setKbMetadata(progressData.kbMetadata || null);
        setAnalysisMetadata(progressData.analysisMetadata || null);
        setProjectAnalysis(progressData.projectAnalysis || []);
        setDocumentHierarchy(progressData.documentHierarchy || []);
        
        // Update project data if needed
        if (progressData.projectData && updateProjectData) {
          updateProjectData(progressData.projectData);
        }
        
        // Progress loaded successfully
      }
    } catch (error) {
      console.error('Failed to load progress:', error);
    }
  }, [updateProjectData]);

  return {
    // Step management - use currentStep from context instead of activeStep
    activeStep: currentStep,
    currentStep,
    completedSteps,
    goToStep,
    nextStep,
    previousStep,
    markStepComplete,
    isStepComplete,

    // Project data from context
    projectData,
    updateProjectData,

    // Data states
    kbMetadata,
    analysisMetadata,
    projectAnalysis,
    documentHierarchy,

    // Loading states
    isLoading,
    isAnalysisLoading,
    isAnalysisDataLoading,

    // Timer states
    elapsedTime,
    apiStartTime,
    timer: { elapsed: elapsedTime },

    // Actions
    updateKbMetadata,
    updateAnalysisMetadata,
    updateProjectAnalysis,
    updateDocumentHierarchy,
    startTimer,
    stopTimer,
    resetWizard,
    saveProgress,
    loadProgress,

    // Validation and errors
    validateStep,
    errors: {}, // Add empty errors object for now

    // Computed values
    isFirstStep: currentStep === 1,
    isLastStep: currentStep === 5,
    canGoNext: currentStep < 5,
    canGoPrevious: currentStep > 1
  };
};

export default useProjectWizard;
