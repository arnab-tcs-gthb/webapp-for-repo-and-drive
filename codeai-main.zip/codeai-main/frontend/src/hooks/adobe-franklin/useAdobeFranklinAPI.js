import { useState, useEffect, useCallback, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import ApiServiceEnhanced from '../../services/ApiServiceEnhanced';
import useApiLoading from '../useApiLoading';
import config from '../../config/config';

/**
 * Custom hook for managing Adobe Franklin API calls
 * 
 * This hook integrates all the missing API functionality from the original
 * monolithic component, including:
 * - KB metadata fetching
 * - Project metadata and analysis
 * - Image captioning preparation
 * - Mapping data posting
 * - Documentation generation
 * - Project images fetching
 * - Project analysis data fetching
 */
export const useAdobeFranklinAPI = (initialProjectId = null) => {
  const location = useLocation();
  
  // State from original component
  const [projectId, setProjectId] = useState(initialProjectId);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [kbMetadata, setKbMetadata] = useState(null);
  const [analysisMetadata, setAnalysisMetadata] = useState(null);
  const [projectAnalysis, setProjectAnalysis] = useState([]);
  const [documentHierarchy, setDocumentHierarchy] = useState([]);
  
  // Loading states
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalysisLoading, setIsAnalysisLoading] = useState(true);
  const [isAnalysisDataLoading, setIsAnalysisDataLoading] = useState(true);
  const [isDocumentationLoading, setIsDocumentationLoading] = useState(false);
  
  // Track specific documentation generation request
  const { isLoading: isDocGenerationLoading } = useApiLoading(`generate-doc-${projectId}`);
  
  // Timer states for API operations
  const [apiStartTime, setApiStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState('0:00');
  const [timerInterval, setTimerInterval] = useState(null);

  // Ref to track captioning calls and prevent duplicates
  const captioningCallsRef = useRef(new Set());

  // Project details from route state
  const project_details = location.state?.project || null;

  /**
   * Initialize project ID from passed parameter, route state, or localStorage
   */
  useEffect(() => {
    let pid = initialProjectId; // Prioritize passed project ID
    
    if (!pid) {
      pid = project_details?.id;
    }
    if (!pid && location.state?.projectId) {
      pid = location.state.projectId;
    } else if (!pid && localStorage.getItem('project_id')) {
      pid = localStorage.getItem('project_id');
    }
    
    if (pid && pid !== projectId) {
      setProjectId(pid);
    }
  }, [initialProjectId, location.state, project_details, projectId]);

  // Wrap these functions in useCallback
  const fetchProjectImages = useCallback(async () => {
    if (!projectId) return;
    
    try {
      const images = await ApiServiceEnhanced.getProjectImages(projectId);
      
      // Map backend image data to frontend file structure
      const mappedFiles = images.map(img => {
        const baseUrl = config.API_BASE_URL.replace('/api/v1', '');
        // Ensure no double slashes in the URL and convert backslashes to slashes
        const cleanPath = img.filepath.replace(/\\/g, '/');
        return {
          name: img.filename,
          extension: img.filename.split('.').pop().toLowerCase(),
          size: img.file_size,
          previewUrl: `${baseUrl}/${cleanPath}`,
          id: img.id
        };
      });
      
      setUploadedFiles(mappedFiles);
    } catch (error) {
      console.error('Error fetching project images:', error);
      setUploadedFiles([]);
    }
  }, [projectId]); // Add projectId as dependency
  /**
   * Try to load analysis metadata from cached sources without making an API call
   * Returns true if cached data was found and loaded, false otherwise
   */  const loadCachedAnalysisMetadata = useCallback(() => {
    if (!projectId) {
      console.log('⚠️ Cannot load cached analysis: No project ID provided');
      return false;
    }
    
    try {
      // Check if we have analysis metadata in localStorage
      const storageKey = `analysis_metadata_${projectId}`;
      const storedMetadata = localStorage.getItem(storageKey);
      const timestampKey = `${storageKey}_timestamp`;
      const storedTimestamp = localStorage.getItem(timestampKey);
      
      if (storedMetadata) {
        try {
          const parsedMetadata = JSON.parse(storedMetadata);
          console.log('📋 Loaded cached analysis metadata from localStorage');
          
          // Get the timestamp when the analysis was performed
          const analysisTime = storedTimestamp ? new Date(storedTimestamp) : 'Unknown time';
          console.log(`📅 Analysis was last performed at: ${analysisTime}`);
          
          // Check if metadata is valid by checking for essential properties
          if (parsedMetadata && (parsedMetadata.llm_response || parsedMetadata.images)) {
            console.log('✅ Using cached analysis metadata from previous session');
            setAnalysisMetadata(parsedMetadata);
            setIsAnalysisLoading(false); // Turn off loading indicator since we have data
            return true;
          } else {
            console.warn('⚠️ Cached metadata exists but appears invalid');
            localStorage.removeItem(storageKey); // Remove invalid data
          }
        } catch (parseError) {
          console.error('❌ Error parsing cached analysis metadata:', parseError);
          localStorage.removeItem(storageKey); // Remove invalid data
        }
      } else {
        console.log('ℹ️ No cached analysis metadata found for project:', projectId);
      }
      
      return false;
    } catch (error) {
      console.error('❌ Error accessing localStorage:', error);
      return false;
    }
  }, [projectId, setAnalysisMetadata, setIsAnalysisLoading]);

  /**
   * Fetch analysis metadata for a specific step
   * Includes image captioning preparation and metadata fetching
   */  const fetchAnalysisMetadata = useCallback(async (forceRefetch = false) => {
    const targetProjectId = projectId || project_details?.id;
    if (!targetProjectId) {
      console.warn('No project ID available for analysis metadata fetch');
      return;
    }
    
    // If we already have metadata and not forcing a refresh, return early
    if (analysisMetadata && !forceRefetch) {
      console.log('Using cached analysis metadata - set forceRefetch=true to refresh');
      return;
    }
    
    console.log(`🔍 Starting analysis metadata fetch for project ${targetProjectId}${forceRefetch ? ' (forced)' : ''}`);
    
    // Use both sessionStorage and ref to prevent duplicate calls
    const captioningKey = `captioning_${targetProjectId}`;
    const isAlreadyProcessing = sessionStorage.getItem(captioningKey) || 
                               captioningCallsRef.current.has(targetProjectId);
    
    setIsAnalysisLoading(true);
    try {
      // First call prepareCaptioning and check if response is successful
      let captioningSuccess = false;
      
      // Only call prepareCaptioning if not already processing or force refetch
      if (!isAlreadyProcessing || forceRefetch) {
        // Mark as processing in both storage mechanisms
          try {
          // Always fetch metadata after prepareCaptioning completes (or fails)
          const metadataResult = await ApiServiceEnhanced.getMetadata(targetProjectId);
          // Store the metadata in localStorage for future use
          try {
            const storageKey = `analysis_metadata_${targetProjectId}`;
            localStorage.setItem(storageKey, JSON.stringify(metadataResult));
            // Also save a timestamp to know when this analysis was performed
            localStorage.setItem(`${storageKey}_timestamp`, new Date().toISOString());
          } catch (storageError) {
            console.warn('Failed to store analysis metadata in localStorage:', storageError);
          }
          setAnalysisMetadata(metadataResult);
        } catch (error) {
          console.error('❌ Error in analysis process:', error);
          throw error; // Rethrow to be caught by outer try/catch
        } finally {
          // Clean up processing flags
          sessionStorage.removeItem(captioningKey);
          if (forceRefetch) {
            // Remove from ref if this was a forced refresh
            captioningCallsRef.current.delete(targetProjectId);
          }
        }
      } else {
        console.log(`⏭️ Skipping caption-images API call for project ${targetProjectId} (already processed)`);
          // Even if we skipped captioning, still try to fetch metadata
        try {
          console.log('📊 Fetching analysis metadata (captioning skipped)...');
          const metadataResult = await ApiServiceEnhanced.getMetadata(targetProjectId);
          console.log('✅ Analysis metadata fetched successfully', metadataResult);
          setAnalysisMetadata(metadataResult);
          captioningSuccess = true;
        } catch (metadataError) {
          console.error('❌ Error fetching metadata:', metadataError);
          throw metadataError;
        }
      }
      
      return true; // Return success indicator
    } catch (error) {
      console.error('❌ Error in analysis metadata process:', error);
      throw error; // Rethrow for the caller to handle
    } finally {
      setIsAnalysisLoading(false);
    }
  }, [projectId, project_details?.id, analysisMetadata]); // Add projectId as dependency

  /**
   * Fetch KB metadata from API
   */
  const fetchKbMetadata = useCallback(async () => {
    try {
      const metadata = await ApiServiceEnhanced.getKBMetadata();
      setKbMetadata(metadata);
    } catch (error) {
      console.error('Error fetching kbMetadata:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Fetch project analysis data with timer
   */
  const fetchProjectAnalysis = useCallback(async () => {
    if (!projectId) return;
    // Start the timer
    const startTime = new Date();
    setApiStartTime(startTime);
    setIsAnalysisDataLoading(true);
    // Set up interval to update elapsed time every second
    const interval = setInterval(() => {
      const currentTime = new Date();
      const timeElapsed = Math.floor((currentTime - startTime) / 1000); // in seconds
      const minutes = Math.floor(timeElapsed / 60);
      const seconds = timeElapsed % 60;
      setElapsedTime(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
    }, 1000);
    setTimerInterval(interval);
    try {
      const data = await ApiServiceEnhanced.getProjectAnalysis(projectId);
      setProjectAnalysis(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to fetch project analysis:', error);
      setProjectAnalysis([]);
    } finally {
      setIsAnalysisDataLoading(false);
      // Keep the timer running to show total elapsed time
    }
  }, [projectId]);

  /**
   * Post mapping data to API
   */
  const postMappingData = useCallback(async (llmResponseData) => {
    if (!projectId) throw new Error('Project ID is required for posting mapping data');
    try {
      const result = await ApiServiceEnhanced.postMappingData(projectId, llmResponseData);
      console.log('Mapping API raw response:', result);
      // Transform result to expected structure for UI
      const transformed = Array.isArray(result)
        ? result.map((item, idx) => {
            // Calculate llm_analysis for UI statistics
            const llm_analysis = {
              reusable_components: Array.isArray(item.mapped_data)
                ? item.mapped_data.filter(md => md.element_type === 'global').length
                : 0,
              total_components: Array.isArray(item.mapped_data)
                ? item.mapped_data.length
                : 0
            };
            return {
              id: item.page_title || idx,
              filename: (item.page_title ? item.page_title.replace(/\s+/g, '_') : `Page_${idx+1}`) + '.json',
              llm_response: JSON.stringify({
                page_title: item.page_title,
                mapped_data: item.mapped_data,
                not_found_block: item.not_found_block,
                global_block_number: item.global_block_number,
                block_used: item.block_used
              }),
              page_title: item.page_title,
              mapped_data: item.mapped_data,
              not_found_block: item.not_found_block,
              global_block_number: item.global_block_number,
              block_used: item.block_used,
              llm_analysis // <-- add for UI
            };
          })
        : [];
      console.log('Transformed projectAnalysis for UI:', transformed);
      setProjectAnalysis(transformed);
      return true;
    } catch (error) {
      console.error('Error posting mapping data:', error);
      setProjectAnalysis([]);
      return false;
    }
  }, [projectId]);

  /**
   * Generate documentation for project
   */
  const generateDocumentation = useCallback(async () => {
    if (!projectId) {
      throw new Error('Project ID is required for generating documentation');
    }
    
    try {
      setIsDocumentationLoading(true);
      const hierarchy = await ApiServiceEnhanced.generateDocumentation(projectId);
      setDocumentHierarchy(hierarchy);
      return hierarchy;
    } catch (error) {
      console.error('Error generating documentation:', error);
      throw error;
    } finally {
      setIsDocumentationLoading(false);
    }
  }, [projectId]);

  /**
   * Fetch UAT testing data for a project
   */
  const getUATData = useCallback(async (pageId = '') => {
    if (!projectId) {
      throw new Error('Project ID is required for fetching UAT data');
    }
    
    try {
      const data = await ApiServiceEnhanced.getUATData(projectId, pageId);
      return data;
    } catch (error) {
      console.error('❌ Error fetching UAT data:', error);
      throw error;
    }
  }, [projectId]);

  /**
   * Handle step-specific API calls
   */
  const executeStepAction = useCallback(async (stepNumber) => {
    switch (stepNumber) {
      case 1:
        // Content Mapping step - post mapping data
        try {
          const llmResponseData = analysisMetadata?.llm_response || [];
          await postMappingData(llmResponseData);
          return { success: true, message: 'Mapping completed successfully!' };
        } catch (error) {
          return { success: false, message: `Mapping failed: ${error.message}` };
        }

      case 2:
        // Generate Documentation step
        try {
          await generateDocumentation(projectId);
          return { success: true, message: 'Documentation generated successfully!' };
        } catch (error) {
          return { success: false, message: `Documentation generation failed: ${error.message}` };
        }

      case 3:
        // Start project analysis for preview generation
        try {
          await fetchProjectAnalysis();
          return { success: true, message: 'Analysis started successfully!' };
        } catch (error) {
          return { success: false, message: `Analysis failed: ${error.message}` };
        }

      default:
        return { success: true, message: 'Step action completed' };
    }
  }, [analysisMetadata, postMappingData, generateDocumentation, fetchProjectAnalysis]);
  /**
   * Auto-fetch KB metadata on mount
   */
  useEffect(() => {
    fetchKbMetadata();
  }, []); // Only run once on mount
  
  /**
   * Auto-fetch project images when projectId is available
   * Note: We don't auto-fetch analysis metadata to avoid unnecessary API calls
   */
  useEffect(() => {
    if (projectId) {
      // Only fetch project images automatically
      fetchProjectImages();
      
      // Try to load analysis metadata from cached sources without API call
      // This will show previously analyzed metadata if available
      loadCachedAnalysisMetadata();
    }
  }, [projectId, fetchProjectImages, loadCachedAnalysisMetadata]); // Include loadCachedAnalysisMetadata in dependencies

  /**
   * Clean up timers
   */
  const stopTimer = useCallback(() => {
    if (timerInterval) {
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
  }, [timerInterval]);

  /**
   * Reset all data
   */
  const resetData = useCallback(() => {
    setProjectId(null);
    setUploadedFiles([]);
    setKbMetadata(null);
    setAnalysisMetadata(null);
    setProjectAnalysis([]);
    setDocumentHierarchy([]);
    setIsLoading(true);
    setIsAnalysisLoading(true);
    setIsAnalysisDataLoading(true);
    setIsDocumentationLoading(false);
    stopTimer();
    setElapsedTime('0:00');
    // Clear captioning call tracking
    captioningCallsRef.current.clear();
  }, [stopTimer]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopTimer();
    };
  }, [stopTimer]);

  return {
    // Data states
    projectId,
    uploadedFiles,
    kbMetadata,
    analysisMetadata,
    projectAnalysis,
    documentHierarchy,
    project_details,    // Loading states
    isLoading,
    isAnalysisLoading,
    setIsAnalysisLoading,
    isAnalysisDataLoading,
    isDocumentationLoading,
    isDocGenerationLoading,

    // Timer states
    apiStartTime,
    elapsedTime,

    // API functions    fetchKbMetadata,
    fetchAnalysisMetadata,
    loadCachedAnalysisMetadata,
    fetchProjectImages,
    fetchProjectAnalysis,
    postMappingData,
    generateDocumentation,
    executeStepAction,
    getUATData, // Expose getUATData function

    // Utility functions
    stopTimer,
    resetData
  };
};

export default useAdobeFranklinAPI;