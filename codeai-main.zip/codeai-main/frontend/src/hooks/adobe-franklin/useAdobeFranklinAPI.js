import { useState, useEffect, useCallback, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import ApiServiceEnhanced from '../../services/ApiServiceEnhanced';
import config from '../../config/config';

/**
 * Custom hook for managing Adobe Franklin API calls
 * 
 * This hook integrates all the missing API functionality from the original
 * monolithic component, including:
 * - KB metadata fetching
 * - Project metadata and analysis
 * - Image captioning preparation
 * - Mapping data posting
 * - Documentation generation
 * - Project images fetching
 * - Project analysis data fetching
 */
export const useAdobeFranklinAPI = (initialProjectId = null) => {
  const location = useLocation();
  
  // State from original component
  const [projectId, setProjectId] = useState(initialProjectId);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [kbMetadata, setKbMetadata] = useState(null);
  const [analysisMetadata, setAnalysisMetadata] = useState(null);
  const [projectAnalysis, setProjectAnalysis] = useState([]);
  const [documentHierarchy, setDocumentHierarchy] = useState([]);
  
  // Loading states
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalysisLoading, setIsAnalysisLoading] = useState(true);
  const [isAnalysisDataLoading, setIsAnalysisDataLoading] = useState(true);
  
  // Timer states for API operations
  const [apiStartTime, setApiStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState('0:00');
  const [timerInterval, setTimerInterval] = useState(null);

  // Ref to track captioning calls and prevent duplicates
  const captioningCallsRef = useRef(new Set());

  // Project details from route state
  const project_details = location.state?.project || null;

  /**
   * Initialize project ID from passed parameter, route state, or localStorage
   */
  useEffect(() => {
    let pid = initialProjectId; // Prioritize passed project ID
    
    if (!pid) {
      pid = project_details?.id;
    }
    if (!pid && location.state?.projectId) {
      pid = location.state.projectId;
    } else if (!pid && localStorage.getItem('project_id')) {
      pid = localStorage.getItem('project_id');
    }
    
    if (pid && pid !== projectId) {
      setProjectId(pid);
    }
  }, [initialProjectId, location.state, project_details, projectId]);

  /**
   * Fetch KB metadata from API
   */
  const fetchKbMetadata = useCallback(async () => {
    try {
      const metadata = await ApiServiceEnhanced.getKBMetadata();
      setKbMetadata(metadata);
    } catch (error) {
      console.error('Error fetching kbMetadata:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Fetch analysis metadata for a specific step
   * Includes image captioning preparation and metadata fetching
   */
  const fetchAnalysisMetadata = useCallback(async (forceRefetch = false) => {
    const targetProjectId = projectId || project_details?.id;
    if (!targetProjectId) {
      console.warn('No project ID available for analysis metadata fetch');
      return;
    }
    
    if (analysisMetadata && !forceRefetch) return;
    
    // Use both sessionStorage and ref to prevent duplicate calls
    const captioningKey = `captioning_${targetProjectId}`;
    const isAlreadyProcessing = sessionStorage.getItem(captioningKey) || 
                               captioningCallsRef.current.has(targetProjectId);
    
    setIsAnalysisLoading(true);
    try {
      // First call prepareCaptioning and check if response is successful
      let captioningSuccess = false;
      
      // Only call prepareCaptioning if not already processing
      if (!isAlreadyProcessing) {
        // Mark as processing in both storage mechanisms
        sessionStorage.setItem(captioningKey, 'processing');
        captioningCallsRef.current.add(targetProjectId);
        
        try {
          // Await prepareCaptioning first
          const captioningResponse = await ApiServiceEnhanced.prepareCaptioning(targetProjectId);
          captioningSuccess = captioningResponse && captioningResponse.status === 200;

          // Always fetch metadata after prepareCaptioning completes
          const metadata = await ApiServiceEnhanced.getMetadata(targetProjectId);
          setAnalysisMetadata(metadata);
        } catch (captioningError) {
          console.error('Error preparing image captions or fetching metadata:', captioningError);
          // Continue cleanup even if either call fails
        } finally {
          // Clean up processing flags
          sessionStorage.removeItem(captioningKey);
          // Keep the ref entry to prevent future duplicate calls for this project
        }
      } else {
        console.log(`⏭️ Skipping caption-images API call for project ${targetProjectId} (already processed)`);
        captioningSuccess = true; // Assume previous call was successful
      }
    } catch (error) {
      console.error('Error fetching analysisMetadata:', error);
    } finally {
      setIsAnalysisLoading(false);
    }
  }, [projectId, project_details?.id, analysisMetadata]);

  /**
   * Fetch uploaded images when project ID is available
   */
  useEffect(() => {
    if (projectId) {
      fetchProjectImages();
    }
  }, [projectId]);

  /**
   * Fetch KB metadata on component mount
   */
  useEffect(() => {
    fetchKbMetadata();
  }, [fetchKbMetadata]);

  /**
   * Fetch analysis metadata after KB metadata is loaded and project ID is available
   * Only trigger once per unique project ID
   */
  useEffect(() => {
    if (kbMetadata && projectId && !analysisMetadata && !captioningCallsRef.current.has(projectId)) {
      fetchAnalysisMetadata();
    }
  }, [kbMetadata, projectId, analysisMetadata]); // Removed fetchAnalysisMetadata from deps to prevent retriggering

  /**
   * Fetch project images from backend
   */
  const fetchProjectImages = useCallback(async () => {
    if (!projectId) return;
    
    try {
      const images = await ApiServiceEnhanced.getProjectImages(projectId);
      
      // Map backend image data to frontend file structure
      const mappedFiles = images.map(img => {
        const baseUrl = config.API_BASE_URL.replace('/api/v1', '');
        // Ensure no double slashes in the URL and convert backslashes to slashes
        const cleanPath = img.filepath.replace(/\\/g, '/');
        return {
          name: img.filename,
          extension: img.filename.split('.').pop().toLowerCase(),
          size: img.file_size,
          previewUrl: `${baseUrl}/${cleanPath}`,
          id: img.id
        };
      });
      
      setUploadedFiles(mappedFiles);
    } catch (error) {
      console.error('Error fetching project images:', error);
      setUploadedFiles([]);
    }
  }, [projectId]);

  /**
   * Fetch project analysis data with timer
   */
  const fetchProjectAnalysis = useCallback(async () => {
    if (!projectId) return;
    
    // Start the timer
    const startTime = new Date();
    setApiStartTime(startTime);
    setIsAnalysisDataLoading(true);

    // Set up interval to update elapsed time every second
    const interval = setInterval(() => {
      const currentTime = new Date();
      const timeElapsed = Math.floor((currentTime - startTime) / 1000); // in seconds
      const minutes = Math.floor(timeElapsed / 60);
      const seconds = timeElapsed % 60;
      setElapsedTime(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
    }, 1000);

    setTimerInterval(interval);

    try {
      const data = await ApiServiceEnhanced.getProjectAnalysis(projectId);
      setProjectAnalysis(data);
    } catch (error) {
      console.error('Failed to fetch project analysis:', error);
      setProjectAnalysis([]);
    } finally {
      setIsAnalysisDataLoading(false);
      // Keep the timer running to show total elapsed time
    }
  }, [projectId]);

  /**
   * Post mapping data to API
   */
  const postMappingData = useCallback(async (llmResponseData) => {
    if (!projectId) {
      throw new Error('Project ID is required for posting mapping data');
    }
    
    try {
      await ApiServiceEnhanced.postMappingData(projectId, llmResponseData);
      return true;
    } catch (error) {
      console.error('Error posting mapping data:', error);
      throw error;
    }
  }, [projectId]);

  /**
   * Generate documentation for project
   */
  const generateDocumentation = useCallback(async () => {
    if (!projectId) {
      throw new Error('Project ID is required for generating documentation');
    }
    
    try {
      const hierarchy = await ApiServiceEnhanced.generateDocumentation(projectId);
      setDocumentHierarchy(hierarchy);
      return hierarchy;
    } catch (error) {
      console.error('Error generating documentation:', error);
      throw error;
    }
  }, [projectId]);

  /**
   * Handle step-specific API calls
   */
  const executeStepAction = useCallback(async (stepNumber) => {
    switch (stepNumber) {
      case 1:
        // Content Mapping step - post mapping data
        try {
          const llmResponseData = analysisMetadata?.llm_response || [];
          await postMappingData(llmResponseData);
          return { success: true, message: 'Mapping completed successfully!' };
        } catch (error) {
          return { success: false, message: `Mapping failed: ${error.message}` };
        }

      case 2:
        // Generate Documentation step
        try {
          await generateDocumentation(projectId);
          return { success: true, message: 'Documentation generated successfully!' };
        } catch (error) {
          return { success: false, message: `Documentation generation failed: ${error.message}` };
        }

      case 3:
        // Start project analysis for preview generation
        try {
          await fetchProjectAnalysis();
          return { success: true, message: 'Analysis started successfully!' };
        } catch (error) {
          return { success: false, message: `Analysis failed: ${error.message}` };
        }

      default:
        return { success: true, message: 'Step action completed' };
    }
  }, [analysisMetadata, postMappingData, generateDocumentation, fetchProjectAnalysis]);

  /**
   * Auto-fetch KB metadata on mount
   */
  useEffect(() => {
    fetchKbMetadata();
  }, []); // Only run once on mount

  /**
   * Auto-fetch analysis metadata when projectId is available
   */
  useEffect(() => {
    if (projectId) {
      fetchAnalysisMetadata();
      fetchProjectImages();
    }
  }, [projectId]); // Only depend on projectId

  /**
   * Clean up timers
   */
  const stopTimer = useCallback(() => {
    if (timerInterval) {
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
  }, [timerInterval]);

  /**
   * Reset all data
   */
  const resetData = useCallback(() => {
    setProjectId(null);
    setUploadedFiles([]);
    setKbMetadata(null);
    setAnalysisMetadata(null);
    setProjectAnalysis([]);
    setDocumentHierarchy([]);
    setIsLoading(true);
    setIsAnalysisLoading(true);
    setIsAnalysisDataLoading(true);
    stopTimer();
    setElapsedTime('0:00');
    // Clear captioning call tracking
    captioningCallsRef.current.clear();
  }, [stopTimer]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopTimer();
    };
  }, [stopTimer]);

  return {
    // Data states
    projectId,
    uploadedFiles,
    kbMetadata,
    analysisMetadata,
    projectAnalysis,
    documentHierarchy,
    project_details,

    // Loading states
    isLoading,
    isAnalysisLoading,
    isAnalysisDataLoading,

    // Timer states
    apiStartTime,
    elapsedTime,

    // API functions
    fetchKbMetadata,
    fetchAnalysisMetadata,
    fetchProjectImages,
    fetchProjectAnalysis,
    postMappingData,
    generateDocumentation,
    executeStepAction,

    // Utility functions
    stopTimer,
    resetData
  };
};

export default useAdobeFranklinAPI;
