# AI Builder Frontend

This is the frontend application for AI Builder, a platform for creating and managing AI-powered web projects.

## Key Features

- Project creation and management
- AI-assisted code generation
- **Adobe Franklin Integration** - Step-by-step wizard for creating Adobe Franklin projects
- Component-level loading state management
- Theme support (light/dark mode)
- Toast notification system
- Modular React architecture with Context API

## Adobe Franklin Project Wizard

The Adobe Franklin project wizard has been refactored into a modular architecture with:

### Architecture Components
- **Context Providers**: `ProjectContext` and `FileContext` for state management
- **Custom Hooks**: `useProjectWizard` and `useFileManagement` for complex logic
- **Styled Components**: Organized in `/styled` directory by purpose
- **Step Components**: Modular wizard steps in `/steps` directory

### Project Creation Steps
1. **Project Setup** - Configure basic project information
2. **Content Mapping** - Map content structure and components  
3. **Preview Generation** - Generate and review site preview
4. **Testing** - Test functionality and performance
5. **Deployment** - Deploy to production

### File Structure
```
src/components/wizard/
├── AdobeFranklinProject.js          # Main orchestrator
├── context/                         # State management
├── hooks/                           # Custom hooks
├── styled/                          # Styled components
├── steps/                           # Wizard steps
└── types/                           # Type definitions
```

## Component-Level Loading System

We've implemented a component-level loading system that replaces the global loading overlay. This allows for more granular control of loading states and a better user experience.

### Key Components

- `LoadingStates.js`: Contains reusable loading components (spinners, skeletons)
- `GlobalLoadingIndicator.js`: Subtle progress bar at the top of the screen
- `LoadingStatus.js`: Status indicator for longer operations
- `useApiLoading.js`: Hook to track API loading states
- `apiClient.js`: Enhanced Axios client with loading state management

For detailed documentation, see [loading-implementation.md](./src/docs/loading-implementation.md).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
