from app.models.page_uat import PageUAT
from app.schemas.jira_schemas import PageUATCreate
from fastapi import HTTPException
from sqlalchemy import and_

class PageUATRepository:
    def __init__(self, db=None):
        self.db = db

    def get_data_by_id(self, **kwargs):
        try:
            filters = [getattr(PageUAT, key) == value for key, value in kwargs.items() if hasattr(PageUAT, key)]
            if filters:
                query = self.db.query(PageUAT).filter(and_(*filters))
            return query.first()     
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    def create_page_uat(self, uat_data: PageUATCreate):
        """
        Creates a new PageUAT record in the database.
        """
        try:
            db_uat = PageUAT(**uat_data.dict())
            self.db.add(db_uat)
            self.db.commit()
            self.db.refresh(db_uat)
            return db_uat
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=str(e))