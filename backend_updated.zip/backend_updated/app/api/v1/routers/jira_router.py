import logging
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status as http_status
from jira import JIRA, JIRAError
from sqlalchemy.orm import Session

from app.services import jira_service
from app.schemas.jira_schemas import (
    EpicCreate, StoryCreate, TaskCreate, SubtaskCreate, IssueResponse, JiraHealthResponse, JiraConfigInfo, PageUATCreate
)
from app.core.config import settings
from app.db.deps import get_db
from app.repositories.page_uat_repo import PageUATRepository
from app.repositories.pages_repo import PagesRepo # <-- Import PagesRepo

logger = logging.getLogger(__name__)
jira_router = APIRouter()


# Dependency to get Jira client
def get_jira_dependency() -> JIRA:
    """FastAPI dependency to get an initialized and validated Jira client instance."""
    client = jira_service.get_jira_client_instance()
    if client is None:
        logger.critical(
            "Jira client could not be initialized for an API request. This indicates a server-side configuration or Jira connectivity issue.")
        raise HTTPException(
            status_code=http_status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Jira integration is currently unavailable. Please check server logs or contact an administrator."
        )
    return client


def _handle_jira_error_response(
        je: JIRAError,
        issue_type: str = "issue",
        project_key_override: Optional[str] = None,
        parent_key: Optional[str] = None
):
    """Centralized JIRAError handling for API responses."""
    status_code = http_status.HTTP_500_INTERNAL_SERVER_ERROR
    error_message = f"An unexpected Jira API error occurred while creating {issue_type}: {je.text}"

    effective_project_key = project_key_override or settings.JIRA_PROJECT_KEY
    jira_status_code = getattr(je, 'status_code', 500)  # Default to 500 if not present

    if jira_status_code == 400:
        status_code = http_status.HTTP_400_BAD_REQUEST
        error_message = f"Jira API Bad Request creating {issue_type}: {je.text}. Check if all required Jira fields are provided and valid (e.g., parent issue '{parent_key}' linkage for subtasks)."
    elif jira_status_code == 401:
        status_code = http_status.HTTP_401_UNAUTHORIZED
        error_message = f"Jira API Unauthorized creating {issue_type}: {je.text}. Check JIRA_USER_EMAIL and JIRA_API_TOKEN in settings."
    elif jira_status_code == 403:
        status_code = http_status.HTTP_403_FORBIDDEN
        error_message = f"Jira API Forbidden creating {issue_type}: {je.text}. User '{settings.JIRA_USER_EMAIL}' may not have permission to create issues in project '{effective_project_key}' or to create the specified issue type."
    elif jira_status_code == 404:
        status_code = http_status.HTTP_404_NOT_FOUND
        not_found_item = f"Project '{effective_project_key}' or issue type '{issue_type}'"
        if issue_type.lower() == "subtask" and parent_key:
            not_found_item = f"Parent issue '{parent_key}'"
        error_message = f"Jira API Not Found: {not_found_item} not found or does not match project. Ensure JIRA_PROJECT_KEY ('{effective_project_key}') is correct. Original error: {je.text}"

    logger.error(
        f"Jira API Error (HTTP {jira_status_code}) for {issue_type} on project '{effective_project_key}': {je.text}. "
        f"Full error response: {getattr(je.response, 'text', 'No response body')}",
        exc_info=True  # Include stack trace for JIRAError
    )
    raise HTTPException(status_code=status_code, detail=error_message)


@jira_router.post("/epic", response_model=IssueResponse,   status_code=http_status.HTTP_201_CREATED)
async def endpoint_create_epic(epic_data: EpicCreate, jira: JIRA = Depends(get_jira_dependency), db: Session = Depends(get_db)):
    try:
        # Validate that the page_id exists before proceeding
        pages_repo = PagesRepo(db)
        if not pages_repo.get_page_by_id(page_id=epic_data.page_id):
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Page with id {epic_data.page_id} not found."
            )

        created_issue = jira_service.create_jira_epic(jira, epic_data)
        
        # Create UAT entry in the database
        uat_repo = PageUATRepository(db)
        uat_data_to_create = PageUATCreate(
            project_id=epic_data.project_id,
            page_id=epic_data.page_id,
            jira=created_issue["self_url"]
        )
        uat_repo.create_page_uat(uat_data_to_create)

        return IssueResponse(**created_issue, message="Epic created successfully in Jira.")
    except ValueError as ve:
        logger.warning(f"Validation error creating epic: {ve}", exc_info=True)
        raise HTTPException(status_code=http_status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except JIRAError as je:
        _handle_jira_error_response(je, "Epic")
    except HTTPException as http_exc:
        raise http_exc # Re-raise HTTPException to preserve status code and detail
    except Exception as e:
        logger.exception(f"An unexpected server error occurred in create_epic_endpoint: {e}")
        raise HTTPException(status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"An unexpected server error occurred: {str(e)}")


@jira_router.post("/story", response_model=IssueResponse,  
                  status_code=http_status.HTTP_201_CREATED)
async def endpoint_create_story(story_data: StoryCreate, jira: JIRA = Depends(get_jira_dependency), db: Session = Depends(get_db)):
    try:
        # Validate that the page_id exists before proceeding
        pages_repo = PagesRepo(db)
        if not pages_repo.get_page_by_id(page_id=story_data.page_id):
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Page with id {story_data.page_id} not found."
            )

        created_issue = jira_service.create_jira_story(jira, story_data)

        # Create UAT entry in the database
        uat_repo = PageUATRepository(db)
        uat_data_to_create = PageUATCreate(
            project_id=story_data.project_id,
            page_id=story_data.page_id,
            jira=created_issue["self_url"]
        )
        uat_repo.create_page_uat(uat_data_to_create)

        return IssueResponse(**created_issue, message="Story created successfully in Jira.")
    except ValueError as ve:
        logger.warning(f"Validation error creating story: {ve}", exc_info=True)
        raise HTTPException(status_code=http_status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except JIRAError as je:
        _handle_jira_error_response(je, "Story")
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        logger.exception(f"An unexpected server error occurred in create_story_endpoint: {e}")
        raise HTTPException(status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"An unexpected server error occurred: {str(e)}")


@jira_router.post("/task", response_model=IssueResponse,   status_code=http_status.HTTP_201_CREATED)
async def endpoint_create_task(task_data: TaskCreate, jira: JIRA = Depends(get_jira_dependency), db: Session = Depends(get_db)):
    try:
        # Validate that the page_id exists before proceeding
        pages_repo = PagesRepo(db)
        if not pages_repo.get_page_by_id(page_id=task_data.page_id):
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Page with id {task_data.page_id} not found."
            )
            
        created_issue = jira_service.create_jira_task(jira, task_data)
        
        # Create UAT entry in the database
        uat_repo = PageUATRepository(db)
        uat_data_to_create = PageUATCreate(
            project_id=task_data.project_id,
            page_id=task_data.page_id,
            jira=created_issue["self_url"]
        )
        uat_repo.create_page_uat(uat_data_to_create)

        return IssueResponse(**created_issue, message="Task created successfully in Jira.")
    except ValueError as ve:
        logger.warning(f"Validation error creating task: {ve}", exc_info=True)
        raise HTTPException(status_code=http_status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except JIRAError as je:
        _handle_jira_error_response(je, "Task")
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        logger.exception(f"An unexpected server error occurred in create_task_endpoint: {e}")
        raise HTTPException(status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"An unexpected server error occurred: {str(e)}")


@jira_router.post("/subtask", response_model=IssueResponse,  
                  status_code=http_status.HTTP_201_CREATED)
async def endpoint_create_subtask(subtask_data: SubtaskCreate, jira: JIRA = Depends(get_jira_dependency), db: Session = Depends(get_db)):
    try:
        # Validate that the page_id exists before proceeding
        pages_repo = PagesRepo(db)
        if not pages_repo.get_page_by_id(page_id=subtask_data.page_id):
            raise HTTPException(
                status_code=http_status.HTTP_404_NOT_FOUND,
                detail=f"Page with id {subtask_data.page_id} not found."
            )

        created_issue = jira_service.create_jira_subtask(jira, subtask_data)

        # Create UAT entry in the database
        uat_repo = PageUATRepository(db)
        uat_data_to_create = PageUATCreate(
            project_id=subtask_data.project_id,
            page_id=subtask_data.page_id,
            jira=created_issue["self_url"]
        )
        uat_repo.create_page_uat(uat_data_to_create)

        return IssueResponse(**created_issue, message="Sub-task created successfully in Jira.")
    except ValueError as ve:
        logger.warning(f"Validation error creating subtask: {ve}", exc_info=True)
        raise HTTPException(status_code=http_status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except JIRAError as je:
        _handle_jira_error_response(je, "Subtask", parent_key=subtask_data.parent_key)
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        logger.exception(f"An unexpected server error occurred in create_subtask_endpoint: {e}")
        raise HTTPException(status_code=http_status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"An unexpected server error occurred: {str(e)}")


@jira_router.get("/health", response_model=JiraHealthResponse,  )
async def jira_health_check(jira: JIRA = Depends(get_jira_dependency)):
    """Performs a health check of the Jira connection. Relies on get_jira_dependency for client."""
    try:
        current_user = jira.myself()
        display_name = current_user.get('displayName', current_user.get('name', 'Unknown User'))
        logger.info(f"Jira health check endpoint: Connection healthy. Jira User: {display_name}")
        return JiraHealthResponse(status="ok", jira_connection="healthy", jira_user=display_name)
    except JIRAError as je:
        logger.error(f"Jira API error during health check endpoint: {je.text}", exc_info=True)
        return JiraHealthResponse(status="degraded", jira_connection="unhealthy", error=f"Jira API error: {je.text}")
    except Exception as e:
        logger.error(f"Unexpected error during Jira health check endpoint: {e}", exc_info=True)
        return JiraHealthResponse(status="error", jira_connection="error", error=f"Unexpected server error: {str(e)}")


@jira_router.get("/config-info", response_model=JiraConfigInfo)
async def get_jira_config_info():
    """Returns sanitized Jira configuration information for debugging purposes."""
    jira_url_str = str(settings.JIRA_BASE_URL) if settings.JIRA_BASE_URL else None
    return JiraConfigInfo(
        jira_url=jira_url_str,
        jira_username=settings.JIRA_USER_EMAIL,
        jira_project_key=settings.JIRA_PROJECT_KEY,
        epic_name_custom_field_id=settings.JIRA_EPIC_NAME_CUSTOM_FIELD_ID,
        epic_link_custom_field_id=settings.JIRA_EPIC_LINK_CUSTOM_FIELD_ID,
        api_token_configured=bool(
            settings.JIRA_API_TOKEN and settings.JIRA_API_TOKEN not in ["YOUR_JIRA_API_TOKEN", None, ""]),
        custom_fields_note=(
            f"Epic Name Custom Field ID: {settings.JIRA_EPIC_NAME_CUSTOM_FIELD_ID or 'Not Set/Used'}. "
            f"Epic Link Custom Field ID: {settings.JIRA_EPIC_LINK_CUSTOM_FIELD_ID or 'Not Set/Used'}."
        )
    )