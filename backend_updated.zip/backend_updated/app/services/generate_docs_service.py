from app.repositories.projects_repo import ProjectsRepo
from app.services.mapping_service import MappingService
import json
import os
import logging

import re
import unicodedata
import string

from google.genai import types

from app.helper.md_to_docx import html_to_docx
from app.helper.doc_format import Document, process_docx_tables
from app.helper.google_docs import upload_docx_as_gdoc
from app.services.upload_service_v2 import publish_for_file, preview_for_file, create_folder, upload_file_to_drive
from app.repositories.images_repo import ImagesRepository
from app.repositories.pages_repo import PagesRepo
from app.services.project_services import ProjectsService
from app.helper.gemini_openai_helper import call_gemini_openai
from app.services.page_service import PageService
import time



logger = logging.getLogger(__name__)

try:
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    model = "gemini-2.5-pro-preview-05-06"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None


image_dir = "images"
output_dir = "output"
class GenerateDocsService:
    def __init__(self, db=None, global_files=False):
        self.db = db
        self.global_files =  global_files

    async def generate_docs_service(self, project_id, page_id):
        import asyncio
        pages_data = []
        if page_id == 0:
            page_id = None
        project_repo = ProjectsRepo(self.db)
        pages_repo = PagesRepo(self.db)
        project = project_repo.get_project_by_id(project_id)
        if page_id is not None:
            pages = pages_repo.get_page_by_id(page_id)
        else:
            pages = pages_repo.get_page_by_project_id(project_id)
        # Run genrate_doc_threading for each page concurrently
        tasks = [self.genrate_doc_threading(page=page, project=project) for page in pages]
        pages_data = await asyncio.gather(*tasks, return_exceptions=True)
        try:
                # print(folder_created_data)
                folder_created_data = project.drive_info
                upload_main_file_data = await self.upload_main_file_to_drive(
                    project.project_name,
                    folder_created_data["folder_id"],
                    folder_created_data["global_folder_id"],
                    folder_created_data["preview_url"],
                    page_id = page_id
                )
                pages_repo.update_status(page_id, status="completed")
                return upload_main_file_data
        except Exception as upload_err:
            logger.error(f"Error uploading main file to drive: {str(upload_err)}")
            pages_repo.update_status(page_id, status="error")
            raise
    

    async def genrate_doc_threading(self, page, project):
        """
        Orchestrates the document generation process for a given project.
        Retrieves project and image data, processes mappings, generates documents, and uploads them to Google Drive.
        Returns a structured response with document links or error details.
        """
        try:
            folder_created_data = None
            folder_created_data = project.drive_info
            project_name = project.project_name
            pages_repo = PagesRepo(self.db)
            mapped_data = []
            global_header_list = []
            try:
                pages_repo.update_status(page.id, status="in-progress", action="generate")
                block_data = await self.create_mapping_block(page.page_components)
                pages_repo.update_mapping_data(page.id, block_data)
                mapped_data.append(block_data)
                try:
                    _, global_header_list = await self.generate_docs(
                        mapped=block_data["mapped_data"],
                        project_name=project_name,
                        global_header_list=global_header_list
                    )
                    
                    pages_repo.update_status(page.id, status="completed", action="generate")
                except Exception as map_err:
                    pages_repo.update_status(page.id, status="error", action="generate")
                    logger.error(f"Error processing mapped data: {str(map_err)}")
                    raise
            except Exception as page_err:
                logger.error(f"Error processing page {getattr(page, 'id', None)}: {str(page_err)}")
                pages_repo.update_status(getattr(page, 'id', None), status="error", action="generate")
                raise
            return {"folder_create_data":folder_created_data}
            
        except Exception as e:
            logger.error(f"Error in generate-doc endpoint: {str(e)}")
            try:
                pages_repo.update_status(page.id, status="error")
            except Exception as status_err:
                logger.error(f"Error updating page status: {str(status_err)}")
            return {
                "documents": {
                    "name": "documents",
                    "type": "folder",
                    "nodeType": "folder",
                    "children": {
                        "error": {
                            "name": "Error",
                            "type": "file",
                            "nodeType": "file",
                            "url": "#",
                            "error_details": str(e)
                        }
                    },
                    "error": str(e)
                }
            }

    async def create_mapping_block(self, analyze_response):
        """
        Maps the LLM analysis response to UI blocks using the MappingService.
        """
        try:
            mapping_service = MappingService(self.db)
            block_data = await mapping_service.map_ui_to_blocks(
                page_json=analyze_response,
                block_kb=mapping_service.load_block_kb()
            )
            return block_data
        except Exception as e:
            logger.error(f"Error in create_mapping_block: {str(e)}")
            raise

    async def create_folder_and_sub_folder(self, project_name):
        """
        Creates a main and global folder for the project in Google Drive.
        """
        try:
            upload_folder_links = await create_folder(username=project_name)
            if "error" in upload_folder_links:
                logger.warning(f"Error in folder creation: {upload_folder_links['error']}")
            else:
                logger.info("Folder creation response Success")
            
            folder_metadata = {
                "folder_id": upload_folder_links.get("folder_id", "default_folder_id"),
                "folder_url": upload_folder_links.get("folder_url", "#"),
                "global_folder_id": upload_folder_links.get("global_folder_id", "default_global_folder_id"),
                "preview_url": upload_folder_links.get("preview_url", "#")
            }
            #update data in project table for further use
            project_services = ProjectsService(self.db)
            updata_metadata = await project_services.update_upload_data_project_name(project_name, folder_metadata)
            return folder_metadata
        
        

        except Exception as e:
            logger.error(f"Error in create_folder_and_sub_folder: {str(e)}")
            raise

    async def upload_main_file_to_drive(self, project_name, folder_id, global_folder_id, preview_url, page_id=None):
        """
        Uploads generated DOCX files to Google Drive and prepares the response structure.
        """
        project_path = os.path.join(output_dir, project_name)
        global_path = os.path.join(project_path, "global")
        pages_repo =  PagesRepo(self.db)
        try:
            if not os.path.exists(project_path):
                logger.warning(f"Project path does not exist: {project_path}")
                os.makedirs(project_path, exist_ok=True)
            if not os.path.exists(global_path):
                logger.warning(f"Global path does not exist: {global_path}")
                os.makedirs(global_path, exist_ok=True)
            page_data_return = {}
            global_pages = []

            try:
                logger.info(f"Processing files in directory: {project_path}")
                for file_name in os.listdir(project_path):
                    #taking this extra folder, ignoring it would be best....
                    if file_name == ".DS_Store":
                        continue
                    full_path = os.path.join(project_path, file_name)
                    if not os.path.isdir(full_path):
                        if file_name.endswith('.html'):
                            logger.info(f"Skipping HTML file: {file_name}")
                            continue
                        try:
                            logger.info(f"Uploading file: {full_path}")
                            file_upload_url = await upload_file_to_drive(full_path, folder_id)
                            logger.info(f"Upload response: {file_upload_url}")
                            do_preview_url = await preview_for_file(
                                "team-argo",
                                site=project_name,
                                path=file_name.split(".")[0]
                            )
                            if page_id is not None:
                                pages_repo.update_preview_url(page_id, do_preview_url["message"])
                            page_data_return[file_name] = {
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": file_upload_url.get("file_url", "#"),
                                "preview_url": do_preview_url["message"],
                            }
                        except Exception as file_err:
                            logger.error(f"Error uploading file {full_path}: {str(file_err)}")
                            page_data_return[file_name] = {
                                "name": file_name,
                                "type": file_name.split(".")[1],
                                "nodeType": 'file',
                                "url": "#",
                                "error": str(file_err)
                            }
                        # os.remove(full_path)
            except Exception as dir_err:
                logger.error(f"Error processing project directory: {str(dir_err)}")

            if not self.global_files:
                try:
                    logger.info(f"Processing files in global directory: {global_path}")
                    for file_name in os.listdir(global_path):
                        if file_name.endswith('.html'):
                            logger.info(f"Skipping HTML file: {file_name}")
                            continue
                        full_path = os.path.join(global_path, file_name)
                        if not os.path.isdir(full_path):
                            try:
                                print("fie name ---------", file_name)

                                path = await upload_file_to_drive(full_path, folder_id)
                                do_preview_url_global = await preview_for_file(
                                    "team-argo",
                                    site=project_name,
                                    path=file_name.split(".")[0]
                                )
                                print(do_preview_url_global)
                                global_pages.append({
                                    "name": file_name,
                                    "type": file_name.split(".")[1],
                                    "nodeType": 'file',
                                    "url": path.get("file_url", "#"),
                                    "preview_url": do_preview_url_global["message"]
                                })
                                self.global_files = True
                                # os.remove(full_path)
                            except Exception as global_file_err:
                                logger.error(f"Error uploading global file {full_path}: {str(global_file_err)}")
                                global_pages.append(f"Error with {file_name}: {str(global_file_err)}")
                except Exception as global_dir_err:
                    logger.error(f"Error processing global directory: {str(global_dir_err)}")
                    global_pages.append("Error loading global files")
            
            page_data_return["global"] = {
                "name": "global",
                "type": 'folder',
                "nodeType": 'folder',
                "children": global_pages
            }
            return_json = {
                "documents": {
                    "name": "documents",
                    "type": "folder",
                    "nodeType": "folder",
                    "children": page_data_return
                }
            }
            return return_json
        except Exception as e:
            logger.error(f"Error in upload_main_file_to_drive: {str(e)}")
            raise

    async def generate_docs(self, mapped, project_name, global_header_list=None):
        """
        Generate HTML and DOCX documents from mapped components.
        """
        try:
            global_blocks = {}
            pages = []
            page_building = []
            global_items = global_header_list or []
            new_project = False
            project_path = os.path.join(output_dir, project_name)
            global_path = os.path.join(project_path, "global")
            if not os.path.exists(project_path):
                new_project = True
                os.makedirs(project_path, exist_ok=True)
                os.makedirs(global_path, exist_ok=True)
                logger.info(f"Created new project directory: {project_path}")
            for comp in mapped:
                if comp["element_type"] == "global":
                    global_blocks.setdefault(comp["type"], comp)
                else:
                    page_building.append(comp)
            #save preview url
            page_service= PageService(self.db)
            

            pages.append({
                "title": mapped[0].get("page_title", ""),
                "components": page_building
            })
            for blk_type, comp in global_blocks.items():
                if blk_type not in global_items:
                    html = self.render_markdown(client, model, {"components": [comp]}).strip()
                    if html:
                        fname_base = os.path.join(global_path, self._slug(blk_type))
                        self.save_html_and_docx(html, fname_base)
                        global_items.append(blk_type)
            for page in pages:
                if not page["components"]:
                    continue
                html = self.render_markdown(client, model, {"components": page["components"]}).strip()
                if html:
                    fname_base = os.path.join(project_path, self._slug(page['title']))
                    self.save_html_and_docx(html, fname_base)
                    save_preview_url = await page_service.save_preview_url(self._slug(page['title']), mapped[0].get("original_file_name", ""))

            json_output = {
                "no_of_global_blocks": len(global_blocks),
                "no_of_side_blocks": len(pages)
            }
            return json_output, global_items
        except Exception as e:
            logger.error(f"Error generating docs: {str(e)}")
            return {"error": str(e), "no_of_global_blocks": 0, "no_of_side_blocks": 0}, global_header_list or []

    def render_markdown(self, client, model, page_payload):
        """
        Generate HTML content from the mapped JSON and block templates using Gemini.
        """
        try:
            if client is None:
                logger.warning("Gemini API client not initialized. Returning dummy HTML.")
                raise RuntimeError("Gemini API client not initialized. API key not available.")
            prompt = f"""
    You are an expert AEM content author.
    TASK
    ----
    Create HTML content based on the JSON page payload and HTML templates provided.
    STRICT RULES
    1. Use ONLY the HTML structure from the templates in `kb_html`, preserving tags, elements, and structure.
    2. Replace ALL content in the templates (titles, descriptions, text, image paths) with values from the JSON properties.
    3. NEVER copy any placeholder text or content from the template examples.
    4. All image src attributes should use the original image paths from the JSON properties.
    5. Output ONLY the final HTML content—no explanations or code fences.
    6. EXCEPTION: Preserve any metadata tables exactly as they appear in the original template.
    7. All HTML id attributes must be unique. Prefix each id with the block type and a running index (e.g., id=\"columns-1\", id=\"cards-2\"), or use a page slug as a prefix. No duplicate ids.
    For example, if kb_html contains:
    <h2>Example Heading</h2>
    <p>Lorem ipsum dolor sit amet</p>
    And your component specifies title "Weather Forecast", your output should be:
    <h2>Weather Forecast</h2>
    <p>Check the latest weather updates for your area.</p>
    CRITICAL: DO NOT KEEP ANY EXAMPLE TEXT FROM THE TEMPLATES EXCEPT FOR METADATA TABLES. Replace all other content while maintaining structure with json provided.
    CRITICAL: Do Not Replace the First Heading: The first <th> element in every HTML component table represents the component's name.
    page_payload:
    {json.dumps(page_payload, indent=2)}
    """
            api_key = os.environ.get("GEMINI_API_KEY", "dummy_key")
            result = call_gemini_openai(prompt=prompt, api_key=api_key)
            return result
        except Exception as e:
            logger.error(f"Error rendering markdown: {str(e)}")
            raise RuntimeError(f"Error rendering markdown: {str(e)}")

    def save_html_and_docx(self, html, fname_base):
        """
        Save HTML to file, convert to DOCX, and enhance DOCX formatting.
        """
        try:
            html_fname = f"{fname_base}.html"
            docx_fname = f"{fname_base}.docx"
            with open(html_fname, "w") as f:
                f.write(html)
            logger.info(f"✓ saved → {html_fname}")
            html_to_docx(html_fname, docx_fname)
            logger.info(f"✓ converted to DOCX → {docx_fname}")
            doc = Document(docx_fname)
            process_docx_tables(doc)
            doc.save(docx_fname)
            logger.info(f"✓ enhanced DOCX formatting → {docx_fname}")
            return True
        except Exception as e:
            logger.error(f"Error saving HTML and DOCX: {str(e)}")
            raise RuntimeError(f"Error saving HTML and DOCX: {str(e)}")

    @staticmethod
    def _slug(txt: str, fallback: str = "page") -> str:
        """
        Convert a string to a safe filename slug (e.g., "Home Page!" -> "home_page").
        """
        try:
            if not txt:
                return fallback
            txt = unicodedata.normalize("NFKD", txt).encode("ascii", "ignore").decode()
            txt = txt.lower()
            allowed = string.ascii_lowercase + string.digits + "_"
            txt = "".join(c if c in allowed else "_" for c in txt)
            txt = re.sub(r"_+", "_", txt).strip("_")
            return txt or fallback
        except Exception as e:
            logger.error(f"Error in _slug: {str(e)}")
            return fallback