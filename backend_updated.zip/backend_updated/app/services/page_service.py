from app.services.project_services import ProjectsService
from app.schemas.page import PageCreate
from app.repositories.pages_repo import PagesRepo
from fastapi import HTTPException,status
from app.services.file_upload import file_upload_service
from app.schemas.image import ImageCreate
from app.repositories.images_repo import ImagesRepository
from app.repositories.projects_repo import ProjectsRepo
from app.schemas.page import PageCreate
from fastapi import HTTPException


class PageService:
    def __init__(self, db):
        self.db = db


    async def get_pages_by_project_id(self, project_id):
        try:
            pages_repo =  PagesRepo(self.db)
            all_pages = pages_repo.get_page_by_project_id(project_id=project_id)
            return all_pages
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    async def get_page_by_id(self, page_id):
        try:
            pages_repo =  PagesRepo(self.db)
            page_data = pages_repo.get_page_by_id(page_id=page_id)
            return page_data
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    async def create_page(self, project_id, page_create:PageCreate):
        try:
            """Create a page within a project"""
            # Verify project exists
            project_service = ProjectsService(self.db)
            project = await project_service.read_project(project_id)
            # Check for duplicate page URL
            pages_repo = PagesRepo(self.db)
            existing_page = pages_repo.get_page_by_url(page_create.page_url)
            if existing_page:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Page with this URL already exists"
                )
            
            db_page = pages_repo.create_page(page_create, project_id=project_id)
            return db_page
        except Exception as e:
           raise HTTPException(status_code=500, detail=str(e))
        
    
    async def upload_project_image(self,project_id:int, file):
        #upload zip for assets, seprate images, each image will be associated with each page
        #create new page for each image with page name
        try:
            file_metadata = await file_upload_service.save_uploaded_file(file, project_id)
            
            if file_metadata is None:
                # Zip file - no DB insert, just return success message or empty response
                return {"detail": "Zip file uploaded and extracted successfully."}
            else:
                #create_page for each image by image name for now
                #TODO: LOOK FOR OTHER OPTION TO GET THE PAGE URL AND PAGE NAME
                page_repo =  PagesRepo(self.db)
                page_create =  PageCreate(
                    page_name=file_metadata["filename"],
                    page_url = file_metadata["filename"],
                    project_id=project_id
                    
                )

                create_page_data = page_repo.create_page(page_create)
                image_data = ImageCreate(
                    filename=file_metadata["filename"],
                    filepath=file_metadata["filepath"],
                    content_type=file.content_type,
                    project_id=project_id,
                    file_size=file_metadata["file_size"],
                    page_id=create_page_data.id
                
                )    
                images_repo  = ImagesRepository(self.db)
                images_create_data  = images_repo.create_image(image_data)
                return images_create_data
        
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
        
    
    async def save_preview_url(self, page_title, orginal_file_name):
        try:
            page_repo = PagesRepo(self.db)
            project_repo = ProjectsRepo(self.db)
            get_page = page_repo.get_page_by_name(orginal_file_name)
            if not get_page:
                raise HTTPException(status_code=404, detail=f"Page with name '{orginal_file_name}' not found")
            get_project = project_repo.get_project_by_id(get_page.project_id)
            if not get_project:
                raise HTTPException(status_code=404, detail=f"Project with id '{get_page.project_id}' not found")
            get_folder_data = get_project.drive_info
            if not get_folder_data or "preview_url" not in get_folder_data:
                raise HTTPException(status_code=500, detail="Drive info or preview_url missing in project metadata")
            create_preview_url = f"{get_folder_data['preview_url']}/{page_title}"
            page_repo.update_preview_url(get_page.id, preview_url=create_preview_url)
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))