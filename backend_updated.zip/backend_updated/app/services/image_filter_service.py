import torch
import torchvision.transforms as T
from PIL import Image  # ImageDraw, ImageFont are not directly used by API response
import numpy as np
import os
import shutil
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Dict, Any, Set, Optional
from dotenv import load_dotenv
from app.schemas.analysis import ImageProcessingPaths
from fastapi import HTTPException
import ast
load_dotenv()

# --- Configuration ---
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
DINOV2_MODEL_NAME = os.getenv("DINOV2_MODEL_NAME", "dinov2_vits14")

IMG_PREPROCESS_SIZE = 224
PREPROCESS_TRANSFORM = T.Compose([
    T.Resize((IMG_PREPROCESS_SIZE, IMG_PREPROCESS_SIZE), interpolation=T.InterpolationMode.BICUBIC),
    T.ToTensor(),
    T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
])

scales_env = os.getenv("SCALES", "1.0")
SCALES = [float(s) for s in ast.literal_eval(scales_env)] if "[" in scales_env else [float(s.strip()) for s in scales_env.split(",")]
SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", 0.80))
WINDOW_STRIDE_FACTOR = float(os.getenv("WINDOW_STRIDE_FACTOR", 0.50))

# --- Module-level Variable for the Hugging Face Model ---
dinov2_model: Optional[Any] = None
async def init_filter_model():
    """
    Initializes the Hugging Face image Filter model.
    This should be called once at application startup.
    """
    global dinov2_model
    try:
        print(f"Attempting to load DINOv2 model ({DINOV2_MODEL_NAME}) on {DEVICE}...")
        dinov2_model_instance = torch.hub.load('facebookresearch/dinov2', DINOV2_MODEL_NAME)
        dinov2_model_instance.eval()
        dinov2_model_instance.to(DEVICE)
        dinov2_model = dinov2_model_instance  # Assign to global after successful load
        print(f"DINOv2 model ({DINOV2_MODEL_NAME}) loaded successfully.")
    except Exception as e:
        print(f"CRITICAL: Error loading DINOv2 model: {e}")
        print("FastAPI app will start, but matching endpoint will fail if model is not loaded.")
        # Depending on desired behavior, you might want the app to not start,
        # but for now, it will start and the endpoint will raise an error if dinov2_model is None.

# --- Core Logic Functions ---
async def extract_features(image_pil: Image.Image, model: torch.nn.Module) -> np.ndarray:
    if model is None:
        raise RuntimeError("DINOv2 model is not loaded. Cannot extract features.")
    if image_pil.mode != 'RGB':
        image_pil = image_pil.convert('RGB')

    img_tensor = PREPROCESS_TRANSFORM(image_pil).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        features_dict = model.forward_features(img_tensor)
        patch_features = features_dict.get('x_norm_patchtokens')
        if patch_features is None:
            raise ValueError("Could not extract patch_features ('x_norm_patchtokens'). Check DINOv2 model output.")
    mean_features = patch_features.mean(dim=1)
    return mean_features.cpu().numpy()


async def find_template_in_screenshot(
        screenshot_pil: Image.Image,
        template_pil: Image.Image,
        template_name: str,
        scales: List[float],
        threshold: float,
        stride_factor: float
) -> List[Dict[str, Any]]:
    found_locations = []
    min_template_dim = 16

    template_features_scaled = {}
    for scale in scales:
        original_w, original_h = template_pil.size
        scaled_w = int(original_w * scale)
        scaled_h = int(original_h * scale)

        if scaled_w < min_template_dim or scaled_h < min_template_dim:
            continue

        try:
            scaled_template_pil = template_pil.resize((scaled_w, scaled_h), Image.Resampling.LANCZOS)
            features = await extract_features(scaled_template_pil, dinov2_model)
            template_features_scaled[scale] = {
                "features": features, "width": scaled_w, "height": scaled_h
            }
        except Exception as e:
            print(f"Error extracting features for template {template_name} at scale {scale}: {e}")
            continue

    if not template_features_scaled:
        return found_locations

    screenshot_w, screenshot_h = screenshot_pil.size
    for scale, t_info in template_features_scaled.items():
        template_feats = t_info["features"]
        window_w, window_h = t_info["width"], t_info["height"]
        stride_w = max(1, int(window_w * stride_factor))
        stride_h = max(1, int(window_h * stride_factor))

        for y in range(0, screenshot_h - window_h + 1, stride_h):
            for x in range(0, screenshot_w - window_w + 1, stride_w):
                window_pil = screenshot_pil.crop((x, y, x + window_w, y + window_h))
                try:
                    window_feats = await extract_features(window_pil, dinov2_model)
                except Exception:
                    continue

                similarity = cosine_similarity(template_feats, window_feats)[0][0]
                if similarity >= threshold:
                    found_locations.append({
                        "template_name": template_name, "scale": scale, "x": x, "y": y,
                        "width": window_w, "height": window_h, "similarity": float(similarity)
                        # Ensure JSON serializable
                    })
    return found_locations


async def perform_image_matching_and_filtering(
        screenshot_path: str,
        images_folder_path: str,
        scales_list: List[float],
        similarity_thresh: float,
        stride_fact: float
) -> (List[Dict[str, Any]], Set[str]):
    """
    Core processing function.
    Returns a list of all detected matches and a set of unique template names copied.
    """
    if not os.path.exists(screenshot_path):
        raise FileNotFoundError(f"Screenshot file not found: {screenshot_path}")
    if not os.path.isdir(images_folder_path):
        raise NotADirectoryError(f"Images folder not found or not a directory: {images_folder_path}")

    try:
        main_screenshot_pil = Image.open(screenshot_path)
    except Exception as e:
        raise RuntimeError(f"Error opening screenshot image {screenshot_path}: {e}")

    all_detected_matches_info: List[Dict[str, Any]] = []
    copied_templates_this_run: Set[str] = set()

    print(f"Processing templates from: {images_folder_path}")
    for image_name in os.listdir(images_folder_path):
        if image_name.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp')):
            template_path = os.path.join(images_folder_path, image_name)
            try:
                current_template_pil = Image.open(template_path)
                print(f"\n--- Processing template: {image_name} ---")

                matches_for_current_template = await find_template_in_screenshot(
                    main_screenshot_pil, current_template_pil, image_name,
                    scales_list, similarity_thresh, stride_fact
                )

                if matches_for_current_template:
                    all_detected_matches_info.extend(matches_for_current_template)
                    highest_similarity = max(m['similarity'] for m in matches_for_current_template)
                    print(f"Template '{image_name}' found with highest similarity of {highest_similarity * 100:.2f}%.")
                else:
                    print(f"Template '{image_name}': No match found above threshold {similarity_thresh * 100:.2f}%.")
            except FileNotFoundError:
                print(f"Skipping: Template file not found at {template_path}")
            except Exception as e:
                print(f"Skipping: Error opening or processing template {template_path}: {e}")

    return all_detected_matches_info, copied_templates_this_run


async def process_images_api(paths: ImageProcessingPaths):
    """
    Processes a screenshot to find template images from a given folder
    and copies the matched templates to a destination folder.
    The destination folder is cleared before processing.
    Returns a custom JSON response with a message and list of matched image names.
    """
    if dinov2_model is None:
        raise HTTPException(status_code=503, detail="DINOv2 model is not loaded. Service unavailable.")

    screenshot_p = paths.screenshot_path
    images_folder_p = paths.images_folder_path
    filtered_dest_p = paths.filtered_destination_path

    # Validate input paths provided by the user
    if not os.path.exists(screenshot_p):
        raise HTTPException(status_code=404, detail=f"Screenshot file not found: {screenshot_p}")
    if not os.path.isdir(images_folder_p):
        raise HTTPException(status_code=404, detail=f"Source images folder not found: {images_folder_p}")

    try:
        print(f"Starting image processing for screenshot: {screenshot_p}")
        # We still need all_matches to know if any detection happened,
        # even if not directly returned in this specific format.
        all_matches, copied_templates = await perform_image_matching_and_filtering(
            screenshot_p,
            images_folder_p,
            SCALES,
            SIMILARITY_THRESHOLD,
            WINDOW_STRIDE_FACTOR
        )

        # Construct the new response
        response_message = "prioritize the list of images over other images while matching"

        # If no templates were copied, the images list will be empty.
        # If templates were copied, copied_templates will contain their names.

        return list(copied_templates)

    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except NotADirectoryError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:  # Catch errors from image opening or model issues
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:  # Generic catch-all for other unexpected errors
        print(f"An unexpected error occurred during processing: {e}")  # Log for server
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")
