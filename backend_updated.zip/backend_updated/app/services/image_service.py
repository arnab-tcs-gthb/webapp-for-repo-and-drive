import logging
from sqlalchemy.orm import Session
from app.models.image import Image
from app.crud.image import (
    get_image,
    update_image_llm_data,
    get_images_by_project
)
from app.repositories.images_repo import ImagesRepository

# Setup logging
logger = logging.getLogger(__name__)

class ImageService:
    def __init__(self, db: Session):
        self.db = db

    async def update_llm_status(
        self,
        image_id: int,
        llm_response: dict,
        llm_processed: bool
    ) -> bool:
        """Update image with LLM processing status"""
        try:
            updated = await update_image_llm_data(
            db=self.db,         # Pass the database session
            image_id=image_id,  # image ID
            llm_response=llm_response,  # LLM response payload
            llm_processed=llm_processed  # processed flag
        )
            return updated
        except Exception as e:
            logger.error(f"Error updating LLM status for image {image_id}: {e}")
            return False
        

    async def get_unprocessed_images(self, project_id: int) -> list[Image]:
        """For LLM service to fetch images needing processing"""
        return get_images_by_project(
            db=self.db,
            project_id=project_id
        ).filter(Image.llm_processed == False).all()
        
    async def get_images_by_project(self, project_id, skip:int=0, limit:int=100):
        try:
            image_repo =  ImagesRepository(self.db)
            all_images = image_repo.get_images_by_project(project_id=project_id, skip=skip, limit=limit)
            return all_images
        except Exception as e:
            return {"error": str(e)}