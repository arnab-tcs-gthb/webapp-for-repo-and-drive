import os
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path
from PIL import Image as PILImage # Alias to avoid conflict if Image model is imported
from fastapi import HTTPException
from transformers import pipeline
import io
from google.genai import types

from app.schemas.captioning_schemas import ImageCaptionResponseItem, CaptionSummaryResponse, ImageCaptionRequest # Import from new location
from app.crud.project import get_project, update_project, get_project
from app.schemas.analysis import AnalysisMetadata, ImageProcessingPaths, ImageFilter
from app.schemas.project import (
    ProjectCreate,
    ProjectUpdate,
    ProjectInDB
)
from app.core.config import settings
from app.helper.gemini_openai_helper import call_gemini_openai

import logging
import mimetypes
logger = logging.getLogger(__name__)



# Initialize Gemini client with robust error handling
try:
    from google import genai
    gemini_client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "dummy_key"))
    gemini_model = "gemini-2.5-pro-preview-05-06"
    logger.info("Gemini API client initialized successfully")
except Exception as e:
    logger.error(f"Could not initialize Gemini API client: {str(e)}")
    client = None
    model = None


from app.repositories.projects_repo import ProjectsRepo
# --- Configuration ---
CAPTIONING_MODEL_NAME = "Salesforce/blip-image-captioning-large"
CAPTIONING_SUPPORTED_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp')
CAPTIONING_GENERATION_ARGS = {
    "max_length": 150,
    "num_beams": 5,
    "early_stopping": True,
    "repetition_penalty": 1.2,
}

static_dir = settings.UPLOAD_DIR_ASSET.parent

logger = logging.getLogger(__name__)

_captioner: Optional[Any] = None

class CaptioningService:
    def __init__(self,db=None):
        self.db =db


    async def captioning_service_main(self, project_id):
        """
        FastAPI endpoint to create captions for images from a given folder.
        Returns a custom JSON response with a message and list of caption names.
        """
        try:
            try:
                project_repo = ProjectsRepo(self.db)
                project_obj = project_repo.get_project_by_id(project_id)
            except Exception as get_project_err:
                logger.error(f"Error retrieving project: {str(get_project_err)}")
                raise HTTPException(status_code=500, detail=f"Error retrieving project: {str(get_project_err)}")

            
            try:
                caption_data = await self.create_captions_for_images_in_folder_endpoint(
                    ImageCaptionRequest(folder_location=f"{settings.UPLOAD_DIR_ASSET.name}/project_{project_id}"),
                    project_id=project_id
                )
                logger.info(caption_data['captions'])
                try:
                    update_project(
                        db=self.db,
                        project_id=project_id,
                        project=ProjectUpdate(captions=caption_data['captions']),
                    )
                except Exception as update_project_err:
                    logger.error(f"Error updating project with captions: {str(update_project_err)}")
                    raise HTTPException(status_code=500, detail=f"Error updating project with captions: {str(update_project_err)}")

                # Validate caption data structure
                if not isinstance(caption_data, dict) and hasattr(caption_data, '__dict__'):
                    logger.info("Converting caption_data object to dictionary")
                    if hasattr(caption_data, 'captions') and caption_data.captions:
                        caption_data = {"captions": caption_data.captions}
                    else:
                        caption_data = {"captions": {}}
                elif not isinstance(caption_data, dict):
                    logger.warning(f"Caption data is not a dict, got {type(caption_data)}")
                    caption_data = {"captions": {}}
            except HTTPException as caption_http_exc:
                raise caption_http_exc
            except Exception as caption_err:
                logger.error(f"Error generating captions: {str(caption_err)}")
                raise HTTPException(status_code=500, detail=f"Error generating captions: {str(caption_err)}")
        except HTTPException as outer_http_exc:
            raise outer_http_exc
        except Exception as outer_err:
            logger.error(f"Unexpected error in caption generation block: {str(outer_err)}")
            raise HTTPException(status_code=500, detail=f"Unexpected error in caption generation block: {str(outer_err)}")

    async def init_captioning_model(self):
        """
        Initializes the Hugging Face image captioning model.
        This should be called once at application startup.
        """
        global _captioner
        if _captioner is not None:
            logger.info("Captioning model already initialized.")
            return
        logger.info(f"Attempting to initialize Hugging Face pipeline with model: {CAPTIONING_MODEL_NAME}...")
        logger.info("This might take some time, especially for larger models on the first run...")
        try:
            _captioner = pipeline("image-to-text", model=CAPTIONING_MODEL_NAME)
            logger.info(f"Captioning pipeline initialized successfully with model: {CAPTIONING_MODEL_NAME}.")
            logger.info(f"Captioning pipeline device: {_captioner.device}")
        except Exception as e:
            logger.error(f"CRITICAL: Failed to initialize Hugging Face captioning pipeline: {e}")
            logger.error(
                "The captioning API endpoint might not function correctly. "
                "Ensure model availability and resources (internet, disk space, memory)."
            )
            _captioner = None
            raise HTTPException(status_code=500, detail=f"Failed to initialize captioning model: {e}")

    def get_captioner(self):
        """
        Returns the initialized captioner pipeline.
        Raises an HTTPException if the model is not loaded.
        """
        if _captioner is None:
            logger.error("Captioning model is not available. Initialization might have failed.")
            raise HTTPException(status_code=503, detail="Captioning service is unavailable. Model not loaded.")
        return _captioner

    async def generate_captions_for_images_in_folder(
        self,
        folder_path_relative: str,
        base_static_path_abs: str,
        project_id: Optional[int] = None
    ) -> CaptionSummaryResponse:
        """
        Processes images in a given folder and generates captions using the initialized model.
        The output image path will be 'static/assets/project_{id}/{image_name}'
        """
        try:
            captioning_pipeline = self.get_captioner()
            # Use settings.UPLOAD_DIR_ASSET as the root for assets
            static_assets_root = settings.UPLOAD_DIR_ASSET
            if project_id is not None:
                folder_path_relative = f"{static_assets_root.name}/project_{project_id}"
            requested_folder_abs = os.path.abspath(os.path.join(static_assets_root.parent, folder_path_relative))
            if not requested_folder_abs.startswith(str(static_assets_root.parent)):
                logger.error(f"Security Alert: Attempted access outside of allowed static sub-directory: {folder_path_relative}")
                raise HTTPException(status_code=400, detail="Access denied: Invalid folder location.")
            if not os.path.isdir(requested_folder_abs):
                logger.error(f"Invalid folder path provided: '{requested_folder_abs}' does not exist or is not a directory.")
                raise HTTPException(status_code=400, detail=f"The folder '{folder_path_relative}' does not exist or is not a directory.")
            try:
                all_files_in_dir = os.listdir(requested_folder_abs)
            except OSError as e:
                logger.error(f"Error listing directory {requested_folder_abs}: {e}")
                raise HTTPException(status_code=500, detail=f"Could not read directory contents: {folder_path_relative}")
            image_filenames = [f for f in all_files_in_dir if f.lower().endswith(CAPTIONING_SUPPORTED_EXTENSIONS)]
            total_images_found = len(image_filenames)
            if total_images_found == 0:
                message = f"No images with supported extensions {CAPTIONING_SUPPORTED_EXTENSIONS} found in folder: {folder_path_relative}"
                logger.info(message)
                return CaptionSummaryResponse(
                    total_images_found=0, successfully_captioned=0, results=[], message=message, errors=[]
                )
            logger.info(f"Found {total_images_found} image(s) to process in folder: {requested_folder_abs}")
            logger.info(f"Using generation parameters for captions: {CAPTIONING_GENERATION_ARGS}")
            results: List[ImageCaptionResponseItem] = []
            errors: List[str] = []
            for filename in image_filenames:
                current_image_path_full_abs = os.path.join(requested_folder_abs, filename)
                logger.info(f"\n--- Processing image: {filename} ---")
                img: Optional[PILImage.Image] = None
                try:
                    logger.info(f"Attempting to load image: {current_image_path_full_abs}...")
                    img = PILImage.open(current_image_path_full_abs).convert("RGB")
                    logger.info(f"Image '{filename}' loaded. Mode: {img.mode}, Size: {img.size}")
                except FileNotFoundError:
                    msg = f"Image file not found at '{current_image_path_full_abs}'. Skipping."
                    logger.error(msg)
                    errors.append(f"{filename}: {msg}")
                    continue
                except Exception as e:
                    msg = f"Unexpected error loading image '{filename}': {e}. Skipping."
                    logger.error(msg)
                    errors.append(f"{filename}: {msg}")
                    continue
                if img is None:
                    msg = f"Image object is None for '{filename}'. Skipping."
                    logger.error(msg)
                    errors.append(f"{filename}: {msg}")
                    continue
                logger.info(f"Generating caption for '{filename}'...")
                try:
                    captions_output = captioning_pipeline(img, generate_kwargs=CAPTIONING_GENERATION_ARGS)
                    if captions_output and isinstance(captions_output, list) and len(captions_output) > 0:
                        first_result = captions_output[0]
                        if isinstance(first_result, dict) and 'generated_text' in first_result:
                            generated_text = first_result['generated_text'].strip()
                            logger.info(f"Generated Caption for '{filename}':\n{generated_text}\n")
                            # Always output path as 'static/assets/project_{id}/{image_name}'
                            image_path = f"static/assets/project_{project_id}/{filename}" if project_id is not None else os.path.join(folder_path_relative, filename).replace("\\", "/")
                            results.append(
                                ImageCaptionResponseItem(image_path=image_path, description=generated_text)
                            )
                        else:
                            msg = f"Caption output format unexpected for '{filename}'. First: {first_result}. Skipping."
                            logger.warning(msg)
                            errors.append(f"{filename}: {msg}")
                    else:
                        msg = f"Captioner returned empty/None output for '{filename}'. Skipping."
                        logger.warning(msg)
                        errors.append(f"{filename}: {msg}")
                except Exception as e:
                    msg = f"Error during caption generation for '{filename}': {e}."
                    logger.error(msg, exc_info=True)
                    errors.append(f"{filename}: {msg}")
                    continue
            successfully_captioned_count = len(results)
            if successfully_captioned_count == total_images_found and total_images_found > 0:
                message = f"Successfully generated captions for all {total_images_found} found image(s) in '{folder_path_relative}'."
            elif successfully_captioned_count > 0:
                message = f"Generated captions for {successfully_captioned_count}/{total_images_found} image(s) in '{folder_path_relative}'. See errors."
            elif total_images_found > 0:
                message = f"Attempted {total_images_found} image(s) in '{folder_path_relative}', no captions generated. See errors."
            else:
                message = f"No images found to process in '{folder_path_relative}'."
            logger.info(f"Captioning for folder '{folder_path_relative}' finished. Result: {message}")
            return CaptionSummaryResponse(
                total_images_found=total_images_found,
                successfully_captioned=successfully_captioned_count,
                results=results,
                message=message,
                errors=errors
            )
        except HTTPException as http_exc:
            raise http_exc
        except Exception as e:
            logger.error(f"Error in generate_captions_for_images_in_folder: {e}")
            raise HTTPException(status_code=500, detail=f"Error in generate_captions_for_images_in_folder: {e}")

    async def generate_gemini_captions_for_images_in_folder(
        self,
        folder_path_relative: str,
        base_static_path_abs: str,
        project_id: Optional[int] = None
    ) -> CaptionSummaryResponse:
        """
        Processes images in a given folder and generates captions using the Gemini model.
        """
        try:
            if gemini_client is None:
                logger.error("Gemini API client is not available.")
                raise HTTPException(status_code=503, detail="Gemini API client is unavailable.")
            requested_folder_abs = os.path.abspath(os.path.join(base_static_path_abs, folder_path_relative))
            if not requested_folder_abs.startswith(base_static_path_abs):
                logger.error(f"Security Alert: Attempted access outside of allowed static sub-directory: {folder_path_relative}")
                raise HTTPException(status_code=400, detail="Access denied: Invalid folder location.")
            if not os.path.isdir(requested_folder_abs):
                logger.error(f"Invalid folder path provided: '{requested_folder_abs}' does not exist or is not a directory.")
                raise HTTPException(status_code=400, detail=f"The folder '{folder_path_relative}' does not exist or is not a directory.")
            results = []
            errors = []
            try:
                all_files_in_dir = os.listdir(requested_folder_abs)
            except Exception as e:
                logger.error(f"Error listing directory {requested_folder_abs}: {e}")
                raise HTTPException(status_code=500, detail=f"Could not read directory contents: {folder_path_relative}")
            image_filenames = [f for f in all_files_in_dir if f.lower().endswith(CAPTIONING_SUPPORTED_EXTENSIONS)]
            total_images_found = len(image_filenames)
            if total_images_found == 0:
                message = f"No images with supported extensions {CAPTIONING_SUPPORTED_EXTENSIONS} found in folder: {folder_path_relative}"
                logger.info(message)
                return CaptionSummaryResponse(
                    total_images_found=0, successfully_captioned=0, results=[], message=message, errors=[]
                )
            logger.info(f"Found {total_images_found} image(s) to process in folder: {requested_folder_abs}")
            for filename in image_filenames:
                current_image_path_full_abs = os.path.join(requested_folder_abs, filename)
                logger.info(f"--- Processing image: {filename} ---")
                mime_type, _ = mimetypes.guess_type(current_image_path_full_abs)
                try:
                    with open(current_image_path_full_abs, "rb") as f:
                        img_bytes = f.read()
                except Exception as e:
                    msg = f"Error loading image '{filename}': {e}. Skipping."
                    logger.error(msg)
                    errors.append(f"{filename}: {msg}")
                    continue
                prompt = """
    You are an expert image captioning AI. Analyze the provided image and generate a concise, descriptive caption that accurately summarizes its content. Return only the caption text, no extra formatting or explanation.
    """
                try:
                    api_key = os.environ.get("GEMINI_API_KEY", "dummy_key")
                    generated_caption = call_gemini_openai(
                        prompt=prompt,
                        api_key=api_key,
                        image_bytes=img_bytes,
                        mime_type=mime_type
                    ).strip()
                    if not generated_caption:
                        raise ValueError("Empty caption returned from Gemini.")
                    # Always output path as 'static/assets/project_{id}/{image_name}' if project_id is provided
                    if project_id is not None:
                        client_accessible_image_path = f"static/assets/project_{project_id}/{filename}"
                    else:
                        client_accessible_image_path = os.path.join(folder_path_relative, filename).replace("\\", "/")
                    results.append(
                        ImageCaptionResponseItem(image_path=client_accessible_image_path, description=generated_caption)
                    )
                    logger.info(f"Generated Caption for '{filename}': {generated_caption}")
                except Exception as e:
                    msg = f"Error during Gemini caption generation for '{filename}': {e}."
                    logger.error(msg, exc_info=True)
                    errors.append(f"{filename}: {msg}")
                    continue
            successfully_captioned_count = len(results)
            if successfully_captioned_count == total_images_found and total_images_found > 0:
                message = f"Successfully generated captions for all {total_images_found} found image(s) in '{folder_path_relative}'."
            elif successfully_captioned_count > 0:
                message = f"Generated captions for {successfully_captioned_count}/{total_images_found} image(s) in '{folder_path_relative}'. See errors."
            elif total_images_found > 0:
                message = f"Attempted {total_images_found} image(s) in '{folder_path_relative}', no captions generated. See errors."
            else:
                message = f"No images found to process in '{folder_path_relative}'."
            logger.info(f"Gemini captioning for folder '{folder_path_relative}' finished. Result: {message}")
            return CaptionSummaryResponse(
                total_images_found=total_images_found,
                successfully_captioned=successfully_captioned_count,
                results=results,
                message=message,
                errors=errors
            )
        except HTTPException as http_exc:
            raise http_exc
        except Exception as e:
            logger.error(f"Error in generate_gemini_captions_for_images_in_folder: {e}")
            raise HTTPException(status_code=500, detail=f"Error in generate_gemini_captions_for_images_in_folder: {e}")

    async def create_captions_for_images_in_folder_endpoint(self, request: ImageCaptionRequest, project_id: Optional[int] = None):
        """
        FastAPI endpoint to process images in a given folder (relative to static root) and generate captions.
        Returns a dictionary with captions that can be used by the analyze_image function.
        """
        try:
            response = await self.generate_gemini_captions_for_images_in_folder(
                folder_path_relative=request.folder_location,
                base_static_path_abs=str(static_dir.resolve()),
                project_id=project_id
            )
            # Convert the Pydantic model to a plain dictionary for better compatibility
            if hasattr(response, 'to_dict') and callable(getattr(response, 'to_dict')):
                return response.to_dict()
            elif hasattr(response, 'dict') and callable(getattr(response, 'dict')):
                return response.dict()
            elif hasattr(response, 'model_dump') and callable(getattr(response, 'model_dump')):
                return response.model_dump()
            else:
                logger.warning(f"Could not convert response to dict. Type: {type(response)}")
                return {"captions": {}}
        except HTTPException as http_exc:
            raise http_exc
        except Exception as e:
            logger.error(f"Error in caption endpoint for folder '{request.folder_location}': {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error in caption endpoint for folder '{request.folder_location}': {str(e)}")