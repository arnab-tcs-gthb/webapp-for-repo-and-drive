from sqlalchemy import Column, String, DateTime, ForeignKey, Text, Boolean, JSON, Integer
import uuid
from datetime import datetime
from app.db.base import Base

class Image(Base):
    __tablename__ = "tbl_images"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    project_id = Column(
        String(36), 
        ForeignKey(
            "tbl_projects.id", 
            name="fk_image_project",  # Explicit constraint naming
            ondelete="CASCADE"
        ),
        nullable=False
    )

    page_id = Column(
        String(36), 
        ForeignKey(
            "tbl_pages.id", 
            name="fk_image_page",  # Explicit constraint naming
            ondelete="CASCADE"
        ),
        nullable=False
    )
    filename = Column(String(255), nullable=False)
    filepath = Column(String(512), nullable=False)
    content_type = Column(String(100), nullable=False)
    upload_date = Column(DateTime, default=datetime.utcnow)
    file_size = Column(Integer)
    width = Column(Integer)
    height = Column(Integer)
    alt_text = Column(String(255))
    llm_processed = Column(Boolean, nullable=False, server_default='0') # need to delete after checking
    llm_response = Column(Text) # need to delete after checking
    matched_images = Column(JSON)