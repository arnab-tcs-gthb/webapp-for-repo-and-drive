from sqlalchemy import Column, String, Text, DateTime, ForeignKey, JSON
import uuid
from datetime import datetime
from app.db.base import Base

class PageUAT(Base):
    __tablename__ = "tbl_page_uat"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    project_id = Column(String(36), ForeignKey("tbl_projects.id"), nullable=False)
    page_id = Column(String(36), ForeignKey("tbl_pages.id"), nullable=False)
    # comment = Column(Text, nullable=True)
    jira = Column(String(255), nullable=True)
    # status = Column(String(50), default='pending')  # e.g., pending, approved, rejected
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
